# -*- coding: utf-8 -*-
"""Anleitung im Fiberation-CI: Schnellstart, Ablauf je Werkzeug, Layer und Farben, Begriffe. Aufruf mit Anker aus den Dialogen."""
from qgis.PyQt.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QTextBrowser, QVBoxLayout
from qgis.PyQt.QtCore import QTimer, Qt, pyqtSignal
from qgis.PyQt.QtWidgets import QWidget

from . import ci
from .plugin import NAME, version

ANLEITUNG = """
<style>
h2 {{ margin-bottom:2px; }}
h3 {{ color:{orange}; margin-top:22px; }}
h4 {{ margin-bottom:2px; margin-top:14px; }}
td, th {{ padding:3px 8px; vertical-align:top; }}
th {{ background:{orange}; color:#1A1A1A; text-align:left; }}
.grau {{ color:{grau}; }}
.kasten {{ background:#FDF0DC; padding:8px 12px; border-left:4px solid {orange}; }}
</style>

<h2>Fiberation Werkzeugkasten</h2>
<p class="grau">Planer-Werkzeuge fuer Plan[Goo] V2. Ein Werkzeug je Planungsschritt, jedes per Knopf, jedes mit klarem Eingang und klarer
Ausgabe. Zwischen den Werkzeugen entscheidet der Planer. Telekom-Dateien werden nicht geaendert.</p>
<p class="grau">Layer im QGIS-Projekt: jede Gruppe und jeder Layer eines Schritts traegt vorn die Schrittnummer (0 Grundkarten, 1 Bestand, 2 Adressen ...); die Gruppen
ordnen sich im Layerbaum nach Nummer, unten 0, darueber 1, 2, ... - spaetere Schritte zeichnen ueber frueheren. Legt ein Schritt eine neue Gruppe an, klappen alle anderen nummerierten Gruppen zu und ihre
Beschriftungen gehen aus (Markus 12.10.: keine Ueberlagerungen in der Karte; Beschriftung bei Bedarf im Layer wieder einschalten). Eigene Layer und Plan[Goo]-Layer bleiben, wo sie sind.</p>
<p class="grau">Tabellen (Markus 12.10.): alle Tabellen im Werkzeugkasten koennen dasselbe wie die QGIS-Attributtabelle. Klick auf den Spaltenkopf sortiert
(Zahlen als Zahlen, Namen natuerlich: 1V2 vor 1V10), Spaltenrand ziehen aendert die Breite (Doppelklick: an den Inhalt), Spalten lassen sich am Kopf
umsortieren und ueber <b>Spalten</b> (oder Rechtsklick auf den Kopf) ein- und ausblenden. Jede Zelle zeigt beim Zeigen den vollen Inhalt. Das Suchfeld
filtert ueber alle sichtbaren Spalten, <b>Nur Auswahl</b> zeigt nur markierte Zeilen. Mehrere Zeilen mit Strg und Umschalt; die Auswahl laeuft
synchron mit der Karte in beide Richtungen. <b>Hinzoomen</b> und <b>Blinken</b> gelten fuer die markierten Zeilen, <b>Kopieren</b> (Strg+C) legt
Kopfzeile und Zeilen Tabulator-getrennt in die Zwischenablage (direkt in Excel einfuegbar). Der Zaehler sagt "12 von 340 ausgewaehlt". Breiten,
Reihenfolge, ausgeblendete Spalten und Sortierung merkt sich jede Tabelle; <i>Reihenfolge und Sortierung zuruecksetzen</i> im Spalten-Menue
stellt den Anfang wieder her.</p>
<p class="grau">Standdatei (Markus 12.10.): jeder Schritt traegt sein Ergebnis in <code>werkzeugkasten_stand.json</code> neben den Ergebnisdateien ein. Schritt 10
fuellt daraus alle Felder, sobald eine Datei des Gebiets gewaehlt ist. Lange Laeufe (ALKIS, OSM, Standorte) laufen in einem eigenen Prozess:
QGIS bleibt bedienbar, <b>Abbrechen</b> beendet den Lauf sofort, das Protokoll laeuft mit. Updates: Erweiterungen > Einstellungen > Repositorys >
<code>https://raw.githubusercontent.com/Fiberation-Labs/werkzeugkasten-release/main/plugins.xml</code> eintragen - danach meldet QGIS neue Versionen selbst.</p>
<p class="grau">Alles in einem Fenster: die Uebersicht zeigt den Ablauf als Schrittliste mit dem juengsten Ergebnis je Schritt. Ein Schritt oeffnet
als Seite im selben Fenster; oben fuehren <b>Uebersicht</b>, die Schrittnummern und die Pfeile vor und zurueck. Geoeffnete Seiten behalten Eingaben,
Ergebnis und Protokoll, bis das Fenster geschlossen wird. Escape auf einer Seite fuehrt zur Uebersicht. <b>An QGIS andocken</b> (Fusszeile)
haengt den Werkzeugkasten als Panel rechts an das QGIS-Fenster - verschiebbar und stapelbar wie das Layer-Panel, per Doppelklick auf die
Titelleiste schwebend; <b>Als Fenster loesen</b> macht wieder ein eigenes Fenster daraus. Die Wahl wird gemerkt.</p>

<p><a href="#schnell">Schnellstart</a> &nbsp;|&nbsp; <a href="#umfeld">0 Umfeld und Grundkarten</a> &nbsp;|&nbsp; <a href="#bestand">1 Bestand</a> &nbsp;|&nbsp; <a href="#w1">2 Adressen und Bedarf</a>
&nbsp;|&nbsp; <a href="#w2">3 NVT-Gebiete</a> &nbsp;|&nbsp; <a href="#w3">4 NVT-Standorte</a> &nbsp;|&nbsp; <a href="#trassen">5 Trassen je NVT</a> &nbsp;|&nbsp; <a href="#hk">6 Hk clustern</a> &nbsp;|&nbsp; <a href="#hktrasse">7 Hk-Trasse</a>
&nbsp;|&nbsp; <a href="#kollo">8 Kollokation</a> &nbsp;|&nbsp; <a href="#wesi">9 Wegesicherung</a> &nbsp;|&nbsp; <a href="#w4">10 Uebergabe nach Plan[Goo]</a> &nbsp;|&nbsp; <a href="#zfp">11 ZFP222</a>
&nbsp;|&nbsp; <a href="#layer">Layer und Farben</a> &nbsp;|&nbsp; <a href="#begriffe">Begriffe</a> &nbsp;|&nbsp; <a href="#helfer">Helfer und Einstellungen</a>
&nbsp;|&nbsp; <a href="#fragen">Wenn etwas nicht klappt</a></p>

<a name="schnell"></a>
<h3>Schnellstart: von der Bedarfsliste zum NVT-Schnitt in 10 Minuten</h3>
<ol>
<li><b>Werkzeug 2 oeffnen</b>, die Telekom-Bedarfsliste (CSV) in den Dialog ziehen, <b>Pruefen</b>. Etwa 30 Sekunden.
    Es entsteht neben der Liste <code>adresspruefung_&lt;Name&gt;_&lt;Datum&gt;.gpkg</code> und eine Layergruppe mit Ampel.</li>
<li>Im Layer <b>Adressen</b> die roten und gelben Faelle ansehen. Was nicht mitgeschnitten werden soll, bekommt in der Spalte
    <i>status</i> den Wert <code>ignorieren</code>. Layer speichern.</li>
<li><b>Werkzeug 3 oeffnen</b>, die Adresspruefung hineinziehen, Netzquelle waehlen (Plan[Goo]-Trassen, wenn ein Projekt offen ist,
    sonst OSM), Regelsatz pruefen, <b>Schneiden</b>. Plan[Goo]-Trassen: 2 bis 3 Minuten. OSM: unter einer Minute, beim ersten Mal
    plus Abruf.</li>
<li>Ergebnis ansehen: jedes Gebiet in eigener Farbe, Label mit den Kennzahlen "Ist von Grenze". Layer <b>Ampel (Grenzen)</b>
    einschalten, um Grenzverletzungen zu sehen.</li>
<li>Gebiete anpassen: im Layer <b>Adressen</b> die Spalte <i>nvt</i> aendern, speichern, <b>Nachrechnen</b>. Sekunden.</li>
<li>Wenn der Schnitt steht: <b>Werkzeug 4</b> prueft die NVT-Standorte, <b>Werkzeug 10</b> schreibt Gebiete, NVT und Adresszuordnung
    nach Plan[Goo] ("Uebergabe nach Plan[Goo]"). <b>Werkzeug 9</b> findet fuer die Wegesicherung Gewaesserquerungen und Landesstrassen-Flurstuecke.</li>
</ol>

<a name="umfeld"></a>
<h3>0. Umfeld und Grundkarten laden</h3>
<p><b>Zweck:</b> Vorhandene Infrastruktur und Grundkarten mit einem Knopf in das offene Projekt, auch in ein frisch angelegtes, leeres
Plan[Goo]-Projekt. Alles in <b>EPSG:3857</b>, dem Koordinatensystem, in dem Plan[Goo] seine Geometrien speichert; auf Wunsch wird auch das
Projekt-KBS darauf gesetzt.</p>
<p><b>Umgriff und Land:</b> Geladen wird der Kartenausschnitt - vorher hinzoomen. Das Land wird daraus erkannt, sonst waehlen.
Dienste, die es fuer das Land nicht gibt, sind ausgegraut. Der Umgriff zaehlt nur fuer OSM; WMS sind unabhaengig vom Ausschnitt.
Fuer OSM gilt eine Obergrenze von 400 km2 - bei groesseren Ausschnitten heranzoomen.</p>
<table>
<tr><th>Gruppe (Layerbaum, von unten)</th><th>Inhalt</th><th>Quelle</th></tr>
<tr><td><b>Grundkarten</b> (ganz unten)</td><td>basemap.de farbig, Orthofoto (ausgeblendet geladen), ALKIS Flurstuecke und Gebaeude, topographische Karte des Landes (P10 / DTK 25)</td>
    <td>Katalog des Plugins GeoBasis Loader, wenn installiert (dort gepflegt), sonst eingebaute Tabelle. NW, SL, BW, NI, HE, RP.</td></tr>
<tr><td><b>Umfeld amtlich</b></td><td>Schutzgebiete bundesweit (BfN: NSG, LSG, FFH, Vogelschutz, Nationalpark, Naturpark, Biosphaere); fuer NRW zusaetzlich
    LINFOS (Schutzgebiete, geschuetzte Biotope, Alleenkataster), Wasserschutzgebiete (Trinkwasser fest/geplant, Heilquellen),
    Gewaesserstationierung (Fliessgewaesser, Gewaesserflaechen, Kanaele), ALKIS Gewaesser; Bundeswasserstrassen (WSV)</td>
    <td>WMS von BfN, LANUV NRW, WSV. Identifizieren-Werkzeug liefert die Sachdaten (Name, Kennung, Zone).</td></tr>
<tr><td><b>Strassen und Verkehr</b> (in der Gruppe Umfeld amtlich, nur NRW)</td><td>Klassifizierte Strassen (Autobahn blau, Bundesstrasse blau, Landesstrasse gruen,
    Kreisstrasse braun) mit Strassenbezeichnung; <b>Ortsdurchfahrten</b> gelb (innerhalb: Kommune zustaendig, ausserhalb: freie Strecke = Strassen.NRW,
    RPS-Abstaende, § 127 TKG); auf Wunsch Bauwerke und Durchlaesse, Verkehrsmenge DTV Kfz 2021 (ZTV 21: keine oberirdische Bauweise an stark
    befahrenen Strassen ausserorts), Zustaendigkeit und Strassenmeisterei</td>
    <td>NWSIB-online, Strasseninformationsbank des Landesbetriebs Strassenbau NRW (WMS 1.1.1, EPSG:3857). Identifizieren liefert Strassennummer,
    Abschnitt und Stadium. Die OD-Grenzen hier sind die amtlichen, Werkzeug 9 rechnet noch mit der ATKIS-Ortslage als Naeherung.</td></tr>
<tr><td><b>Umfeld OSM &lt;Datum&gt;</b></td><td>Baeume und Baumreihen, Gewaesser, Schutzgebiete, Wald und Gruen, Bahnanlagen, Freileitungen und Masten, Bruecken und Durchlaesse</td>
    <td>OpenStreetMap ueber Overpass, eine Sammelabfrage fuer alle Themen im Hintergrund (QGIS bleibt bedienbar, Knopf Abbrechen;
    Witten 2x2 km: 15 s). Ergebnis als <code>umfeld_osm_&lt;Datum&gt;.gpkg</code> im Ordner <i>umfeld</i>
    neben dem Plan[Goo]-Projekt (sonst C:\\Users\\...\\PlanGoo\\umfeld). Spalten: osm_id, typ, name, die wichtigsten Tags einzeln, alle Tags als JSON.</td></tr>
</table>
<p><b>Farben OSM:</b> Baeume gruene Punkte, Baumreihen gruen gestrichelt; Gewaesser blau; Schutzgebiete gruen schraffiert; Wald/Gruen hellgruen;
Bahn schwarz gestrichelt; Freileitungen violett, Masten violette Dreiecke; Bruecken orange, Durchlaesse braun gestrichelt.</p>
<p><b>Grenzen:</b> OSM-Strassenbaeume sind lueckenhaft und OSM-Schutzgebietsgrenzen nicht rechtsverbindlich - fuer die Vorpruefung; fuer
Antraege zaehlen BfN, LINFOS und die Wasserbehoerde. Baumkataster gibt es nur kommunal (Open Data), nicht landesweit. Fuer Saarland und
Baden-Wuerttemberg fehlen Landes-Umweltdienste im Katalog, dort gilt BfN bundesweit.</p>
<p><b>Ein zweiter Lauf</b> ersetzt die drei Gruppen; die Haken werden gemerkt. "Vorhandenes OSM-GeoPackage laden" holt ein frueheres Ergebnis
zurueck (auch per Drag &amp; Drop auf den Dialog).</p>

<a name="bestand"></a>
<h3>1. Bestand aus Telekom-Lieferung</h3>
<p><b>Zweck:</b> Alles, was der Telekom-Export als Bestand kennzeichnet, sichtbar und nutzbar machen - vor der Hauptkabel-Planung und als
Kontrolle fuer die Trassen aus Schritt 5 - deshalb steht der Bestand gleich nach den Grundkarten.</p>
<p><b>Eingang:</b> das GeoPackage <i>Nur Export Extern</i> des Plan[Goo]-FPF-Importers (<code>&lt;Workspace&gt;_extern.gpkg</code>, liegt im
Telekom-Paket neben dem Plan[Goo]-Projekt). Es enthaelt die Comsof-Layer in EPSG:25832. Bestand steckt darin in mehreren Layern:</p>
<ul>
<li><b>Bestandsrohre</b>: "Verwendbare Trassen" mit TYPE <code>EXISTINGPIPE</code>. Rohrklasse (KKR 110, KKR 110 mit Innenrohr, Kabelkanalformstein,
    Mikrorohr 35/25, Speednet-Rohr 8 mm), <i>freie Rohre</i> (MAX_DUCTS: so viele Rohre lassen sich noch einziehen, leer = unbekannt),
    <i>nur Kabel einblasen</i> (Speednet-Rohr: kein weiteres Rohr), Innendurchmesser, Megaplan-ID, Strassentyp, Hinweise Baumkrone/Natur-/Wasserschutz.</li>
<li><b>Bestandskabel</b>: TYPE <code>EXISTINGCABLE</code> mit Kabellinie (z. B. 5R/3), Kabeltyp und <i>freien Fasern</i>.</li>
<li><b>Bestandspunkte</b>: "Strukturpunkte/Ausruestungen" mit EXISTING = wahr: Zugschaechte, begehbare Schaechte, Masten, KVz/NVt Bestand, HVt.
    Dazu Bestandsmuffen und die vorhandenen Hauptkabel, die der Comsof-Plan weiterbenutzt.</li>
<li><b>genutzt</b>: liegt das Stueck auch in den "Verwendeten Trassen" (Comsof-Ergebnis), nutzt der Plan es schon - im Label "im Plan".</li>
</ul>
<p><b>Ablauf:</b> Export hineinziehen oder waehlen, Haken fuer Kabel, Punkte und Anschlussstuecke setzen, <b>Bestand aufbereiten</b> (Witten Heven:
22.000 Rohrstuecke in 8 s). Es entstehen <code>bestand_&lt;Workspace&gt;_&lt;Datum&gt;.gpkg</code>, Bericht und Liste; die Layer kommen als Gruppe
<i>1 Bestand</i> ins Projekt. Rohre gruen = Rohr einziehbar, blau = nur Kabel einblasen, grau gestrichelt = Kapazitaet unbekannt, dunkelrot = voll.
Die Tabelle zeigt Kennzahlen je Rohrklasse, Nutzbarkeit, Kabellinie und Punkttyp; <b>Doppelklick</b> auf eine Zeile waehlt die Stuecke im Kartenfenster
und zoomt darauf. Die Zeile <i>Rohrnetz</i> im Ueberblick sagt, in wie viele zusammenhaengende Teile das Bestandsrohrnetz zerfaellt - viele kleine
Inseln sind meist Exportgrenzen, keine echten Luecken.</p>
<p><b>Zweite Quelle: Plan[Goo]-Projekt.</b> Liegt kein Extern-Export vor, aber ein Plan[Goo]-Projekt mit Bestand aus dem Megaplan-As-built-Import
(Barntrup: <code>PlGoV2_05766012_0001_..._.gpkg</code> mit gleichnamiger <code>.db</code> daneben), waehlt man <i>offenes Plan[Goo]-Projekt</i> oder die
GeoPackage-Datei. Bestand ist dort alles mit dem Kennzeichen <i>extern</i>: Bestandstrassen mit den Bestandsrohren darauf (KKR 110, Speednet-Rohr
unbekannter Belegung), dieselben Rohre als <i>Rohrzuege</i> (eine Linie je Rohr mit Megaplan-ID), Kabelschaechte, Kabel-Uebergabegestelle und die
Rohrenden. <i>genutzt</i> heisst hier: ein neues Rohr liegt auf der Bestandstrasse oder als Innenrohr im Bestandsrohr, an den Punkt ist ein neues Rohr
angeschlossen. Freie Rohre und Kabel kennt Plan[Goo] nicht; die Nutzbarkeit kommt aus dem Materialkatalog des Plan[Goo]-Plugins.</p>
<p><b>Bestand ist:</b> <i>nur Objekte mit Bestandskennzeichen</i> (Vorgabe) oder <i>das ganze Projekt</i>. Letzteres fuer ein bereits gebautes Netz,
das als Plan[Goo]-Projekt vorliegt (Mannheim-Rheinau: 42 NVT, 6.583 Trassen, 4.168 Rohre, 2.015 versorgte APL) - Plan[Goo] kennzeichnet so ein
Netz nicht als Bestand, im Label steht ueberall "(Neu)". Dann gelten alle Trassen, die Hauptrohre (ohne Innenrohre), NVT, Schaechte, Muffen,
Kabel-Uebergabegestelle und Hausuebergabepunkte als Bestand; die versorgten APL (Ausbauzustand passed+) kommen als eigener Layer dazu.
Das Megaplan-Kennzeichen bleibt in den Spalten trasse_markiert, rohr_markiert und punkt_markiert sichtbar.</p>
<p><b>Dritte und vierte Quelle: was die Telekom direkt liefern kann.</b> Ohne Plan[Goo]-Paket kommen vom PTI zwei Dateien, die das Werkzeug
an den Feldern erkennt (Datei hineinziehen genuegt):</p>
<ul>
<li><b>MegaPlan-Export "Rohranlage"</b> (GeoPackage, ein Layer mit UNDERGROUND_ROUTE_TYPE / INSTALLATION_TYPE): das <i>Trassennetz</i> der Telekom mit
    Verlegeart, nicht die Rohre. Layer <i>Telekom-Trassen</i>: gruen = Rohrtrasse (Rohrverlegt, da liegt mindestens ein Rohr), dunkelrot = erdverlegtes
    Kabel (Kabel direkt im Boden, <b>kein Rohr, nichts einziehbar</b>), grau gepunktet = Hauseinfuehrung, blau = Spuelbohrung/Bodenverdraengung.
    Dazu Verlegetiefe (aus PLACE_DEPTH_HEIGHT, -60 = 60 cm, Annahme) und die MegaPlan-Rohwerte (mp_*). Barntrup: 22.619 Stuecke, 305 km, davon
    Rohrtrassen 86 km, erdverlegt 208 km, Hauseinfuehrungen 10 km; 1 s. Keine Rohrklasse, keine freien Rohre, keine Schaechte, keine Kabel.</li>
<li><b>Comsof-Rohrliste "IN_ExistingPipes"</b> (Shapefile, auch als Zip): die <i>Rohre</i> mit Rohrklasse, freien Rohren (MAX_DUCTS), Innendurchmesser und
    Megaplan-ID - dieselben Felder wie EXISTINGPIPE im Extern-Export, aber ohne Nutzung im Plan, ohne Knoten und ohne Punkte (STRUCT_IDS nennt nur
    IDs). Mehrere Rohre liegen auf derselben Linie (<i>rohre_auf_trasse</i>, Barntrup bis 26 Speednet-Rohre); die Tabelle zeigt sie als Buendel.
    Barntrup: 1.058 Rohre, 231 km auf 531 Linien; 2 s.</li>
</ul>
<p><b>Welche ist besser?</b> Beide zusammen. Die Rohrliste sagt, <i>was</i> im Boden liegt und ob etwas einziehbar ist - das braucht Schritt 6
(Bestand uebernehmen). Der MegaPlan-Export sagt, <i>wo ueberall</i> Telekom liegt: in Barntrup lagen alle Rohre der Rohrliste auf MegaPlan-Trassen, aber
nur 52 von 305 km Trassen tragen ein Rohr aus der Liste; 208 km sind erdverlegte Kabel ohne Rohr, und <b>39 km Rohrtrassen haben kein Rohr in der
Rohrliste</b>. Deshalb: MegaPlan-Export als Quelle waehlen und die Rohrliste unter <i>Rohrliste dazu</i> angeben. Dann werden beide Layer geschrieben,
Rohrtrassen bekommen <i>Rohr in Rohrliste</i> ja/nein (orange = MegaPlan sagt Rohr, Comsof kennt keins - vor dem Einplanen beim PTI klaeren) und jedes
Rohr seine MegaPlan-Trasse (<i>mp_trasse</i>). Barntrup mit Abgleich: 20 s.</p>
<p><b>Grenzen:</b> Enthalten ist nur, was der PTI in den Comsof-Arbeitsbereich exportiert hat bzw. ueber den As-built-Import ins Projekt kam. Die Klartexte der Rohrklassen sind aus Code und
Durchmesser abgeleitet (Code steht in <i>rohrklasse_code</i>). Nichts wird nach Plan[Goo] geschrieben - Bestandsrohre als Plan[Goo]-Objekte
kommen ueber den Megaplan-As-built-Import oder spaeter Schritt 10. DXF der Netzdokumentation folgt als weiterer Eingang.</p>

<a name="w1"></a>
<h3>2. Adressen und Bedarf pruefen</h3>
<h4>Wozu</h4>
<p>Die Bedarfsliste der Telekom ist der Eingang jeder Planung. Das Werkzeug prueft jede Adresse, bevor gerechnet wird, und bestimmt den
Bedarf nach ZTV 21. Fehler, die hier durchrutschen, kosten spaeter in jedem Werkzeug.</p>
<h4>Ablauf</h4>
<p>Die Dialoge 1, 2 und 4 sind gleich aufgebaut (17.09.): Kopf mit Titel, ein Block Einstellungen, eine Zeile Knoepfe, darunter die Arbeitstabelle. Das Protokoll ist eingeklappt (Knopf <b>Protokoll</b>) und klappt bei Fehlern von selbst auf; Erklaerungen stehen als Tooltip auf den Knoepfen. Comsof- und Plan[Goo]-Eingaben sind aus den Dialogen raus, weil sie nicht gebraucht wurden.</p>
<ol>
<li>Quelle: Telekom-Bedarfsliste (CSV, Semikolon) hineinziehen oder waehlen. Bei MBfD-Projekten kann statt der Bedarfsliste der <b>Angebotslayer</b> kommen: die Plan[Goo]-Projektdatei (.gpkg, am besten mit der gleichnamigen .db daneben), mit der die Telekom den Zuschlag bekommen hat. An ihn halten wir uns, die Adressen werden trotzdem auf Plausibilitaet geprueft. Im Angebotslayer liegt der APL an der Hauswand (die Telekom rechnet im Angebot keine Inhouse-Trasse); bis 1,5 m neben dem Gebaeude gilt er deshalb als im Gebaeude. <b>MBfD</b> (Angebotslayer oder Ausbautreiber MBfD, auch bei einer CSV): die Adressliste steht fest. Es kommen keine Bauluecken und fehlenden Adressen dazu (die Suche danach entfaellt, Aufnehmen ist gesperrt). Die Adressen muessen nur gueltig sein: gelb wird eine Adresse nur, wenn es sie in ALKIS nicht gibt (Strasse oder Hausnummer unbekannt), die amtliche Adresse mehr als 50 m entfernt liegt, sie doppelt ist oder 0 WE hat. Lage und Nutzung stehen nur als Hinweis da; Spalte <i>alkis_adresse</i> zeigt das Ergebnis. Wird eine Lage verschoben, steht das in der Spalte <i>abweichung_angebot</i> und im Excel-Export "anders verortet". Gelesen werden die APL mit Adresse, KLS-ID, WE (HH), GE (USTO), Gebaeudenutzung und bisherigem NVT; der Ausbautreiber kommt aus der .db. Die Telekom-Kenner (adress_qualitaet_kenner, Bewertung) fehlen dann, die Ampel stuetzt sich nur auf ALKIS.
<b>Bedarf bei MBfD</b> (ZTV 21 Kap. 13, seit 30.09.2026): 4 Fasern je WE + 2 je Gebaeude (Spalte <i>fasern_bedarf</i>), Hauszufuehrung als
Mikrokabel 6/12/24/36 Fs bis 8 WE, Minikabel 48/72/96 Fs bis 68 WE, darueber OneBox wie Eigenausbau plus 3 Kollo-SNR ins Haus (Spalten
<i>kabel_haus</i>, <i>snr_kollo</i>); kein pauschaler Zusatzbedarf (100 % Anschaltung). Adressen mit 0 WE (Bauluecken im Angebot) bekommen
die mittlere WE-Zahl der Nachbarn (gleiche Strasse im Umkreis 150 m, sonst die naechsten 5) - Spalte <i>we_quelle</i> = umgebung, die
gelieferte WE bleibt in <i>we</i> stehen und geht unveraendert nach Plan[Goo]. Schulen (BF), Krankenhaeuser (BF), oeffentliche Gebaeude und
Gewerbeobjekte haben eigene Mindestwerte, der Planer fragt nach.</li>
<li>Haken <i>ALKIS-Gebaeude abrufen</i> lassen. Das Bundesland wird aus den Koordinaten erkannt, sonst waehlen.</li>
<li><b>Pruefen</b>. Fortschrittsbalken zeigt: Laden, ALKIS-Abruf je Kachel, Pruefen, Bedarf, Schreiben. Am Ende ein Fenster mit Zahlen.</li>
<li>Layer <b>Adressen</b> durchsehen. Rot zuerst, dann gelb. Spalte <i>hinweise</i> nennt den Grund. Ab 1:3000 steht an jedem
    Punkt die Adresse als Label, darunter der Hinweis (in Werkzeug 3 ebenso die Adresse).</li>
<li><b>Pruefliste</b> unten im Dialog: zeigt nur die gelben und roten Adressen (Filter: offen, nur rot, nur gelb, mit Vorschlag). Je Adresse
    steht ein <b>Lagevorschlag</b>, aber nur bei einem Lageproblem (keine Koordinate, Punkt neben oder ohne Gebaeude, Platzhalter-Nummer,
    Sammelpunkt). Kenner ohne A, Telekom-Bewertung, leere Gebaeudefunktion oder Nutzung sind Attributfragen: die Lage stimmt, kein Vorschlag
    (Markus 17.09.). Vorschlag: das naechste ALKIS-Gebaeude ohne Adresse in 40 m, sonst die Mitte zwischen den Nachbarn derselben Strasse und
    Strassenseite (Nr. -2/-4 und +2/+4, bei gemischter Nummerierung -1/-2 und +1/+2; auch fuer Adressen ohne Koordinate), auf ein freies
    Gebaeude in 25 m gezogen. In der Karte: oranger Punkt
    mit Callout-Label und gestrichelte Linie von der alten Lage. Zeile anwaehlen zoomt hin und laesst den Punkt rot blinken (Haken
    <b>automatisch</b>; sonst Doppelklick, <b>Hinzoomen</b> oder <b>Aufblinken</b> ohne Ausschnittwechsel). Spaltenbreiten am Tabellenkopf
    ziehen. Knoepfe: <b>Vorschlag uebernehmen</b> (Lage
    setzen, status geprueft, alte Lage im Kommentar), <b>Lage stimmt - geprueft</b>, <b>Ignorieren</b>, <b>Wieder offen</b>. Mehrere Zeilen mit
    Strg/Umschalt. Jede Aktion schreibt in das GeoPackage und laedt die Layer neu. <b>Vorhandenes Ergebnis laden</b> holt mit einem Klick die
    juengste Pruefung zurueck (Pfeil daneben: aeltere Laeufe oder andere Datei) und rechnet die Vorschlaege nach.</li>
<li>Von Hand geht es weiter: <i>status</i> auf <code>geprueft</code> oder <code>ignorieren</code>, <i>kommentar</i> nach Bedarf. Speichern.</li>
<li>Nach Plan[Goo] geht es erst in <b>Schritt 10</b>: Adressen als APL, inklusive der aus der Pruefliste aufgenommenen Bauluecken und fehlenden Gebaeude (Begruendung wird gesetzt).</li>
</ol>
<h4>Was geprueft wird</h4>
<table>
<tr><th>Pruefung</th><th>Ergebnis</th></tr>
<tr><td>Telekom-Qualitaetskenner (Spalte adress_qualitaet_kenner)</td><td>Buchstabe A = amtliche Adresse mit Gebaeude. Ohne A gelb.</td></tr>
<tr><td>Dubletten</td><td>Gleiche Adresse oder gleiche KLS-ID mehrfach: rot.</td></tr>
<tr><td>Koordinate gegen ALKIS-Gebaeude</td><td>Im Gebaeude: gruen. Bis 12 m daneben: gelb mit Abstand. Kein Gebaeude in 25 m: rot oder gelb.</td></tr>
<tr><td>Gleiche Koordinate fuer mehrere Adressen</td><td>Hof oder Sammelpunkt: gelb, pruefen.</td></tr>
<tr><td>Adressen ohne Gebaeude</td><td>Platzhalter-Hausnummer (999) oder kein ALKIS-Gebaeude in 25 m: eigener Layer (Spalte bauluecke).</td></tr>
<tr><td><b>Fehlender Bedarf</b></td><td>ALKIS-Gebaeude mit amtlicher Adresse (Lagebezeichnung), die nicht in der Bedarfsliste steht und in dem kein
    Listenpunkt liegt, naechste Listenadresse hoechstens 60 m (Beispiel Wannen 102, Markus 17.09.). Strassennamen werden angeglichen
    (Str. = Strasse). Prioritaet <b>hoch</b> = Luecke in der Nummernfolge (Nachbarn derselben Strassenseite stehen in der Liste),
    <b>mittel</b> = Strasse in der Liste, Nummer im Bereich, Nachbarn fehlen auch (ganze Strassenseite: anderes Gebiet oder vergessen),
    <b>niedrig</b> = am Rand. Eigener Layer mit Callout, Abschnitt im Bericht; status/kommentar gehoeren dem Planer, erledigte
    verschwinden aus der Karte.</td></tr>
<tr><td><b>Bauluecke moeglich</b></td><td>ALKIS-Flurstueck (zweiter WFS-Abruf) mit Nutzung Wohnbau oder gemischt, 250 bis 3000 m2, ohne Wohn- oder
    Gewerbegebaeude (Garage/Schuppen erlaubt, vermerkt), ohne Listenadresse, mit gemeinsamer Grenze zu mindestens einem Flurstueck mit
    Listenadresse (Markus 17.09., Weg 2 + 3). <b>hoch</b> = zwischen bebauten Nachbarn derselben Strasse, <b>mittel</b> = ein bebauter Nachbar
    (Eck- oder Randgrundstueck). Hausnummer-Vorschlag aus der ALKIS-Lagebezeichnung (reservierte Nummer) oder aus der Luecke zwischen den
    Nachbarnummern. Eigener Layer mit Callout, Abschnitt im Bericht.</td></tr>
<tr><td>Gebaeude ohne Adresse</td><td>ALKIS-Gebaeude ohne Lagebezeichnung und ohne Listenadresse in 12 m (Nebengebaeude, Neubau): eigener Layer,
    ausgeblendet, Prioritaet hoch bei Wohngebaeuden.</td></tr>
<tr><td>Kandidaten in der Pruefliste</td><td>Bauluecken und fehlender Bedarf stehen <b>rot</b> in der Pruefliste ('Bauluecke: Strasse [Flurstueck]',
    'Fehlt: Adresse'; Filter "nur Bauluecken und fehlender Bedarf"). Entscheidung des Planers: <b>In Adressen aufnehmen</b> (bei einer Zeile fragt
    das Werkzeug Hausnummer und WE ab, sonst Vorschlag bzw. 1 WE) oder <b>Ignorieren</b>. Aufnehmen legt im Layer <i>Adressen</i> eine neue Zeile
    mit allem an, was Plan[Goo] fuer den APL braucht: Strasse, Hausnummer, PLZ/Ort/Ortsteil, ONKZ/ASB, Gebietstyp und Sponsor vom naechsten
    Listenpunkt, WE, Gebaeudenutzung, Bedarf nach ZTV 21, Kennzeichen bauluecke (-> Begruendung "Bauluecke") bzw. quelle alkis (-> "vorhandenes
    Gebaeude im Ausbaugebiet"). Die Zeile ist gelb und geprueft, der Kandidat bekommt status aufgenommen und verschwindet aus der Karte.
    Nach Plan[Goo] geht das alles erst in <b>Schritt 10</b> (Teil 1 des Import-Assistenten, Adressen als APL).</td></tr>
</table>
<h4>Bedarf nach ZTV 21</h4>
<table>
<tr><th>Regel</th><th>Kapitel</th></tr>
<tr><td>WE + Gewerbeeinheiten; kleine Gewerbe in Wohnobjekten je +1 WE</td><td>8.5.1.1</td></tr>
<tr><td>Pauschaler Zusatzbedarf: 1-3 WE keiner, 4-8 WE +1, ab 9 WE +2</td><td>8.5.1.2</td></tr>
<tr><td>Oeffentliche Gebaeude: min. 12 Fasern, 9 Anschluesse + 4 Direktfasern; Hauptverwaltung 24 Fasern</td><td>8.5.1.3</td></tr>
<tr><td>Schulen (Schueler), Krankenhaeuser (Betten): Planer fragt nach</td><td>8.5.1.3</td></tr>
<tr><td>Technische Einrichtungen: 1 SNR, Anschluss nur bei Bedarf</td><td>8.5.1.7</td></tr>
<tr><td>Gewerbegebiet: min. 12 Fasern, 4 Anschluesse + 4 Direktfasern je Objekt</td><td>8.8.2</td></tr>
<tr><td>SNR: 1 je Adresse, +1 bei Gewerbe, Schule, Krankenhaus, oeff. Gebaeude</td><td>Fiberation-Regelsatz</td></tr>
</table>

<p><b>Filter "aufgenommene Bauluecken und fehlender Bedarf"</b> zeigt die Adressen, die der Planer aus der Pruefliste uebernommen hat (Quelle
Bauluecke oder ALKIS-Gebaeude), <b>"anders verortete Adressen"</b> die, deren Lage vom Vorschlag uebernommen wurde (alte Lage und Verschiebung in Metern
stehen in den Spalten lage_alt_x/y, lage_verschoben_m). <b>Nach Excel</b> schreibt die Zeilen des gewaehlten Filters als .xlsx neben das Ergebnis und
oeffnet sie - fuer die Rueckmeldung an die Telekom (Markus 22.09.2026).</p>

<a name="w2"></a>
<h3>3. NVT-Gebiete bilden</h3>
<h4>Wozu</h4>
<p>Adressen zu NVT-Gebieten schneiden, so dass jedes Gebiet die Grenzen des Ausbautreibers einhaelt und die Vzk-Wege kurz bleiben.
Das Ergebnis ist ein Vorschlag, den der Planer verschiebt und nachrechnen laesst.</p>
<h4>Ablauf</h4>
<ol>
<li>Adressen: die Adresspruefung aus Werkzeug 2 (empfohlen), die Bedarfsliste direkt oder die APL des Projekts. Das Feld ist mit dem
    juengsten Ergebnis von Werkzeug 2 vorbelegt; aufklappen zeigt die letzten Dateien (zuletzt benutzt, im QGIS-Projekt geladen, im
    Projektordner gefunden). <i>Waehlen</i> startet im zuletzt benutzten Ordner.</li>
<li>Netz: OSM-Strassen (Overpass). Die Gebiete wachsen entlang der Strassen; Zwangsgrenzen und Vorgabe-Gebiete des Planers gelten hart.</li>
<li>Regelsatz: automatisch nach Ausbautreiber oder waehlen. Die Grenzen darunter sind aenderbar.</li>
<li><b>Zwangsgrenzen</b> (optional): Klick auf das Feld oeffnet ein Fenster mit allen Linien- und Flaechenlayern des QGIS-Projekts zum
    Anhaken - mehrere zugleich (z. B. selbst gezeichnete Grenze, Bahnlinie, Ortsteilgrenze; Markus 12.10.). Trassen, die einen angehakten
    Layer schneiden, werden beim Wachsen nicht ueberschritten. Ist in einem Layer etwas ausgewaehlt, gilt dort nur die
    Auswahl. Hauptstrassen, Bahn und Gewaesser aus OSM wirken ohnehin als Grenze (weich, siehe unten).</li>
<li><b>Schneiden</b>. Am Ende ein Fenster mit Anzahl Gebiete und Ampel. Der Haken <i>Altes Verfahren</i> rechnet zum Vergleich mit dem
    Punkt-Clustering von vor dem 16.09.2026 (kann Inseln erzeugen).</li>
<li>Pruefen: Label je Gebiet mit Adressen, SNR, WE, PON, Kassetten, <b>Hk-Fasern</b> nach ZTV 21 Kap. 8.6.2.3 (je PON-Abschnitt 1 Fs,
    je P2P-Weg 2 Fs, bei mehr als 3 PON plus 6 Fs Netzreserve, in 6er-Schritten aufgerundet, mindestens 12, hoechstens 36; bis 3 PON
    mindestens 6) - die Rechnung steht in Klammern im Label - und Vzk-Weg. Layer <i>Ampel (Grenzen)</i> einschalten, Bericht ueber den Knopf.</li>
<li>Anpassen, drei Wege, alle rechnen automatisch nach und setzen die Beschriftung neu:
    <ul>
    <li><b>Gebiete aus Polygonen uebernehmen</b>: Layer <i>NVT-Gebiete</i> mit QGIS bearbeiten - zwei Polygone auswaehlen und
        <i>Ausgewaehlte Objekte verschmelzen</i>, Knoten verschieben, Polygon loeschen. Dann der Knopf: jede Adresse bekommt das
        Gebiet, in dem sie liegt (bei Ueberlappung das kleinere), Adressen ausserhalb behalten ihres, entfallene Gebiete raeumen ihren
        Sitz ab. Die Polygone werden danach aus den Adressen neu abgeleitet (Voronoi: lueckenlos, ueberlappungsfrei) - die Zeichnung
        des Planers bestimmt also die Zuordnung, die Grenze liegt danach mittig zwischen den Adressen beider Gebiete.</li>
<li><b>Handpolygone behalten</b> (Markus 29.10.2026): "Gebiete aus Polygonen uebernehmen" rechnet die Polygone danach neu. Sollen von Hand gezeichnete
    Polygone genau so bleiben, hier nur zeichnen und speichern, dann in Schritt 5 <b>Adressen nach Gebieten</b> - das haengt die Adressen um und
    zieht die Kennwerte nach, ohne die Polygone anzufassen.</li>
    <li><b>Ausgewaehlte Adressen nach ... Verschieben</b>: Adressen im Layer <i>Adressen</i> mit Rechteck, Freihand oder Polygon
        auswaehlen, Zielgebiet in der Liste waehlen oder einen neuen Namen tippen, Verschieben. Der Layer <i>Adressen</i> bleibt danach
        aktiv (Markus 12.10.), die naechste Auswahl kann gleich folgen.</li>
    <li>Von Hand: Spalte <i>nvt</i> im Layer Adressen aendern, speichern, <b>Nachrechnen</b>.</li>
    </ul>
    Offene Bearbeitungen der Layer werden vor dem Uebernehmen gespeichert. Sitze, die du verschoben hast, bleiben.</li>
<li><b>Vorgabe-Gebiete des Planers</b> (Markus 17.09.): Wer Gebiete selbst festlegen will, legt sie <i>vor</i> dem Schneiden fest - auf
    zwei Wegen. <b>Aus Auswahl</b> (Markus 12.10.): Adressen in der Karte mit dem QGIS-Auswahlwerkzeug markieren (Layer <i>Adressen</i> aus
    Schritt 2 oder 3), Knopf druecken, Name eintragen - eine eng anliegende Huelle um die Auswahl plus 10 m wird als Polygon in den Layer
    <i>Vorgabe-Gebiete</i> geschrieben, der Zaehler zeigt sofort, wie viele Adressen wirklich darin liegen; der aktive Layer bleibt, die
    naechste Auswahl kann gleich folgen. Oder zeichnen: <b>Zeichnen</b> legt den Layer <i>Vorgabe-Gebiete</i> an, schaltet die Bearbeitung ein und aktiviert das Zeichenwerkzeug; sobald ein
    Polygon geschlossen oder ein Knoten verschoben ist, stehen <b>Adressen und WE darin</b> am Polygon (Felder adressen, we) und in der Zeile unter
    dem Zeichnen-Knopf (Live-Zaehler, Markus 22.09.2026; Adressen aus der gewaehlten Adresspruefung, ignorierte zaehlen nicht). Der Knopf
    <b>Adressen zaehlen</b> zaehlt alle Polygone auf einmal durch - fuer Layer, die schon vorher bestanden, oder nach dem Speichern: Polygon
    ziehen, Rechtsklick schliesst, im Formular <i>name</i> eintragen (leer = Nummer aus dem Nummernkreis), Bearbeitung speichern. Beim
    Schneiden gilt: Adressen in einem Vorgabe-Polygon gehoeren fest zu diesem Gebiet, das Netz darin ist fuer die Automatik <b>gesperrt</b>,
    die Automatik schneidet nur den Rest und waechst nicht in die Vorgaben hinein. Die Vorgabe bekommt genau die gezeichnete Flaeche, die
    automatischen Gebiete werden darum herum beschnitten; Kennzahlen und Ampel werden fuer die Vorgabe wie fuer alle anderen gerechnet -
    ein zu grosses oder zu kleines Vorgabe-Gebiet zeigt sich also gelb oder rot. Vorgaben stehen im Layer <i>Vorgabe (gesperrt)</i>
    (schwarz gestrichelt), in der Kopfzeile des Labels und im Bericht; das GeoPackage haelt sie im Layer <i>vorgaben</i>, und
    <b>Nachrechnen</b> behaelt sie. Als Vorgabe-Layer eignet sich jeder Polygonlayer im Projekt; besteht dort eine Auswahl, zaehlt nur sie.</li>
<li><b>Ordentliche Polygone</b> (Markus 17.09.): Die Gebietsgrenzen entstehen aus Voronoi-Zellen je Adresse und waren entsprechend
    zackig. Jetzt wird jede Grenze zwischen zwei Gebieten als Ganzes geglaettet (Douglas-Peucker 4 m, Knoten bleiben), Flaechen werden
    neu gebildet, Loecher gefuellt (ausser ein anderes Gebiet liegt darin), Splitter unter 50 m2 gehen an den Nachbarn. Ergebnis: rund
    80 % weniger Stuetzpunkte, weiter lueckenlos und ueberlappungsfrei, jede Adresse bleibt in ihrem Gebiet (Selbeck 715 -> 178
    Stuetzpunkte, Sommersell 487 -> 85).</li>
<li><b>Namen und Nummern</b> (Markus 17.09.):
    <ul>
    <li><b>Nummernkreis (BVT)</b> oben: Stamm (z. B. <code>1V</code>, leer = aus der ASB) und die Nummer, ab der gezaehlt wird. Gibt der
        Auftraggeber einen Block vor, traegst du ihn hier ein; der Schnitt vergibt dann <code>1V05</code>, <code>1V06</code> und so fort.
        Nummern gehen bis <b>9999</b>; zweistellig wird mit fuehrender Null geschrieben (<code>1V05</code>), darueber ohne
        (<code>1V100</code>). Das Feld <i>bis</i> dient nur der Kontrolle: Namen ausserhalb des Blocks werden nach dem Schneiden gemeldet.</li>
    <li><b>Gewaehltes Gebiet umbenennen</b>: ein Polygon im Layer <i>NVT-Gebiete</i> anklicken, der Name steht dann im Feld, ueberschreiben,
        <b>Umbenennen</b>. Der Name wird in allen Layern gesetzt (Gebiete, NVT-Sitz, Adressen, Strassenabschnitte). Freie Namen sind erlaubt.
        Ein Ringtausch (A wird B, B wird A) geht in einem Schritt; ein schon vergebener Name wird abgelehnt.</li>
    <li><b>Nummern aufruecken</b>: faellt durch Umclustern eine Nummer weg, schliesst dieser Knopf die Luecke - aus 1V03, 1V05, 1V06 wird
        1V03, 1V04, 1V05. Das Werkzeug zeigt vorher die vollstaendige Liste der Umbenennungen und fragt nach; ohne Bestaetigung passiert
        nichts. Namen ohne Nummer bleiben unberuehrt.</li>
    </ul>
    Beide Wege ziehen die Dateien der Werkzeuge 3 und 4 mit, die zu diesem Schnitt gehoeren (gleicher Namensstamm im selben Ordner):
    Standorte, Korridore, Trassen (Vorlage, Planung, Endstand, Adressen, NVT-Status, Befunde) samt dem Namensvorsatz der Trassen-uid
    <code>1V02_0007</code>. Im Protokoll steht, welche Datei mit wie vielen Eintraegen mitgezogen wurde. Nicht mitgezogen wird, was schon
    in Plan[Goo] steht - dort aendert der Planer die Namen selbst.</li>
<li>Fertig? <b>Weiter mit 10: Uebergabe nach Plan[Goo]</b> oeffnet Werkzeug 10 mit diesem Schnitt.</li>
<li>Spaeter wieder oeffnen: <b>Vorhandenes Ergebnis laden</b> holt mit einem Klick den juengsten Schnitt (<code>nvt_gebiete_....gpkg</code>);
    der Pfeil daneben zeigt aeltere Laeufe und die Dateiwahl.</li>
</ol>
<h4>Wie geschnitten wird (netzorientiert, seit 16.09.2026)</h4>
<p><b>Bausteine sind Strassenabschnitte</b>: das Netz wird in Ketten zwischen Kreuzungen zerlegt, lange Ketten in Stuecke von hoechstens
8 Adressen oder 250 m. Ein Abschnitt wechselt als Ganzes das Gebiet - eine Strasse wird nur geteilt, wenn es sonst nicht aufgeht.</p>
<p><b>Gebiete wachsen entlang des Netzes</b>: Startzahl k = Adressen durch Zielgroesse (48), Startsitze per k-means++. Von jedem Sitz aus
werden die benachbarten Abschnitte in Reihenfolge ihres Netzwegs zum Sitz angelagert, solange Adressen, WE, SNR, PON und Kassetten passen
und jede Adresse innerhalb der Vzk-Grenze bleibt. Jedes Gebiet ist damit auf dem Netz zusammenhaengend - keine Inseln, Grenzen liegen
zwischen den Bloecken. Neuer Sitz ist der Medoid (kuerzeste Wegsumme) des Gebiets, bis zu acht Runden; behalten wird die Runde mit der
kleinsten Summe der Vzk-Baumlaengen.</p>
<p><b>Sperrkanten</b>: Wachsen ueber eine Hauptstrasse (OSM primary/secondary) kostet +300 m, ueber eine Bundesstrasse +600 m, Bahn
+800 m, Gewaesser +500 m Netzweg. Gebiete bleiben so bevorzugt auf einer Seite, duerfen aber hinueber, wenn sonst nichts geht.
Zwangsgrenzen des Planers sind hart. Bei Plan[Goo]-Trassen als Netz fehlen die OSM-Merkmale - dort zaehlen nur Zwangsgrenzen.</p>
<p><b>Rest und Verdichten</b>: Adressen, die kein Gebiet aufnehmen kann (voll oder ausser Reichweite), eroeffnen neue Gebiete. Danach wird
jedes Gebiet probeweise aufgeloest (kleinste zuerst) und neu gewachsen; angenommen, wenn alle Adressen unterkommen und das Gebiet
kleiner als die Mindestgroesse war oder der Vzk-Baum um weniger waechst, als ein NVT kostet (Annahme 15.000 EUR je NVT geteilt durch die
mittleren Tiefbaukosten je Meter, in Barntrup rund 110 m).</p>
<p><b>Gegenprobe Gold Mannheim-Rheinau</b> (Telekom-Schnitt, 1.740 angebundene Adressen): Planer 38 NVT, Median 48 Adressen, Vzk-Baum
27,5 km; Werkzeug 41 NVT, Median 44, Vzk-Baum 22,8 km, kein Strassenabschnitt geteilt (Planer: 26), 90 % der Adresspaare eines Abschnitts
wie beim Planer behandelt (altes Verfahren: 84 %, 49 geteilte Abschnitte).</p>
<p>Polygone entstehen aus Voronoi-Zellen je Adresse plus Stuetzpunkten entlang der Strassenabschnitte; der Layer
<i>Strassenabschnitte</i> (ausgeblendet) zeigt die Bausteine in Gebietsfarbe, geteilte Abschnitte schwarz gestrichelt, Sperren gepunktet.</p>
<h4>Grenzen je Regelsatz (myDMS-Regelwerk der Telekom, seit 30.09.2026)</h4>
<p>Adressen, Koppler, Kassetten und WE je NVT kommen aus dem <b>myDMS-Regelwerk</b> (myDMS 23499 V34), so wie Plan[Goo] es beim
Befuellen und in der Abnahme prueft. Der Werkzeugkasten liest die Tabelle aus dem installierten Plan[Goo] (ein Plan[Goo]-Update kommt
damit automatisch an) und traegt eine Kopie vom 30.09.2026 als Rueckfall. "Erstausbau" (in Plan[Goo] warning) faerbt gelb, "Maximal"
(maximum) rot. Der Ausbautreiber der Adressen waehlt die Zeile (Gewerbe-Treiber pushgk/mbfd_gwg haben eigene Werte). Das Protokoll nennt
Quelle und Zahlen bei jedem Lauf.</p>
<table>
<tr><th>Groesse</th><th>Eigenausbau Gf-NVt 22 L</th><th>MBfD Gf-NVt 22 L (BF)</th><th>MBfD Gf-NVt 22 XS (BF)</th></tr>
<tr><td>Adressen Erstausbau / Maximal (neuer NVT)</td><td>40 / 90</td><td>45 / 51</td><td>10 / 13 (nur auf Wahl des Planers)</td></tr>
<tr><td>Adressen Erweiterung Bestands-NVT</td><td>40 / 90</td><td>51 / 60</td><td>13 / 15</td></tr>
<tr><td>Koppler Erstausbau / Maximal (= PON-Fasern)</td><td>15 / 23</td><td>8 / 12</td><td>0 / 2</td></tr>
<tr><td>Vzk-Kassetten Erstausbau / Maximal</td><td>40 / 90</td><td>40 / 72</td><td>13 / 15</td></tr>
<tr><td>WE weich</td><td>736 (23 Koppler x 32)</td><td>384 (12 x 32)</td><td>64 (2 x 32)</td></tr>
<tr><td>SNR in der Bodenplatte (ZTV 21)</td><td>90</td><td>57 (60 minus 3 Kollo)</td><td>12 (15 minus 3 Kollo)</td></tr>
<tr><td>Hk-Fasern (ZTV 21)</td><td>36</td><td>36</td><td>12</td></tr>
<tr><td>Vzk-Weg NVT zu Adresse (ZTV 21)</td><td>750 m</td><td>1.200 m</td><td>1.200 m</td></tr>
</table>
<p>Bis 29.09. galten 60/74 (Eigen, aus den Gold-Projekten) und 51/57 (MBfD, Annahme). Wer weiter mit 60/74 schneiden will, traegt es in
die Grenzen-Felder ein: nur geaenderte Felder ueberschreiben das Regelwerk, bei "automatisch nach Ausbautreiber" gilt sonst die Zeile des
Treibers (vorher ueberschrieben die Felder auch einen MBfD-Schnitt mit den Eigenausbau-Zahlen).</p>
<p><b>MBfD-Lasten je Haus (Kap. 13, seit 30.09.2026):</b> alle Gebaeude bis 68 WE haengen am zentralen 1:32 im NVT (PON = WE/32, kein 1:8),
Kassetten je Haus = 4 Fs je WE + 2 je Gebaeude in UNI-Kassetten a 12 Fs (Annahme). Der Regelsatz kommt aus dem Ausbautreiber der Adressen
(Schritt 2), die Materialkonzept-Version aus den Einstellungen.</p>
<div class="kasten"><b>Das Label am Gebiet</b> zeigt jede Groesse als "Ist von Grenze":<br>
<code>1V12 (gruen)</code><br><code>60 von 60/74 Adr | 64 von 90 SNR</code><br><code>137 von 600 WE | 149 Anschl.</code><br>
<code>9.3 von 23 PON | 24 von 36 Hk-Fs | 69 von 126 Kass.</code><br><code>Vzk max 268 von 750 m | Baum 1840 m</code><br>
Adr = Adressen = Einfuehrungen in die Bodenplatte. Anschl. = FTTH-Anschluesse nach ZTV (WE + Gewerbe + Zusatzbedarf). Baum = Laenge aller
Vzk-Wege des Gebiets zusammen.</div>

<a name="w3"></a>
<h3>4. NVT-Standorte und Sicherung</h3>
<h4>Wozu</h4>
<p>Der Sitz aus Werkzeug 3 ist ein Netzpunkt, meist mitten auf der Strasse. Der NVT muss aber im oeffentlichen Raum stehen - auf dem Gehweg,
auf dem Bankett am Strassenrand oder neben einem vorhandenen Netzverteiler - und fuer die Zustimmung des Wegebaulasttraegers (§ 127 TKG)
braucht es Flurstueck, Gemarkung, Flur, Strasse und Hausnummer. Werkzeug 4 liefert den Standortvorschlag mit Korridor, die Daten fuer das
Formular und fuehrt danach die Standortsicherung: Checkliste je Standort, Rechtliche Sicherung, Alternativstandort, Gesamtstatus.</p>
<h4>Ablauf</h4>
<ol>
<li><b>NVT-Gebiete (2)</b>: die Gebietsdatei aus Werkzeug 3 (Sitz, Gebiete, Adressen und Netz kommen mit); vorbelegt mit dem juengsten Ergebnis.</li>
<li>Regeln pruefen: Gehwegrest 1,5 m, Grenze 0,6 m, Gebaeude 1,0 m, Kreuzung 8 m, Suchradius 60 m. Gehaeusetyp eintragen.</li>
<li><b>Methode</b> (Markus 12.10.): drei gleichwertige Wege zum selben Ergebnislayer - Standortsicherung, Excel, Pruefblatt, Schritt 5 und
    Schritt 10 arbeiten danach gleich.
    <ul>
    <li><b>Vorschlag (ALKIS/OSM)</b> - <b>Standorte vorschlagen</b>: ALKIS (Flurstuecke, Verkehrsflaechen, Gebaeude) und OSM (Strassenachsen,
        Schaltschraenke) werden abgerufen; je NVT werden Kandidaten am Rand der Strassenflaechen, auf Gehwegen und neben Bestand-NVT bewertet,
        der beste gewinnt (siehe Regeln).</li>
    <li><b>Zeichnen</b> - <b>Zeichnen starten</b> legt den Arbeitslayer <i>Standorte zeichnen</i> mit den Sitzvorschlaegen aus Schritt 3 an,
        schaltet die Bearbeitung ein und das Verschieben-Werkzeug scharf: Punkte an die richtige Stelle ziehen, bei Bedarf Punkte
        hinzufuegen (Name im Formular) oder loeschen; <b>Zeichnung uebernehmen</b> schreibt daraus die Standortdatei.</li>
    <li><b>Aus Layer uebernehmen</b>: Quelllayer waehlen (Punktlayer des QGIS-Projekts mit Namensfeld, oder die NVT des offenen
        Plan[Goo]-Projekts); besteht im Layer eine Auswahl, zaehlt nur sie. <b>Aktualisieren</b> liest die Layerliste neu.</li>
    </ul>
    Haken <b>Lage mit ALKIS/OSM pruefen</b> (Zeichnen und Uebernahme): der Punkt bleibt, wo der Planer ihn gesetzt hat, und gilt als zulaessig;
    Lage (Gehweg/Bankett/privat), Flurstueck, Strasse und Abstaende werden ermittelt, Beanstandungen (z. B. auf der Fahrbahn) stehen im Hinweis.
    Ohne Haken geht es ohne Netz, Lage und Flurstueck bleiben leer. Spalte <i>herkunft</i> im Layer nennt den Weg.</li>
<li>Layer ansehen: <b>Standort (Vorschlag)</b> in der Farbe des Gesamtstatus (Orange OFFEN, Rot Abgelehnt, Gruen Gesichert; Alternativstandorte kleiner),
    Beschriftung mit Lage, Adresse und Flurstueck; <b>Korridor</b> = alle zulaessigen Stellen im Umkreis; <b>Sitz vorher</b>; <b>Bestand-NVT</b> (schwarz, aus
    OSM und dem offenen Plan[Goo]-Projekt). Punkt bei Bedarf im Layer verschieben - beim naechsten Speichern oder Excel wird die Bearbeitung uebernommen.</li>
<li><b>Standortsicherung</b> (unterer Block): die Uebersicht zeigt alle Standorte mit Lage, zulaessig, Gesamtstatus und offenen Punkten; Filter nach
    Status. Zeile waehlen: <b>Hinzoomen</b> blinkt den Punkt an und zoomt hin; <b>Checkliste</b> (oder Doppelklick) oeffnet das Pruefblatt des Standorts;
    <b>Alternativstandort</b> legt einen zweiten Standort fuer den NVT an (Kopie 3 m oestlich, Checkliste leer - Punkt danach verschieben).</li>
<li>Im <b>Checklisten-Fenster</b>: acht Pruefpunkte mit Status <i>OK / Nicht OK / Nicht relevant</i> und Bemerkung (P1 Stellflaeche und Arbeitsraum,
    P2 Gehwegrestbreite 1,50 m, P3 Sichtdreiecke, P4 Abstaende Baeume/Einbauten/Hydranten/Hausanschluesse, P5 Untergrund Sockel, P6 Leitungsauskunft/
    Fremdleitungen, P7 Denkmalschutz/Gestaltungssatzung, P8 Kabelzufuehrung). Rechtliche Sicherung: Grund <i>oeffentlich</i> mit Zustimmung nach
    § 127 TKG (beantragt / erteilt / abgelehnt) oder <i>privat</i> mit Gestattungsvertrag (in Verhandlung / unterschrieben / abgelehnt) und
    Eigentuemer-Kontakt. Der Gesamtstatus steht live unten im Fenster; <b>Speichern</b> schreibt in die Standortdatei und aktualisiert Layer und Uebersicht.</li>
<li><b>Gesamtstatus</b> (automatisch): <b>Gesichert</b> = alle Punkte OK oder Nicht relevant und Zustimmung erteilt bzw. Gestattung unterschrieben;
    <b>Abgelehnt</b> = ein Punkt Nicht OK oder Sicherung abgelehnt; sonst <b>OFFEN</b> mit den offenen Punkten als Text (Uebersicht, Layer, Excel, Pruefblatt).</li>
<li><b>Lageplaene 1:1000</b>: je Standort ein PNG mit ALKIS-Hintergrund (NRW), Flurstuecken, Korridor und Standort im Ordner "Standortsicherungen &lt;Projekt&gt;".
    <b>Excel</b>: "Netzverteiler-Standorte [Projekt].xlsx" aus dem aktuellen Stand neu schreiben und oeffnen - Blatt <i>Netzverteiler-Standorte</i> im
    Fiberation-Format (Bezeichner, Variante, Gehaeusetyp, Gemeinde, PLZ, Strasse, Hausnummer, Flurstueck, Nenner, Gemarkung, Flur, Station, Information,
    Rechts-/Hochwert) plus Pruefspalten, Checkliste, Sicherung und Gesamtstatus; Blatt <i>Uebersicht</i> mit Autofilter nach Status.
    <b>Ergebnis laden</b> holt eine fruehere Standortdatei zurueck, um die Sicherung weiterzufuehren.
    <b>StoSi-Shape exportieren</b> (Markus 12.10.): wie <i>Export StoSi-Shape fuer GDI</i> in Plan[Goo] (Reiter Allgemein, Bereich Export) - eine
    Zip-Datei <code>StoSi_GDI_shp_&lt;Projekt&gt;_&lt;Datum&gt;.zip</code> mit ESRI-Shape (UTF-8, EPSG:25832) im Plan[Goo]-Punktschema
    GEOMETRY_POINT: fid, UID, TYPE <code>nvt</code>, NAME, PLZ, ORT, STRASSE, HS_NR, IS_EXTERNAL_OBJECT 0, MAIN_MATERIAL = Gehaeusetyp
    (Plan[Goo] schreibt dort den Materialnamen, z. B. <i>GF-NVt22 L (Eigen) Langmatz</i> - im Feld Gehaeusetyp so eintragen, wenn die GDI das
    erwartet), MAIN_PROJECT = NVT-Name, SHOW_LABEL 1; lange Feldnamen kuerzt der Shape-Treiber wie bei Plan[Goo] auf 10 Zeichen. Je NVT der
    Hauptstandort, bei abgelehntem Hauptstandort der Alternativstandort.</li>
</ol>
<p>Werkzeug 5 (Trassen) und Werkzeug 10 (Plan[Goo]) nehmen je NVT den Hauptstandort; ist er abgelehnt und ein Alternativstandort nicht abgelehnt, den Alternativstandort.</p>
<h4>Regeln der Platzierung (ZTV 21 Kap. 8.6.5 Standortwahl, Checkliste Fiberation 18.09.2026)</h4>
<table>
<tr><th>Regel</th><th>Pruefung</th></tr>
<tr><td>Flaechen einstufen</td><td>Jede ALKIS-Verkehrsflaeche wird einzeln eingestuft (Spalte <i>einstufung</i> im Layer "ALKIS Verkehrsflaechen"):
    <b>Fahrbahn</b> = Strassenverkehr, Fahrweg/Wirtschaftsweg, Parkplatz und jeder "Weg", der befahrbar ist (eine OSM-Fahrachse laeuft darin,
    er traegt einen Strassennamen oder ist breiter als 3,5 m - typisch Stichstrassen und Anliegerwege, die ALKIS nur als "Weg" fuehrt).
    <b>Gehweg</b> = "Begleitflaeche Strassenverkehr", Fussweg/Gehweg/Radweg/Platz und namenlose schmale Wege, die an eine Fahrbahn grenzen.
    <b>Weg</b> = Gehweg-Einstufung ohne Strassenanschluss (Fuss-/Wirtschaftsweg im Gelaende) - moeglich, aber ohne Bonus.</td></tr>
<tr><td>Nie auf der Fahrbahn</td><td>Wo in der Fahrbahn-Flaeche die Fahrbahn liegt, sagt ALKIS nicht. Sie wird aus der OSM-Achse <i>in dieser Flaeche</i> und der Regelbreite
    je Strassentyp geschaetzt (residential 5,5 m, tertiary 6,5 m, secondary 7,5 m ...), mindestens 3,5 m. Ein Punkt naeher als Regelbreite/2 + 0,2 m + 0,5 m an der
    Achse heisst <i>Bankett schmal</i> (Fahrbahnbreite vor Ort pruefen, Abzug), naeher als 1,75 m + 0,7 m heisst <i>Fahrbahn</i> (unzulaessig). Ohne Achse in der
    Flaeche wird die Fahrbahn aus der Flaechenbreite geschaetzt: neben dem NVT muessen mindestens 4,0 m frei bleiben, sonst <i>Fahrbahn</i>.</td></tr>
<tr><td>Gehweg bevorzugt</td><td>Gehwegrestbreite = Abstand zur Fahrbahn-Flaeche minus halbe NVT-Tiefe (0,2 m), mindestens 1,50 m (Regler). Ein Gehweg
    bekommt den groessten Bonus (1,5 Punkte), ein Bankett 0,5-1,0 Punkte.</td></tr>
<tr><td>Neben Bestand-NVT</td><td>OSM man_made=street_cabinet und NVT des offenen Plan[Goo]-Projekts; Kandidaten im Ring 1,2-1,8 m um den Bestand mit deutlichem Bonus.</td></tr>
<tr><td>Abstand Grenze 0,6 m, Wunsch 0,8 m</td><td>Zur Grenze der eigenen oeffentlichen Flaeche (Strassenflurstueck, Bankett). <b>Auf dem Gehweg 0,3 m</b> (Wunsch 0,4 m):
    dort steht der NVT mit der Rueckwand an der Grundstuecksgrenze, nur so passt ein 2,0 m breiter Buergersteig (0,1 + 0,4 Tiefe + 1,5 Rest).</td></tr>
<tr><td>Abstand Gebaeude 1,0 m</td><td>Montagearbeitsraum, Tuer, kein Standort im Gebaeude.</td></tr>
<tr><td>Abstand Kreuzung 8 m</td><td>Sichtfeld an Kreuzungen und Einmuendungen (Knoten mit drei und mehr Netzkanten).</td></tr>
<tr><td>Nah am Netzschwerpunkt</td><td>0,05 Punkte je Meter zum Sitz aus Werkzeug 3 und nur im eigenen Gebiet - lieber Bankett schmal am Schwerpunkt als Gehweg 60 m weiter.</td></tr>
<tr><td>Privatgrund als Notloesung</td><td>Direkt an der Strassengrenze (bis 1,2 m) mit Gestattungsvertrag, deutlicher Abzug; Grund in der Checkliste auf privat vorbelegt.</td></tr>
</table>
<p class="grau">Ohne ALKIS-Flaechen wird nur nach OSM geschaetzt, ohne OSM-Achse bleibt die Fahrbahnlage ungeprueft (Hinweis im Ergebnis). Nicht geprueft werden
Leitungen im Boden, Baeume, Parkbuchten, Einfahrten und Sichtdreiecke - dafuer ist die Checkliste da, mit Fotos aus der Ortsbegehung.</p>

<a name="trassen"></a>
<h3>5. Trassen je NVT planen</h3>
<h4>Wozu</h4>
<p>Das Werkzeug erzeugt je NVT eine <b>Vorlage</b>: das Kondensat der Trassen aus dem Netz, auf dem Werkzeug 3 geschnitten hat. Die Vorlage liegt auf den Strassenachsen und ist gesperrt - sie zeigt, welche Strassen der Vzk braucht.
Der Planer zeichnet in der <b>Planung</b> die richtige Lage (Gehweg, Gruenstreifen) nach oder uebernimmt die Vorlage und verschiebt sie. Bevor die
Planung nach Plan[Goo] geht, muss sie je NVT valide sein: zusammenhaengend, genau eine Zufuehrung am NVT, keine Luecken, keine Dopplungen,
Knoten an jeder Beruehrung, Attribute gesetzt. Das Werkzeug fuehrt NVT fuer NVT durch, beginnend mit dem niedrigsten.</p>
<h4>Ebenen im GeoPackage</h4>
<table>
<tr><th>Layer</th><th>Bedeutung</th></tr>
<tr><td>Vorlage</td><td>Erzeugtes Kondensat, blasses Orange gestrichelt, <b>gesperrt</b>. Nur zum Nachzeichnen und Fangen. Zufuehrung grau gepunktet.</td></tr>
<tr><td>Planung</td><td>Die Ebene des Planers. In Arbeit orange (Laengstrasse kraeftig, Hauszufuehrung duenn, Zufuehrung schwarz gestrichelt),
    <b>geprueft gruen</b> (final), nach Plan[Goo] uebertragen blau (Markus 12.10.). Gepruefte und uebertragene Straenge bleiben immer sichtbar, auch
    mit dem Haken <i>nur diesen NVT zeigen</i>; der Status steht an jeder Trasse und ueberlebt Speichern und Neuladen. Eine gespeicherte Aenderung
    setzt den NVT auf <i>in Arbeit</i> zurueck - erst die Pruefung macht ihn wieder gruen. Alle Werkzeuge, die Pruefung und die Uebertragung wirken
    hier. Label: Bauverfahren | Oberflaeche.</td></tr>
<tr><td>Endstand</td><td>Ausgeblendet. Der eingefrorene Stand des Kondensats je Uebergabe in Schritt 10 (Spalte <code>stand</code>), blau. Belegt, was nach Plan[Goo] ging.</td></tr>
<tr><td>Kandidaten</td><td>Graue Netzstuecke ausserhalb der Vorlage, per Auswahl in die Planung zu uebernehmen.</td></tr>
<tr><td>NVT / Adressen / Befunde</td><td>NVT-Punkte mit Status (grau offen, gelb in Arbeit, gruen geprueft, blau uebertragen), Adressen des Schnitts, Pruefbefunde
    (rot blockierend, gelb Hinweis).</td></tr>
</table>
<h4>Ablauf</h4>
<ol>
<li><b>NVT-Standort:</b> liegt eine Standortdatei aus Werkzeug 4 vor (Haken <i>NVT-Standorte aus Werkzeug 4</i>), waechst der Trassenbaum vom <b>gesicherten
    Standort</b> aus und der NVT wird nicht mehr verschoben - in Werkzeug 4 entschieden heisst entschieden (Markus 22.09.2026). Ohne Standortdatei gilt der
    Sitzvorschlag aus Werkzeug 3, der bei Bedarf 2,5 m zur Seite rueckt, damit genau eine Trasse am NVT endet.</li>
<li>Schnitt aus Werkzeug 3 waehlen (vorbelegt). Haken: <i>beidseitig im Seitenraum</i> (Gehweg statt Strassenachse), <i>an ALKIS-Verkehrsflaechen ausrichten</i>, <i>NVT-Standorte aus Werkzeug 4</i> (falls eine Standortdatei zum Schnitt vorliegt),
    <i>Telekom-Trassen aus Schritt 1 als Wegefuehrung</i> (vorbelegt): Netzkanten, die naeher als 8 m an einer Telekom-Trasse liegen, kosten im Weg nur 70 % -
    der Baum bleibt im Seitenraum (dort haengen die Adressen), waehlt aber die Seite und den Zug, auf dem die Telekom schon liegt. <b>Das hilft spaeter bei
    Wegesicherung und KMU</b> (Markus 22.09.2026). Die Telekom-Trasse wird <i>nicht</i> als zweites Netz eingehaengt - das liess den Baum zwischen Gehweglinie und
    Trasse pendeln und zerlegte die Vorlage in Kurzstuecke. Betroffene Stuecke tragen in der Spalte <code>quelle</code> den Zusatz <i>+telekom</i>.
    Fuer den Hauptkabel-Weg gilt die Trasse dagegen hart (Schritt 6 und 7). Der Vzk baut dort trotzdem neu
    (kein Einzug in Bestandsrohre, Attribut <code>bestand</code> bleibt 0, <code>quelle</code> traegt die MegaPlan-ID). Wo keine Trasse liegt, sucht der Baum wie bisher den guenstigsten Weg.</li>
<li><b>Vorlage erzeugen</b>: je NVT der kostenminimale Baum vom Sitz zu allen Adressen (Steinerbaum, Kosten je Kante: Gehweg 148 EUR/m, Fahrbahnquerung 180 EUR/m + Kopfloch + 500 EUR Seitenwechsel-Aufschlag, Hausquerung als Pressung 121,50 EUR/m + Kopfloch).
    <b>Trassen in fremden NVT-Gebieten werden gemeldet</b> (Markus 17.09.): laeuft der Baum eines NVT durch das Gebiet eines anderen,
    traegt jedes betroffene Stueck den Hinweis "laeuft n m durch ein fremdes NVT-Gebiet" und der NVT-Status meldet Anzahl und Laenge
    (Randstreifen 15 m am eigenen Gebiet zaehlt nicht mit, weil die Gebietsgrenze auf der Strassenmitte liegt und der Seitenraum daneben).
    Gebaut wird trotzdem, denn die Ursache liegt nicht im Baum, sondern in der Gebietsgeometrie: die NVT-Gebiete sind Huellen um die
    Adressen, und eine Zufahrtsstrasse, die Adressen des einen NVT erschliesst, kann im Gebiet des anderen liegen (Selbeck: osm:37836681
    erschliesst Alter Kirchweg 1 aus 1V01, liegt aber in 1V02). Die Meldung gehoert in Werkzeug 3 geklaert - Gebietsgrenze oder Zuordnung
    der Adresse aendern. Danach die Seitenregel: eine beidseitig gebaute Strasse verliert die schwaechere Seite, wenn Hausquerungen dort billiger sind (Faustregel: zweite Seite nur bei Haeusern dichter als 10 m). Wege ueber der Vzk-Hoechstlaenge werden nachgebessert. Hauszufuehrungen vom Strassenknoten zum Haus (eine je
    Koordinate), Zufuehrungstrasse zum NVT-Punkt. Stuecke zwischen zwei Abzweigen werden eine Trasse. Mit dem Haken <b>beidseitig im Seitenraum</b>
    (Vorgabe, wie im HLD Roboter) liegen die Kandidaten nicht auf der Strassenachse, sondern links und rechts im Gehweg (Abstand je Strassentyp,
    an den Rand der ALKIS-Verkehrsflaeche gerueckt, wo ein offener Dienst existiert - NRW, BW u. a.); Querungen an Kreuzungen und alle 70 m,
    Hausquerung als Pressung zur Gegenseite. Der Baum waehlt nach Kosten (Gehweg 148 EUR/m gegen Querung rund 1.950 EUR), ob eine Strasse beidseitig
    gebaut wird. Lagehinweis Gehweg/Querung und Bauverfahren (Tiefbau, Querung Fahrbahn Tiefbau, Hausquerung Tiefbau_Verdraengung) stehen an den
    Trassen. Datei <code>trassen_....gpkg</code>;
    die Planung ist zunaechst leer. Ein frueheres Ergebnis laedt <b>Vorhandenes Ergebnis laden</b> - der Stand je NVT steht in der Datei, das Fenster
    darf also geschlossen werden.</li>
<li><b>Nur Rahmen anlegen</b> (Markus 09.10.2026): dasselbe Ergebnis ohne Vorlage - NVT-Liste, NVT-Punkte (Standort aus Schritt 4, sonst
    Sitzvorschlag aus Schritt 3) und Adressen je NVT, Vorlage, Planung und Kandidaten bleiben leer. Kein OSM-Abruf, kein Steinerbaum, Sekunden
    statt Minuten. Danach <b>Trasse zeichnen</b> oder <b>Auswahl uebernehmen</b> (z. B. die Angebotsplanung), dann <b>Hauszufuehrungen ableiten</b>,
    <b>NVT pruefen</b> wie gewohnt; nach Plan[Goo] geht es in Schritt 10. "Vorlage uebernehmen" und "Kandidaten uebernehmen" haben hier nichts zu holen.</li>
<li>Links den NVT waehlen (oder <b>Naechster offener NVT</b>). Die Karte zeigt nur seine Vorlage und Planung (Haken). Doppelklick zoomt hin.
    Der Fang (Snapping) wird auf Vorlage, Planung, Adressen und NVT gesetzt (Stuetzpunkte und Segmente, 12 Pixel) und beim Schliessen zurueckgestellt.</li>
<li>Zwei Wege in die Planung: <b>Trasse zeichnen</b> entlang der Vorlage in der richtigen Lage (Start am NVT, Ende an der Vorlage oder einer
    Planungstrasse - der Fang hilft); das Attributformular danach bietet die Plan[Goo]-Felder als Auswahllisten wie die Leiste
    Trassenattribute (Bestand, Bauverfahren, Oberflaeche, Zulage, Lagehinweis, WeSi, Hauszufuehrung), danach <b>Aenderungen speichern</b>. Oder <b>Vorlage in Planung uebernehmen</b> und die Linien mit
    <b>Trasse umzeichnen</b> oder dem QGIS-Stuetzpunktwerkzeug verschieben; das ersetzt eine vorhandene Planung des NVT.</li>
<li><b>Hauszufuehrungen ableiten</b>: je Adresse das Lot vom Adresspunkt auf die naechste Laengstrasse der Planung (Hoechstabstand einstellbar,
    Vorgabe 60 m). Der Fusspunkt wird Stuetzpunkt der Laengstrasse (T-Stoss mit Knoten). Vom Planer gezeichnete Hauszufuehrungen bleiben,
    abgeleitete oder aus der Vorlage uebernommene werden ersetzt. Adressen ohne Trasse im Hoechstabstand werden gemeldet. So zeichnet der Planer nur
    Laengstrassen und Zufuehrung - in Selbeck sind 109 von 158 Trassen Hauszufuehrungen.</li>
<li>Aufraeumen wie im Plan[Goo]-Trassenreiter: <b>umzeichnen / schneiden</b> (QGIS-Werkzeuge, danach speichern); <b>verschmelzen</b>, <b>einrasten</b>
    (Toleranz), <b>Luecken finden</b>, <b>loeschen</b>, <b>Zu NVT verschieben</b> (markierte Trassen der Planung und markierte Adressen einem anderen NVT zuordnen; nvt und uid wechseln, Hauszufuehrungen der Adressen wandern mit, betroffene NVT erneut pruefen; bei Adressen Rueckfrage "Auch Schritt 3": dann werden sie in der oben gewaehlten Gebiete-Datei mit umgehaengt, die Polygone dort bleiben - sonst blockiert Schritt 10 die Uebergabe, bis beide Dateien gleich sind) und <b>Kandidaten uebernehmen</b> schreiben direkt in das GeoPackage.</li>
<li><b>Gebiete nachladen</b> (Markus 28.10.2026): hat Schritt 3 nach dem Erzeugen neue oder andere NVT-Gebiete gebildet, die geaenderte Gebiete-Datei oben
    waehlen und nachladen. Neue NVT kommen als <i>offen</i> in die Liste (ohne Vorlage - zeichnen oder Auswahl uebernehmen), Adressen wechseln auf den
    neuen Stand und nehmen ihre Hauszufuehrungen mit, NVT ohne Gebiet und Trassen in einem fremden Gebiet werden gemeldet. Die Planung bleibt, wie sie ist. Tragen Adressen in Schritt 5 einen anderen NVT als in
    Schritt 3 (weil sie hier verschoben wurden), zeigt eine Konfliktliste sie vorher an: <b>Schritt 3 gilt</b> (Schritt 5 zieht nach) oder <b>Schritt 5 gilt</b>
    (die Zuordnung wird nach Schritt 3 geschrieben, die Polygone bleiben).</li>
<li><b>Layer "NVT-Gebiete"</b> (Markus 29.10.2026): die Polygone aus Schritt 3 liegen als eigener, bearbeitbarer Layer in der Gruppe 5 (gestrichelter Rand
    in Ampelfarbe). Beim Zeichnen, Umzeichnen oder Verschieben zaehlt das Label sofort Adressen, WE und Ampel wie der Zaehler in Schritt 3 - umgehaengt wird
    dabei noch nichts. <b>Gebiete aus Schritt 3</b> holt die Polygone neu aus der oben gewaehlten Datei (ersetzt hier geaenderte).</li>
<li><b>Adressen nach Gebieten</b> ("Polygon ist Master"): der Layer "NVT-Gebiete" dieses Ergebnisses entscheidet. Seine Polygone gehen nach Schritt 3 (namenlose
    bekommen die naechste Nummer nach dem Muster der vorhandenen, neue Gebiete werden samt Sitz angelegt, hier geloeschte fallen dort weg), jede Adresse bekommt
    das Polygon, in dem sie liegt (ausserhalb aller Polygone: bleibt; Ueberlappung: kleinstes), die Kennwerte je Gebiet werden nachgezogen (apl, WE, PON, SNR,
    Kassetten, Hk-Fasern, Ampel; der Vzk-Weg bleibt vom letzten Schnitt), die Polygone bleiben exakt - kein Nachrechnen. Danach zieht Schritt 5 nach wie bei
    "Gebiete nachladen". Von Hand verschobene Adressen, die in einem anderen Polygon liegen, gehen in dieses Polygon zurueck. Das ist die finale Festlegung vor
    Schritt 10: Layer bearbeiten, "Adressen nach Gebieten", betroffene NVT pruefen, uebergeben.</li>
<li><b>Teilen an Abzweigen</b> (Phillip 27.10.2026): teilt die Trassen automatisch an allen Abzweigen und Kreuzungen - Rueckfrage: <b>Nur markierte</b>
    (nur wenn in der Planung etwas markiert ist), <b>Nur NVT</b> (gewaehlter NVT) oder <b>Alle NVT</b>. Bei "Nur markierte" werden nur die markierten
    Trassen an ihren Abzweigen geteilt (die abzweigenden duerfen unmarkiert sein); kreuzt eine markierte Trasse eine unmarkierte, wird auch die
    unmarkierte dort geteilt, damit an der Kreuzung beidseitig ein Knoten liegt. Abzweig: das Ende einer Trasse liegt bis zur Toleranz auf dem Inneren einer anderen (Hausstich-Fusspunkt,
    Einmuendung) - die andere wird dort geteilt, das Ende auf den Teilungspunkt gesetzt. Kreuzung: zwei Trassen schneiden sich ohne Ende dort -
    beide werden geteilt. Die Teile behalten alle Attribute, der erste Teil die uid, die weiteren bekommen neue. Trassen verschiedener NVT werden
    nicht gegeneinander geteilt, Mehrfachlinien bleiben unberuehrt. Dieselben Regeln wie <b>Trassen bereinigen</b> in Schritt 7.</li>
<li><b>Auswahl uebernehmen</b>: Linien aus einem BELIEBIGEN Linienlayer in die Planung dieses NVT anhaengen - etwa eine gute Trasse der
    Angebotsplanung (Plan[Goo]-Layer), ein Stueck der Vorlage oder eine Planung aus einem anderen Ergebnis. Den Layer im Layerbaum anklicken
    (aktiv), die Linien markieren, Knopf druecken. Plan[Goo]-Attribute kommen mit, wenn der Layer sie traegt (BAUVERFAHREN, SURFACE, ALLOWANCE,
    LOCATION_HINT, WESI, SUB_TYPE Hauszufuehrung, IS_EXTERNAL_OBJECT Bestand); Werte ausserhalb des Plan[Goo]-Wertevorrats bleiben leer.
    Leere Felder bekommen die Vorgabe der Attributmaske (z. B. Bauverfahren Tiefbau, Oberflaeche geb_Oberbau einstellen, dann uebernehmen).
    Mehrteilige Linien werden zerlegt, Koordinaten umgerechnet, Hauseinfuehrungen im Gebaeude (TYPE in_house) ausgelassen. Danach
    <b>Einrasten</b> und <b>Luecken finden</b>, damit die uebernommenen Stuecke an der Planung haengen.</li>
<li>Attribute fuer die gewaehlten Trassen setzen wie in Plan[Goo]: Bestandstrasse, Bauverfahren, Oberflaeche, Zulage, Lagehinweis, WeSi-Status,
    Hauszufuehrung. "- keine Aenderung -" laesst das Feld, "- leer -" loescht es. Unbekanntes bleibt leer - nichts erfinden.</li>
<li><b>NVT pruefen</b>: Reststuecke (Laengstrasse unter 1 m mit freiem Ende - Befund waehlen, Loeschen), Luecken, T-Stoesse und Kreuzungen ohne Knoten, Dopplungen, nicht verbundene Trassen, Adressen ohne Anschluss,
    <b>NVT-Anbindung</b> (Markus 12.10.: genau eine Trasse muss mit ihrem Ende auf dem NVT-Punkt liegen, Toleranz 0,05 m; ein Ende bis 0,5 m daneben
    zieht die Pruefung auf den Punkt - keine Luecke; weiter weg ist ein blockierender Befund, der NVT und Strang-uid nennt), fehlende Attribute,
    WeSi-Spezialfaelle aus Werkzeug 9. Blockierende Befunde rot, Hinweise gelb.
    <b>Befund anwaehlen</b> (Markus 17.09.): die betroffenen Trassen werden im Layer Planung ausgewaehlt und bleiben hervorgehoben, Fundpunkt und
    Trassen blinken dreimal rot auf. Doppelklick oder der Knopf <b>Befund zeigen (blinken)</b> zoomt zusaetzlich hin, mit einem Fenster, das zum
    Befund passt (Kreuzung und Luecke eng, nicht verbundene Trasse oder fehlende Zufuehrung weit). Zu jedem Befund gehoeren die uid der
    betroffenen Trassen, bei Paaren wie Dopplung, Kreuzung und T-Stoss beide. Ohne blockierende Befunde: Status geprueft.</li>
<li><b>Nach Plan[Goo]</b> geht es nicht mehr je NVT (Markus 12.10.): sind alle NVT geprueft, legt Schritt 10 das Kondensat aus allen NVT-Trassen
    und der Hk-Trasse im Projekt an - ein Weg, ein finales Plan[Goo]-Projekt.</li>
</ol>
<p>Ergebnisse aus Version 0.7.0 (eine Ebene "Arbeitskopie") werden beim Laden automatisch gehoben: alles Erzeugte wird Vorlage, vom Planer
gezeichnete Stuecke werden Planung.</p>
<p>Danach: Vzk-Befuellung (Plan[Goo] nativ), Hk (Werkzeuge 6 bis 8), zuletzt <b>10 Uebergabe nach Plan[Goo]</b>.</p>

<a name="hk"></a>
<h3>6. Hauptkabel clustern</h3>
<p><b>Zweck:</b> Aus den NVT des Schnitts die Hauptkabel-Straenge bilden. Markus 22.09.2026: "erst Hk clustern als ein Tool, dann Wegefuehrung
pro Hk als Trassenvorschlag und am Ende Einzeichnen vom Planer" - der Weg je Strang ist Schritt 7, Rohre und Kabel legt der Planer in Plan[Goo].</p>
<p><b>Eingang:</b> NVT-Gebiete aus Schritt 3 (Fasern je NVT nach ZTV 21 Kap. 8.6.2.3 stehen darin, dazu der Netzgraph), wahlweise die gesicherten
Standorte aus Schritt 4, die Vzk-Trassen aus Schritt 5 (der Clusterbaum folgt ihnen, Tiefbau wird nur einmal bezahlt) und der <b>Bestand aus
Schritt 1</b> (Telekom-Trassen als Weg, Regeln siehe Schritt 7). Die <b>Betriebsstelle</b> kommt aus dem offenen Plan[Goo]-Projekt (Punkt vom Typ
bst) oder wird mit <i>Setzen</i> in der Karte angeklickt; Name und <b>Hk-Nummernkreis</b> (Telekom-Muster <code>5263B-1/1</code>) leiten sich aus
ONKZ/ASB der Bedarfsliste ab - gibt der BVT einen anderen Block vor, traegt der Planer Stamm und Startnummer ein.</p>
<p><b>Hk clustern:</b> kuerzeste Wege von der BSt zu allen NVT ueber das Netz (Steinerbaum, nur intern), dann die Zerlegung in Straenge: jede Richtung
ab BSt ist ein eigener Strang, weiter aussen fuehrt der schwerste Ast den Strang weiter, kleinere Aeste werden eigene Straenge; Deckel
<b>hoechstens 5 NVT und 96 Fasern</b> je Strang (einstellbar). Weil Straenge Teilbaeume des Wegs sind, liegen ihre NVT immer beieinander.
Je Strang Kabelgroesse (12/24/48/96E), Reserve (Kabel minus Bedarf), freie NVT-Plaetze und der Weg aus dem Clusterbaum als Schaetzung.
Layer: <i>6 Hk-Straenge</i> (Polygone), <i>6 NVT mit Strang</i>, <i>6 Betriebsstelle</i>. Doppelklick in der Tabelle zoomt auf den Strang;
<b>Weiter: 7 Hk-Trasse je Strang</b> oeffnet Schritt 7 mit diesem Ergebnis.</p>
<p><b>Planer-Aenderungen</b> (Markus 22.09.2026, wie bei den NVT-Gebieten): NVT im Layer <i>6 NVT mit Strang</i> mit den QGIS-Auswahlwerkzeugen
markieren, Zielstrang waehlen oder einen neuen Namen tippen, <b>Verschieben</b> - Polygone, NVT-Anzahl, Fasern, Kabel und Reserve werden neu
gerechnet, Straenge ohne NVT fallen weg, Deckel-Ueberschreitungen stehen als Hinweis am Strang. Die Weg-Vorlage der geaenderten Straenge aus
Schritt 7 wird geloescht (sie stimmt nicht mehr) - dort neu rechnen; die gezeichnete Hk-Trasse bleibt. <b>Umbenennen</b>: Strang in der Tabelle
oder im Layer <i>6 Hk-Straenge</i> waehlen, neuen Namen eintragen - gilt in allen Ebenen (Straenge, NVT, Weg-Vorlage, Muffen, Hk-Trasse) und in
der Liste fuer Schritt 7 und 8. <b>Nummern aufruecken</b> schliesst Luecken im Nummernkreis (Vorschau, Rueckfrage).</p>
<p><b>Grenzen:</b> Die Straenge folgen dem Netz von Schritt 3; fehlt dort eine Landstrasse, ueberbrueckt eine gerade Netzluecke (Meldung). Ein
Verschieben prueft nicht, ob die NVT kartografisch zusammenpassen - das sieht der Planer am Polygon.</p>

<a name="hktrasse"></a>
<h3>7. Hk-Trasse je Strang</h3>
<p><b>Zweck:</b> Strang fuer Strang den Weg von der Betriebsstelle zeigen und die Hk-Trasse zeichnen - wie Schritt 5 NVT fuer NVT. Das Werkzeug
ist Unterstuetzung und Visualisierung: der Planer entscheidet, das Werkzeug erspart ihm die Recherche.</p>
<p><b>Eingang:</b> das Hk-Ergebnis aus Schritt 6 (vorbelegt mit dem juengsten), dazu die Vzk-Trassen aus Schritt 5 und der Bestand aus Schritt 1
(leer = dieselben Dateien wie in Schritt 6).</p>
<p><b>Vorlage rechnen</b> (fuer den gewaehlten Strang oder alle): Steinerbaum von der BSt zu den NVT des Strangs. <b>Die Wegefuehrung ist die Trasse</b>
(Markus 22.09.2026): Rohrtrassen mit potenziell freiem Hk-tauglichem Rohr (Kabelkanalrohr, Mikrorohr ab 20 mm; nicht Speednet 8 mm oder Mikrorohr
10 mm) kosten im Weg nur den Einzug (5,83 EUR/m, Ein- und Ausstieg je ein Kopfloch), alle anderen Telekom-Trassen bekommen als Neubau den Vorzug
(70 %), Vzk-Trassen kosten 10 %. <b>Harte Regel:</b> Netzkanten parallel zu einer Telekom-Trasse (naeher als 10 m) sind gesperrt - wo eine Trasse liegt, geht der
Weg auf die Trasse, Neubau nur dort, wo keine fuehrt; liegt Telekom einen Umweg, geht der Vorschlag mit, der Planer sieht es und weicht ab. Rohrtrassen ohne Rohr in der
Rohrliste gelten als potenziell frei und tragen den Hinweis <i>Rohr unbestaetigt</i>.
Je Abschnitt die Kabelgroesse (12/24/48/96E), Muffen an Verzweigungen und an NVT, an denen das Kabel weiterlaeuft. In der Karte: <i>7 Hk-Weg (Vorlage)</i>
gruen gestrichelt = Weg im Bestandsrohr (Label mit Rohrklasse), blau = Neubau entlang der Telekom-Trasse, grau = Neubau ohne Bestand, rot = Netzluecke;
<i>7 Muffen (Vorschlag)</i>; Tabelle und Bericht mit Kilometern je Art. Das Netz wird nur beim ersten Strang aufgebaut (5-20 s), danach ist jeder
Strang in Sekunden gerechnet.</p>
<p><b>Hk-Trasse zeichnen:</b> Strang waehlen (oder Doppelklick in der Tabelle), <b>Zeichnen</b> startet das QGIS-Zeichenwerkzeug auf <i>7 Hk-Trasse
(Planung)</i> mit Fang auf Weg, Bestand, NVT und BSt; <b>Vorlage uebernehmen</b> kopiert den gerechneten Weg des Strangs; <b>Bestand uebernehmen</b>
holt im Kartenfenster gewaehlte Bestandsrohre, Rohrzuege oder Telekom-Trassen aus Schritt 1 als Hk-Trasse mit <i>bestand = 1</i> und MegaPlan-ID
(gruen gestrichelt). <b>Aenderungen speichern</b> schreibt die QGIS-Bearbeitung ins GeoPackage. <b>Pruefen</b> meldet je Strang NVT ohne Trasse,
NVT ohne Zufuehrung (das Netz kommt bis 30 m nahe, aber kein Trassenende liegt bis 3 m am NVT - Markus 12.10., vorher galt so ein NVT als
verbunden), NVT ohne Verbindung zur BSt (Luecke) und Fasern ueber dem Deckel; der Strangstatus wird <i>geprueft</i>, wenn alles verbunden ist
und an jedem NVT eine Trasse endet. Pruefen aendert nichts an den Daten. Die Pruefung versteht
Abzweige mitten auf einer Linie, Kreuzungen ohne Knoten und Enden, die nur Zentimeter auseinanderliegen (echter Abstand bis 3 m, kein Raster).
<b>Trassen bereinigen</b> (Markus 12.10.) raeumt die Daten dazu auf: Linien werden dort geteilt, wo das Ende einer anderen Linie im Umkreis von 3 m
auf ihr liegt (Abzweig) oder wo sich zwei Linien ohne Knoten kreuzen; Enden innerhalb von 3 m rasten auf einen gemeinsamen Punkt ein. Attribute
bleiben (die uid bleibt am ersten Teil, weitere Teile heissen _t1, _t2 ...), Laengen werden neu gerechnet. Erst kommt eine Vorschau
("3 Linien an 3 Abzweigen und 1 Kreuzung geteilt; 1 Enden zusammengefuehrt"), nach Ja wird gespeichert, jede Aenderung steht im Protokoll, und die
Pruefung laeuft erneut. Weitere Regeln (Markus 12.10.): Kleinstsegmente unter 0,5 m werden auf einen Knoten eingezogen; doppelte Linien
(gleiche Geometrie) fallen weg, Bestand gewinnt; offene Enden 3 bis 10 m vom Netz bekommen automatisch ein Verbindungsstueck (quelle
<i>Bereinigung: Luecke geschlossen</i>), ausser in 15 m um NVT oder BSt (dort endet eine Zufuehrung gewollt); Ueberstaende - ein kurzes Neubaustueck
bis 15 m, das hinter einem Knoten frei endet - werden geloescht; ein NVT ohne Trasse, dem das Netz bis 15 m nahekommt, bekommt eine Zufuehrung
(<i>typ Zufuehrung</i>, Strang des NVT); Stuecke, die nur an einem fremden Strang haengen, werden nur gemeldet. Die Pruefung selbst ergaenzt
nichts: Luecken ueber 3 m bleiben dort Befund, bis <b>Trassen bereinigen</b> gelaufen ist oder der Planer sie schliesst.</p>
<p><b>Grenzen:</b> Ob ein Rohr wirklich frei ist, sagt erst die Telekom (Rohrliste, <i>Rohr unbestaetigt</i> klaeren). Freie Rohre werden noch nicht
ueber mehrere Straenge gebucht: nutzen zwei Straenge dasselbe Rohr, faellt das erst dem Planer auf. Der Stamm nahe der BSt liegt in jeder
Strang-Vorlage - die Summe der Vorlage-Kilometer zaehlt ihn mehrfach. Rohre, Kabel und Muffenbelegung legt der Planer in Plan[Goo]; der Import der
Hk-Trasse und der Muffen nach Plan[Goo] folgt in Schritt 10.</p>

<a name="kollo"></a>
<h3>8. Kollokation (Open Access)</h3>
<p><b>Zweck:</b> Alle Open-Access-Punkte finden und die Kollokationswege bis zur Betriebsstelle nach ZTV 21 Kap. 13 (MBfD/Bundesfoerderung)
zeigen (Markus 22.09.2026). Das Werkzeug zeigt, der Planer entscheidet Muffenlage und Antraege; Kollo-SNR und Kabel legt er in Plan[Goo].</p>
<p><b>Eingang:</b> das Hk-Ergebnis aus Schritt 6 mit der Hk-Trasse aus Schritt 7 (Planung des Planers, sonst die gerechnete Vorlage), die NVT mit
WE und Strang, die Betriebsstelle und die Adressen des Schnitts (WE je Adresse, Gebaeude). <b>Materialkonzept</b> aus dem Zuwendungsbescheid:
Vorgabe 5.0, Schalter auf 4.1.</p>
<p><b>Regeln:</b> Kollokationspunkt ist ab Materialkonzept 5.0 jeder NVT mit mehr als 95 WE, bis 4.1 jeder NVT; Gebaeude mit mehr als 68 WE
immer (Kollokation im Haus). Je Punkt laufen <b>3 Kollo-SNR 12x2,0</b> Richtung BSt (enden vor der BSt, MegaPlan-Belegung "Kollo-Reserve (BF)",
duerfen im regulaeren Hk-Verband mitlaufen). NVT unter 96 WE werden ab 5.0 je Strang zu <b>Kollokationsmuffen</b> gebuendelt: bis 10 NVT,
96 bis 208 WE, je WE 3 Fasern vom NVT zur Muffe auf eigenem Kollokationskabel (Minikabel 48/96 Fs, eigenes SNR), Muffentyp 2 mit hoechstens
16 SNR; die Muffe sitzt am NVT der Gruppe, der der BSt am naechsten liegt, nicht auf BSt-Gelaende. Einzelstandorte unter 96 WE brauchen einen
genehmigten Antrag (Hinweis).</p>
<p><b>Kollokation rechnen:</b> Punkte und Muffen bestimmen, je Punkt und Muffe der kuerzeste Weg auf der Hk-Trasse zur BSt, je NVT einer
Muffe der Weg zur Muffe. Layer <i>8 Kollokationspunkte</i> (Quadrat NVT, Dreieck Gebaeude), <i>8 Kollokationsmuffen</i>, <i>8 Kollo-Wege</i>
(Linienbreite und Label = SNR je Abschnitt, Kollo-SNR plus Kabel-SNR), <i>8 Kollokationskabel</i>; Tabelle mit Weg und SNR je Punkt, Bericht mit
Regeln, Punkten, Muffen und Hinweisen (Regelsatz nicht MBfD, Punkte ohne Weg, Muffen unter 96 WE).</p>
<p><b>Grenzen:</b> Ohne Hk-Trasse (Schritt 7) gibt es keine Wege - dann erst dort die Vorlage rechnen. Gebaeude werden ueber die Gebaeude-Kennung
der Bedarfsliste oder gleiche Koordinaten zusammengefasst. Die Muffenbuendelung ist ein Vorschlag je Strang; ueber Strangrenzen wird nicht
gebuendelt. Kollo-SNR und Kabel werden nicht nach Plan[Goo] geschrieben.</p>

<a name="wesi"></a>
<h3>9. Wegesicherung: Gewaesser und Landesstrassen</h3>
<h4>Wozu</h4>
<p>Zwei Faelle der Wegesicherung brauchen eigene Antraege und Fristen: Trassen, die ein <b>Gewaesser</b> queren (Wasserbehoerde,
Gewaesserunterhaltung), und Trassen auf Flurstuecken einer <b>Landesstrasse ausserhalb der Ortsdurchfahrt</b> (Strassen.NRW statt Kommune).
Das Werkzeug findet beide fuer alle Tiefbautrassen des Projekts und liefert Layer, Liste und Bericht.</p>
<h4>Ablauf</h4>
<ol>
<li>Trassen: das offene Plan[Goo]-Projekt (Vorgabe) oder ein Plan[Goo]-GeoPackage. Geprueft werden Tiefbautrassen (TYPE underground) ohne
    rohrfreie ("blaue") Trassen, Hauszufuehrungen eingeschlossen. Der NVT je Trasse kommt aus dem Versorgungsbereich, in dem die Trassenmitte liegt.</li>
<li>Regeln: Kreis um den Querungspunkt (10 m), Achsabstand ATKIS zu OSM-Landesstrasse (12 m, zweibahnige Strassen), Mindestlaenge im
    Flurstueck (1 m). Land automatisch aus der Lage.</li>
<li><b>Spezialfaelle pruefen</b>: ALKIS/ATKIS per WFS (Gewaesserachsen auch Graeben, Fliess- und stehende Gewaesser, Bauwerke im
    Gewaesserbereich = Durchlaesse, Strassenachsen, Ortslage, Flurstuecke) und OSM per Overpass (Gewaesser, Strassen mit ref). Je nach
    Gebiet 1 bis 3 Minuten.</li>
<li>Ergebnis: Layer <b>Trassen mit Gewaesserquerung</b> (blau), <b>Trassen auf Landesstrasse</b> (orange), <b>WeSi-Flaechen</b>
    (blau = Gewaesser, gelb = Strassen.NRW-Flurstueck), dazu <code>wesi_spezialfaelle_..._bericht.md</code> und <code>_liste.json</code>.</li>
</ol>
<h4>Wie geprueft wird</h4>
<ul>
<li>Gewaesserquerung: Kreuzung der Trasse mit einer Gewaesserachse oder -flaeche. Feld <i>durchlass_5m</i> = ja: ein ALKIS-Bauwerk im
    Gewaesserbereich liegt in 5 m - die Trasse quert vermutlich im Strassendamm ueber dem Durchlass, das ist meist kein Gewaesserantrag.</li>
<li>Landesstrasse: OSM ref "L ..." plus ATKIS-Strassenachse. Ortsdurchfahrt = Achse innerhalb der geschlossenen ATKIS-Ortslage
    (Naeherung, die amtlichen OD-Grenzen von Strassen.NRW sind nicht offen). Flurstueck der Landesstrasse = ALKIS-Flurstueck, das die freie
    Achse mindestens 5 m durchlaeuft. Eigentuemer stehen nicht im offenen ALKIS: Nachbarflurstuecke (Bankett, Boeschung, Graben) koennen
    ebenfalls Strassen.NRW gehoeren und fehlen.</li>
<li>ALKIS/ATKIS im AAA-Modell gibt es offen nur in NRW. In anderen Laendern laeuft die Gewaesserpruefung mit OSM, die Landesstrassenpruefung
    entfaellt (Hinweis im Bericht).</li>
</ul>
<p>Herkunft: Einzelauswertung Bielefeld-Eckardtsheim (10.09.2026), hier fuer jedes Projekt nutzbar gemacht.</p>

<a name="w4"></a>
<h3>10. Uebergabe nach Plan[Goo]</h3>
<h4>Wozu</h4>
<p>Der letzte Schritt. Die Schritte 1 bis 4 rechnen in eigenen GeoPackages, ohne Plan[Goo] anzufassen. Erst hier entsteht das Plan[Goo]-Projekt:
ein neues leeres Projekt wird angelegt und dann Schritt fuer Schritt befuellt, in der Reihenfolge, in der Plan[Goo] die Objekte braucht -
APL, dann NVT mit Projekt und Versorgungsbereich, dann Trassen. Jeder Schritt zeigt vorher seine Zahlen und schreibt ein Backup-Zip.</p>
<h4>Ablauf</h4>
<ol>
<li><b>Projekt</b>: <i>Neues leeres Projekt anlegen</i> - Ordner (Vorgabe <code>C:\\Users\\&lt;Nutzer&gt;\\PlanGoo\\&lt;Stamm&gt;</code>, kurz und nicht
    synchronisiert; Plan[Goo] bricht ueber 259 Zeichen Pfad ab) und Name (Vorgabe <code>PlGoo_&lt;Stamm&gt;</code>). <b>Anlegen</b> fragt den
    Ausbautreiber ueber den Plan[Goo]-Dialog ab, kopiert die Plan[Goo]-Vorlagen (<code>&lt;Name&gt;.gpkg</code> + <code>&lt;Name&gt;.db</code>, wie das
    Menue "Leeres Plan[Goo] V2-Projekt speichern unter") und nimmt das Projekt im Offline-Reiter von Plan[Goo] in Bearbeitung. Alternativ
    <i>Offenes Plan[Goo]-Projekt verwenden</i>. Der Kasten darunter zeigt den Stand: APL, NVT, Trassen.</li>
<li><b>2 Adressen als APL</b>: Adresspruefung aus Schritt 2. Vorhandene APL bekommen WE, Gewerbe, P2P, Gebaeudenutzung; fehlende werden neu
    angelegt (ASB aus dem ersten APL, im leeren Projekt aus ONKZ/ASB der Bedarfsliste). <i>ignorieren</i> wird immer ausgelassen, rote Adressen
    mit dem Haken.</li>
<li><b>3 Gebiete, NVT, Zuordnung</b>: Schnitt aus Schritt 3, Standorte aus Schritt 4 werden automatisch gefunden (gleicher Stamm). Legt je Gebiet
    Projekt, NVT-Punkt und Versorgungsbereich an und haengt jede Adresse an ihren NVT (Einzelheiten unten).</li>
<li><b>5 NVT-Trassen und 7 Hk-Trasse</b>: beide Dateien, dann <b>Kondensat importieren</b> - nur wenn alle NVT und alle Straenge geprueft sind
    (Einzelheiten unten).</li>
</ol>
<p>Ein Schritt laesst sich wiederholen, wenn ein Schritt neu gerechnet wurde: Adressen setzen dann nur Attribute, Gebiete kennzeichnen die
alten NVT als _alt (Haken); das Kondensat der Trassen wird beim Wiederholen erneut angelegt - vorher in Plan[Goo] die alten Trassen entfernen oder das Backup-Zip nutzen.</p>
<h4>Was Schritt 3 anlegt</h4>
<ul>
<li>Je Gebiet ein <b>Projekt</b> auf Netzebene Vzk mit Gebiets-ID, ONB, ASB und Ausbautreiber wie das offene Projekt.</li>
<li>Der <b>NVT-Punkt</b> (Typ nvt) am geprueften Standort bzw. Sitz, mit dem Gehaeuse nach Ausbautreiber (seit 30.09.2026): Eigenausbau
    GF-NVt22 L (Eigen) GH_OCL, MBfD GF-NVt22 L (BF) GH_NCL wie in den Telekom-Angeboten (Dornberg: 16x GH_NCL), Regelsatz XS GH_NCLXS.
    Ein vorhandenes NVT-Gehaeuse wird uebernommen, wenn es zum Ausbautreiber passt (Sichert/Raycap gelten auch), sonst steht das im Protokoll.
    Dazu die Materialvorlagen des Plugins (Bodenplatte, UNI-Kassetten), Planungsaktivitaet im Projekt, Adresse der ersten Adresse im Gebiet
    (Abnahme verlangt eine Adresse). APL bekommen kein Gf-AP-Material - auch das Telekom-Angebot traegt keins, den HUEP setzt Plan[Goo].</li>
<li>Der <b>Versorgungsbereich</b> als Polygon Typ nvt mit Bezug auf den NVT, in Gebietsfarbe.</li>
<li>Jede <b>Adresse</b> (KLS-ID, sonst Strasse+Hausnummer) haengt an ihrem NVT (PARENT) und bekommt eine Planungsaktivitaet im neuen Projekt.</li>
<li>Vorhandene NVT und ihre Projekte bekommen den Suffix <i>_alt</i>, ihre Bereiche werden geloescht (Haken). Vorher Backup-Zip
    <code>&lt;Projekt&gt;_nvt_&lt;Datum&gt;.zip</code> neben der Projektdatenbank.</li>
</ul>
<p>Nicht angelegt werden Rohre und Kabel. Adressen ohne APL im Projekt stehen im Protokoll.</p>
<h4>Trassen: Kondensat aus Schritt 5 und 7 (Markus 12.10.)</h4>
<p>Die Zeile <b>5 NVT-Trassen</b> nimmt die Trassendatei aus Schritt 5, die Zeile <b>7 Hk-Trasse</b> das Hk-GeoPackage aus Schritt 6/7.
<b>Kondensat importieren</b> geht nur, wenn beide Planungen final sind: alle NVT in Schritt 5 geprueft (oder schon uebertragen) und alle Straenge
in Schritt 7 geprueft. Sonst bleibt die Uebergabe blockiert und das Fenster nennt, was fehlt. Dann werden beide Planungen zusammengelegt:
Stuetzpunkte bis 0,05 m rasten aufeinander ein (dieselbe Toleranz wie die NVT-Anbindung), jede Kreuzung und Beruehrung wird ein Knoten,
deckungsgleiche und ueberlappende Abschnitte werden ein Stueck, Linien werden an Knoten getrennt und nicht zu einer Gesamtlinie verschmolzen.
Je Stueck steht die <i>Herkunft</i> NVT, HK oder HK+NVT; Attribute kommen zuerst aus der NVT-Planung (Bauverfahren, Oberflaeche, Zulage, Lagehinweis,
WeSi, Hauszufuehrung), sonst aus der Hk-Planung, Bestand gilt, sobald eine Quelle Bestand ist; Konflikte stehen im Protokoll. Vor dem Import zeigt
das Fenster die Selbstpruefung: Stuecke und Meter vorher und nachher, Ueberlappung nach dem Dissolve (muss 0 sein). Das Kondensat liegt als
Ebene <i>uebergabe</i> im Trassen-GeoPackage, nach Plan[Goo] geht es mit demselben Attributsatz wie bisher, der Endstand ist das Kondensat.
Beide Planungen tragen dafuer dasselbe Schema (die Hk-Planung hat seit 0.20.0 die Felder Zulage, Lagehinweis, WeSi, Trassentyp); leere Felder sind
erlaubt.</p>

<a name="zfp"></a>
<h3>11. ZFP222 Ringauftraege</h3>
<p><b>Zweck:</b> Zum Schluss, wenn Plan[Goo] fertig ist, das Telekom-Formblatt <b>ZFP222 "Ringauftraege erzeugen v3.4"</b> (.xlsm) automatisch fuellen,
damit die Auftraege ausgerollt werden koennen (Markus 22.09.2026). Block 4 (NVt Nachinstallation) und Block 5 (HVt) bleiben leer, die Spalte SMA fuellt
die Telekom, Plan[Goo] ist die einzige Quelle.</p>
<p><b>Eingang:</b> das offene Plan[Goo]-Projekt (oder ein PlGoV2_....gpkg mit .db daneben). Gelesen werden die NVT mit Hk-Bezeichnung (Feld
NVT_HK_NAMEN), Montageort (Adresse des NVT-Standorts, sonst der naechste APL), KLS-ID und APL-Anzahl, die Betriebsstelle (KLS-ID, wenn eingetragen),
und aus der Projektdatenbank ONKZ (ONB) und AsB je Hk-Projekt sowie das Vorhaben als Projekt-ID. <b>Projekt lesen</b> belegt den Kopf vor und zeigt die
Pruefhinweise: NVT ohne Hk-Bezeichnung (blockierend), NVT ohne Adresse, doppelte Namen, fehlende oder mehrere BSt, mehrere AsB.</p>
<p><b>Kopf:</b> Auftragsart (PUSH PK, MBfD PASSED, MBfD PREPARED), Gebietsname, BA-ID, Projekt-ID, ONKZ, AsB, KLS-ID der BSt (Eintrag L9.97R), wahlweise
ein Termin fuer alle Zeilen. Leere Felder werden aus dem Projekt ergaenzt, den Rest traegt der Planer ein.</p>
<p><b>ZFP222 fuellen:</b> Block 1 je Hk-Strang (Nr., HK-Bez., Auftragsbezeichnung <code>HK_{{HK}}_{{Anzahl NVT}}_{{ONKZ}}_{{AsB}}_FTTH_{{NVT_NVT_...}}</code>,
Montageort = erster NVT), Block 2 je NVT (<code>NVT_{{NVT}}_{{ONKZ}}_{{AsB}}_FTTH_{{HK}}</code>), Block 3 je NVT-Gebiet (<code>NE4_{{Gebiets-ID}}_{{ONKZ}}_{{AsB}}_FTTH_{{HK}}</code>);
Hk mit anderem AsB als der Kopf bekommen den AsB in Spalte A "AsB fuer Fremdansch.". Zeilen werden je Block eingefuegt, verbundene Zellen und die
benannten Bereiche des Formblatts wandern mit, die Makros bleiben erhalten. Ausgabe: <code>ZFP222_&lt;Vorhaben&gt;_&lt;Datum&gt;.xlsm</code>, dieselbe Liste
ohne Makros als <code>_Auftragsliste.xlsx</code> (Blatt Pruefung) und ein Bericht. Danach in Excel oeffnen, Kopf pruefen, Makro "Auftraege erzeugen"
starten - GF-Codes und PGZ zieht das Formblatt selbst aus dem Blatt VORLAGEN.</p>
<p><b>Grenzen:</b> Die Vorlage v3.4 ist mitgeliefert; eine neuere Version der Telekom kann als eigene Vorlage gewaehlt werden, solange Blatt "Form" und
die benannten Bereiche Block1 bis Block3 gleich heissen. Ob das Makro mit den eingefuegten Zeilen laeuft, prueft der Planer in Excel. Mehrere BSt im
Projekt: KLS-ID der richtigen eintragen.</p>

<a name="layer"></a>
<h3>Layer und Farben</h3>
<h4>Werkzeug 2, Gruppe "Adresspruefung ..."</h4>
<table>
<tr><th>Layer</th><th>Bedeutung</th></tr>
<tr><td>NVT-Sitz / Standort (Vorschlag)</td><td>NVT-Symbol wie in Plan[Goo] (Kreis mit Quadrat) in Fiberation-Orange = Vorschlag des Werkzeugkastens. In Werkzeug 4 zeigt die Farbe den Gesamtstatus der Standortsicherung: Orange OFFEN, Rot Abgelehnt, Gruen Gesichert; Alternativstandorte kleiner; Bestand-NVT schwarz. In Plan[Goo] steht Rot fuer NVt Planung, Schwarz fuer Bestand.</td></tr>
<tr><td>Lagevorschlag (Callout) / Linie</td><td>Werkzeug 2: oranger Ring am vorgeschlagenen Ort mit Label 'Adresse / Vorschlag: ...', gestrichelte Linie von der alten Lage. Verschwindet, sobald die Adresse geprueft oder ignoriert ist.</td></tr>
<tr><td>NVT-Gebiete</td><td>Eine Farbe je Gebiet, Fuellung 12 %, kraeftige Grenze. Layer Ampel (Grenzen): gestrichelte Grenze nur bei gelb/rot, ohne Fuellung.</td></tr>
<tr><td>Adressen</td><td>Punkte, Ampel gruen/gelb/rot, Label = Hinweis ab Massstab 1:3000. Spalten status und kommentar gehoeren dem Planer.</td></tr>
<tr><td>Adressen ohne Gebaeude</td><td>Violette Quadrate: Platzhalter-Hausnummer oder kein Gebaeude.</td></tr>
<tr><td>Fehlender Bedarf</td><td>Grundrisse mit Callout 'Adresse / fehlt in der Bedarfsliste'. Rot = Luecke in der Nummernfolge, orange = Strasse in der Liste,
    grau = am Rand. Nur offene; status geprueft/ignorieren blendet aus.</td></tr>
<tr><td>Bauluecke moeglich</td><td>Violette Flurstuecke mit Callout 'Bauluecke moeglich: Strasse Nummer / Nutzung, m2, Nachbarn'. Voll = zwischen bebauten
    Nachbarn, gestrichelt = Eck- oder Randgrundstueck. Nur offen/geprueft; uebernommen und ignorieren sind ausgeblendet.</td></tr>
<tr><td>Gebaeude ohne Adresse</td><td>Gestrichelte Grundrisse, ausgeblendet: ALKIS-Gebaeude ohne Lagebezeichnung und ohne Listenadresse. Rot = Wohngebaeude, gelb = Gewerbe u. a.</td></tr>
<tr><td>ALKIS-Gebaeude</td><td>Graue Grundrisse, ausgeblendet. Zur Kontrolle.</td></tr>
</table>
<h4>Werkzeug 3, Gruppe "NVT-Gebiete ..."</h4>
<table>
<tr><th>Layer</th><th>Bedeutung</th></tr>
<tr><td>NVT-Gebiete</td><td>Polygone, je NVT eine Farbe, halbtransparent, Label mit Kennzahlen. Spalten status und kommentar gehoeren dem Planer.</td></tr>
<tr><td>Adressen</td><td>Punkte in der Farbe ihres Gebiets. Spalte nvt = Zuordnung, hier aendert der Planer.</td></tr>
<tr><td>NVT-Sitz (Vorschlag)</td><td>Nur in Schritt 4 und 5 sichtbar (Schritt 3 gibt nur die Polygone aus, Markus 22.09.2026; der Sitz steht
    weiter im GeoPackage). Schwarzes Quadrat, 2,5 m neben der Trasse auf der Seite mit den meisten Adressen. Standort im oeffentlichen
    Raum prueft Werkzeug 4.</td></tr>
<tr><td>Ampel (Grenzen)</td><td>Ausgeblendet. Gestrichelte Umrandung gruen/gelb/rot mit dem Grund als Label.</td></tr>
<tr><td>Netz</td><td>Ausgeblendet. Das Trassennetz, auf dem gerechnet wurde.</td></tr>
</table>
<h4>Ampel</h4>
<table>
<tr><th>Farbe</th><th>Adressen (Werkzeug 2)</th><th>Gebiete (Werkzeug 3)</th></tr>
<tr><td>gruen</td><td>amtlich bestaetigt, im Gebaeude, keine Auffaelligkeit</td><td>alle Grenzen eingehalten</td></tr>
<tr><td>gelb</td><td>pruefen: Kenner ohne A, neben dem Gebaeude, 0 WE, Bewertung schwach, Sonderfall</td><td>ueber weicher Grenze (Adressen, WE) oder zu klein</td></tr>
<tr><td>rot</td><td>Dublette, keine Koordinate, kein Gebaeude in 25 m ohne amtliche Adresse</td><td>ueber harter Grenze: Adressen, SNR, PON, Kassetten, Vzk-Weg</td></tr>
</table>

<a name="begriffe"></a>
<h3>Begriffe</h3>
<table>
<tr><th>Begriff</th><th>Bedeutung</th></tr>
<tr><td>Nachrechnen</td><td>Bewertet den vom Planer geaenderten Stand (Spalte nvt) neu: Polygone, Kennzahlen, Ampel. Schneidet nicht neu.</td></tr>
<tr><td>Schneiden</td><td>Rechnet den Vorschlag komplett neu. Noetig bei anderem Regelsatz, anderen Grenzen oder anderem Netz.</td></tr>
<tr><td>Sitz</td><td>Vorgeschlagener NVT-Standort: Medoid des Gebiets auf dem Netz, seitlich versetzt. Kein geprueftes Standortergebnis.</td></tr>
<tr><td>Vzk max</td><td>Laengster Weg vom Sitz zu einer Adresse des Gebiets ueber das Netz.</td></tr>
<tr><td>Baum</td><td>Summe aller Vzk-Wege des Gebiets (Kantenunion). Naeherung fuer die Grabenlaenge.</td></tr>
<tr><td>Anschluesse</td><td>FTTH-Anschluesse nach ZTV 21: WE + Gewerbeeinheiten + pauschaler Zusatzbedarf.</td></tr>
<tr><td>PON-Fasern</td><td>Faserbedarf am NVT fuer 1:32-Koppler, gerechnet aus den Anschluessen je Gebaeude.</td></tr>
<tr><td>Kassetten</td><td>UNI-Kassetten im Gf-NVt 22 L: 1 je Gebaeude + Koppler; 144 minus 18 fuer die Hk-Fasern.</td></tr>
<tr><td>Kenner</td><td>Telekom-Spalte adress_qualitaet_kenner. A = amtliche Adresse mit Gebaeude. Weitere Buchstaben noch ungeklaert.</td></tr>
<tr><td>Regelsatz</td><td>Grenzen je Ausbautreiber aus ZTV 21. Vorwahl nach Ausbau_Sponsor der Liste.</td></tr>
</table>

<a name="helfer"></a>
<h3>Plan[Goo]-Helfer und Einstellungen</h3>
<p><b>Trassenbefuellung Eigenausbau:</b> blendet die automatische Trassenbefuellung (Reiter Funktionen) auch fuer Eigenausbau ein und
macht die Regelsatz-Auswahl sichtbar (MBfD x12, Eigenausbau x7, Eigenausbau ZTV 21 + Sonderbedarf Fiberation). Hebt die Grenze von
10 Hauszufuehrungsstuecken auf 100, Wegsuche mit Tracer zuerst. Nach jedem QGIS-Start neu druecken.</p>
<p><b>Projektpfad pruefen:</b> Plan[Goo] bricht beim Oeffnen ab, wenn der Pfad des Backup-Zips 259 Zeichen ueberschreitet. Der Knopf prueft
und legt eine Arbeitskopie unter <b>C:\\PlanGoo\\&lt;Projektname&gt;\\</b> an.</p>
<p><b>Einstellungen:</b> Startwarnungen von Plan[Goo] unterdruecken (QGIS-Thema, Sprache). Einzige Automatik. Dazu die
<b>Materialkonzept-Version</b> fuer MBfD-Gebiete (3.0 bis 5.0, steht im Zuwendungsbescheid; Vorgabe 5.0, solange keiner vorliegt).
Sie wirkt auf Schritt 2 (Bedarf), 3 (Regelsatz) und 8 (Kollokation). Ob ein Projekt MBfD ist, erkennt der Werkzeugkasten am Ausbautreiber
(Plan[Goo] AUSBAUTREIBER, Spalte sponsor) oder am Angebotslayer - einmal zentral fuer alle Schritte.</p>

<a name="fragen"></a>
<h3>Wenn etwas nicht klappt</h3>
<table>
<tr><th>Symptom</th><th>Ursache und Abhilfe</th></tr>
<tr><td>Fenster verschwunden (ausserhalb des Bildschirms, zweiter Monitor abgesteckt)</td><td>Knopf in der Werkzeugleiste oder im Werkzeugkasten noch einmal druecken: das Fenster kommt in den sichtbaren Bereich. Jedes Fenster hat Minimieren, Maximieren und Schliessen und einen eigenen Eintrag in der Taskleiste; der Inhalt ist scrollbar, Groesse und Lage werden gemerkt.</td></tr>
<tr><td>Gebiete ohne Sitz, ein Gebiet mit sehr vielen Adressen und Vzk 0</td><td>Netz deckt einen Ortsteil nicht ab. Protokoll lesen: "Adressen ohne Netzanschluss".
    Andere Netzquelle waehlen oder OSM-Cache (osm_cache.json neben der Quelle) loeschen und neu abrufen.</td></tr>
<tr><td>Werkzeug 0: SSL-Fenster "Unable to Get Local Issuer Certificate"</td><td>Kommt beim allerersten Kontakt mit basemap.de (BKG) oder den
    Bundeswasserstrassen (WSV) vor: deren Wurzelzertifikate (HARICA, D-Trust) fehlen auf einem frischen Windows und werden erst beim ersten
    Zugriff von Windows nachgeladen. Fenster mit "Ignorieren" schliessen, Knopf "Layer laden" noch einmal druecken - danach gilt das Zertifikat.
    Kommt es wieder: im SSL-Fenster "Ausnahme speichern" waehlen.</td></tr>
<tr><td>ALKIS-Abruf schlaegt fehl</td><td>Kein Netz oder Bundesland ohne offenen Dienst (Bayern, Bremen, Thueringen). Pruefung laeuft ohne Gebaeude weiter.</td></tr>
<tr><td>Uebernahme: 0 APL geaendert</td><td>Schluessel passt nicht. Abgleich ueber KLS-ID, sonst Strasse + Hausnummer. Projekt und Liste vergleichen.</td></tr>
<tr><td>Nachrechnen: "Netzgraph fehlt"</td><td>Die Datei <code>..._graph.pkl</code> neben dem GeoPackage wurde geloescht. Neu schneiden.</td></tr>
<tr><td>Laufzeit lang</td><td>Plan[Goo]-Trassen 2 bis 3 Minuten, mit Varianten das Dreifache. OSM ist schneller, aber nur Naeherung.</td></tr>
<tr><td>Fehlerfenster</td><td>Einzelheiten stehen im Protokoll des Dialogs. Text kopieren und weitergeben.</td></tr>
</table>

<h3>Installation und Updates</h3>
<p>Erweiterungen &gt; Verwalten &gt; "Aus ZIP installieren" mit <code>fiberation_werkzeugkasten.zip</code> aus der Team-Ablage
(02_Planung\\12_Software&amp;Tools). Nach einem Update QGIS neu starten.</p>
<p class="grau" style="font-size:11px">{fuss}</p>
"""


KAPITEL = [("Schnellstart", "schnell"), ("0 Umfeld", "umfeld"), ("1 Bestand", "bestand"), ("2 Adressen", "w1"), ("3 NVT-Gebiete", "w2"), ("4 Standorte", "w3"),
           ("5 Trassen", "trassen"), ("6 Hk clustern", "hk"), ("7 Hk-Trasse", "hktrasse"), ("8 Kollokation", "kollo"), ("9 Wegesicherung", "wesi"), ("10 Uebergabe", "w4"), ("11 ZFP222", "zfp"), ("Layer und Farben", "layer"),
           ("Begriffe", "begriffe"), ("Helfer", "helfer"), ("Probleme", "fragen")]


class AnleitungWidget(QWidget):
    """Die Anleitung als Seite (im Hauptfenster) oder als Inhalt des Fallback-Dialogs: Textbrowser, darunter die Kapitelknoepfe.
    Escape meldet 'zurueck' (im Hauptfenster: zur Uebersicht)."""
    zurueck = pyqtSignal()

    def __init__(self, parent=None, mit_kopf=False):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        if mit_kopf:
            kopf = QHBoxLayout()
            kopf.addWidget(ci.logo_label(36))
            kopf.addStretch(1)
            t = QLabel("Anleitung")
            t.setStyleSheet("font-size:18px; font-weight:700;")
            kopf.addWidget(t)
            lay.addLayout(kopf)
        self.tb = QTextBrowser()
        self.tb.setOpenExternalLinks(False)
        self.tb.setHtml(ANLEITUNG.format(orange=ci.ORANGE, grau=ci.GRAU, fuss=ci.fuss_text(version())))
        lay.addWidget(self.tb, 1)
        self.knoepfe = QHBoxLayout()
        self.knoepfe.setSpacing(6)
        for text, a in KAPITEL:
            b = QPushButton(text)
            b.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda *_, a_=a: self.springe(a_))
            self.knoepfe.addWidget(b)
        self.knoepfe.addStretch(1)
        lay.addLayout(self.knoepfe)

    def springe(self, anker):
        if anker:
            self.tb.scrollToAnchor(anker)
            QTimer.singleShot(0, lambda: self.tb.scrollToAnchor(anker))   # nach dem ersten Layout noch einmal, sonst stimmt die Lage nicht

    def keyPressEvent(self, ev):
        if ev.key() == Qt.Key_Escape:
            ev.accept()
            self.zurueck.emit()
            return
        super().keyPressEvent(ev)


def zeige_anleitung(parent=None, anker=None):
    """Anleitung zeigen: als Seite im Werkzeugkasten-Fenster, wenn das Plugin laeuft (von dort fuehren Uebersicht, Schrittnummern und
    Escape zurueck); sonst als eigener Dialog."""
    try:
        from qgis.utils import plugins
        pl = plugins.get("fiberation_werkzeugkasten")
        if pl is not None and hasattr(pl, "zeige"):
            pl.zeige("anleitung", anker=anker)
            return
    except Exception:
        pass
    d = QDialog(parent)
    d.setWindowTitle(NAME + " - Anleitung")
    d.resize(900, 760)
    lay = QVBoxLayout(d)
    lay.setContentsMargins(16, 12, 16, 12)
    w = AnleitungWidget(d, mit_kopf=True)
    lay.addWidget(w, 1)
    schl = QPushButton("Schliessen")
    schl.setStyleSheet(ci.STIL_KNOPF)
    schl.clicked.connect(d.accept)
    w.knoepfe.addWidget(schl)
    w.zurueck.connect(d.accept)
    from . import fenster
    fenster.einrichten(d, "anleitung", None, eigenes_fenster=False, scrollen=False)
    w.springe(anker)
    d.exec_()
