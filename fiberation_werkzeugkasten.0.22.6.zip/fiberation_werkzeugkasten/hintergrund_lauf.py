# -*- coding: utf-8 -*-
"""Kindprozess fuer hintergrund.starten(): liest den Auftrag (JSON), ruft die Kernfunktion, meldet LOG/FORTSCHRITT zeilenweise, schreibt das
zusammengefasste Ergebnis als JSON. Laeuft mit dem QGIS-Python (python-qgis-ltr.bat), ohne GUI."""
import importlib
import json
import os
import sys
import traceback


def probe(sekunden=1.0, datei=None, log=print, fortschritt=None):
    """Selbsttest fuer hintergrund.starten: wartet, meldet Fortschritt, schreibt optional eine Datei. -> dict"""
    import time
    schritte = max(1, int(sekunden / 0.1))
    for i in range(schritte):
        time.sleep(0.1)
        if fortschritt:
            fortschritt(100.0 * (i + 1) / schritte, "Probe {}/{}".format(i + 1, schritte))
        if datei and i == 0:
            with open(datei, "w", encoding="utf-8") as f:
                f.write("probe\n")
    log("Probe fertig")
    return {"ok": True, "sekunden": sekunden, "datei": datei}


def main(argv):
    with open(argv[0], encoding="utf-8") as f:
        spec = json.load(f)
    sys.path.insert(0, spec["pfad"])
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

    def log(t):
        print("LOG " + str(t).replace("\r", "").replace("\n", " | "), flush=True)

    def fortschritt(p, t):
        print("FORTSCHRITT {}|{}".format(float(p), str(t).replace("\n", " ")), flush=True)

    app = None
    try:
        from qgis.core import QgsApplication
        app = QgsApplication([], False)
        app.initQgis()
    except Exception as e:
        log("QGIS im Kindprozess nicht gestartet ({!r}) - Kern laeuft ohne".format(e))
    try:
        m = importlib.import_module(spec["modul"])
        fn = getattr(m, spec["funktion"])
        r = fn(*spec["args"], log=log, fortschritt=fortschritt, **spec["kwargs"])
        z = getattr(m, spec["funktion"] + "_zusammenfassung", None) or getattr(m, "lauf_zusammenfassung", None)
        out = z(r) if z is not None else r
        with open(spec["ergebnis"], "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, default=str)
        print("FERTIG", flush=True)
        code = 0
    except Exception as e:
        with open(spec["ergebnis"], "w", encoding="utf-8") as f:
            json.dump({"fehler": repr(e), "rueckverfolgung": traceback.format_exc()}, f, ensure_ascii=False)
        print("FEHLER " + repr(e), flush=True)
        code = 1
    if app is not None:
        try:
            app.exitQgis()
        except Exception:
            pass
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
