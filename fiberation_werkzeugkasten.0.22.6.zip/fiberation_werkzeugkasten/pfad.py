# -*- coding: utf-8 -*-
"""Pfadlaengen-Pruefung fuer Plan[Goo]-Projekte und lokale Arbeitskopie unter C:\\PlanGoo\\<Projektname>\\.

Plan[Goo] V2 legt vor einer Datenbank-Migration ein Backup "<gpkg-Name>_db_JJJJ-MM-TT_HH-MM.zip" im Projektordner an. QGIS ist auf
Windows nicht "longPathAware", deshalb gilt die Grenze von 259 Zeichen auch bei freigeschalteten langen Pfaden. Liegt das Projekt tief
in einer Team-Ablage, scheitert das Oeffnen mit "FileNotFoundError ... .zip".
"""
import os
import re
import shutil
import subprocess
import zipfile
from datetime import datetime

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QTextEdit,
                                 QVBoxLayout)

from . import ci

GRENZE = 259
BACKUP_ZUSATZ = len("_db_2026-09-10_08-08.zip")   # 24 Zeichen, die Plan[Goo] an den GeoPackage-Namen haengt
ZIEL_WURZEL = r"C:\PlanGoo"


def projektdateien(pfad):
    """(db, gpkg, info, zip) fuer einen gewaehlten Pfad (.db, .gpkg oder .zip). Fehlende Teile None."""
    pfad = os.path.abspath(pfad)
    ordner, name = os.path.split(pfad)
    stamm, ext = os.path.splitext(name)
    if ext.lower() == ".zip":
        return None, None, None, pfad
    db = os.path.join(ordner, stamm + ".db")
    gpkg = os.path.join(ordner, stamm + ".gpkg")
    info = os.path.join(ordner, "info.txt")
    return (db if os.path.exists(db) else None, gpkg if os.path.exists(gpkg) else None,
            info if os.path.exists(info) else None, None)


def laengen(pfad):
    """Pfadlaengen, wie Plan[Goo] sie erzeugt: laengster Dateipfad und der Backup-Zip-Pfad."""
    db, gpkg, info, zp = projektdateien(pfad)
    if zp:
        # Plan[Goo] entpackt das Zip in einen Ordner neben dem Zip: <Ordner>/<Zipname ohne .zip>/<Inhalt>
        ordner = os.path.splitext(zp)[0]
        namen = []
        try:
            with zipfile.ZipFile(zp) as z:
                namen = [n for n in z.namelist() if n.lower().endswith((".db", ".gpkg"))]
        except Exception:
            pass
        stamm = os.path.splitext(os.path.basename(namen[0]))[0] if namen else os.path.basename(ordner)
        basis = os.path.join(ordner, stamm)
    else:
        basis = os.path.splitext(gpkg or db or pfad)[0]
    return {"datei": len(basis + ".gpkg"), "backup": len(basis) + BACKUP_ZUSATZ, "basis": basis}


def projektname(pfad):
    stamm = os.path.splitext(os.path.basename(pfad))[0]
    stamm = re.sub(r"[^A-Za-z0-9_\-]+", "_", stamm).strip("_")
    return stamm[:60] or "Projekt"


def arbeitskopie(pfad, ziel_wurzel=ZIEL_WURZEL, name=None):
    """Kopiert db+gpkg(+info.txt) bzw. entpackt das Zip nach <ziel_wurzel>\\<name>\\, schreibt HERKUNFT.txt. -> Zielordner"""
    name = name or projektname(pfad)
    ziel = os.path.join(ziel_wurzel, name)
    n = 1
    while os.path.exists(ziel) and os.listdir(ziel):
        n += 1
        ziel = os.path.join(ziel_wurzel, "{}_{}".format(name, n))
    os.makedirs(ziel, exist_ok=True)
    db, gpkg, info, zp = projektdateien(pfad)
    kopiert = []
    if zp:
        with zipfile.ZipFile(zp) as z:
            for m in z.namelist():
                if m.lower().endswith((".db", ".gpkg")) or os.path.basename(m).lower() == "info.txt":
                    with z.open(m) as q, open(os.path.join(ziel, os.path.basename(m)), "wb") as out:
                        shutil.copyfileobj(q, out)
                    kopiert.append(os.path.basename(m))
    else:
        for q in (db, gpkg, info):
            if q:
                shutil.copy2(q, ziel)
                kopiert.append(os.path.basename(q))
    with open(os.path.join(ziel, "HERKUNFT.txt"), "w", encoding="utf-8") as f:
        f.write("Quelle: {}\nKopiert am {} (Fiberation Werkzeugkasten, Pfadlaengen-Pruefung).\n"
                "Nach der Bearbeitung das Export-Zip zurueck in die Team-Ablage legen; die Quelle wurde nicht veraendert.\n"
                .format(pfad, datetime.now().strftime("%d.%m.%Y %H:%M")))
    return ziel, kopiert


class PfadDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Fiberation Werkzeugkasten - Projektpfad pruefen")
        self.setMinimumWidth(720)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 16, 20, 14)
        lay.setSpacing(10)
        lay.addWidget(ci.logo_label(36))
        erkl = QLabel("Plan[Goo]-Projekt waehlen (Export-Zip, .db oder .gpkg). Geprueft wird der laengste Pfad, den Plan[Goo] beim "
                      "Oeffnen anlegt (Backup-Zip mit Zeitstempel). Grenze in QGIS: {} Zeichen.".format(GRENZE))
        erkl.setWordWrap(True)
        erkl.setStyleSheet("color:{};".format(ci.GRAU))
        lay.addWidget(erkl)
        zeile = QHBoxLayout()
        self.feld = QLineEdit()
        self.feld.setPlaceholderText("Pfad zum Projekt ...")
        w = QPushButton("Waehlen")
        w.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        w.clicked.connect(self._waehlen)
        zeile.addWidget(self.feld, 1)
        zeile.addWidget(w)
        lay.addLayout(zeile)
        self.ergebnis = QTextEdit()
        self.ergebnis.setReadOnly(True)
        self.ergebnis.setMinimumHeight(150)
        lay.addWidget(self.ergebnis)
        knoepfe = QHBoxLayout()
        self.k_pruefen = QPushButton("Pruefen")
        self.k_pruefen.setStyleSheet(ci.STIL_KNOPF)
        self.k_pruefen.clicked.connect(self._pruefen)
        self.k_kopie = QPushButton("Arbeitskopie nach {} anlegen".format(ZIEL_WURZEL))
        self.k_kopie.setStyleSheet(ci.STIL_KNOPF)
        self.k_kopie.setEnabled(False)
        self.k_kopie.clicked.connect(self._kopie)
        self.k_ordner = QPushButton("Zielordner oeffnen")
        self.k_ordner.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_ordner.setEnabled(False)
        self.k_ordner.clicked.connect(self._ordner)
        for k in (self.k_pruefen, self.k_kopie, self.k_ordner):
            k.setCursor(Qt.PointingHandCursor)
            knoepfe.addWidget(k)
        knoepfe.addStretch(1)
        schl = QPushButton("Schliessen")
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.accept)
        knoepfe.addWidget(schl)
        lay.addLayout(knoepfe)
        from . import fenster
        fenster.einrichten(self, "pfad", 720, eigenes_fenster=False)
        self.ziel = None

    def _waehlen(self):
        p, _ = QFileDialog.getOpenFileName(self, "Plan[Goo]-Projekt waehlen", "",
                                           "Plan[Goo]-Projekt (*.zip *.db *.gpkg);;Alle Dateien (*.*)")
        if p:
            self.feld.setText(p)
            self._pruefen()

    def _pruefen(self):
        p = self.feld.text().strip().strip('"')
        if not p or not os.path.exists(p):
            self.ergebnis.setHtml("<span style='color:#B00020'>Datei nicht gefunden.</span>")
            return
        L = laengen(p)
        db, gpkg, info, zp = projektdateien(p)
        zeilen = ["<b>Projekt:</b> {}".format(p),
                  "Laengster Dateipfad: <b>{}</b> Zeichen".format(L["datei"]),
                  "Backup-Zip beim Oeffnen: <b>{}</b> Zeichen (Grenze {})".format(L["backup"], GRENZE)]
        if not zp and not (db and gpkg):
            zeilen.append("<span style='color:#B00020'>Zum Projekt fehlt die .db oder .gpkg im selben Ordner.</span>")
        if L["backup"] > GRENZE:
            zeilen.append("<span style='color:#B00020; font-weight:600'>Zu lang: Plan[Goo] bricht beim Oeffnen mit "
                          "'FileNotFoundError ... .zip' ab. Arbeitskopie anlegen.</span>")
        elif L["backup"] > GRENZE - 15:
            zeilen.append("<span style='color:{}; font-weight:600'>Knapp: {} Zeichen Luft. Arbeitskopie empfohlen.</span>"
                          .format(ci.ORANGE_DUNKEL, GRENZE - L["backup"]))
        else:
            zeilen.append("<span style='color:#1B7F3B; font-weight:600'>In Ordnung: {} Zeichen Luft.</span>".format(GRENZE - L["backup"]))
        zeilen.append("Hinweis: SQLite-Dateien nicht direkt im OneDrive-/SharePoint-Sync bearbeiten; die Arbeitskopie vermeidet auch das.")
        self.ergebnis.setHtml("<br>".join(zeilen))
        self.k_kopie.setEnabled(bool(zp or (db and gpkg)))

    def _kopie(self):
        p = self.feld.text().strip().strip('"')
        try:
            ziel, kopiert = arbeitskopie(p)
        except Exception as e:
            QMessageBox.critical(self, "Fiberation Werkzeugkasten", "Arbeitskopie fehlgeschlagen:\n{!r}".format(e)[:600])
            return
        self.ziel = ziel
        self.k_ordner.setEnabled(True)
        L = len(os.path.join(ziel, max(kopiert, key=len) if kopiert else "x")) + BACKUP_ZUSATZ
        self.ergebnis.append("<br><b>Arbeitskopie angelegt:</b> {}<br>Dateien: {}<br>Backup-Zip dort: {} Zeichen. "
                             "Projekt jetzt in Plan[Goo] aus diesem Ordner oeffnen; nach der Bearbeitung das Export-Zip zurueck in "
                             "die Team-Ablage legen.".format(ziel, ", ".join(kopiert), L))

    def _ordner(self):
        if self.ziel and os.path.isdir(self.ziel):
            subprocess.Popen(["explorer", self.ziel])
