# -*- coding: utf-8 -*-
"""Standdatei je Gebiet: werkzeugkasten_stand.json neben den Ergebnissen (Markus 12.10.2026, Entscheidung: "neben den Ergebnissen").

Jeder Schritt traegt sein Ergebnis beim Merken ein (dateiwahl.merken ruft schreiben()). Die Datei verkettet die Schritte eines Gebiets:
  {"stamm": "...", "schritte": {"adresspruefung": {"pfad": "adresspruefung_....gpkg", "zeit": "2026-10-12 14:03"}, "nvt_gebiete": ..., ...}}
Schritt 10 fuellt daraus alle Felder, sobald eine Datei des Ordners gewaehlt ist; die Uebersicht kann daraus den Stand eines Gebiets zeigen.
Pfade stehen relativ zum Ordner, damit der Ordner als Ganzes wandern kann."""
import json
import os
from datetime import datetime

DATEI = "werkzeugkasten_stand.json"
ARTEN = ("adresspruefung", "nvt_gebiete", "nvt_standorte", "trassen", "hk", "kollo", "wesi", "umfeld", "bestand", "zfp")


def pfad(ordner):
    return os.path.join(ordner, DATEI)


def lesen(ordner):
    p = pfad(ordner)
    if not os.path.exists(p):
        return {"stamm": "", "schritte": {}}
    try:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        d.setdefault("schritte", {})
        d.setdefault("stamm", "")
        return d
    except Exception:
        return {"stamm": "", "schritte": {}}


def schreiben(ordner, art, datei, stamm=None):
    """Ergebnis eines Schritts eintragen. datei: Pfad oder Dateiname im Ordner. -> dict (neuer Stand) oder None bei Fehler."""
    if art not in ARTEN or not ordner or not os.path.isdir(ordner):
        return None
    d = lesen(ordner)
    name = os.path.basename(str(datei))
    d["schritte"][art] = {"pfad": name, "zeit": datetime.now().strftime("%Y-%m-%d %H:%M")}
    if stamm:
        d["stamm"] = stamm
    elif not d.get("stamm"):
        d["stamm"] = _stamm_aus(name)
    d["geaendert"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    try:
        with open(pfad(ordner), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except Exception:
        return None
    return d


def ergebnis(ordner, art):
    """Vollstaendiger Pfad des eingetragenen Ergebnisses einer Art, sofern die Datei noch da ist, sonst None."""
    e = lesen(ordner)["schritte"].get(art)
    if not e:
        return None
    p = os.path.join(ordner, e.get("pfad", ""))
    return p if os.path.exists(p) else None


def _stamm_aus(name):
    import re
    n = os.path.splitext(name)[0]
    for praefix in ("adresspruefung_", "nvt_gebiete_", "nvt_standorte_", "trassen_", "hk_", "kollo_", "wesi_spezialfaelle_", "umfeld_osm_", "bestand_", "zfp222_"):
        if n.startswith(praefix):
            n = n[len(praefix):]
            break
    return re.sub(r"(_\d{8}_\d{4})+$", "", n)
