# -*- coding: utf-8 -*-
"""Schritt 8 - Kollokation (Open Access) nach ZTV 21 Kap. 13 (MBfD): Kollokationspunkte, Kollokationsmuffen und die Kollo-Wege auf der
Hk-Trasse bis zur Betriebsstelle mit Zaehlung der Kollo-SNR je Abschnitt."""
