# -*- coding: utf-8 -*-
"""Schritt 8 - Dialog "Kollokation (Open Access)": Hk-Ergebnis aus Schritt 6/7 waehlen, Materialkonzept (5.0 Vorgabe, 4.1), Gebaeude > 68 WE,
Hk-Trasse aus Planung oder Vorlage -> Kollokationspunkte, Kollokationsmuffen, Kollo-Wege mit SNR je Abschnitt, Kollokationskabel; Tabelle,
Layer, Bericht. Markus 22.09.2026: "alle Open-Access-Punkte identifizieren und die Kollokationswege bis zur BSt gemaess ZTV 21 aufzeigen"."""
import json
import os
import traceback

from qgis.core import (QgsCategorizedSymbolRenderer, QgsCoordinateReferenceSystem, QgsGraduatedSymbolRenderer, QgsLineSymbol, QgsMarkerSymbol,
                       QgsProject, QgsRendererCategory, QgsRendererRange, QgsVectorLayer)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QGridLayout, QHBoxLayout, QHeaderView, QLabel,
                                 QLineEdit, QMessageBox, QProgressBar, QPushButton, QRadioButton, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout)

from ... import ablauf, ci, dateiwahl, layerbaum, tabelle
from ...dialogbasis import WerkzeugDialog
from ...dateiwahl import DateiFeld
from ..hk.dialog import layer_finden

SCHL = "kollo"
LAYER = {"kollo_punkte": "Kollokationspunkte", "kollo_muffen": "Kollokationsmuffen", "kollo_wege": "Kollo-Wege (SNR je Abschnitt)", "kollo_kabel": "Kollokationskabel NVT -> Muffe"}
VIOLETT = "#6A4C93"


def stil(lyr, lname):
    if lname == "kollo_wege":
        stufen = [(0, 3, "1.2", "3 SNR"), (3, 6, "2.0", "4-6 SNR"), (6, 12, "2.8", "7-12 SNR"), (12, 999, "3.8", "> 12 SNR")]
        bereiche = [QgsRendererRange(a, b, QgsLineSymbol.createSimple({"color": VIOLETT, "width": w}), t) for a, b, w, t in stufen]
        lyr.setRenderer(QgsGraduatedSymbolRenderer("snr_gesamt", bereiche))
        ci.label_kasten(lyr, "concat(\"snr_gesamt\", ' SNR', if(\"kabel\" > 0, ' (' || \"kabel\" || ' Kabel)', ''))", groesse=6.5, rahmen=VIOLETT, min_massstab=3000)
    elif lname == "kollo_kabel":
        lyr.renderer().setSymbol(QgsLineSymbol.createSimple({"color": "#C2185B", "width": "0.9", "line_style": "dash"}))
        ci.label_kasten(lyr, "concat(\"nvt\", ' -> ', \"muffe\", ' | ', \"kabel\")", groesse=6, rahmen="#C2185B", min_massstab=3000)
    elif lname == "kollo_punkte":
        kats = []
        for art, farbe, form in (("NVT", VIOLETT, "square"), ("Gebaeude", "#C2185B", "triangle")):
            kats.append(QgsRendererCategory(art, QgsMarkerSymbol.createSimple({"name": form, "color": farbe, "outline_color": "#FFFFFF", "outline_width": "0.4", "size": "4.5"}), art))
        lyr.setRenderer(QgsCategorizedSymbolRenderer("left(\"art\", 3) = 'NVT' ? 'NVT' : 'Gebaeude'", kats))
        ci.label_kasten(lyr, "concat(\"name\", ' | ', \"we\", ' WE | ', \"snr\", ' Kollo-SNR')", groesse=7, rahmen=VIOLETT, abstand_mm=2.0)
    elif lname == "kollo_muffen":
        lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({"name": "hexagon", "color": "#FFFFFF", "outline_color": VIOLETT, "outline_width": "0.9", "size": "5"}))
        ci.label_kasten(lyr, "concat(\"name\", ' | ', \"nvt_anzahl\", ' NVT, ', \"we\", ' WE, ', \"kabel\", ' Kabel')", groesse=7, rahmen=VIOLETT, abstand_mm=2.5)


class KolloDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self.ergebnis = None
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel(SCHL).replace("  ", " ", 1))
        self.setMinimumWidth(900)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel(SCHL), "Kollokationspunkte (Open Access) nach ZTV 21 Kap. 13, Kollokationsmuffen fuer kleine NVT und die Kollo-Wege "
                                                       "auf der Hk-Trasse bis zur Betriebsstelle mit den Kollo-SNR je Abschnitt. Der Planer entscheidet, Plan[Goo] legt die Rohre.")
        lay.addWidget(self.kopf)

        lay.addWidget(self._ueberschrift("Kollokation rechnen"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(6)
        g.addWidget(QLabel("Hk-Ergebnis (Schritt 6/7):"), 0, 0)
        self.f_hk = DateiFeld("hk", "hk_....gpkg aus Schritt 6, Weg-Vorlage oder Hk-Trasse aus Schritt 7 - aufklappen fuer die letzten Ergebnisse", "GeoPackage (*.gpkg)",
                              "Hk-Ergebnis waehlen", ci.STIL_KNOPF_ZWEIT)
        g.addWidget(self.f_hk, 0, 1, 1, 5)
        g.addWidget(QLabel("Materialkonzept:"), 1, 0)
        o = QHBoxLayout()
        o.setSpacing(10)
        self.mk = QComboBox()
        self.mk.addItem("5.0 - Kollokationspunkt nur NVT > 95 WE, kleinere NVT ueber Kollokationsmuffen (Vorgabe)", "5.0")
        self.mk.addItem("4.1 - jeder NVT ist Kollokationspunkt, keine Muffen", "4.1")
        self.mk.setToolTip("Steht im Zuwendungsbescheid. Vorgabe aus den Einstellungen (Markus 30.09.2026: 5.0, solange kein Bescheid vorliegt).")
        try:
            from ... import regelwerk
            i = self.mk.findData("5.0" if regelwerk.mk_ab(regelwerk.materialkonzept(), "5.0") else "4.1")
            if i >= 0:
                self.mk.setCurrentIndex(i)
        except Exception:
            pass
        o.addWidget(self.mk, 1)
        self.h_geb = QCheckBox("Gebaeude > 68 WE aus den Adressen")
        self.h_geb.setChecked(True)
        self.h_geb.setToolTip("Gebaeude mit mehr als 68 WE sind immer Kollokationspunkt (Kollokation im Haus, 3 Kollo-SNR bis ins Haus). Adressen aus dem Schnitt von Schritt 3.")
        o.addWidget(self.h_geb)
        g.addLayout(o, 1, 1, 1, 5)
        g.addWidget(QLabel("Hk-Trasse:"), 2, 0)
        q = QHBoxLayout()
        q.setSpacing(10)
        self.r_planung = QRadioButton("Planung des Planers (Schritt 7), sonst Vorlage")
        self.r_planung.setChecked(True)
        self.r_vorlage = QRadioButton("nur die gerechnete Vorlage")
        q.addWidget(self.r_planung)
        q.addWidget(self.r_vorlage)
        q.addStretch(1)
        g.addLayout(q, 2, 1, 1, 5)
        g.addWidget(QLabel("Ausgabeordner:"), 3, 0)
        self.out = QLineEdit()
        self.out.setPlaceholderText("leer = neben dem Hk-Ergebnis")
        g.addWidget(self.out, 3, 1, 1, 4)
        ob = QPushButton("Waehlen")
        ob.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        ob.clicked.connect(self._out_waehlen)
        g.addWidget(ob, 3, 5)
        g.setColumnStretch(1, 1)
        lay.addLayout(g)

        k = QHBoxLayout()
        self.k_start = QPushButton("Kollokation rechnen")
        self.k_start.setStyleSheet(ci.STIL_KNOPF)
        self.k_start.setCursor(Qt.PointingHandCursor)
        self.k_start.clicked.connect(self._start)
        self.k_laden = dateiwahl.ErgebnisKnopf("kollo", self._ergebnis_setzen, "Kollokations-Ergebnis (GeoPackage) waehlen", stil=ci.STIL_KNOPF_ZWEIT)
        self.k_bericht = QPushButton("Bericht oeffnen")
        self.k_bericht.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_bericht.setEnabled(False)
        self.k_bericht.clicked.connect(lambda: self._oeffnen(self.ergebnis and self.ergebnis.get("bericht")))
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        for x in (self.k_start, self.k_laden, self.k_bericht, self.k_log):
            k.addWidget(x)
        k.addStretch(1)
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, SCHL))
        k.addWidget(hilfe)
        schl = QPushButton("Schliessen")
        self.k_schliessen = schl
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.close)
        k.addWidget(schl)
        lay.addLayout(k)
        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)

        self.tabelle = tabelle.Tabelle("kollo_punkte", ["Punkt / Muffe", "Art", "WE", "Strang", "Kollo-Weg m", "SNR / Kabel", "Hinweis"], self.iface)
        self.tabelle.layer_finder(self._layer)
        self.tabelle.setMinimumHeight(200)
        self.tabelle.setToolTip("Doppelklick: auf den Punkt zoomen")
        self.tabelle.itemDoubleClicked.connect(self._zeile_zoomen)
        lay.addWidget(self.tabelle, 1)
        self.lab_summe = QLabel("")
        self.lab_summe.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        lay.addWidget(self.lab_summe)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(120)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log)
        self.setAcceptDrops(True)
        from ... import fenster
        fenster.einrichten(self, SCHL, 900)

    # --- Hilfen ------------------------------------------------------------------------------------------------------------------------
    def _out_waehlen(self):
        p = dateiwahl.ordner_waehlen(self, "Ausgabeordner waehlen", "ausgabe", self.out.text())
        if p:
            self.out.setText(p)

    def _datei_fallen_gelassen(self, p):
        n = os.path.basename(p).lower()
        if not n.endswith(".gpkg"):
            return False
        if n.startswith("kollo_"):
            self._ergebnis_setzen(p)
        elif n.startswith("hk_"):
            self.f_hk.setText(p)
        return True

    # --- Rechnen -----------------------------------------------------------------------------------------------------------------------
    def _start(self):
        from . import kern
        self.log.clear()
        self.k_start.setEnabled(False)
        try:
            hk = self.f_hk.text().strip() or (dateiwahl.zuletzt("hk") or [""])[0]
            if not hk or not os.path.exists(hk):
                self.k_log.setChecked(True)
                self._log("Hk-Ergebnis nicht gefunden - erst Schritt 6 und 7 ausfuehren oder ein hk_....gpkg waehlen.")
                QMessageBox.information(self, "Kollokation", "Erst Schritt 6 (Straenge) und 7 (Weg-Vorlage) ausfuehren oder ein hk_....gpkg waehlen.")
                return
            if not self.f_hk.text().strip():
                self.f_hk.setText(hk)
            dateiwahl.merken("hk", hk)
            r = kern.rechnen(hk, mk=self.mk.currentData(), gebaeude=self.h_geb.isChecked(), quelle_weg="planung" if self.r_planung.isChecked() else "vorlage",
                             out_dir=dateiwahl.ausgabeordner(self.out.text()), log=self._log, fortschritt=self._fortschritt)
            dateiwahl.merken("kollo", r["gpkg"])
            self.ergebnis = r
            self.k_bericht.setEnabled(True)
            self._tabelle_fuellen(r["kennzahlen"])
            self._layer_laden(r["gpkg"], r["stamm"])
            kz = r["kennzahlen"]
            text = "{} Kollokationspunkte, {} Kollokationsmuffen (Materialkonzept {}).\n\nHk-Trasse mit Kollo-SNR: {:.2f} km, hoechstens {} SNR auf einem Abschnitt; {} Kollokationskabel NVT -> Muffe.".format(
                r["punkte"], r["muffen"], kz["mk"], kz["kollo_snr_km"], kz["max_snr_abschnitt"], kz["kabel"])
            if kz.get("hinweise"):
                text += "\n\nHinweise ({}):\n".format(len(kz["hinweise"])) + "\n".join("- " + h for h in kz["hinweise"][:6])
            QMessageBox.information(self, "Kollokation", text + "\n\nDer Planer entscheidet Muffenlage und Antraege; Kollo-SNR und Kabel legt er in Plan[Goo].")
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "Kollokation - Fehler", "{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])
        finally:
            self.k_start.setEnabled(True)

    def _ergebnis_setzen(self, gpkg):
        dateiwahl.merken("kollo", gpkg)
        basis = os.path.splitext(gpkg)[0]
        self.ergebnis = {"gpkg": gpkg, "bericht": basis + "_bericht.md", "liste": basis + "_liste.json"}
        self.k_bericht.setEnabled(os.path.exists(self.ergebnis["bericht"]))
        st = os.path.basename(basis).replace("kollo_", "")
        try:
            with open(self.ergebnis["liste"], encoding="utf-8") as fh:
                daten = json.load(fh)
            st = daten.get("stamm", st)
            self._tabelle_fuellen(daten)
            if daten.get("hk") and not self.f_hk.text():
                self.f_hk.setText(daten["hk"])
        except Exception as e:
            self._log("Liste nicht gelesen ({!r}).".format(e))
        self.ergebnis["stamm"] = st
        self._layer_laden(gpkg, st)
        self._log("Ergebnis geladen: " + gpkg)

    # --- Tabelle -----------------------------------------------------------------------------------------------------------------------
    def _tabelle_fuellen(self, daten):
        self.tabelle.setRowCount(0)
        zeilen = [(p["name"], p["art"], p["we"], p["hk"], p.get("weg_m"), "{} SNR".format(p["snr"]), p.get("hinweis", ""), "kollo_punkte") for p in daten.get("punkte", [])]
        zeilen += [(m["name"], "Kollokationsmuffe ({} NVT: {})".format(m["nvt_anzahl"], m["nvt_liste"]), m["we"], m["hk"], m.get("weg_m"),
                    "{} SNR + {} Kabel".format(m["snr"], m["kabel"]), m.get("hinweis", ""), "kollo_muffen") for m in daten.get("muffen", [])]
        for z in zeilen:
            i = self.tabelle.rowCount()
            self.tabelle.insertRow(i)
            for j, w in enumerate(z[:7]):
                it = QTableWidgetItem("-" if w is None else str(w))
                if j in (2, 4):
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.tabelle.setItem(i, j, it)
            self.tabelle.karte_setzen(i, bezug=(z[7], {"name": str(z[0])}))
        self.tabelle.resizeColumnsToContents()
        self.tabelle.fertig()
        self.lab_summe.setText("{} Punkte, {} Muffen | Hk-Trasse mit Kollo-SNR {:.2f} km, hoechstens {} SNR je Abschnitt | {} Kollokationskabel | Materialkonzept {}{}".format(
            len(daten.get("punkte", [])), len(daten.get("muffen", [])), daten.get("kollo_snr_km", 0.0), daten.get("max_snr_abschnitt", 0), daten.get("kabel", 0), daten.get("mk", ""),
            " | Regelsatz {}".format(daten["regelsatz"]) if daten.get("regelsatz") else ""))

    def _zeile_zoomen(self, item):
        name = self.tabelle.item(item.row(), 0).text()
        for lname in ("kollo_punkte", "kollo_muffen"):
            lyr = self._layer(lname)
            if lyr is None:
                continue
            lyr.selectByExpression("\"name\" = '{}'".format(name.replace("'", "''")))
            if lyr.selectedFeatureCount():
                try:
                    self.iface.mapCanvas().zoomToSelected(lyr)
                    self.iface.mapCanvas().zoomScale(max(self.iface.mapCanvas().scale(), 2000))
                    self.iface.mapCanvas().refresh()
                except Exception:
                    pass
                return

    # --- Layer -------------------------------------------------------------------------------------------------------------------------
    def _layer(self, name):
        if not self.ergebnis:
            return None
        return layer_finden(self.ergebnis["gpkg"], name)

    def _layer_laden(self, gpkg, st):
        self.ergebnis = dict(self.ergebnis or {}, gpkg=gpkg, stamm=st)
        gruppe = layerbaum.gruppe(SCHL, "Kollokation {}".format(st))
        for lname in ("kollo_kabel", "kollo_wege", "kollo_muffen", "kollo_punkte"):
            lyr = QgsVectorLayer("{}|layername={}".format(gpkg, lname), LAYER.get(lname, lname), "ogr")
            if not lyr.isValid():
                continue
            lyr.setCrs(QgsCoordinateReferenceSystem("EPSG:25832"))
            try:
                stil(lyr, lname)
            except Exception as e:
                self._log("Stil {} nicht gesetzt: {!r}".format(lname, e))
            layerbaum.einhaengen(gruppe, lyr, SCHL, sichtbar=True)
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass
