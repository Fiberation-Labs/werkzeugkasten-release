# -*- coding: utf-8 -*-
"""Schritt 8 - Kollokation (Open Access) - Kern ohne Qt.

Markus 22.09.2026: "Auf die Agenda muss noch ein Kollokationstool. Dieses Tool soll alle Open-Access-Punkte identifizieren und dann
entsprechend die Kollokationswege bis zur BSt bei Tiefbau gemaess ZTV 21 identifizieren und aufzeigen." Platz 8, Materialkonzept 5.0 als
Vorgabe mit Schalter auf 4.1 (Markus "ja fang an").

Regeln (ZTV 21 Kap. 13 MBfD, Memory-Database-Fiberation/docs/06_ztv_tknetz21_planungsregeln.md):
  - Kollokationspunkt: Gf-NVt bis Materialkonzept 4.1 JEDER NVT, ab 5.0 nur NVT > 95 WE; Gebaeude > 68 WE immer (Kollokation im Haus).
  - Je Kollokationspunkt 3 Kollo-SNR 12x2,0 Richtung BSt (nur fuer Zugangsnachfrager, enden im Einfuehrungsschacht/vor der BSt,
    MegaPlan-Belegung "Kollo-Reserve (BF)"); Kollo-SNR duerfen im regulaeren Hk-Verband mitlaufen, nicht in Zusatz-/KH-Verbaenden.
  - Kollokationsmuffe (ab 5.0, NVT < 96 WE): bis 10 NVT buendeln, Bereich 96-208 WE; je WE 3 Fasern vom NVT zur Muffe auf separaten
    Kollokationskabeln (Minikabel 48-96 Fs, eigenes SNR je Kabel); Muffe nicht auf BSt-Gelaende; Einzelstandort < 96 WE nur mit Antrag.
Eingang: Hk-Ergebnis aus Schritt 6/7 (hk_nvt mit WE und Strang, bst, hk_planung bzw. hk_vorlage als Hk-Trasse) und die Adressen des Schnitts
(WE je Adresse, Gebaeude). Ausgabe kollo_<Stamm>_<Datum>.gpkg: kollo_punkte, kollo_muffen, kollo_wege (Kollo-SNR je Abschnitt), kollo_kabel
(NVT -> Muffe) + Bericht + Liste. Das Werkzeug zeigt, der Planer entscheidet (Muffenlage, Antraege, Rohre in Plan[Goo]).
"""
import json
import math
import os
import time
from collections import defaultdict
from datetime import datetime

import geopandas as gpd
import networkx as nx
import pandas as pd
from shapely.geometry import LineString, Point

from ..hk import kern as hk_kern

CRS = 25832
MK_VERSIONEN = ("5.0", "4.1")
KOLLO_SNR_JE_PUNKT = 3
NVT_KOLLO_WE = 95            # ab MK 5.0: NVT mit MEHR als 95 WE = eigener Kollokationspunkt
GEBAEUDE_KOLLO_WE = 68       # Gebaeude mit MEHR als 68 WE = Kollokation im Haus (immer)
MUFFE_WE_MIN, MUFFE_WE_MAX, MUFFE_NVT_MAX = 96, 208, 10
FS_JE_WE = 3
MINIKABEL = (48, 96)         # Kollokationskabel NVT -> Muffe
KNOTEN_TOL_M = 1.0           # Enden der Hk-Trasse innerhalb dieser Toleranz sind ein Knoten
ANBINDUNG_M = 40.0           # Punkt/NVT/BSt haengt am naechsten Knoten der Hk-Trasse, wenn er naeher liegt
BST_GELAENDE_M = 50.0        # Muffe naeher als 50 m an der BSt: Hinweis "nicht auf BSt-Gelaende"


from ... import gemeinsam
_s = gemeinsam.s


def _i(v, d=0):
    try:
        if v is None or (isinstance(v, float) and math.isnan(v)):
            return d
        return int(round(float(v)))
    except Exception:
        return d


def kabel_fuer(fasern):
    """Kollokationskabel: Minikabel 48/96 Fs, mehrere bei Bedarf. -> Liste Kabelgroessen"""
    if fasern <= 0:
        return []
    kabel = []
    rest = fasern
    while rest > 0:
        g = MINIKABEL[0] if rest <= MINIKABEL[0] else MINIKABEL[1]
        kabel.append(g)
        rest -= g
    return kabel


# --- Punkte -------------------------------------------------------------------------------------------------------------------------------
def punkte_bestimmen(nvt, adressen, mk="5.0", gebaeude=True, log=print):
    """-> (punkte (Liste dict), muffen_kandidaten (Liste NVT-Namen))"""
    punkte, kand = [], []
    for _, r in nvt.iterrows():
        we = _i(r.get("we"))
        hk = _s(r.get("hk"))
        if not hk:
            continue
        if mk == "4.1" or we > NVT_KOLLO_WE:
            punkte.append({"name": _s(r["name"]), "art": "NVT (jeder NVT bis MK 4.1)" if mk == "4.1" else "NVT > {} WE".format(NVT_KOLLO_WE), "we": we, "hk": hk,
                           "nvt": _s(r["name"]), "snr": KOLLO_SNR_JE_PUNKT, "hinweis": "", "geometry": r.geometry})
        else:
            kand.append(_s(r["name"]))
    n_geb = 0
    if gebaeude and adressen is not None and len(adressen):
        a = adressen.copy()
        we_sp = "we_gesamt" if "we_gesamt" in a else "we"
        a["_we"] = pd.to_numeric(a.get(we_sp), errors="coerce").fillna(0)
        # Gebaeude = Adressen auf demselben Punkt (die Bedarfsliste traegt keine Gebaeude-Kennung; 'gebaeude' ist die ALKIS-Funktion)
        a["_geb"] = ["{:.0f}_{:.0f}".format(g.x, g.y) if g is not None else "" for g in a.geometry]
        a = a[a["_geb"] != ""]
        nvt_hk = dict(zip(nvt["name"].astype(str), nvt["hk"].map(_s)))
        for gid, grp in a.groupby("_geb"):
            we = int(grp["_we"].sum())
            if we <= GEBAEUDE_KOLLO_WE:
                continue
            r0 = grp.iloc[0]
            nvt_name = _s(r0.get("nvt"))
            name = "{} {}{}".format(_s(r0.get("strasse")), _s(r0.get("hnr")), _s(r0.get("hnr_zs"))).strip() or "Gebaeude {}".format(gid)
            punkte.append({"name": name, "art": "Gebaeude > {} WE (Kollokation im Haus)".format(GEBAEUDE_KOLLO_WE), "we": we, "hk": nvt_hk.get(nvt_name, ""),
                           "nvt": nvt_name, "snr": KOLLO_SNR_JE_PUNKT, "hinweis": "3 Kollo-SNR bis ins Haus; {} Adressen".format(len(grp)), "geometry": r0.geometry})
            n_geb += 1
    log("Kollokationspunkte (MK {}): {} NVT{}, {} Gebaeude > {} WE; {} NVT < {} WE als Muffen-Kandidaten".format(
        mk, len(punkte) - n_geb, "" if mk == "4.1" else " > {} WE".format(NVT_KOLLO_WE), n_geb, GEBAEUDE_KOLLO_WE, len(kand), MUFFE_WE_MIN))
    return punkte, kand


def muffen_bilden(nvt, kandidaten, bst_pt, log=print):
    """Kollokationsmuffen je Strang: NVT < 96 WE entlang des Strangs (Reihenfolge von der BSt) zu Gruppen 96-208 WE, hoechstens 10 NVT.
    Muffe sitzt am NVT der Gruppe, der der BSt am naechsten liegt. -> Liste dict (name, hk, nvt_liste, we, kabel, hinweis, geometry)"""
    n = nvt[nvt["name"].astype(str).isin(kandidaten)].copy()
    n["_we"] = n["we"].map(_i)
    n["_weg"] = pd.to_numeric(n.get("weg_m"), errors="coerce").fillna(1e9)
    muffen = []
    for hk, grp in n.groupby(n["hk"].map(_s)):
        if not hk:
            continue
        reihe = grp.sort_values("_weg", ascending=False)         # vom Ende des Strangs Richtung BSt
        gruppen, akt = [], []
        for _, r in reihe.iterrows():
            we_akt = sum(_i(x["we"]) for x in akt)
            if akt and (we_akt + _i(r["we"]) > MUFFE_WE_MAX or len(akt) >= MUFFE_NVT_MAX):
                gruppen.append(akt)
                akt = []
            akt.append(r)
            if sum(_i(x["we"]) for x in akt) >= MUFFE_WE_MIN and len(akt) >= 1:
                # Gruppe voll genug - aber weiter fuellen, solange der naechste NVT noch passt? Nein: schliessen, sonst wandert die Muffe zu weit
                gruppen.append(akt)
                akt = []
        if akt:
            # Rest unter 96 WE: an die letzte Gruppe haengen, wenn sie es traegt, sonst eigene Gruppe mit Antrag
            if gruppen and sum(_i(x["we"]) for x in gruppen[-1]) + sum(_i(x["we"]) for x in akt) <= MUFFE_WE_MAX and len(gruppen[-1]) + len(akt) <= MUFFE_NVT_MAX:
                gruppen[-1] = gruppen[-1] + akt
            else:
                gruppen.append(akt)
        for k, g in enumerate(gruppen):
            we = sum(_i(x["we"]) for x in g)
            nah = min(g, key=lambda x: float(x["_weg"]))
            kabel = sum(len(kabel_fuer(_i(x["we"]) * FS_JE_WE)) for x in g)
            hinweis = []
            if we < MUFFE_WE_MIN:
                hinweis.append("unter {} WE - Einzelstandort nur mit genehmigtem Antrag".format(MUFFE_WE_MIN))
            if we > MUFFE_WE_MAX:
                hinweis.append("ueber {} WE".format(MUFFE_WE_MAX))
            if 3 + kabel > 16:
                hinweis.append("{} SNR am Muffentyp 2 (max. 16: 3 Kollo + 13 vom NVT)".format(3 + kabel))
            if bst_pt is not None and nah.geometry is not None and nah.geometry.distance(bst_pt) < BST_GELAENDE_M:
                hinweis.append("Muffe nahe BSt ({:.0f} m) - nicht auf BSt-Gelaende setzen".format(nah.geometry.distance(bst_pt)))
            muffen.append({"name": "{} Kollo M{}".format(hk, k + 1), "hk": hk, "nvt_liste": ", ".join(sorted(str(x["name"]) for x in g)), "nvt_anzahl": len(g),
                           "we": we, "fasern": we * FS_JE_WE, "kabel": kabel, "snr": KOLLO_SNR_JE_PUNKT, "an_nvt": str(nah["name"]),
                           "hinweis": "; ".join(hinweis), "geometry": nah.geometry, "_nvt": [str(x["name"]) for x in g]})
    log("Kollokationsmuffen: {} ({} NVT gebuendelt)".format(len(muffen), sum(m["nvt_anzahl"] for m in muffen)))
    return muffen


# --- Wege auf der Hk-Trasse ------------------------------------------------------------------------------------------------------------------
def hk_trasse_laden(hk_gpkg, quelle="planung", log=print):
    """Hk-Trasse als Linien: je Strang die Planung des Planers, wenn er dort schon gezeichnet hat, sonst die Vorlage aus Schritt 7.
    -> (GeoDataFrame hk, quelle, geometry; dict Strang -> Quelle)"""
    eb = hk_kern.ebenen(hk_gpkg)
    plan = hk_kern.planung_lesen(hk_gpkg) if "hk_planung" in eb else gpd.GeoDataFrame(geometry=[], crs=CRS)
    vorl = gpd.read_file(hk_gpkg, layer="hk_vorlage") if "hk_vorlage" in eb else gpd.GeoDataFrame(geometry=[], crs=CRS)
    teile, quellen = [], {}
    hks = set(plan["hk"].map(_s)) if len(plan) and "hk" in plan else set()
    if len(vorl) and "hk" in vorl:
        hks |= set(x for v in vorl["hk"].map(_s) for x in v.split("; "))
    for hk in sorted(h for h in hks if h):
        p = plan[plan["hk"].map(_s) == hk] if len(plan) else plan
        if quelle == "planung" and len(p):
            teile.append(gpd.GeoDataFrame({"hk": hk, "quelle": "Planung", "geometry": p.geometry}, crs=CRS))
            quellen[hk] = "Planung"
            continue
        v = vorl[vorl["hk"].map(_s).str.split("; ").apply(lambda xs: hk in xs)] if len(vorl) else vorl
        if len(v):
            teile.append(gpd.GeoDataFrame({"hk": hk, "quelle": "Vorlage", "geometry": v.geometry}, crs=CRS))
            quellen[hk] = "Vorlage"
        else:
            quellen[hk] = "keine"
    t = pd.concat(teile, ignore_index=True) if teile else gpd.GeoDataFrame({"hk": [], "quelle": []}, geometry=[], crs=CRS)
    t = gpd.GeoDataFrame(t, geometry="geometry", crs=CRS)
    t = t[t.geometry.notna()].explode(index_parts=False, ignore_index=True)
    t = t[(t.geometry.geom_type == "LineString") & (t.geometry.length > 0.01)].reset_index(drop=True)
    log("Hk-Trasse: {} Stuecke, {:.1f} km; je Strang: {}".format(len(t), t.geometry.length.sum() / 1000,
                                                              ", ".join("{} {}".format(k, v) for k, v in quellen.items())))
    return t, quellen


def _graph(trasse):
    k = 1.0 / KNOTEN_TOL_M
    key = lambda x, y: (round(x * k), round(y * k))
    P = nx.Graph()
    xy = {}
    for i, r in trasse.iterrows():
        c = list(r.geometry.coords)
        a, b = key(*c[0][:2]), key(*c[-1][:2])
        xy.setdefault(a, c[0][:2])
        xy.setdefault(b, c[-1][:2])
        if a == b:
            continue
        L = r.geometry.length
        if P.has_edge(a, b) and P[a][b]["length"] <= L:
            continue
        P.add_edge(a, b, length=L, i=i, hk=_s(r["hk"]))
    return P, xy


def _naechster(P, xy, pt, max_m):
    best, bd = None, max_m
    for n, (x, y) in xy.items():
        d = math.hypot(x - pt.x, y - pt.y)
        if d < bd:
            best, bd = n, d
    return best, bd


# --- Hauptlauf ------------------------------------------------------------------------------------------------------------------------------
def rechnen(hk_gpkg, mk="5.0", gebaeude=True, quelle_weg="planung", out_dir=None, log=print, fortschritt=None):
    """-> dict(gpkg, bericht, liste, stamm, punkte, muffen, kennzahlen)"""
    t0 = time.time()
    f = fortschritt or (lambda p, t: None)
    hk_gpkg = str(hk_gpkg)
    mk = mk if mk in MK_VERSIONEN else "5.0"
    liste6 = hk_kern.liste_lesen(hk_gpkg)
    stamm = liste6.get("stamm") or os.path.basename(os.path.splitext(hk_gpkg)[0]).replace("hk_", "")
    out_dir = out_dir or os.path.dirname(hk_gpkg)
    os.makedirs(out_dir, exist_ok=True)
    from ..bestand.kern import ausgabe_pfad
    gpkg = ausgabe_pfad(out_dir, "kollo_{}_{}.gpkg".format(stamm, datetime.now().strftime("%Y%m%d_%H%M")), log)
    if os.path.exists(gpkg):
        try:
            os.remove(gpkg)          # zweiter Lauf in derselben Minute: keine alten Ebenen stehen lassen
        except OSError:
            pass

    f(5, "NVT, BSt, Adressen lesen")
    nvt = gpd.read_file(hk_gpkg, layer="hk_nvt")
    bst = gpd.read_file(hk_gpkg, layer="bst")
    bst_pt = bst.geometry.iloc[0] if len(bst) else None
    regelsatz, adressen = "", None
    try:
        geb = gpd.read_file(liste6["quelle"], layer="nvt_gebiete")
        regelsatz = _s(geb["regelsatz"].iloc[0]) if "regelsatz" in geb and len(geb) else ""
        if "we" not in nvt or nvt["we"].isna().all():
            nvt = nvt.merge(geb[["name", "we"]], on="name", how="left", suffixes=("_alt", ""))
        adressen = gpd.read_file(liste6["quelle"], layer="adressen")
    except Exception as e:
        log("NVT-Gebiete/Adressen aus Schritt 3 nicht lesbar ({}) - Gebaeude > {} WE werden nicht gesucht".format(str(e)[:100], GEBAEUDE_KOLLO_WE))
    hinweise = []
    from ... import regelwerk
    if regelsatz and not regelwerk.ist_mbfd_text(regelsatz):
        hinweise.append("Regelsatz des Schnitts ist '{}' - Kollokation nach ZTV 21 Kap. 13 gilt fuer MBfD/Bundesfoerderung; Ergebnis nur zur Orientierung.".format(regelsatz))
        log("ACHTUNG: " + hinweise[-1])
    log("NVT: {} ({} WE), Materialkonzept {}".format(len(nvt), int(pd.to_numeric(nvt["we"], errors="coerce").fillna(0).sum()), mk))

    f(20, "Kollokationspunkte")
    punkte, kand = punkte_bestimmen(nvt, adressen, mk, gebaeude, log)
    f(35, "Kollokationsmuffen")
    muffen = muffen_bilden(nvt, kand, bst_pt, log) if mk == "5.0" else []
    if mk != "5.0" and kand:
        log("MK 4.1: keine Kollokationsmuffen, jeder NVT ist Kollokationspunkt")

    f(50, "Hk-Trasse lesen")
    trasse, quellen = hk_trasse_laden(hk_gpkg, quelle_weg, log)
    f(60, "Kollo-Wege")
    nvt_geom = {str(r["name"]): (r.geometry, _i(r.get("we"))) for _, r in nvt.iterrows()}
    wege, kabel, hw = wege_rechnen(trasse, punkte, muffen, bst_pt, nvt_geom, log)
    hinweise += hw
    for h in hw[:10]:
        log("Hinweis: " + h)

    f(85, "Schreiben")
    p_df = gpd.GeoDataFrame([{k: v for k, v in p.items() if not k.startswith("_")} for p in punkte], geometry="geometry", crs=CRS) if punkte else gpd.GeoDataFrame(geometry=[], crs=CRS)
    m_df = gpd.GeoDataFrame([{k: v for k, v in m.items() if not k.startswith("_")} for m in muffen], geometry="geometry", crs=CRS) if muffen else gpd.GeoDataFrame(geometry=[], crs=CRS)
    for df, name in ((p_df, "kollo_punkte"), (m_df, "kollo_muffen"), (wege, "kollo_wege"), (kabel, "kollo_kabel")):
        if len(df):
            df.to_file(gpkg, layer=name, driver="GPKG")
    if not os.path.exists(gpkg):
        gpd.GeoDataFrame({"hinweis": ["ohne Kollokationspunkte"]}, geometry=[bst_pt] if bst_pt is not None else [Point(0, 0)], crs=CRS).to_file(gpkg, layer="kollo_punkte", driver="GPKG")
    from ...gemeinsam import wal_schliessen
    wal_schliessen(gpkg)

    km_snr = wege.loc[wege["snr_kollo"] > 0, "laenge_m"].sum() / 1000 if len(wege) else 0.0
    max_snr = int(wege["snr_gesamt"].max()) if len(wege) else 0
    liste = {"stamm": stamm, "mk": mk, "regelsatz": regelsatz, "hk": hk_gpkg, "quelle_weg": quelle_weg, "quellen": quellen,
             "punkte": [{k: v for k, v in p.items() if k != "geometry" and not k.startswith("_")} for p in punkte],
             "muffen": [{k: v for k, v in m.items() if k != "geometry" and not k.startswith("_")} for m in muffen],
             "kabel": int(kabel["kabel_anzahl"].sum()) if len(kabel) else 0, "kabel_km": round(kabel["laenge_m"].sum() / 1000, 2) if len(kabel) else 0.0,
             "kollo_snr_km": round(km_snr, 2), "max_snr_abschnitt": max_snr, "hinweise": hinweise,
             "regeln": {"nvt_kollo_we": NVT_KOLLO_WE, "gebaeude_kollo_we": GEBAEUDE_KOLLO_WE, "snr_je_punkt": KOLLO_SNR_JE_PUNKT,
                        "muffe_we": [MUFFE_WE_MIN, MUFFE_WE_MAX], "muffe_nvt_max": MUFFE_NVT_MAX, "fs_je_we": FS_JE_WE}}
    liste_pfad = os.path.splitext(gpkg)[0] + "_liste.json"
    with open(liste_pfad, "w", encoding="utf-8") as fh:
        json.dump(liste, fh, indent=1, ensure_ascii=False, default=str)
    bericht = _bericht(gpkg, liste, time.time() - t0)
    f(100, "Fertig")
    return {"gpkg": gpkg, "bericht": bericht, "liste": liste_pfad, "stamm": stamm, "punkte": len(punkte), "muffen": len(muffen), "kennzahlen": liste}


def wege_rechnen(trasse, punkte, muffen, bst_pt, nvt_geom, log=print):
    """Kollo-Wege: je Punkt und Muffe der kuerzeste Weg auf der Hk-Trasse zur BSt (3 Kollo-SNR je Abschnitt), je NVT einer Muffe der Weg
    zur Muffe (Kollokationskabel, eigenes SNR je Kabel). nvt_geom: NVT-Name -> (Punkt, WE). Setzt weg_m/hinweis in punkte und muffen.
    -> (wege GeoDataFrame je Trassenstueck mit snr_kollo/kabel/snr_gesamt, kabel GeoDataFrame NVT -> Muffe, Hinweise)"""
    for m in muffen:
        m["_nvt_geom"] = {n: nvt_geom.get(n, (None, 0)) for n in m["_nvt"]}
    hinweise = []
    if not len(trasse):
        return gpd.GeoDataFrame(geometry=[], crs=CRS), gpd.GeoDataFrame(geometry=[], crs=CRS), ["keine Hk-Trasse - in Schritt 7 die Vorlage rechnen oder die Trasse zeichnen"]
    P, xy = _graph(trasse)
    kb, dkb = _naechster(P, xy, bst_pt, ANBINDUNG_M * 2) if bst_pt is not None else (None, None)
    if kb is None:
        return gpd.GeoDataFrame(geometry=[], crs=CRS), gpd.GeoDataFrame(geometry=[], crs=CRS), ["Hk-Trasse endet nicht an der BSt ({:.0f} m Toleranz)".format(ANBINDUNG_M * 2)]
    snr, kab, namen = defaultdict(int), defaultdict(int), defaultdict(list)

    def pfad(pt, ziel, name, art):
        if pt is None:
            hinweise.append("{}: ohne Geometrie - {}".format(name, art))
            return None
        kn, d = _naechster(P, xy, pt, ANBINDUNG_M)
        if kn is None:
            hinweise.append("{}: keine Hk-Trasse in {:.0f} m - {}".format(name, ANBINDUNG_M, art))
            return None
        try:
            return nx.shortest_path(P, kn, ziel, weight="length")
        except nx.NetworkXNoPath:
            hinweise.append("{}: Hk-Trasse dort nicht mit dem Ziel verbunden - {}".format(name, art))
            return None

    for p in punkte + muffen:
        pf = pfad(p["geometry"], kb, p["name"], "Kollo-Weg zur BSt")
        p["weg_m"] = None
        if pf is None:
            p["hinweis"] = "; ".join(x for x in (p.get("hinweis", ""), "kein Kollo-Weg zur BSt") if x)
            continue
        L = 0.0
        for a, b in zip(pf[:-1], pf[1:]):
            e = frozenset((a, b))
            snr[e] += KOLLO_SNR_JE_PUNKT
            namen[e].append(p["name"])
            L += P[a][b]["length"]
        p["weg_m"] = round(L, 0)
    kabel_rows = []
    for m in muffen:
        zk, _ = _naechster(P, xy, m["geometry"], ANBINDUNG_M)
        if zk is None:
            continue
        for nvt_name, (g, we) in m.get("_nvt_geom", {}).items():
            fas = _i(we) * FS_JE_WE
            kabel = kabel_fuer(fas)
            if nvt_name == m["an_nvt"]:
                kabel_rows.append({"nvt": nvt_name, "muffe": m["name"], "hk": m["hk"], "we": _i(we), "fasern": fas, "kabel": " + ".join("{} Fs".format(k) for k in kabel),
                                   "kabel_anzahl": len(kabel), "laenge_m": 0.0, "geometry": None})
                continue
            pf = pfad(g, zk, nvt_name, "Kollokationskabel zur Muffe {}".format(m["name"]))
            if pf is None:
                continue
            L, coords = 0.0, [xy[pf[0]]]
            for a, b in zip(pf[:-1], pf[1:]):
                kab[frozenset((a, b))] += len(kabel)
                L += P[a][b]["length"]
                coords.append(xy[b])
            kabel_rows.append({"nvt": nvt_name, "muffe": m["name"], "hk": m["hk"], "we": _i(we), "fasern": fas, "kabel": " + ".join("{} Fs".format(k) for k in kabel),
                               "kabel_anzahl": len(kabel), "laenge_m": round(L, 0), "geometry": LineString(coords) if len(coords) > 1 else None})
    wege = []
    for a, b, d in P.edges(data=True):
        e = frozenset((a, b))
        if snr.get(e, 0) == 0 and kab.get(e, 0) == 0:
            continue
        r = trasse.loc[d["i"]]
        wege.append({"hk": d["hk"], "quelle": _s(r["quelle"]), "snr_kollo": snr.get(e, 0), "punkte": len(namen.get(e, [])), "kabel": kab.get(e, 0),
                     "snr_gesamt": snr.get(e, 0) + kab.get(e, 0), "laenge_m": round(d["length"], 1), "punkt_liste": "; ".join(namen.get(e, []))[:250], "geometry": r.geometry})
    wege_df = gpd.GeoDataFrame(wege, geometry="geometry", crs=CRS) if wege else gpd.GeoDataFrame(geometry=[], crs=CRS)
    kabel_df = gpd.GeoDataFrame([k for k in kabel_rows if k["geometry"] is not None], geometry="geometry", crs=CRS) if any(k["geometry"] is not None for k in kabel_rows) else gpd.GeoDataFrame(geometry=[], crs=CRS)
    log("Kollo-Wege: {} Trassenstuecke mit Kollo-SNR ({:.2f} km), hoechstens {} SNR auf einem Abschnitt; {} Kollokationskabel NVT -> Muffe ({} mit eigenem Weg)".format(
        len(wege_df), wege_df["laenge_m"].sum() / 1000 if len(wege_df) else 0.0, int(wege_df["snr_gesamt"].max()) if len(wege_df) else 0,
        sum(k["kabel_anzahl"] for k in kabel_rows), len(kabel_df)))
    return wege_df, kabel_df, hinweise


def _bericht(gpkg, liste, dauer):
    p = os.path.splitext(gpkg)[0] + "_bericht.md"
    r = liste["regeln"]
    z = ["# Kollokation (Open Access) - {}".format(liste["stamm"]), "",
         "Stand {}, {:.0f} s. Materialkonzept {}. Regelsatz des Schnitts: {}. Hk-Trasse: {}.".format(
             datetime.now().strftime("%d.%m.%Y %H:%M"), dauer, liste["mk"], liste["regelsatz"] or "unbekannt",
             ", ".join("{} aus {}".format(k, v) for k, v in liste["quellen"].items()) or "keine"), "",
         "## Regeln (ZTV 21 Kap. 13 MBfD)", "",
         "- Kollokationspunkt: {}; Gebaeude > {} WE immer (Kollokation im Haus). Je Punkt {} Kollo-SNR 12x2,0 Richtung BSt, enden vor der BSt, "
         "MegaPlan-Belegung 'Kollo-Reserve (BF)', duerfen im Hk-Verband mitlaufen.".format(
             "jeder NVT (bis MK 4.1)" if liste["mk"] == "4.1" else "NVT > {} WE (ab MK 5.0)".format(r["nvt_kollo_we"]), r["gebaeude_kollo_we"], r["snr_je_punkt"]),
         "- Kollokationsmuffe (ab MK 5.0) fuer NVT < {} WE: bis {} NVT, {}-{} WE, je WE {} Fasern vom NVT zur Muffe auf eigenem Kollokationskabel "
         "(Minikabel 48/96 Fs, eigenes SNR), Muffentyp 2 max. 16 SNR; nicht auf BSt-Gelaende; Einzelstandort < {} WE nur mit Antrag.".format(
             r["muffe_we"][0], r["muffe_nvt_max"], r["muffe_we"][0], r["muffe_we"][1], r["fs_je_we"], r["muffe_we"][0]), ""]
    if liste["hinweise"]:
        z += ["## Hinweise", ""] + ["- " + h for h in liste["hinweise"][:40]] + [""]
    z += ["## Kollokationspunkte", "", "| Punkt | Art | WE | Strang | Kollo-Weg m | SNR | Hinweis |", "|---|---|---|---|---|---|---|"]
    for q in liste["punkte"]:
        z.append("| {} | {} | {} | {} | {} | {} | {} |".format(q["name"], q["art"], q["we"], q["hk"], q.get("weg_m") if q.get("weg_m") is not None else "-", q["snr"], q.get("hinweis", "")))
    if liste["muffen"]:
        z += ["", "## Kollokationsmuffen", "", "| Muffe | Strang | NVT | WE | Fasern | Kabel | am NVT | Kollo-Weg m | Hinweis |", "|---|---|---|---|---|---|---|---|---|"]
        for m in liste["muffen"]:
            z.append("| {} | {} | {} ({}) | {} | {} | {} | {} | {} | {} |".format(m["name"], m["hk"], m["nvt_anzahl"], m["nvt_liste"], m["we"], m["fasern"], m["kabel"], m["an_nvt"],
                                                                         m.get("weg_m") if m.get("weg_m") is not None else "-", m.get("hinweis", "")))
    z += ["", "## Kollo-Wege", "", "Hk-Trasse mit Kollo-SNR: {:.2f} km; hoechstens {} SNR (Kollo + Kabel) auf einem Abschnitt; {} Kollokationskabel NVT -> Muffe, {:.2f} km.".format(
        liste["kollo_snr_km"], liste["max_snr_abschnitt"], liste["kabel"], liste["kabel_km"]), "",
        "## Vorgehen", "- Das Werkzeug zeigt Punkte, Muffen und Wege; der Planer entscheidet Muffenlage, Antraege fuer Einzelstandorte und legt Kollo-SNR und Kabel in Plan[Goo].",
        "- Layer: 8 Kollokationspunkte, 8 Kollokationsmuffen, 8 Kollo-Wege (Breite = SNR je Abschnitt), 8 Kollokationskabel.", "", "GeoPackage: `{}`".format(os.path.basename(gpkg))]
    with open(p, "w", encoding="utf-8") as fh:
        fh.write("\n".join(z))
    return p
