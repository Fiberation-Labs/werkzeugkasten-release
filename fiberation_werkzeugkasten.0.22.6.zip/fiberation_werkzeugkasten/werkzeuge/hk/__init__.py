# -*- coding: utf-8 -*-
"""Schritt 6 - Hauptkabel: Straenge schneiden, Weg zeigen, Hk-Trasse zeichnen und mit Bestand anreichern."""
