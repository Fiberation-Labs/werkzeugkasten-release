# -*- coding: utf-8 -*-
"""Schritt 7 - Hk-Trassen automatisch bereinigen (Markus 12.10.2026: "Tool 7 soll Fehler auf den Trassen kuenftig automatisch beheben,
statt nur Befunde zu melden").

Regeln laufen nacheinander ueber die Stuecke der Planung (hk_planung); jede Regel bekommt den Zustand (Liste von Stuecken) und gibt ihn
geaendert zurueck, dazu Meldungen fuers Protokoll. Neue Korrekturen = neue Funktion + Eintrag in REGELN.

  1. enden_einrasten   - Enden, die hoechstens toleranz m auseinanderliegen, auf einen gemeinsamen Punkt (Mittel) setzen
  2. abzweige_teilen   - liegt das Ende eines Stuecks im Umkreis von toleranz m auf dem Inneren eines anderen, wird das andere dort geteilt
                         und das Ende auf den Teilungspunkt gesetzt (Abzweig mitten auf einer Linie)
  3. kreuzungen_teilen - schneiden sich zwei Stuecke, ohne dass dort ein Ende liegt, werden beide am Schnittpunkt geteilt
  4. enden_einrasten   - noch einmal, weil Teilungen neue Enden erzeugen

Geteilte Stuecke behalten alle Attribute des Originals (uid bleibt am ersten Teil, die weiteren bekommen eine neue uid), die Laenge rechnet
planung_schreiben neu. Dieselbe Normalisierung nutzt pruefen() nur im Speicher, damit die Pruefung Abzweige und nahe Enden versteht, ohne die
Daten anzufassen.

Stueck = dict(attr=dict der Spalten, geom=LineString, quelle=Index des Originals)."""
import math

from shapely.geometry import LineString, Point
from shapely.ops import substring
from shapely.strtree import STRtree

from ..topologie import (UnionFind as _UnionFind, _enden, _ende_setzen, _in_stuecke, _name, _teilen, abzweige_teilen,  # noqa: F401
                         enden_cluster, enden_einrasten, kreuzungen_teilen, stuecke_als_gdf)


# --- Hilfen ---------------------------------------------------------------------------------------------------------------------------------
# --- Regeln ---------------------------------------------------------------------------------------------------------------------------------
# --- weitere Regeln (Markus 12.10.2026: "1 ja 2 ja 3 automatisch machen ohne abfrage 4 ja bei neubau und das ueberfluessige stueck
#     loeschen 5 ja 6 melden") ----------------------------------------------------------------------------------------------------------
KLEINST_M = 0.5            # Regel 1: Stuecke unter dieser Laenge werden auf einen Knoten zusammengezogen
LUECKE_MAX_M = 10.0        # Regel 3: offene Enden bis hierhin werden mit einem Verbindungsstueck ans Netz geschlossen
UEBERSTAND_MAX_M = 15.0    # Regel 4: freier Ueberstand hinter einem Knoten bis hierhin wird gekappt (nur Neubau; schraege Kreuzung = laengerer Rest)
ZIEL_NAH_M = 15.0          # Enden in diesem Umkreis um NVT oder BSt gelten als gewollt offen (Zufuehrung endet dort)
NVT_MAX_M = 30.0           # Regel 5: NVT ohne Trassenende bekommt eine Zufuehrung, wenn das Netz so nah ist (Hk auf der anderen Strassenseite)


def _grade(stuecke, toleranz):
    """-> (knoten_von, mittel, mitglieder[kid] = [(i, w), ...])"""
    knoten_von, mittel = enden_cluster(stuecke, toleranz)
    mitglieder = {}
    for (i, w), kid in knoten_von.items():
        mitglieder.setdefault(kid, []).append((i, w))
    return knoten_von, mittel, mitglieder


def _neue_uid(attr, kuerzel):
    from ... import gemeinsam
    return gemeinsam.uid(attr.get("hk") or "hk", kuerzel)


def _ziele(kontext):
    return list((kontext or {}).get("ziele") or [])


def _nahe_ziel(p, kontext):
    return any(p.distance(z) <= ZIEL_NAH_M for z in _ziele(kontext))


def _ist_bestand(s):
    try:
        return int(float(s["attr"].get("bestand") or 0)) == 1
    except (TypeError, ValueError):
        return False


def doppelte_entfernen(stuecke, toleranz, log, kontext=None):
    """Regel 2: zwei Stuecke mit (fast) gleicher Geometrie - die Kopie faellt weg, Bestand gewinnt, sonst bleibt das erste."""
    geoms = [s["geom"] for s in stuecke]
    tree = STRtree(geoms)
    weg = set()
    meld = []
    for i, g in enumerate(geoms):
        if i in weg:
            continue
        for j in tree.query(g):
            j = int(j)
            if j <= i or j in weg:
                continue
            h = geoms[j]
            if abs(g.length - h.length) > max(toleranz, 0.1 * g.length):
                continue
            if g.hausdorff_distance(h) > toleranz:
                continue
            # Kopie bestimmen: Neubau faellt vor Bestand, sonst die spaetere
            if _ist_bestand(stuecke[j]) and not _ist_bestand(stuecke[i]):
                weg.add(i)
                meld.append("doppelte Linie: Stueck {} (Neubau) entfernt, Bestand {} bleibt".format(_name(stuecke[i]), _name(stuecke[j])))
                break
            weg.add(j)
            meld.append("doppelte Linie: Stueck {} entfernt, {} bleibt".format(_name(stuecke[j]), _name(stuecke[i])))
    neu = [s for k, s in enumerate(stuecke) if k not in weg]
    return neu, meld, {"doppelte": len(weg)}


def kleinstsegmente_verschmelzen(stuecke, toleranz, log, kontext=None):
    """Regel 1: Stuecke unter KLEINST_M werden auf einen Knoten zusammengezogen - alle Enden an ihren beiden Knoten wandern auf die Mitte,
    das Stueck faellt weg; die laengeren Nachbarn behalten ihre Attribute."""
    knoten_von, mittel, mitglieder = _grade(stuecke, toleranz)
    weg = set()
    meld = []
    for i, s in enumerate(stuecke):
        if s["geom"].length >= KLEINST_M or i in weg:
            continue
        ka, kb = knoten_von[(i, 0)], knoten_von[(i, 1)]
        pa, pb = mittel[ka], mittel[kb]
        ziel = Point((pa.x + pb.x) / 2.0, (pa.y + pb.y) / 2.0)
        for kid in {ka, kb}:
            for (j, w) in mitglieder.get(kid, []):
                if j != i and j not in weg:
                    stuecke[j]["geom"] = _ende_setzen(stuecke[j]["geom"], w, ziel)
            mittel[kid] = ziel
        weg.add(i)
        meld.append("Kleinstsegment: Stueck {} ({:.2f} m) auf einen Knoten zusammengezogen".format(_name(s), s["geom"].length))
    neu = [s for k, s in enumerate(stuecke) if k not in weg and s["geom"].length > 0.01]
    return neu, meld, {"kleinst": len(weg)}


def _verbinder(vorbild, p_von, p_nach, kuerzel, quelle, typ=None, hk=None):
    attr = dict(vorbild["attr"]) if vorbild is not None else {}
    attr["uid"] = _neue_uid(attr if hk is None else {"hk": hk}, kuerzel)
    if hk is not None:
        attr["hk"] = hk
    if typ is not None:
        attr["typ"] = typ
    attr["bestand"] = 0
    attr["quelle_id"] = ""
    attr["mp_id"] = ""
    attr["quelle"] = quelle
    attr["hinweis"] = quelle
    return {"attr": attr, "geom": LineString([(p_von.x, p_von.y), (p_nach.x, p_nach.y)]), "quelle": None, "teil": 0}


def offene_enden_schliessen(stuecke, toleranz, log, kontext=None):
    """Regel 3: offenes Ende (kein anderes Ende in der Toleranz), nicht an NVT/BSt, naechstes anderes Stueck zwischen toleranz und
    LUECKE_MAX_M -> Verbindungsstueck zum naechsten Punkt auf dem Netz (das Abzweig-Teilen danach macht daraus einen Knoten)."""
    knoten_von, mittel, mitglieder = _grade(stuecke, toleranz)
    geoms = [s["geom"] for s in stuecke]
    tree = STRtree(geoms)
    neu, meld = [], []
    for i, w, p in _enden(stuecke):
        if len(mitglieder.get(knoten_von[(i, w)], [])) > 1:
            continue                                  # haengt schon an einem Knoten
        if _nahe_ziel(p, kontext):
            continue                                  # gewollt offen: Zufuehrung endet am NVT / an der BSt
        if len(mitglieder.get(knoten_von[(i, 1 - w)], [])) >= 3 and stuecke[i]["geom"].length <= UEBERSTAND_MAX_M:
            continue                                  # kurzer Ueberstand hinter einem Knoten (z. B. Bestand, nicht gekappt): nicht zur Schleife schliessen
        best = None
        for j in tree.query(p.buffer(LUECKE_MAX_M)):
            j = int(j)
            if j == i:
                continue
            dd = geoms[j].distance(p)
            if toleranz < dd <= LUECKE_MAX_M and (best is None or dd < best[0]):
                best = (dd, j)
        if best is None:
            continue
        dd, j = best
        g = geoms[j]
        dproj = g.project(p)
        if dproj <= toleranz:
            q = Point(g.coords[0][:2])
        elif dproj >= g.length - toleranz:
            q = Point(g.coords[-1][:2])
        else:
            q = g.interpolate(dproj)
        neu.append(_verbinder(stuecke[i], p, q, "v", "Bereinigung: Luecke {:.1f} m geschlossen".format(dd)))
        meld.append("offenes Ende: Stueck {} mit {:.1f} m Verbindungsstueck an Stueck {} angeschlossen".format(_name(stuecke[i]), dd, _name(stuecke[j])))
    return stuecke + neu, meld, {"luecken_geschlossen": len(neu)}


def nvt_zufuehrung(stuecke, toleranz, log, kontext=None):
    """Regel 5: NVT ohne Trassenende in der Toleranz, Netz aber innerhalb NVT_MAX_M -> Zufuehrung vom naechsten Netzpunkt zum NVT."""
    nvts = list((kontext or {}).get("nvt") or [])
    if not nvts or not stuecke:
        return stuecke, [], {"zufuehrungen": 0}
    enden = [e[2] for e in _enden(stuecke)]
    etree = STRtree(enden) if enden else None
    geoms = [s["geom"] for s in stuecke]
    tree = STRtree(geoms)
    neu, meld = [], []
    for name, hk, p in nvts:
        if not hk:
            continue
        if etree is not None and any(enden[int(k)].distance(p) <= toleranz for k in etree.query(p.buffer(toleranz))):
            continue
        best = None
        for j in tree.query(p.buffer(NVT_MAX_M)):
            j = int(j)
            dd = geoms[j].distance(p)
            if dd <= NVT_MAX_M and (best is None or dd < best[0]):
                best = (dd, j)
        if best is None:
            continue
        dd, j = best
        g = geoms[j]
        dproj = g.project(p)
        q = Point(g.coords[0][:2]) if dproj <= toleranz else (Point(g.coords[-1][:2]) if dproj >= g.length - toleranz else g.interpolate(dproj))
        neu.append(_verbinder(stuecke[j], q, p, "z", "Bereinigung: Zufuehrung NVT {}".format(name), typ="Zufuehrung", hk=hk))
        meld.append("NVT ohne Trasse: Zufuehrung {:.1f} m vom Netz zum NVT {} angelegt (Strang {})".format(dd, name, hk))
    return stuecke + neu, meld, {"zufuehrungen": len(neu)}


def ueberstaende_kappen(stuecke, toleranz, log, kontext=None):
    """Regel 4: Neubau-Stueck bis UEBERSTAND_MAX_M, ein Ende frei (nicht an NVT/BSt), das andere an einem Knoten mit mindestens drei
    Stuecken -> ueberfluessiger Ueberstand hinter dem Abzweig, wird geloescht."""
    knoten_von, mittel, mitglieder = _grade(stuecke, toleranz)
    weg = set()
    meld = []
    for i, s in enumerate(stuecke):
        if _ist_bestand(s) or s["geom"].length > UEBERSTAND_MAX_M:
            continue
        ka, kb = knoten_von[(i, 0)], knoten_von[(i, 1)]
        ga, gb = len(mitglieder.get(ka, [])), len(mitglieder.get(kb, []))
        if {ga == 1, gb == 1} != {True, False}:
            continue
        frei, knoten = (0, kb) if ga == 1 else (1, ka)
        if len(mitglieder.get(knoten, [])) < 3:
            continue
        c = list(s["geom"].coords)
        p_frei = Point(c[0][:2] if frei == 0 else c[-1][:2])
        if _nahe_ziel(p_frei, kontext):
            continue
        weg.add(i)
        meld.append("Ueberstand: Stueck {} ({:.1f} m, freies Ende hinter dem Knoten) geloescht".format(_name(s), s["geom"].length))
    return [s for k, s in enumerate(stuecke) if k not in weg], meld, {"ueberstaende": len(weg)}


def strang_pruefen(stuecke, toleranz, log, kontext=None):
    """Regel 6 (nur melden): Stueck traegt Strang X, haengt aber nur an Stuecken eines anderen Strangs Y."""
    knoten_von, mittel, mitglieder = _grade(stuecke, toleranz)
    meld = []
    for i, s in enumerate(stuecke):
        hk = str(s["attr"].get("hk") or "")
        if not hk:
            continue
        nachbarn = set()
        for w in (0, 1):
            for (j, _) in mitglieder.get(knoten_von[(i, w)], []):
                if j != i:
                    nachbarn.add(str(stuecke[j]["attr"].get("hk") or ""))
        nachbarn.discard("")
        if nachbarn and hk not in nachbarn and len(nachbarn) == 1:
            meld.append("Hinweis Strang: Stueck {} traegt Strang {}, haengt aber nur an Strang {} - bitte pruefen (nicht geaendert)".format(
                _name(s), hk, next(iter(nachbarn))))
    return stuecke, meld, {"strang_hinweise": len(meld)}


# Reihenfolge: erst Netz sauber (Enden, Doppelte, Abzweige, Kreuzungen), dann Luecken und Zufuehrungen anbauen und ihre Enden einbinden,
# dann Ueberstaende kappen, Kleinstsegmente einziehen, zuletzt Strang-Hinweise.
REGELN = [("Enden einrasten", enden_einrasten), ("Doppelte entfernen", doppelte_entfernen), ("Abzweige teilen", abzweige_teilen),
          ("Kreuzungen teilen", kreuzungen_teilen), ("Enden einrasten", enden_einrasten),
          ("Ueberstaende kappen", ueberstaende_kappen),          # vor dem Lueckenschluss, sonst wird der Ueberstand zurueck ans Netz gehaengt
          ("Luecken schliessen", offene_enden_schliessen), ("NVT-Zufuehrung", nvt_zufuehrung), ("Abzweige teilen", abzweige_teilen),
          ("Enden einrasten", enden_einrasten), ("Kleinstsegmente", kleinstsegmente_verschmelzen),
          ("Enden einrasten", enden_einrasten), ("Strang pruefen", strang_pruefen)]
# Fuer pruefen(): nur, was die Verbindung erklaert, ohne etwas anzubauen - Luecken ueber 3 m bleiben dort Befund
REGELN_PRUEFUNG = [("Enden einrasten", enden_einrasten), ("Doppelte entfernen", doppelte_entfernen), ("Abzweige teilen", abzweige_teilen),
                   ("Kreuzungen teilen", kreuzungen_teilen), ("Enden einrasten", enden_einrasten)]


def normalisieren(a, toleranz=3.0, log=None, regeln=None, kontext=None):
    """Alle Regeln ueber die Planung laufen lassen. a: GeoDataFrame hk_planung. kontext: dict(ziele=[Point], nvt=[(name, hk, Point)]).
    -> (stuecke, zusammenfassung dict, meldungen list)"""
    stuecke = _in_stuecke(a)
    zusammen = {"vorher": len(stuecke)}
    meldungen = []
    for name, fn in (regeln or REGELN):
        try:
            stuecke, meld, z = fn(stuecke, toleranz, log, kontext)
        except TypeError:
            stuecke, meld, z = fn(stuecke, toleranz, log)
        for k, v in z.items():
            zusammen[k] = zusammen.get(k, 0) + v
        meldungen.extend("{}: {}".format(name, m) for m in meld)
    zusammen["nachher"] = len(stuecke)
    zusammen["geteilt_linien"] = zusammen.get("linien_abzweig", 0) + zusammen.get("linien_kreuzung", 0)
    zusammen["geaendert"] = sum(zusammen.get(k, 0) for k in ("geteilt_linien", "enden_zusammen", "doppelte", "kleinst", "luecken_geschlossen",
                                                              "zufuehrungen", "ueberstaende"))
    return stuecke, zusammen, meldungen


def zusammenfassung_text(z):
    teile = []
    if z.get("geteilt_linien"):
        teile.append("{} Linien an {} Abzweigen und {} Kreuzungen geteilt".format(z["geteilt_linien"], z.get("abzweige", 0), z.get("kreuzungen", 0)))
    if z.get("enden_zusammen"):
        teile.append("{} Enden zusammengefuehrt".format(z["enden_zusammen"]))
    for k, text in (("doppelte", "{} doppelte Linien entfernt"), ("luecken_geschlossen", "{} Luecken (3-10 m) geschlossen"),
                    ("zufuehrungen", "{} NVT-Zufuehrungen angelegt"), ("ueberstaende", "{} Ueberstaende gekappt"), ("kleinst", "{} Kleinstsegmente eingezogen")):
        if z.get(k):
            teile.append(text.format(z[k]))
    hinweis = " | {} Strang-Hinweise (nur gemeldet)".format(z["strang_hinweise"]) if z.get("strang_hinweise") else ""
    if not teile:
        return "Nichts zu bereinigen: keine Abzweige mitten auf Linien, keine Kreuzungen ohne Knoten, keine nahen Enden, keine Doppelten, " \
               "Luecken, Ueberstaende oder Kleinstsegmente." + hinweis
    return "; ".join(teile) + " ({} -> {} Stuecke)".format(z.get("vorher", 0), z.get("nachher", 0)) + hinweis


