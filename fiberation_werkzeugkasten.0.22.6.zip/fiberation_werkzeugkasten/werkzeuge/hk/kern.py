# -*- coding: utf-8 -*-
"""Schritt 6 "Hauptkabel clustern" und Schritt 7 "Hk-Trasse je Strang" - Kern ohne Qt.

Markus 22.09.2026: "Tool 6 muss naeher an die Funktionen ran wie beim Vzk: erst Hk clustern als ein Tool, dann Wegefuehrung pro Hk als
Trassenvorschlag und am Ende Einzeichnen vom Planer - zwei Tools. Rohre und Kabel (alter Punkt 7) macht der Planer am Ende in Plan[Goo]."
Markus 18.09.2026: "das Werkzeug schneidet die Hk und macht Polygone mit Reserve, maximaler Anzahl an NVT und Faserreserven aus ZTV; die NVT
muessen kartografisch aneinander sein; der Planer braucht den kuerzesten Weg von der Betriebsstelle zu allen NVT; die Trasse dahin zeichnet er
nach; Vorschlaege fuer Muffen; Bestand aus Schritt 1 uebernehmen".

Schritt 6 - schneiden(): NVT-Gebiete aus Schritt 3 (Polygone, hk_fasern nach ZTV 21 Kap. 8.6.2.3, Sitz, Netzgraph _graph.pkl), wahlweise
gesicherte Standorte aus Schritt 4, die Vzk-Trassen aus Schritt 5 (der Hk folgt ihnen: Tiefbau nur einmal bezahlt) und der Bestand aus
Schritt 1 (Telekom-Trassen als Weg, werkzeuge/bestand/netz.py), die Betriebsstelle (Plan[Goo]-Punkt bst oder Klick) und der Hk-Nummernkreis
(Stamm wie "5263B-1/" + laufende Nummer; ohne Vorgabe aus ONKZ/ASB).
  1. Steinerbaum von der BSt zu allen NVT im Netz (Vzk-Trassen 10 %, Bestandsrohr Einzugspreis, Telekom-Trasse Vorzug) - nur intern, um die
     Straenge zu bilden; der Baum wird NICHT als Vorlage ausgegeben.
  2. Straenge = zusammenhaengende Teilbaeume in Laufrichtung von der BSt nach aussen (HLD Roboter naming): an der BSt trennt jede Richtung
     einen eigenen Strang, weiter aussen fuehrt der schwerste Ast den Strang weiter, kleinere Aeste werden eigene Straenge; Deckel MAX_NVT
     und MAX_FASERN; Kleinstraenge (<= 2 NVT) wandern in den Strang des Stammes oder in die winkelnaechste Nachbarrichtung.
  Ausgabe hk_<Stamm>_<Datum>.gpkg: hk_gebiete (Polygon je Strang, Reserve, weg_km als Schaetzung aus dem Clusterbaum), hk_nvt (Strang,
  Reihenfolge), bst, leere hk_vorlage/hk_muffen/hk_planung + _liste.json (alle Parameter fuer Schritt 7) + Bericht.

Schritt 7 - vorlage_rechnen(): je Strang der Steinerbaum BSt -> NVT des Strangs auf demselben Netz (Vzk-Trassen, Bestand als Weg), Kabelgroesse
je Abschnitt (12/24/48/96, ZTV 21 Kap. 8.6.2.2), Zufuehrungen NVT/BSt, Muffen an Verzweigungen und NVT-Abzweigen -> hk_vorlage/hk_muffen
(Zeilen des Strangs ersetzt), hk_gebiete.vorlage_km, hk_nvt.weg_m/reihenfolge. Der Planer zeichnet danach die Hk-Trasse (hk_planung), uebernimmt
die Vorlage oder Bestand aus Schritt 1, prueft (pruefen()). Nach Plan[Goo] ueber Schritt 10.
"""
import json
import math
import os
import re
import time
from collections import defaultdict
from datetime import datetime

import geopandas as gpd
import networkx as nx
import numpy as np
import pandas as pd
from shapely.geometry import LineString, Point
from shapely.ops import unary_union

from ... import schema

CRS = 25832
HK_REIHE = [12, 24, 48, 96]
MAX_NVT = 5              # Markus 09.09.2026: hoechstens 5 NVT je Hk-Strang (Reserve im Stamm)
MAX_FASERN = 96
ANTEIL_VZK = 0.1         # Kante auf einer Vzk-Trasse kostet fuer den Hk nur diesen Anteil (Tiefbau wird nur einmal bezahlt)
ANTEIL_BESTAND = 0.05
BST_MAX_ABSTAND_M = 300.0
# Markus 12.10.2026: dieselben Plan[Goo]-Felder wie die NVT-Planung aus Schritt 5 (bauverfahren, surface, allowance, location_hint, wesi,
# sub_type, bestand) - die Tabellen beider Planungen sind einheitlich, leere Werte sind erlaubt; die Uebergabe (Schritt 10) legt beide zusammen.
PLANUNG_SPALTEN = schema.HK_PLANUNG_SPALTEN
STATUS_STRANG = schema.STATUS


from ... import gemeinsam
_s = gemeinsam.s


def stamm_von(gebiete_gpkg):
    s = os.path.splitext(os.path.basename(str(gebiete_gpkg)))[0]
    return s[len("nvt_gebiete_"):] if s.startswith("nvt_gebiete_") else s


def onkz_asb(gebiete_gpkg):
    """(ONKZ, ASB) aus dem Adressen-Layer des Schnitts (haeufigster Wert), sonst ('', '')."""
    try:
        a = gpd.read_file(gebiete_gpkg, layer="adressen", columns=["onkz", "asb"])
        onkz = str(a["onkz"].dropna().astype(str).str.strip().replace("", np.nan).dropna().mode().iloc[0]) if "onkz" in a else ""
        asb = str(a["asb"].dropna().astype(str).str.strip().replace("", np.nan).dropna().mode().iloc[0]) if "asb" in a else ""
        return onkz, asb
    except Exception:
        return "", ""


def hk_stamm_vorschlag(gebiete_gpkg):
    """'5263B-1/' aus ONKZ/ASB (Telekom-Muster {onkz}B-{asb}/{nr}, Mannheim 621B-87/15), sonst 'Hk '."""
    onkz, asb = onkz_asb(gebiete_gpkg)
    return "{}B-{}/".format(onkz, asb) if onkz and asb else "Hk "


def bst_name_vorschlag(gebiete_gpkg):
    onkz, asb = onkz_asb(gebiete_gpkg)
    return "BSt {}/{}".format(onkz, asb) if onkz and asb else "BSt"


def bst_aus_plangoo(plangoo_gpkg):
    """Betriebsstelle aus einem Plan[Goo]-GeoPackage (GEOMETRY_POINT, TYPE bst) -> (x, y, name) in EPSG:25832 oder None."""
    try:
        pt = gpd.read_file(plangoo_gpkg, layer="GEOMETRY_POINT")
    except Exception:
        return None
    pt = pt[pt["TYPE"].astype(str) == "bst"]
    if not len(pt):
        return None
    if pt.crs is None:
        pt = pt.set_crs(3857, allow_override=True)
    pt = pt.to_crs(CRS)
    g = pt.geometry.iloc[0]
    return (g.x, g.y, _s(pt["NAME"].iloc[0]) or "BSt")


def bst_abstand_km(gebiete_gpkg, x, y):
    """Abstand der Betriebsstelle zur Mitte der NVT-Gebiete in km - Plausibilitaet (Markus 18.09.2026: BSt aus Mannheim fuer Barntrup genommen)."""
    try:
        g = gpd.read_file(gebiete_gpkg, layer="nvt_gebiete")
        if g.crs is not None and g.crs.to_epsg() != CRS:
            g = g.to_crs(CRS)
        b = g.total_bounds
        return math.hypot(x - (b[0] + b[2]) / 2, y - (b[1] + b[3]) / 2) / 1000.0
    except Exception:
        return 0.0


def nvt_laden(gebiete_gpkg, standorte_gpkg=None, log=print):
    """NVT des Schnitts: name, hk_fasern, apl, Polygon, Punkt (Standort aus Schritt 4, sonst Sitz)."""
    geb = gpd.read_file(gebiete_gpkg, layer="nvt_gebiete")
    if geb.crs is None or geb.crs.to_epsg() != CRS:
        geb = geb.set_crs(CRS, allow_override=True) if geb.crs is None else geb.to_crs(CRS)
    sitz = gpd.read_file(gebiete_gpkg, layer="nvt_sitz")
    if sitz.crs is None or sitz.crs.to_epsg() != CRS:
        sitz = sitz.set_crs(CRS, allow_override=True) if sitz.crs is None else sitz.to_crs(CRS)
    punkt = {str(r["name"]): (r.geometry.x, r.geometry.y) for _, r in sitz.iterrows() if r.geometry is not None}
    quelle = {n: "Sitz" for n in punkt}
    if standorte_gpkg and os.path.exists(standorte_gpkg):
        try:
            from ..standort import kern as sk
            for n, xy in sk.standorte_fuer_netz(standorte_gpkg, log=log).items():
                punkt[n] = xy
                quelle[n] = "Standort"
        except Exception as e:
            log("Standorte nicht gelesen: {!r}".format(e))
    geb["name"] = geb["name"].astype(str)
    geb["hk_fasern"] = pd.to_numeric(geb["hk_fasern"], errors="coerce").fillna(12).astype(int) if "hk_fasern" in geb else 12
    geb["px"] = geb["name"].map(lambda n: punkt.get(n, (None, None))[0])
    geb["py"] = geb["name"].map(lambda n: punkt.get(n, (None, None))[1])
    geb["punkt_quelle"] = geb["name"].map(lambda n: quelle.get(n, ""))
    ohne = geb[geb["px"].isna()]
    for _, r in ohne.iterrows():           # ohne Sitz: Polygonmitte
        c = r.geometry.representative_point()
        geb.loc[r.name, ["px", "py", "punkt_quelle"]] = [c.x, c.y, "Polygonmitte"]
    return geb


def graph_laden(gebiete_gpkg):
    import pickle
    pkl = os.path.splitext(gebiete_gpkg)[0] + "_graph.pkl"
    if not os.path.exists(pkl):
        raise RuntimeError("Netzgraph fehlt ({}) - Schritt 3 neu schneiden.".format(os.path.basename(pkl)))
    with open(pkl, "rb") as fh:
        G = pickle.load(fh)
    return G


def _knoten_index(G):
    namen = [n for n in G.nodes if "x" in G.nodes[n]]
    xy = np.array([[G.nodes[n]["x"], G.nodes[n]["y"]] for n in namen]) if namen else np.zeros((0, 2))
    return namen, xy


def naechster_knoten(namen, xy, x, y, ohne_adressen=True):
    if not len(xy):
        return None, None
    d = np.hypot(xy[:, 0] - x, xy[:, 1] - y)
    if ohne_adressen:
        maske = np.array([not str(n).startswith("A_") for n in namen])
        d = np.where(maske, d, np.inf)
    i = int(np.argmin(d))
    return namen[i], float(d[i])


def _kante_geom(G, u, v):
    d = G[u][v]
    g = d.get("geometry")
    ux, uy = G.nodes[u]["x"], G.nodes[u]["y"]
    vx, vy = G.nodes[v]["x"], G.nodes[v]["y"]
    if g is None or getattr(g, "is_empty", True) or g.geom_type != "LineString":
        return LineString([(ux, uy), (vx, vy)])
    c = list(g.coords)
    if math.hypot(c[0][0] - vx, c[0][1] - vy) < math.hypot(c[0][0] - ux, c[0][1] - uy):
        c = c[::-1]
    c[0], c[-1] = (ux, uy), (vx, vy)
    return LineString(c)


def _vzk_markieren(G, trassen_gpkg, log):
    """Kanten, die auf Vzk-Trassen aus Schritt 5 liegen (Planung + Endstand), bekommen den guenstigen Hk-Preis."""
    linien = []
    for ebene in ("planung", "final"):
        try:
            t = gpd.read_file(trassen_gpkg, layer=ebene)
            t = t[t.geometry.notna()]
            if t.crs is not None and t.crs.to_epsg() != CRS:
                t = t.to_crs(CRS)
            linien += list(t.geometry)
        except Exception:
            pass
    if not linien:
        return 0
    from shapely.strtree import STRtree
    puffer = [g.buffer(2.0) for g in linien]
    baum = STRtree(puffer)
    n = 0
    for u, v, d in G.edges(data=True):
        if "x" not in G.nodes[u] or "x" not in G.nodes[v]:
            continue
        geom = _kante_geom(G, u, v)
        treffer = baum.query(geom)
        if len(treffer) == 0:
            continue
        drin = unary_union([puffer[i] for i in treffer]).intersection(geom).length
        if geom.length > 0 and drin / geom.length >= 0.8:
            d["vzk"] = True
            n += 1
    log("Vzk-Trassen aus Schritt 5: {} Netzkanten liegen darauf (Hk-Preis {:.0f} %)".format(n, ANTEIL_VZK * 100))
    return n


def _lage(d):
    from ..bestand.netz import lage_von
    return lage_von(d)


def _luecken_schliessen(G, bst, nvt_knoten, log):
    """Netzteile, die einen NVT tragen, aber nicht mit der BSt verbunden sind, mit der kuerzesten geraden Verbindung an den BSt-Teil haengen
    (Barntrup 18.09.2026: OSM-Abruf auf den Adressbereich beschnitten, Landstrassen zu Selbeck/Sommersell fehlen -> 21 NVT ohne Strang).
    Die Bruecke bekommt den mittleren Strassenpreis und art 'Netzluecke'; der Planer zeichnet dort den echten Weg. -> Liste (u, v, laenge)"""
    komps = list(nx.connected_components(G))
    komp_von = {n: i for i, c in enumerate(komps) for n in c}
    ziel = komp_von[bst]
    noetig = sorted(set(komp_von[k] for k in nvt_knoten.values() if komp_von.get(k, ziel) != ziel))
    if not noetig:
        return []
    preise = [d["cost"] / d["length"] for _, _, d in G.edges(data=True) if d.get("length") and d.get("cost")]
    eur_m = float(np.median(preise)) if preise else 150.0

    def punkte(c):
        namen = [n for n in c if "x" in G.nodes[n] and not str(n).startswith("A_")]
        return namen, np.array([[G.nodes[n]["x"], G.nodes[n]["y"]] for n in namen])

    bruecken = []
    verbunden = set(komps[ziel])
    offen = [komps[i] for i in noetig]
    while offen:
        hn, hxy = punkte(verbunden)
        beste = None
        for c in offen:
            cn, cxy = punkte(c)
            if not len(cxy) or not len(hxy):
                continue
            for j in range(0, len(cxy), 500):
                blk = cxy[j:j + 500]
                d = np.hypot(blk[:, None, 0] - hxy[None, :, 0], blk[:, None, 1] - hxy[None, :, 1])
                i = int(np.argmin(d))
                a, b = divmod(i, d.shape[1])
                if beste is None or d[a, b] < beste[0]:
                    beste = (float(d[a, b]), cn[j + a], hn[b], c)
        if beste is None:
            break
        l, u, v, c = beste
        G.add_edge(u, v, length=l, cost=l * eur_m, geometry=LineString([(G.nodes[u]["x"], G.nodes[u]["y"]), (G.nodes[v]["x"], G.nodes[v]["y"])]),
                   name="Netzluecke", quelle_id="luecke", luecke=True)
        bruecken.append((u, v, l))
        verbunden |= set(c)
        offen.remove(c)
    log("ACHTUNG: {} Netzluecken ueberbrueckt (gerade Verbindung, {:.0f} m gesamt) - Landstrassen fehlen im OSM-Ausschnitt von Schritt 3; den Weg dort bitte nachzeichnen".format(
        len(bruecken), sum(b[2] for b in bruecken)))
    return bruecken


def _hk_groesse(fasern, eltern=None):
    """Kabelgroesse eines Hk-Segments (ZTV 21 Kap. 8.6.2.2). eltern = Groesse stromauf (None = Start an der BSt): Kabel halbieren sich
    nur, wenn der Bedarf dahinter in die halbe Groesse passt."""
    if eltern is None:
        for g in HK_REIHE:
            if g >= fasern:
                return g
        return HK_REIHE[-1]
    g = eltern
    while g > HK_REIHE[0] and fasern <= g / 2:
        g //= 2
    return max(g, HK_REIHE[0])


def _straenge(tree, bst, node_nvt, fasern_von, xy_von, max_f, max_n):
    """Strangzerlegung (HLD Roboter naming.benenne, 08.-09.09.2026). -> (strang_von_nvt, wurzel_von_strang)"""
    unter, unter_n = {}, {}
    for n in reversed(list(nx.topological_sort(tree))):
        unter[n] = sum(fasern_von[j] for j in node_nvt.get(n, [])) + sum(unter[c] for c in tree.successors(n))
        unter_n[n] = len(node_nvt.get(n, [])) + sum(unter_n[c] for c in tree.successors(n))
    strang_von_nvt, strang_von_node, summen, anz, wurzel = {}, {}, {}, {}, {}
    zaehler = [0]

    def neuer_strang(n=None):
        zaehler[0] += 1
        st = zaehler[0]
        summen[st], anz[st], wurzel[st] = 0, 0, n
        return st

    def passt(st, n):
        return summen[st] + unter[n] <= max_f and anz[st] + unter_n[n] <= max_n

    def zuweisen(n, st):
        for j in node_nvt.get(n, []):
            strang_von_nvt[j] = st
            strang_von_node[n] = st
            summen[st] += fasern_von[j]
            anz[st] += 1

    def ganzer_teilbaum(n, st):
        for d in nx.dfs_preorder_nodes(tree, n):
            zuweisen(d, st)

    stapel = [(bst, None)]
    while stapel:
        n, st = stapel.pop()
        if unter[n] == 0:
            continue
        if st is not None and passt(st, n):
            ganzer_teilbaum(n, st)
            continue
        if st is None and unter[n] <= max_f and unter_n[n] <= max_n and n != bst:
            st = neuer_strang(n)
            ganzer_teilbaum(n, st)
            continue
        eigene = sum(fasern_von[j] for j in node_nvt.get(n, []))
        if eigene:
            if st is None or summen[st] + eigene > max_f or anz[st] + len(node_nvt.get(n, [])) > max_n:
                st = neuer_strang(n)
            zuweisen(n, st)
        kinder = sorted([c for c in tree.successors(n) if unter[c] > 0], key=lambda c: unter[c])
        if not kinder:
            continue
        if n == bst:
            for c in kinder:                       # jede Richtung ab BSt ein eigener Strang
                stapel.append((c, None))
            continue
        schwer = kinder[-1]
        for c in kinder[:-1]:                      # kleine Abzweige: passen sie noch in den laufenden Strang?
            if st is not None and passt(st, c):
                ganzer_teilbaum(c, st)
            elif unter[c] <= max_f and unter_n[c] <= max_n:
                ganzer_teilbaum(c, neuer_strang(c))
            else:
                stapel.append((c, None))
        stapel.append((schwer, st))                # schwerster Ast fuehrt den Strang weiter

    # Kleinstraenge (<= 2 NVT) zusammenlegen: erst untereinander am selben Stamm, dann in den Stamm bzw. die winkelnaechste Nachbarrichtung
    def erster_nvt_unter(c):
        for d in nx.dfs_preorder_nodes(tree, c):
            if d in strang_von_node:
                return strang_von_node[d]
        return None

    def stamm_von(st):
        w = wurzel.get(st)
        if w is None:
            return None
        p_ = list(tree.predecessors(w))
        p_ = p_[0] if p_ else None
        while p_ is not None and p_ != bst:
            if p_ in strang_von_node and strang_von_node[p_] != st:
                return strang_von_node[p_]
            pr_ = list(tree.predecessors(p_))
            p_ = pr_[0] if pr_ else None
        return "BST"

    def verschmelzen(st, z):
        for j, sj in list(strang_von_nvt.items()):
            if sj == st:
                strang_von_nvt[j] = z
        for n_, sn in list(strang_von_node.items()):
            if sn == st:
                strang_von_node[n_] = z
        summen[z] += summen[st]
        anz[z] += anz[st]
        summen[st], anz[st] = 0, 0

    klein = [st for st in summen if 0 < anz.get(st, 0) <= 2 and wurzel.get(st) not in (None, bst)]
    for st in sorted(klein, key=lambda k: summen[k]):
        if anz.get(st, 0) == 0:
            continue
        stamm = stamm_von(st)
        wx, wy = xy_von(wurzel[st])
        partner = [z for z in klein if z != st and anz.get(z, 0) > 0 and stamm_von(z) == stamm and summen[z] + summen[st] <= max_f
                   and anz[z] + anz[st] <= max_n]
        partner.sort(key=lambda z: math.hypot(xy_von(wurzel[z])[0] - wx, xy_von(wurzel[z])[1] - wy))
        if partner:
            verschmelzen(st, partner[0])
    for st in sorted(list(summen), key=lambda k: summen[k]):
        if anz.get(st, 0) == 0 or anz[st] > 2 or wurzel.get(st) in (None, bst):
            continue
        w = wurzel[st]
        eltern = list(tree.predecessors(w))
        if not eltern:
            continue
        e = eltern[0]
        kandidaten = []
        if e != bst:
            p_ = e
            while p_ is not None and p_ != bst:
                if p_ in strang_von_node and strang_von_node[p_] != st:
                    kandidaten.append(strang_von_node[p_])
                    break
                pr_ = list(tree.predecessors(p_))
                p_ = pr_[0] if pr_ else None
        wx, wy = xy_von(w)
        ex, ey = xy_von(e)
        geschwister = []
        for c in tree.successors(e):
            if c == w:
                continue
            s2 = erster_nvt_unter(c)
            if s2 is None or s2 == st:
                continue
            cx, cy = xy_von(c)
            a1, a2 = math.atan2(wy - ey, wx - ex), math.atan2(cy - ey, cx - ex)
            geschwister.append((abs((a1 - a2 + math.pi) % (2 * math.pi) - math.pi), s2))
        kandidaten += [s2 for _, s2 in sorted(geschwister)]
        for z in kandidaten:
            if z in summen and anz.get(z, 0) > 0 and summen[z] + summen[st] <= max_f and anz[z] + anz[st] <= max_n:
                verschmelzen(st, z)
                break
    # lueckenlos neu nummerieren in Reihenfolge des ersten NVT im Baum (DFS von der BSt)
    reihen = []
    for n in nx.dfs_preorder_nodes(tree, bst):
        for j in node_nvt.get(n, []):
            st = strang_von_nvt.get(j)
            if st is not None and st not in reihen:
                reihen.append(st)
    neu = {st: i + 1 for i, st in enumerate(reihen)}
    return {j: neu[st] for j, st in strang_von_nvt.items()}, {neu[st]: wurzel.get(st) for st in reihen}


def netz_vorbereiten(gebiete_gpkg, nvt, bst_xy, trassen_gpkg=None, bestand_gpkg=None, log=print, fortschritt=None):
    """Netz fuer Straenge und Weg: Graph aus Schritt 3, Vzk-Trassen (Hk-Preis 10 %), Bestand aus Schritt 1 als Weg, BSt und NVT anbinden,
    Netzluecken ueberbruecken. nvt: DataFrame mit name, px, py. -> dict(G, bst, dbst, hinweis_bst, nvt_knoten, node_nvt, bruecken, bestand_weg)"""
    f = fortschritt or (lambda p, t: None)
    G = graph_laden(gebiete_gpkg)
    log("Netz: {} Knoten, {} Kanten".format(G.number_of_nodes(), G.number_of_edges()))
    if trassen_gpkg and os.path.exists(str(trassen_gpkg)):
        _vzk_markieren(G, str(trassen_gpkg), log)
    bestand_weg = None
    if bestand_gpkg and os.path.exists(str(bestand_gpkg)):
        f(12, "Bestand aus Schritt 1 als Weg")
        from ..bestand import netz as bnetz
        xs = list(nvt["px"].astype(float)) + [float(bst_xy[0])]
        ys = list(nvt["py"].astype(float)) + [float(bst_xy[1])]
        try:
            bestand_weg = bnetz.einblenden(G, str(bestand_gpkg), zweck="hk", bbox=(min(xs), min(ys), max(xs), max(ys)), log=log)
        except Exception as e:
            log("ACHTUNG: Bestand aus Schritt 1 nicht eingeblendet ({}) - Weg nur auf dem Netz".format(str(e)[:160]))
    for u, v, d in G.edges(data=True):
        basis = float(d.get("cost", d.get("length", 1.0)) or d.get("length", 1.0))
        d["hk_cost"] = basis * (ANTEIL_VZK if d.get("vzk") and not d.get("telekom_trasse") else 1.0)
        d["laenge"] = float(d.get("length") or 0.0)

    f(20, "Betriebsstelle anbinden")
    namen, xy = _knoten_index(G)
    bx, by = float(bst_xy[0]), float(bst_xy[1])
    bst, dbst = naechster_knoten(namen, xy, bx, by)
    if bst is None:
        raise RuntimeError("Netz ohne Knoten")
    hinweis_bst = ""
    if dbst > BST_MAX_ABSTAND_M:
        hinweis_bst = "Betriebsstelle liegt {:.0f} m vom Netz entfernt - der Weg beginnt am naechsten Netzknoten".format(dbst)
        log("ACHTUNG: " + hinweis_bst)
    nvt_knoten = {}
    for _, r in nvt.iterrows():
        k, _dk = naechster_knoten(namen, xy, float(r["px"]), float(r["py"]))
        nvt_knoten[str(r["name"])] = k
    node_nvt = defaultdict(list)
    for n_, k in nvt_knoten.items():
        node_nvt[k].append(n_)
    bruecken = _luecken_schliessen(G, bst, nvt_knoten, log)
    for u, v, d in G.edges(data=True):
        if d.get("luecke"):
            d["hk_cost"] = float(d["cost"])
            d["laenge"] = float(d["length"])
    return {"G": G, "bst": bst, "dbst": dbst, "hinweis_bst": hinweis_bst, "nvt_knoten": nvt_knoten, "node_nvt": node_nvt, "bruecken": bruecken,
            "bestand_weg": bestand_weg, "bst_xy": (bx, by)}


def _steinerbaum(G, bst, terminals):
    from networkx.algorithms.approximation import steiner_tree
    komp = nx.node_connected_component(G, bst)
    H = G.subgraph(komp)
    ts = [t for t in dict.fromkeys(terminals) if t in komp]
    if len(ts) < 2:
        return None, komp
    try:
        T = steiner_tree(H, ts, weight="hk_cost", method="mehlhorn")
    except TypeError:
        T = steiner_tree(H, ts, weight="hk_cost")
    return nx.bfs_tree(T, bst), komp


def _weg_aus_baum(netz, tree, hk_von_nvt, fasern_von, nvt_xy, bst_name):
    """Kanten der Weg-Vorlage, Muffen und Weglaengen aus einem Baum (BSt -> NVT). hk_von_nvt: NVT-Name -> Strangname.
    -> (kanten (Liste dict), muffen (Liste dict), weg (Knoten -> m von der BSt), groesse_am (Knoten -> Kabelgroesse))"""
    G, bst = netz["G"], netz["bst"]
    node_nvt = {k: [j for j in v if j in hk_von_nvt] for k, v in netz["node_nvt"].items()}
    xy_von = lambda n: (G.nodes[n]["x"], G.nodes[n]["y"])
    demand, straenge_unter = {}, {}
    for n in reversed(list(nx.topological_sort(tree))):
        s_ = sum(fasern_von[j] for j in node_nvt.get(n, []))
        ss = set(hk_von_nvt[j] for j in node_nvt.get(n, []))
        for c in tree.successors(n):
            s_ += demand[c]
            ss |= straenge_unter[c]
        demand[n], straenge_unter[n] = s_, ss
    groesse_am, kanten = {}, []
    for a, b in nx.bfs_edges(tree, bst):
        fas = demand[b]
        eltern = groesse_am.get(a) if a != bst else None
        groesse = _hk_groesse(fas, eltern)
        groesse_am[b] = groesse
        geom = _kante_geom(G, a, b)
        d = G[a][b]
        sts = sorted(straenge_unter[b], key=_natsort)
        kanten.append({"hk": "; ".join(sts), "straenge": len(sts), "fasern": int(fas), "kabel": int(groesse), "laenge_m": round(geom.length, 1),
                       "vzk": int(bool(d.get("vzk"))), "art": "Netzluecke" if d.get("luecke") else "Weg", "lage": _lage(d), "rohrklasse": _s(d.get("rohrklasse")),
                       "mp_id": _s(d.get("mp_id")), "bestand_hinweis": _s(d.get("bestand_hinweis")), "strasse": _s(d.get("name")), "quelle_id": _s(d.get("quelle_id")), "geometry": geom})
    # Zufuehrungen: vom Netzknoten zum NVT-Punkt und vom Netzknoten zur BSt
    for n_, hk in hk_von_nvt.items():
        k = netz["nvt_knoten"].get(n_)
        if k is None or k not in tree:
            continue
        px, py = nvt_xy[n_]
        kx, ky = xy_von(k)
        if math.hypot(px - kx, py - ky) > 0.3:
            kanten.append({"hk": hk, "straenge": 1, "fasern": int(fasern_von[n_]), "kabel": int(groesse_am.get(k, _hk_groesse(fasern_von[n_]))),
                           "laenge_m": round(math.hypot(px - kx, py - ky), 1), "vzk": 0, "art": "Zufuehrung NVT", "lage": "", "rohrklasse": "", "mp_id": "",
                           "bestand_hinweis": "", "strasse": n_, "quelle_id": "nvt:" + n_, "geometry": LineString([(kx, ky), (px, py)])})
    bx, by = netz["bst_xy"]
    kx, ky = xy_von(bst)
    alle = sorted(set(hk_von_nvt.values()), key=_natsort)
    if math.hypot(bx - kx, by - ky) > 0.3:
        erster = next(iter(tree.successors(bst)), None)
        kanten.append({"hk": "; ".join(alle), "straenge": len(alle), "fasern": int(demand.get(bst, 0)), "kabel": int(groesse_am.get(erster, HK_REIHE[-1])) if erster else HK_REIHE[-1],
                       "laenge_m": round(math.hypot(bx - kx, by - ky), 1), "vzk": 0, "art": "Zufuehrung BSt", "lage": "", "rohrklasse": "", "mp_id": "", "bestand_hinweis": "",
                       "strasse": bst_name, "quelle_id": "bst", "geometry": LineString([(bx, by), (kx, ky)])})
    # Muffen: Verzweigung im Baum oder NVT, an dem das Kabel weiterlaeuft
    muffen = []
    for n in tree.nodes():
        if n == bst:
            continue
        kids = list(tree.successors(n))
        if len(kids) >= 2:
            art = "Verzweigung"
        elif n in node_nvt and node_nvt[n] and (kids or len(node_nvt[n]) > 1):
            art = "Abzweig NVT"
        else:
            continue
        sts = sorted(straenge_unter.get(n, set()), key=_natsort)
        muffen.append({"art": art, "hk": "; ".join(sts), "fasern_durch": int(demand[n]), "nvt": "; ".join(node_nvt.get(n, [])), "geometry": Point(*xy_von(n))})
    weg = nx.single_source_dijkstra_path_length(tree.to_undirected(), bst, weight=lambda u, v, d: G[u][v].get("laenge", 0.0))
    return kanten, muffen, weg, groesse_am


_natsort = gemeinsam.natsort


VORLAGE_SPALTEN = [("hk", "str"), ("straenge", "int"), ("fasern", "int"), ("kabel", "int"), ("laenge_m", "real"), ("vzk", "int"), ("art", "str"), ("lage", "str"),
                   ("rohrklasse", "str"), ("mp_id", "str"), ("bestand_hinweis", "str"), ("strasse", "str"), ("quelle_id", "str")]
MUFFEN_SPALTEN = [("art", "str"), ("hk", "str"), ("fasern_durch", "int"), ("nvt", "str"), ("name", "str")]


def _leere_ebene(gpkg, name, spalten, punkt=False):
    """Leere Ebene mit Spalten anlegen (OGR), falls sie fehlt."""
    from osgeo import ogr, osr
    ogr.UseExceptions()
    ds = ogr.Open(gpkg, 1)
    for i in range(ds.GetLayerCount()):
        if ds.GetLayerByIndex(i).GetName() == name:
            ds = None
            return
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(CRS)
    lyr = ds.CreateLayer(name, srs, ogr.wkbPoint if punkt else ogr.wkbLineString, ["GEOMETRY_NAME=geometry"])
    for c, t in spalten:
        lyr.CreateField(ogr.FieldDefn(c, {"int": ogr.OFTInteger, "real": ogr.OFTReal}.get(t, ogr.OFTString)))
    ds = None


def schneiden(gebiete_gpkg, bst_xy, bst_name=None, standorte_gpkg=None, trassen_gpkg=None, out_dir=None, hk_stamm=None, hk_start=1, hk_bis=None,
              max_nvt=MAX_NVT, max_fasern=MAX_FASERN, bestand_gpkg=None, log=print, fortschritt=None):
    """Schritt 6: Straenge bilden (Clusterbaum intern), Strang-Polygone, NVT mit Strang, BSt; leere Vorlage/Muffen/Planung fuer Schritt 7;
    GeoPackage + Liste (mit allen Parametern) + Bericht. -> dict"""
    t0 = time.time()
    f = fortschritt or (lambda p, t: None)
    gebiete_gpkg = str(gebiete_gpkg)
    out_dir = out_dir or os.path.dirname(gebiete_gpkg)
    os.makedirs(out_dir, exist_ok=True)
    st_name = stamm_von(gebiete_gpkg)
    hk_stamm = hk_stamm if hk_stamm is not None and str(hk_stamm).strip() != "" else hk_stamm_vorschlag(gebiete_gpkg)
    bst_name = bst_name or bst_name_vorschlag(gebiete_gpkg)
    from ..bestand.kern import ausgabe_pfad
    gpkg = ausgabe_pfad(out_dir, "hk_{}_{}.gpkg".format(st_name, datetime.now().strftime("%Y%m%d_%H%M")), log)

    f(5, "NVT und Netz lesen")
    nvt = nvt_laden(gebiete_gpkg, standorte_gpkg, log)
    log("NVT: {} ({} Fasern nach ZTV)".format(len(nvt), int(nvt["hk_fasern"].sum())))
    netz = netz_vorbereiten(gebiete_gpkg, nvt, bst_xy, trassen_gpkg, bestand_gpkg, log, f)
    G, bst, dbst = netz["G"], netz["bst"], netz["dbst"]
    nvt_knoten, node_nvt, bruecken = netz["nvt_knoten"], netz["node_nvt"], netz["bruecken"]
    bx, by = netz["bst_xy"]
    fasern_von = dict(zip(nvt["name"], nvt["hk_fasern"].astype(int)))

    f(35, "Clusterbaum (Steinerbaum)")
    tree, komp = _steinerbaum(G, bst, [bst] + [nvt_knoten[n_] for n_ in nvt["name"]])
    erreichbar = [n_ for n_ in nvt["name"] if nvt_knoten[n_] in komp]
    nicht = [n_ for n_ in nvt["name"] if nvt_knoten[n_] not in komp]
    if nicht:
        log("ACHTUNG: {} NVT im Netz nicht von der BSt erreichbar: {}".format(len(nicht), ", ".join(nicht[:10])))
    if tree is None:
        raise RuntimeError("Kein NVT von der Betriebsstelle aus erreichbar - Netz oder BSt-Lage pruefen.")

    f(55, "Straenge schneiden")
    xy_von = lambda n: (G.nodes[n]["x"], G.nodes[n]["y"])
    strang_von_nvt, wurzel_von_strang = _straenge(tree, bst, node_nvt, fasern_von, xy_von, int(max_fasern), int(max_nvt))
    anzahl = len(wurzel_von_strang)
    hk_name = {st: "{}{}".format(hk_stamm, int(hk_start) + st - 1) for st in range(1, anzahl + 1)}
    if hk_bis and int(hk_start) + anzahl - 1 > int(hk_bis):
        log("ACHTUNG: {} Straenge, der Nummernkreis {}{}-{}{} reicht nur fuer {}".format(anzahl, hk_stamm, hk_start, hk_stamm, hk_bis, int(hk_bis) - int(hk_start) + 1))
    hk_von_nvt = {n_: hk_name[s_] for n_, s_ in strang_von_nvt.items()}
    nvt_xy = {str(r["name"]): (float(r["px"]), float(r["py"])) for _, r in nvt.iterrows()}
    # Weg aus dem Clusterbaum nur fuer Kennzahlen (Schaetzung) - die Vorlage je Strang rechnet Schritt 7
    kanten, _muffen, weg, _g = _weg_aus_baum(netz, tree, hk_von_nvt, fasern_von, nvt_xy, bst_name)
    schaetz = gpd.GeoDataFrame(kanten, geometry="geometry", crs=CRS)

    reihenfolge = {}
    for st in wurzel_von_strang:
        js = [j for j, s_ in strang_von_nvt.items() if s_ == st]
        for i, j in enumerate(sorted(js, key=lambda j: weg.get(nvt_knoten[j], 0.0))):
            reihenfolge[j] = i + 1
    nvt_out = nvt.copy()
    nvt_out["hk"] = nvt_out["name"].map(lambda n_: hk_von_nvt.get(n_))
    nvt_out["hk_nr"] = nvt_out["name"].map(lambda n_: strang_von_nvt.get(n_))
    nvt_out["reihenfolge"] = nvt_out["name"].map(lambda n_: reihenfolge.get(n_))
    nvt_out["weg_m"] = nvt_out["name"].map(lambda n_: round(weg.get(nvt_knoten[n_], float("nan")), 0))
    nvt_out["status"] = ["offen" if n_ in strang_von_nvt else "nicht erreichbar" for n_ in nvt_out["name"]]
    nvt_out["hinweis"] = ["" if n_ in strang_von_nvt else "im Netz nicht von der BSt erreichbar - Netz in Schritt 3 pruefen oder Weg zeichnen" for n_ in nvt_out["name"]]
    spalten = [c for c in ("name", "hk", "hk_nr", "reihenfolge", "hk_fasern", "hk_text", "apl", "we", "weg_m", "punkt_quelle", "status", "hinweis") if c in nvt_out]
    nvt_pt = gpd.GeoDataFrame(nvt_out[spalten].copy(), geometry=[Point(x, y) for x, y in zip(nvt_out["px"], nvt_out["py"])], crs=CRS)

    f(75, "Strang-Polygone")
    zeilen = []
    for st, name in hk_name.items():
        js = [j for j, s_ in strang_von_nvt.items() if s_ == st]
        teil = nvt_out[nvt_out["name"].isin(js)]
        fas = int(teil["hk_fasern"].sum())
        kabel = _hk_groesse(fas)
        weg_km = round(schaetz[schaetz["art"].isin(("Weg", "Netzluecke")) & schaetz["hk"].astype(str).str.split("; ").apply(lambda xs: name in xs)]["laenge_m"].sum() / 1000, 2)
        poly = unary_union(list(teil.geometry)) if len(teil) else None
        if poly is not None and not poly.is_empty:
            geschlossen = poly.buffer(25.0).buffer(-25.0)
            poly = geschlossen if geschlossen.geom_type == "Polygon" else poly.buffer(0.5).buffer(-0.5)
        zeilen.append({"name": name, "nr": st, "nvt_anzahl": len(js), "nvt_frei": int(max_nvt) - len(js),
                       "nvt_liste": ", ".join(sorted(js, key=lambda j: reihenfolge.get(j, 0))), "fasern": fas, "kabel": int(kabel),
                       "reserve_fasern": int(kabel) - fas, "max_fasern": int(max_fasern), "weg_km": weg_km, "vorlage_km": 0.0, "vorlage_stand": "",
                       "muffen": 0, "muffen_stamm": 0, "status": "offen", "hinweis": "", "geometry": poly})
    gebiete = gpd.GeoDataFrame(zeilen, geometry="geometry", crs=CRS) if zeilen else gpd.GeoDataFrame(geometry=[], crs=CRS)
    bst_df = gpd.GeoDataFrame([{"name": bst_name, "knoten": str(bst), "abstand_netz_m": round(dbst, 1), "hinweis": netz["hinweis_bst"]}], geometry=[Point(bx, by)], crs=CRS)

    f(88, "Schreiben")
    gebiete.to_file(gpkg, layer="hk_gebiete", driver="GPKG")
    nvt_pt.to_file(gpkg, layer="hk_nvt", driver="GPKG")
    bst_df.to_file(gpkg, layer="bst", driver="GPKG")
    _leere_ebene(gpkg, "hk_vorlage", VORLAGE_SPALTEN)
    _leere_ebene(gpkg, "hk_muffen", MUFFEN_SPALTEN, punkt=True)
    planung_anlegen(gpkg)
    liste = {"straenge": [{k: (v if not isinstance(v, (np.integer, np.floating)) else v.item()) for k, v in z.items() if k != "geometry"} for z in zeilen],
             "nvt": [{"name": r["name"], "hk": r["hk"], "reihenfolge": None if pd.isna(r["reihenfolge"]) else int(r["reihenfolge"]), "fasern": int(r["hk_fasern"]),
                      "weg_m": None if pd.isna(r["weg_m"]) else float(r["weg_m"]), "status": r["status"], "punkt": r["punkt_quelle"]} for _, r in nvt_out.iterrows()],
             "bst": {"name": bst_name, "x": bx, "y": by, "abstand_netz_m": round(dbst, 1)}, "hk_stamm": hk_stamm, "hk_start": int(hk_start),
             "max_nvt": int(max_nvt), "max_fasern": int(max_fasern), "nicht_erreichbar": nicht, "quelle": gebiete_gpkg, "standorte": standorte_gpkg or "",
             "trassen": str(trassen_gpkg or ""), "bestand": str(bestand_gpkg or ""), "stamm": st_name,
             "netzluecken": [{"laenge_m": round(l, 0)} for _, _, l in bruecken], "bestand_weg": netz["bestand_weg"],
             "weg_km_schaetzung": round(schaetz.loc[schaetz["art"].isin(("Weg", "Netzluecke")), "laenge_m"].sum() / 1000, 2)}
    liste_pfad = os.path.splitext(gpkg)[0] + "_liste.json"
    with open(liste_pfad, "w", encoding="utf-8") as fh:
        json.dump(liste, fh, indent=1, ensure_ascii=False, default=str)
    bericht = _bericht(gpkg, liste, time.time() - t0)
    f(100, "Fertig")
    return {"gpkg": gpkg, "bericht": bericht, "liste": liste_pfad, "stamm": st_name, "straenge": anzahl, "nvt": len(nvt), "nicht_erreichbar": nicht,
            "weg_km": liste["weg_km_schaetzung"], "kennzahlen": liste, "netz": netz}


def liste_lesen(hk_gpkg):
    p = os.path.splitext(str(hk_gpkg))[0] + "_liste.json"
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def liste_schreiben(hk_gpkg, liste):
    p = os.path.splitext(str(hk_gpkg))[0] + "_liste.json"
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(liste, fh, indent=1, ensure_ascii=False, default=str)


def vorlage_rechnen(hk_gpkg, hks=None, trassen_gpkg=None, bestand_gpkg=None, netz=None, log=print, fortschritt=None):
    """Schritt 7: Weg-Vorlage und Muffen je Strang rechnen und in hk_vorlage/hk_muffen schreiben (Zeilen der Straenge ersetzt).
    hks: Strangnamen (None = alle). trassen_gpkg/bestand_gpkg: None = wie in der Liste von Schritt 6, "" = ohne. netz: Rueckgabe eines
    frueheren Aufrufs (Cache, spart 5-20 s je Strang). -> dict(kennzahlen je Strang, netz, bericht)"""
    t0 = time.time()
    f = fortschritt or (lambda p, t: None)
    hk_gpkg = str(hk_gpkg)
    liste = liste_lesen(hk_gpkg)
    trassen_gpkg = liste.get("trassen", "") if trassen_gpkg is None else trassen_gpkg
    bestand_gpkg = liste.get("bestand", "") if bestand_gpkg is None else bestand_gpkg
    geb = gpd.read_file(hk_gpkg, layer="hk_gebiete")
    nvt_pt = gpd.read_file(hk_gpkg, layer="hk_nvt")
    nvt = pd.DataFrame({"name": nvt_pt["name"].astype(str), "hk": nvt_pt["hk"], "hk_fasern": pd.to_numeric(nvt_pt["hk_fasern"], errors="coerce").fillna(0).astype(int),
                        "px": nvt_pt.geometry.x, "py": nvt_pt.geometry.y})
    bst_xy = (float(liste["bst"]["x"]), float(liste["bst"]["y"]))
    bst_name = liste["bst"]["name"]
    if netz is None:
        f(3, "Netz vorbereiten")
        netz = netz_vorbereiten(liste["quelle"], nvt, bst_xy, trassen_gpkg or None, bestand_gpkg or None, log, f)
    alle_hk = [str(n) for n in geb["name"]]
    hks = [h for h in (hks or alle_hk) if h in alle_hk]
    fasern_von = dict(zip(nvt["name"], nvt["hk_fasern"]))
    nvt_xy = {r["name"]: (float(r["px"]), float(r["py"])) for _, r in nvt.iterrows()}
    alt_v = gpd.read_file(hk_gpkg, layer="hk_vorlage") if "hk_vorlage" in ebenen(hk_gpkg) else gpd.GeoDataFrame(geometry=[], crs=CRS)
    alt_m = gpd.read_file(hk_gpkg, layer="hk_muffen") if "hk_muffen" in ebenen(hk_gpkg) else gpd.GeoDataFrame(geometry=[], crs=CRS)
    neu_v, neu_m, kz = [], [], {}
    stand = datetime.now().strftime("%d.%m.%Y %H:%M")
    for i, hk in enumerate(hks):
        f(25 + 65 * i / max(len(hks), 1), "Weg {}".format(hk))
        js = [n_ for n_, h in zip(nvt["name"], nvt["hk"]) if _s(h) == hk]
        term = [netz["bst"]] + [netz["nvt_knoten"][j] for j in js if j in netz["nvt_knoten"]]
        tree, komp = _steinerbaum(netz["G"], netz["bst"], term)
        if tree is None:
            log("{}: kein NVT von der BSt erreichbar".format(hk))
            kz[hk] = {"weg_km": 0.0, "fehlt": js}
            continue
        hk_von_nvt = {j: hk for j in js if netz["nvt_knoten"].get(j) in komp}
        fehlt = [j for j in js if j not in hk_von_nvt]
        kanten, muffen, weg, _g = _weg_aus_baum(netz, tree, hk_von_nvt, fasern_von, nvt_xy, bst_name)
        for k_, m in enumerate(muffen):
            m["name"] = "{} M{}".format(hk, k_ + 1)
        neu_v += kanten
        neu_m += muffen
        v = pd.DataFrame(kanten)
        wegk = v.loc[v["art"].isin(("Weg", "Netzluecke")), "laenge_m"] if len(v) else pd.Series(dtype=float)
        kz[hk] = {"weg_km": round(wegk.sum() / 1000, 2), "muffen": len(muffen), "fehlt": fehlt,
                  "km_bestandsrohr": round(v.loc[v["lage"] == "Bestandsrohr", "laenge_m"].sum() / 1000, 2) if len(v) else 0.0,
                  "km_telekom_trasse": round(v.loc[v["lage"] == "Telekom-Trasse", "laenge_m"].sum() / 1000, 2) if len(v) else 0.0,
                  "km_neu": round(v.loc[v["art"].isin(("Weg", "Netzluecke")) & ~v["lage"].isin(("Bestandsrohr", "Telekom-Trasse")), "laenge_m"].sum() / 1000, 2) if len(v) else 0.0,
                  "km_unbestaetigt": round(v.loc[v["bestand_hinweis"].astype(str).str.startswith("Rohr unbestaetigt"), "laenge_m"].sum() / 1000, 2) if len(v) else 0.0,
                  "netzluecke_m": round(v.loc[v["art"] == "Netzluecke", "laenge_m"].sum(), 0) if len(v) else 0.0}
        # Reihenfolge und Weg je NVT
        ordnung = sorted(hk_von_nvt, key=lambda j: weg.get(netz["nvt_knoten"][j], 0.0))
        for r_, j in enumerate(ordnung):
            m_ = nvt_pt["name"].astype(str) == j
            nvt_pt.loc[m_, "reihenfolge"] = r_ + 1
            nvt_pt.loc[m_, "weg_m"] = round(weg.get(netz["nvt_knoten"][j], float("nan")), 0)
        mg = geb["name"].astype(str) == hk
        geb.loc[mg, "vorlage_km"] = kz[hk]["weg_km"]
        geb.loc[mg, "vorlage_stand"] = stand
        geb.loc[mg, "muffen"] = len(muffen)
        geb.loc[mg, "nvt_liste"] = ", ".join(ordnung)
        if fehlt:
            geb.loc[mg, "hinweis"] = "nicht erreichbar: " + ", ".join(fehlt)
        log("{}: Weg {:.2f} km ({} NVT, {} Muffen; Bestandsrohr {:.2f} km, Telekom-Trasse {:.2f} km, neu {:.2f} km){}".format(
            hk, kz[hk]["weg_km"], len(hk_von_nvt), len(muffen), kz[hk]["km_bestandsrohr"], kz[hk]["km_telekom_trasse"], kz[hk]["km_neu"],
            "; NICHT erreichbar: " + ", ".join(fehlt) if fehlt else ""))

    f(92, "Schreiben")
    def _ohne(df, spalte):
        if not len(df) or spalte not in df:
            return df.iloc[0:0]
        treffer = df[spalte].astype(str).str.split("; ").apply(lambda xs: any(x in hks for x in xs))
        return df[~treffer]
    v_df = gpd.GeoDataFrame(neu_v, geometry="geometry", crs=CRS) if neu_v else gpd.GeoDataFrame({c: [] for c, _ in VORLAGE_SPALTEN}, geometry=[], crs=CRS)
    v_alle = pd.concat([_ohne(alt_v, "hk"), v_df], ignore_index=True) if len(alt_v) else v_df
    m_df = gpd.GeoDataFrame(neu_m, geometry="geometry", crs=CRS) if neu_m else gpd.GeoDataFrame({c: [] for c, _ in MUFFEN_SPALTEN}, geometry=[], crs=CRS)
    m_alle = pd.concat([_ohne(alt_m, "hk"), m_df], ignore_index=True) if len(alt_m) else m_df
    for df, name, sp, pt in ((v_alle, "hk_vorlage", VORLAGE_SPALTEN, False), (m_alle, "hk_muffen", MUFFEN_SPALTEN, True)):
        df = gpd.GeoDataFrame(df, geometry="geometry", crs=CRS)
        if len(df):
            for c, t in sp:
                if c not in df:
                    df[c] = 0 if t in ("int", "real") else ""
            if "vzk" in df:
                df["vzk"] = pd.to_numeric(df["vzk"], errors="coerce").fillna(0).astype(int)
            df = df[[c for c, _ in sp] + ["geometry"]]
            df.to_file(hk_gpkg, layer=name, driver="GPKG")
        else:
            from osgeo import ogr
            ds = ogr.Open(hk_gpkg, 1)
            for i in range(ds.GetLayerCount()):
                if ds.GetLayerByIndex(i).GetName() == name:
                    ds.DeleteLayer(i)
                    break
            ds = None
            _leere_ebene(hk_gpkg, name, sp, punkt=pt)
    geb.to_file(hk_gpkg, layer="hk_gebiete", driver="GPKG")
    nvt_pt.to_file(hk_gpkg, layer="hk_nvt", driver="GPKG")
    wal_schliessen = gemeinsam.wal_schliessen
    wal_schliessen(hk_gpkg)
    liste["vorlage"] = dict(liste.get("vorlage") or {}, **{h: kz[h] for h in kz})
    liste["vorlage_parameter"] = {"trassen": str(trassen_gpkg or ""), "bestand": str(bestand_gpkg or ""), "stand": stand, "bestand_weg": netz.get("bestand_weg")}
    for z in liste.get("straenge", []):
        if z["name"] in kz:
            z["vorlage_km"], z["muffen"] = kz[z["name"]]["weg_km"], kz[z["name"]].get("muffen", 0)
    liste_schreiben(hk_gpkg, liste)
    bericht = _trassen_bericht(hk_gpkg, liste, v_alle, time.time() - t0)
    f(100, "Fertig")
    gesamt = {"weg_km": round(sum(k["weg_km"] for k in kz.values()), 2), "km_bestandsrohr": round(sum(k.get("km_bestandsrohr", 0) for k in kz.values()), 2),
              "km_telekom_trasse": round(sum(k.get("km_telekom_trasse", 0) for k in kz.values()), 2), "km_neu": round(sum(k.get("km_neu", 0) for k in kz.values()), 2),
              "km_unbestaetigt": round(sum(k.get("km_unbestaetigt", 0) for k in kz.values()), 2), "muffen": sum(k.get("muffen", 0) for k in kz.values()),
              "fehlt": [j for k in kz.values() for j in k.get("fehlt", [])], "netzluecke_m": round(sum(k.get("netzluecke_m", 0) for k in kz.values()), 0)}
    return {"gpkg": hk_gpkg, "hks": hks, "kennzahlen": kz, "gesamt": gesamt, "netz": netz, "bericht": bericht, "liste": liste}


def _trassen_bericht(gpkg, liste, vorlage, dauer):
    p = os.path.splitext(gpkg)[0] + "_trasse_bericht.md"
    vp = liste.get("vorlage_parameter") or {}
    z = ["# Hk-Trasse je Strang - {}".format(liste["stamm"]), "",
         "Stand {}, {:.0f} s. BSt {}. Vzk-Trassen: {}. Bestand aus Schritt 1: {}.".format(datetime.now().strftime("%d.%m.%Y %H:%M"), dauer, liste["bst"]["name"],
                                                                                          os.path.basename(vp.get("trassen") or "") or "ohne", os.path.basename(vp.get("bestand") or "") or "ohne"), "",
         "## Weg-Vorlage je Strang", "", "| Strang | NVT | Weg km | im Bestandsrohr | entlang Telekom-Trasse | Neubau | Rohr unbestaetigt | Muffen | Netzluecke m |",
         "|---|---|---|---|---|---|---|---|---|"]
    for s in liste.get("straenge", []):
        k = (liste.get("vorlage") or {}).get(s["name"])
        if not k:
            z.append("| {} | {} | - | | | | | | |".format(s["name"], s["nvt_anzahl"]))
            continue
        z.append("| {} | {} | {:.2f} | {:.2f} | {:.2f} | {:.2f} | {:.2f} | {} | {:.0f} |".format(
            s["name"], s["nvt_anzahl"], k["weg_km"], k.get("km_bestandsrohr", 0), k.get("km_telekom_trasse", 0), k.get("km_neu", 0), k.get("km_unbestaetigt", 0),
            k.get("muffen", 0), k.get("netzluecke_m", 0)))
    if vp.get("bestand_weg"):
        bw = vp["bestand_weg"]
        z += ["", "Die Wegefuehrung folgt der Telekom-Trasse (Markus 22.09.2026): {} Bestandsstuecke im Umkreis, {:.1f} km Rohrtrassen mit potenziell freiem Hk-tauglichem "
              "Rohr (Einzugspreis) und {:.1f} km Telekom-Trassen ohne nutzbares Rohr (Neubau entlang der Trasse, Vorzug im Weg); {} Ankopplungen an das Netz. "
              "Harte Regel: {} Netzkanten ({:.1f} km) parallel zur Trasse gesperrt - dort liegt der Weg auf der Trasse, Neubau nur ohne Trasse. "
              "'Rohr unbestaetigt' = Rohrtrasse ohne Rohr in der Rohrliste - vor dem Einzug bei der Telekom klaeren.".format(
                  bw["stuecke"], bw["km_rohr"], bw["km_trasse"], bw["ankopplungen"], bw.get("gesperrt", 0), bw.get("km_gesperrt", 0.0))]
    z += ["", "## Vorgehen", "- Die Vorlage (hk_vorlage) ist je Strang ein Vorschlag auf dem Netz: gruen gestrichelt = Weg im Bestandsrohr (Kabel einziehen), blau = Neubau entlang "
          "der Telekom-Trasse, grau = Neubau ohne Bestand, rot = Netzluecke (Weg nachzeichnen).",
          "- Der Planer zeichnet die Hk-Trasse in hk_planung, uebernimmt die Vorlage oder holt Bestand aus Schritt 1 ('Bestand uebernehmen', bestand = 1, MegaPlan-ID).",
          "- Muffen (hk_muffen) sind Vorschlaege an Verzweigungen und an NVT, an denen das Kabel weiterlaeuft.",
          "- 'Pruefen' meldet NVT ohne Trasse oder ohne Verbindung zur BSt und Straenge ueber dem Faserdeckel; Rohre und Kabel legt der Planer in Plan[Goo].",
          "", "GeoPackage: `{}`".format(os.path.basename(gpkg))]
    with open(p, "w", encoding="utf-8") as fh:
        fh.write("\n".join(z))
    return p


# --- Planer-Aenderungen an den Straengen (Markus 22.09.2026: "in Tool 6 muss man die Hks manuell aendern koennen - ausgewaehlte NVT
# verschieben nach Hk, umbenennen, aufruecken - wie beim Vzk-Netz") -----------------------------------------------------------------------
def _hk_teile(name):
    """'5263B-1/12' -> ('5263B-1/', 12); ohne Nummer am Ende -> (name, None)."""
    m = re.match(r"^(.*?)(\d+)$", str(name).strip())
    return (m.group(1), int(m.group(2))) if m else (str(name).strip(), None)


def hk_namen(hk_gpkg):
    geb = gpd.read_file(str(hk_gpkg), layer="hk_gebiete")
    return sorted((_s(n) for n in geb["name"]), key=_natsort)


def nvt_verschieben(hk_gpkg, nvt_namen, ziel_hk, log=print):
    """Ausgewaehlte NVT (hk_nvt.name) in den Strang ziel_hk haengen; ziel darf neu sein. -> (Anzahl geaendert, betroffene Straenge).
    Danach nachrechnen()."""
    hk_gpkg, ziel = str(hk_gpkg), _s(ziel_hk)
    if not ziel:
        raise RuntimeError("Kein Zielstrang angegeben.")
    nvt = gpd.read_file(hk_gpkg, layer="hk_nvt")
    maske = nvt["name"].astype(str).isin({str(n) for n in nvt_namen})
    alt = nvt.loc[maske, "hk"].map(_s)
    betroffen = set(a for a in alt if a) | {ziel}
    n = int((alt != ziel).sum())
    nvt.loc[maske, "hk"] = ziel
    nvt.loc[maske & (nvt["status"].astype(str) == "nicht erreichbar"), "status"] = "offen"
    nvt.to_file(hk_gpkg, layer="hk_nvt", driver="GPKG")
    log("NVT verschoben: {} von {} nach '{}' (Straenge: {})".format(n, int(maske.sum()), ziel, ", ".join(sorted(betroffen, key=_natsort))))
    return n, betroffen


def hk_umbenennen(hk_gpkg, paare, log=print):
    """paare: alter Strangname -> neuer. Benennt in hk_gebiete, hk_nvt, hk_vorlage, hk_muffen, hk_planung und der Liste um; Ringtausch ueber
    Zwischennamen. -> dict Layer -> Anzahl"""
    hk_gpkg = str(hk_gpkg)
    paare = {_s(a): _s(b) for a, b in (paare or {}).items() if _s(a) and _s(b) and _s(a) != _s(b)}
    if not paare:
        return {}
    vorhanden = set(hk_namen(hk_gpkg))
    ziele = list(paare.values())
    if len(set(ziele)) != len(ziele):
        raise RuntimeError("Zwei Straenge sollen denselben Namen bekommen: {}".format(", ".join(sorted({z for z in ziele if ziele.count(z) > 1}))))
    kollision = [z for z in ziele if z in vorhanden and z not in paare]
    if kollision:
        raise RuntimeError("Name schon vergeben: {}".format(", ".join(sorted(set(kollision)))))
    zwischen = {a: "~~{}~~".format(i) for i, a in enumerate(paare)}
    zurueck = {zwischen[a]: b for a, b in paare.items()}

    def ersetze(v):
        teile = [t for t in _s(v).split("; ")]
        neu = [zurueck.get(zwischen.get(t, t), zwischen.get(t, t)) for t in teile]
        neu = [zurueck.get(t, t) for t in neu]
        return "; ".join(neu)

    erg = {}
    eb = ebenen(hk_gpkg)
    for lname, spalten in (("hk_gebiete", ("name",)), ("hk_nvt", ("hk",)), ("hk_vorlage", ("hk",)), ("hk_muffen", ("hk", "name")), ("hk_planung", ("hk",))):
        if lname not in eb:
            continue
        df = gpd.read_file(hk_gpkg, layer=lname)
        if not len(df):
            continue
        n = 0
        for sp in spalten:
            if sp not in df:
                continue
            if lname == "hk_muffen" and sp == "name":
                # "5263B-1/3 M2" -> Strangteil ersetzen
                neu = df[sp].map(lambda v: (lambda hk, rest: (paare.get(hk, hk) + rest))(*(_s(v).rsplit(" M", 1)[0], " M" + _s(v).rsplit(" M", 1)[1]) if " M" in _s(v) else (_s(v), "")))
            else:
                neu = df[sp].map(ersetze)
            n += int((neu.astype(str) != df[sp].astype(str)).sum())
            df[sp] = neu
        if n:
            df.to_file(hk_gpkg, layer=lname, driver="GPKG")
            erg[lname] = n
    try:
        liste = liste_lesen(hk_gpkg)
        for z in liste.get("straenge", []):
            z["name"] = paare.get(z["name"], z["name"])
        liste["straenge"] = sorted(liste.get("straenge", []), key=lambda z: _natsort(z["name"]))
        for i, z in enumerate(liste["straenge"], 1):
            z["nr"] = i
        for z in liste.get("nvt", []):
            if z.get("hk"):
                z["hk"] = paare.get(z["hk"], z["hk"])
        if liste.get("vorlage"):
            liste["vorlage"] = {paare.get(k, k): v for k, v in liste["vorlage"].items()}
        liste.setdefault("planer", []).append({"zeit": datetime.now().strftime("%d.%m.%Y %H:%M"), "umbenannt": paare})
        liste_schreiben(hk_gpkg, liste)
    except Exception as e:
        log("Liste nicht angepasst ({})".format(str(e)[:80]))
    wal_schliessen = gemeinsam.wal_schliessen
    wal_schliessen(hk_gpkg)
    log("Straenge umbenannt: {} ({})".format(", ".join("{} -> {}".format(a, b) for a, b in paare.items()), ", ".join("{} {}".format(v, k) for k, v in erg.items())))
    return erg


def nummern_vorschlag(hk_gpkg, stamm=None, start=None):
    """Lueckenlose Nummern je Stamm ('5263B-1/'): Reihenfolge der vorhandenen Nummern bleibt. -> (dict alt -> neu, Luecken als Text)"""
    gruppen = {}
    for n in hk_namen(hk_gpkg):
        p, z = _hk_teile(n)
        if z is None or (stamm and p != _s(stamm)):
            continue
        gruppen.setdefault(p, []).append((z, n))
    paare, luecken = {}, []
    for p, liste in gruppen.items():
        liste.sort()
        ab = int(start) if start is not None else liste[0][0]
        vor = None
        for i, (z, alt) in enumerate(liste):
            if vor is not None and z > vor + 1:
                luecken.append("{}{}".format(p, vor + 1) if z == vor + 2 else "{}{} bis {}{}".format(p, vor + 1, p, z - 1))
            vor = z
            neu = "{}{}".format(p, ab + i)
            if neu != alt:
                paare[alt] = neu
    return paare, luecken


def nachrechnen(hk_gpkg, betroffen=None, log=print):
    """Straenge aus hk_nvt neu aufbauen: Polygone, NVT-Anzahl, Fasern, Kabel, Reserve, Deckel-Hinweise; verschwundene Straenge fallen weg,
    neue kommen dazu. Die Weg-Vorlage (Schritt 7) der betroffenen Straenge wird geloescht (sie stimmt nicht mehr) - dort neu rechnen.
    -> dict(straenge, hinweise, geloescht_vorlage)"""
    hk_gpkg = str(hk_gpkg)
    liste = liste_lesen(hk_gpkg)
    max_nvt, max_fasern = int(liste.get("max_nvt", MAX_NVT)), int(liste.get("max_fasern", MAX_FASERN))
    nvt = gpd.read_file(hk_gpkg, layer="hk_nvt")
    geb = gpd.read_file(hk_gpkg, layer="hk_gebiete")
    alt = {_s(r["name"]): r for _, r in geb.iterrows()}
    nvt["hk"] = nvt["hk"].map(_s)
    hks = sorted(set(h for h in nvt["hk"] if h), key=_natsort)
    betroffen = set(betroffen or []) | (set(alt) - set(hks)) | (set(hks) - set(alt))
    zeilen, hinweise = [], []
    fasern_sp = pd.to_numeric(nvt["hk_fasern"], errors="coerce").fillna(0).astype(int)
    weg_sp = pd.to_numeric(nvt.get("weg_m"), errors="coerce") if "weg_m" in nvt else pd.Series([float("nan")] * len(nvt))
    for i, hk in enumerate(hks, 1):
        m = nvt["hk"] == hk
        teil = nvt[m]
        ordnung = teil.assign(_w=weg_sp[m]).sort_values("_w")
        namen = [_s(n) for n in ordnung["name"]]
        nvt.loc[ordnung.index, "reihenfolge"] = list(range(1, len(namen) + 1))
        nvt.loc[m, "hk_nr"] = i
        fas = int(fasern_sp[m].sum())
        kabel = _hk_groesse(fas)
        poly = unary_union(list(teil.geometry)) if len(teil) else None
        if poly is not None and not poly.is_empty:
            geschlossen = poly.buffer(25.0).buffer(-25.0)
            poly = geschlossen if geschlossen.geom_type == "Polygon" else poly.buffer(0.5).buffer(-0.5)
        hw = []
        if len(namen) > max_nvt:
            hw.append("{} NVT ueber dem Deckel {}".format(len(namen), max_nvt))
        if fas > max_fasern:
            hw.append("{} Fasern ueber dem Deckel {}".format(fas, max_fasern))
        for h in hw:
            hinweise.append("{}: {}".format(hk, h))
        a = alt.get(hk)
        geaendert = hk in betroffen
        zeilen.append({"name": hk, "nr": i, "nvt_anzahl": len(namen), "nvt_frei": max_nvt - len(namen), "nvt_liste": ", ".join(namen), "fasern": fas, "kabel": int(kabel),
                       "reserve_fasern": int(kabel) - fas, "max_fasern": max_fasern,
                       "weg_km": float(a["weg_km"]) if a is not None and not geaendert else 0.0,
                       "vorlage_km": float(a["vorlage_km"]) if a is not None and not geaendert and "vorlage_km" in a else 0.0,
                       "vorlage_stand": _s(a["vorlage_stand"]) if a is not None and not geaendert and "vorlage_stand" in a else "",
                       "muffen": int(a["muffen"]) if a is not None and not geaendert else 0, "muffen_stamm": int(a.get("muffen_stamm", 0)) if a is not None and not geaendert else 0,
                       "status": "offen" if geaendert or a is None else _s(a["status"]), "hinweis": "; ".join(hw) if hw else ("" if a is None or geaendert else _s(a["hinweis"])),
                       "geometry": poly})
    gebiete = gpd.GeoDataFrame(zeilen, geometry="geometry", crs=CRS) if zeilen else gpd.GeoDataFrame(geometry=[], crs=CRS)
    gebiete.to_file(hk_gpkg, layer="hk_gebiete", driver="GPKG")
    nvt.to_file(hk_gpkg, layer="hk_nvt", driver="GPKG")
    # Vorlage/Muffen der betroffenen Straenge loeschen
    geloescht = 0
    eb = ebenen(hk_gpkg)
    for lname, sp in (("hk_vorlage", VORLAGE_SPALTEN), ("hk_muffen", MUFFEN_SPALTEN)):
        if lname not in eb:
            continue
        df = gpd.read_file(hk_gpkg, layer=lname)
        if not len(df) or "hk" not in df:
            continue
        treffer = df["hk"].astype(str).str.split("; ").apply(lambda xs: any(x in betroffen for x in xs))
        if treffer.any():
            geloescht += int(treffer.sum())
            rest = df[~treffer]
            if len(rest):
                rest.to_file(hk_gpkg, layer=lname, driver="GPKG")
            else:
                from osgeo import ogr
                ds = ogr.Open(hk_gpkg, 1)
                for k in range(ds.GetLayerCount()):
                    if ds.GetLayerByIndex(k).GetName() == lname:
                        ds.DeleteLayer(k)
                        break
                ds = None
                _leere_ebene(hk_gpkg, lname, sp, punkt=(lname == "hk_muffen"))
    liste["straenge"] = [{k: (v if not isinstance(v, (np.integer, np.floating)) else v.item()) for k, v in z.items() if k != "geometry"} for z in zeilen]
    liste["nvt"] = [{"name": _s(r["name"]), "hk": _s(r["hk"]) or None, "reihenfolge": None if pd.isna(r.get("reihenfolge")) else int(r["reihenfolge"]),
                     "fasern": int(f), "weg_m": None if pd.isna(w) else float(w), "status": _s(r.get("status")), "punkt": _s(r.get("punkt_quelle"))}
                    for (_, r), f, w in zip(nvt.iterrows(), fasern_sp, weg_sp)]
    if liste.get("vorlage"):
        liste["vorlage"] = {k: v for k, v in liste["vorlage"].items() if k not in betroffen}
    liste.setdefault("planer", []).append({"zeit": datetime.now().strftime("%d.%m.%Y %H:%M"), "nachgerechnet": sorted(betroffen, key=_natsort)})
    liste_schreiben(hk_gpkg, liste)
    wal_schliessen = gemeinsam.wal_schliessen
    wal_schliessen(hk_gpkg)
    log("Straenge nachgerechnet: {} Straenge, {} geaendert ({}); {} Vorlage-/Muffenzeilen geloescht - in Schritt 7 neu rechnen{}".format(
        len(zeilen), len(betroffen), ", ".join(sorted(betroffen, key=_natsort)) or "-", geloescht, "; ACHTUNG " + "; ".join(hinweise) if hinweise else ""))
    return {"straenge": liste["straenge"], "hinweise": hinweise, "geloescht_vorlage": geloescht, "betroffen": sorted(betroffen, key=_natsort)}


# --- Planung des Planers ---------------------------------------------------------------------------------------------------------------
def ebenen(gpkg):
    import pyogrio
    try:
        return set(pyogrio.list_layers(gpkg)[:, 0])
    except Exception:
        return set()


def planung_anlegen(gpkg):
    """Leere Ebene hk_planung mit den Arbeitsspalten (OGR, weil GeoPandas keinen leeren Rahmen ohne Geometrietyp schreibt)."""
    from osgeo import ogr, osr
    ogr.UseExceptions()
    ds = ogr.Open(gpkg, 1)
    for i in range(ds.GetLayerCount()):
        if ds.GetLayerByIndex(i).GetName() == "hk_planung":
            ds = None
            return
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(CRS)
    lyr = ds.CreateLayer("hk_planung", srs, ogr.wkbLineString, ["GEOMETRY_NAME=geometry"])
    for c in PLANUNG_SPALTEN:
        typ = ogr.OFTInteger if c == "bestand" else (ogr.OFTReal if c == "laenge_m" else ogr.OFTString)
        lyr.CreateField(ogr.FieldDefn(c, typ))
    ds = None


def planung_lesen(gpkg):
    if "hk_planung" not in ebenen(gpkg):
        return gpd.GeoDataFrame({c: [] for c in PLANUNG_SPALTEN}, geometry=[], crs=CRS)
    a = gpd.read_file(gpkg, layer="hk_planung")
    if a.crs is None or a.crs.to_epsg() != CRS:
        a = a.set_crs(CRS, allow_override=True)
    for c in PLANUNG_SPALTEN:
        if c not in a:
            a[c] = 0 if c in ("bestand", "laenge_m") else ""
    return a


def planung_schreiben(gpkg, a):
    wal_schliessen = gemeinsam.wal_schliessen
    b = a.copy()
    for c in b.columns:
        if b[c].dtype == object and c != "geometry":
            b[c] = b[c].astype(str).replace({"None": "", "nan": ""})
    if not len(b):
        from osgeo import ogr
        ogr.UseExceptions()
        ds = ogr.Open(gpkg, 1)
        for i in range(ds.GetLayerCount()):
            if ds.GetLayerByIndex(i).GetName() == "hk_planung":
                ds.DeleteLayer(i)
                break
        ds = None
        planung_anlegen(gpkg)
    else:
        b["laenge_m"] = [round(g.length, 1) if g is not None else 0 for g in b.geometry]
        b["bestand"] = pd.to_numeric(b["bestand"], errors="coerce").fillna(0).astype(int)
        b.to_file(gpkg, layer="hk_planung", driver="GPKG")
    wal_schliessen(gpkg)


def _neue_uid(hk, i):
    return gemeinsam.uid(hk)


def vorlage_uebernehmen(gpkg, hk, log=print):
    """Weg-Vorlage eines Strangs in die Planung kopieren (Stuecke, die der Strang nutzt; schon vorhandene gleiche Stuecke werden ausgelassen)."""
    v = gpd.read_file(gpkg, layer="hk_vorlage")
    v = v[v["hk"].astype(str).str.split("; ").apply(lambda xs: hk in xs)]
    a = planung_lesen(gpkg)
    vorhanden = set(a["quelle"].astype(str))
    neu = []
    for i, r in v.iterrows():
        q = "vorlage:{}:{}".format(hk, r["quelle_id"] or i)
        if q in vorhanden:
            continue
        neu.append({"uid": _neue_uid(hk, i), "hk": hk, "typ": "Hk-Trasse", "bestand": 0, "quelle_id": _s(r["quelle_id"]), "rohrklasse": "", "mp_id": "",
                    "bauverfahren": "", "surface": "", "laenge_m": round(r.geometry.length, 1), "status": "entwurf",
                    "hinweis": "Vorlage ({} Fs, {}E)".format(r["fasern"], r["kabel"]) + (", auf Vzk-Trasse" if r.get("vzk") else ""), "quelle": q, "geometry": r.geometry})
    if neu:
        a = pd.concat([a, gpd.GeoDataFrame(neu, geometry="geometry", crs=CRS)], ignore_index=True)
        planung_schreiben(gpkg, a)
    log("Vorlage uebernommen: {} Stuecke fuer {}".format(len(neu), hk))
    return len(neu)


def bestand_uebernehmen(gpkg, hk, stuecke, log=print):
    """Bestandsstuecke aus Schritt 1 (Liste von dict: geometry (shapely LineString), quelle_id, rohrklasse, mp_id, nutzbarkeit) als Hk-Trasse
    mit bestand=1 in die Planung (Markus 18.09.2026: 'Bestand uebernehmen')."""
    a = planung_lesen(gpkg)
    vorhanden = set(a["quelle_id"].astype(str))
    neu = []
    for i, s in enumerate(stuecke):
        g = s.get("geometry")
        if g is None or g.is_empty:
            continue
        geoms = list(g.geoms) if g.geom_type == "MultiLineString" else [g]
        for k, gg in enumerate(geoms):
            qid = _s(s.get("quelle_id")) or "bestand:{}".format(i)
            if qid in vorhanden and len(geoms) == 1:
                continue
            neu.append({"uid": _neue_uid(hk, i), "hk": hk, "typ": "Hk-Trasse", "bestand": 1, "quelle_id": qid, "rohrklasse": _s(s.get("rohrklasse")),
                        "mp_id": _s(s.get("mp_id")), "bauverfahren": "", "surface": "", "laenge_m": round(gg.length, 1), "status": "entwurf",
                        "hinweis": "Bestand: {}{}".format(_s(s.get("rohrklasse")) or "Rohr", " ({})".format(_s(s.get("nutzbarkeit"))) if s.get("nutzbarkeit") else ""),
                        "quelle": "bestand", "geometry": gg})
    if neu:
        a = pd.concat([a, gpd.GeoDataFrame(neu, geometry="geometry", crs=CRS)], ignore_index=True)
        planung_schreiben(gpkg, a)
    log("Bestand uebernommen: {} Stuecke fuer {}".format(len(neu), hk))
    return len(neu)


def pruefen(gpkg, toleranz=3.0, nvt_toleranz=15.0, log=print):
    """Je Strang: sind alle NVT ueber die gezeichnete Hk-Trasse mit der BSt verbunden, passen die Fasern ins Kabel?
    -> Liste Befunde (dict hk, nvt, art, text, blockiert, x, y); Status in hk_gebiete und hk_nvt."""
    a = planung_lesen(gpkg)
    geb = gpd.read_file(gpkg, layer="hk_gebiete")
    nvt = gpd.read_file(gpkg, layer="hk_nvt")
    bst = gpd.read_file(gpkg, layer="bst")
    bpt = bst.geometry.iloc[0]
    befunde = []
    a = a[a.geometry.notna()].copy()
    # Markus 12.10.2026: Graph aus den NORMALISIERTEN Stuecken (nur im Speicher): Abzweige mitten auf einer Linie und Kreuzungen werden
    # geteilt, Enden innerhalb der Toleranz ueber den echten Abstand zu einem Knoten zusammengefasst (vorher 3-m-Raster: Enden wenige
    # Zentimeter auseinander konnten in zwei Rasterzellen fallen und galten als Luecke). Die Daten aendert erst 'Trassen bereinigen'.
    from . import bereinigen
    stuecke, _, _ = bereinigen.normalisieren(a, toleranz, regeln=bereinigen.REGELN_PRUEFUNG)
    knoten_von, mittel = bereinigen.enden_cluster(stuecke, toleranz)
    P = nx.Graph()
    for i, s in enumerate(stuecke):
        P.add_edge(knoten_von[(i, 0)], knoten_von[(i, 1)], hk=str(s["attr"].get("hk", "")), i=i)
    knoten_pts = list(mittel.items())
    stueck_geoms = [s["geom"] for s in stuecke]
    def knoten_nahe(pt, umkreis):
        """Knoten des Planungsgraphen innerhalb der Toleranz, sonst das naechste Stueck im Umkreis (sein Anfangsknoten)."""
        if knoten_pts:
            kid, d0 = min(((kid, p.distance(pt)) for kid, p in knoten_pts), key=lambda t: t[1])
            if d0 <= toleranz:
                return kid
        if not stueck_geoms:
            return None
        j, d1 = min(((j, g.distance(pt)) for j, g in enumerate(stueck_geoms)), key=lambda t: t[1])
        if d1 <= umkreis:
            return knoten_von[(j, 0)]
        return None
    kb = knoten_nahe(bpt, max(toleranz, nvt_toleranz))
    if kb is None:
        befunde.append({"hk": "", "nvt": "", "art": "BSt nicht angebunden", "text": "Keine gezeichnete Hk-Trasse beginnt an der Betriebsstelle ({:.0f} m Toleranz).".format(max(toleranz, nvt_toleranz)),
                        "blockiert": 1, "x": bpt.x, "y": bpt.y})
    erreichbar = set(nx.node_connected_component(P, kb)) if kb is not None and kb in P else set()
    status_nvt = {}
    zuf_max = max(nvt_toleranz, bereinigen.NVT_MAX_M)
    for _, r in nvt.iterrows():
        if _s(r.get("hk")) == "":
            continue
        # Markus 12.10. (Phil): ein NVT gilt nur als angebunden, wenn ein Trassenende am NVT liegt (toleranz). Vorher reichte irgendein
        # Stueck bis 15 m - der NVT hing dann am Anfangsknoten dieses Stuecks und galt als verbunden, obwohl keine Zufuehrung existierte.
        d_ende, kn = None, None
        if knoten_pts:
            kn, d_ende = min(((kid, p.distance(r.geometry)) for kid, p in knoten_pts), key=lambda t: t[1])
        d_tr = min((g.distance(r.geometry) for g in stueck_geoms), default=None)
        if d_ende is not None and d_ende <= toleranz:
            if kn not in erreichbar:
                befunde.append({"hk": r["hk"], "nvt": r["name"], "art": "NVT nicht mit BSt verbunden", "text": "Die Trasse am NVT {} haengt nicht mit der BSt zusammen (Luecke > {} m).".format(r["name"], toleranz),
                                "blockiert": 1, "x": r.geometry.x, "y": r.geometry.y})
                status_nvt[r["name"]] = "in Arbeit"
            else:
                status_nvt[r["name"]] = "geprueft"
        elif d_tr is not None and d_tr <= zuf_max:
            befunde.append({"hk": r["hk"], "nvt": r["name"], "art": "NVT ohne Zufuehrung",
                            "text": "Keine Trasse endet am NVT {} (naechste Trasse {:.1f} m, naechstes Ende {:.1f} m) - 'Trassen bereinigen' legt die Zufuehrung an.".format(
                                r["name"], d_tr, d_ende if d_ende is not None else d_tr), "blockiert": 1, "x": r.geometry.x, "y": r.geometry.y})
            status_nvt[r["name"]] = "in Arbeit"
        else:
            befunde.append({"hk": r["hk"], "nvt": r["name"], "art": "NVT ohne Trasse", "text": "Keine gezeichnete Hk-Trasse am NVT {} ({:.0f} m).".format(r["name"], zuf_max), "blockiert": 1,
                            "x": r.geometry.x, "y": r.geometry.y})
            status_nvt[r["name"]] = "offen"
    for _, g in geb.iterrows():
        js = [x.strip() for x in _s(g["nvt_liste"]).split(",") if x.strip()]
        if int(g["fasern"]) > int(g.get("max_fasern", MAX_FASERN)):
            befunde.append({"hk": g["name"], "nvt": "", "art": "Fasern", "text": "{}: {} Fasern ueber dem Deckel {}.".format(g["name"], g["fasern"], g.get("max_fasern", MAX_FASERN)), "blockiert": 1,
                            "x": g.geometry.representative_point().x if g.geometry is not None else 0, "y": g.geometry.representative_point().y if g.geometry is not None else 0})
        gez = a[a["hk"].astype(str) == str(g["name"])]
        if not len(gez):
            befunde.append({"hk": g["name"], "nvt": "", "art": "keine Trasse", "text": "{}: noch keine Hk-Trasse gezeichnet.".format(g["name"]), "blockiert": 0,
                            "x": g.geometry.representative_point().x if g.geometry is not None else 0, "y": g.geometry.representative_point().y if g.geometry is not None else 0})
        fertig = all(status_nvt.get(j) == "geprueft" for j in js) and len(gez) > 0 and kb is not None
        geb.loc[_, "status"] = "geprueft" if fertig else ("in Arbeit" if len(gez) else "offen")
        geb.loc[_, "hinweis"] = "" if fertig else "; ".join(b["text"] for b in befunde if b["hk"] == g["name"])[:250]
    nvt["status"] = [status_nvt.get(n_, s_) for n_, s_ in zip(nvt["name"], nvt["status"])]
    geb.to_file(gpkg, layer="hk_gebiete", driver="GPKG")
    nvt.to_file(gpkg, layer="hk_nvt", driver="GPKG")
    if befunde:
        gpd.GeoDataFrame(befunde, geometry=[Point(b["x"], b["y"]) for b in befunde], crs=CRS).drop(columns=["x", "y"]).to_file(gpkg, layer="hk_pruefung", driver="GPKG")
    else:
        gpd.GeoDataFrame({"hk": ["-"], "nvt": ["-"], "art": ["ohne Befund"], "text": ["Alle Straenge verbunden"], "blockiert": [0]}, geometry=[bpt], crs=CRS).to_file(gpkg, layer="hk_pruefung", driver="GPKG")
    wal_schliessen = gemeinsam.wal_schliessen
    wal_schliessen(gpkg)
    log("Pruefung: {} Befunde, davon {} blockierend; {} von {} Straengen geprueft".format(len(befunde), sum(1 for b in befunde if b["blockiert"]),
                                                                                      int((geb["status"] == "geprueft").sum()), len(geb)))
    return befunde, geb


def trassen_bereinigen(gpkg, toleranz=3.0, anwenden=True, log=print):
    """Markus 12.10.2026: Hk-Planung automatisch bereinigen - Linien an Abzweigen (Ende eines Stuecks auf dem Inneren eines anderen) und
    Kreuzungen teilen, Enden innerhalb der Toleranz zusammenfuehren. Attribute bleiben, Laengen werden neu gerechnet. anwenden=False liefert
    nur die Vorschau (Zusammenfassung + Protokollzeilen), nichts wird geschrieben. -> dict(zusammen, text, meldungen, geschrieben)"""
    from . import bereinigen
    a = planung_lesen(gpkg)
    kontext = {"ziele": [], "nvt": []}
    try:
        bst = gpd.read_file(gpkg, layer="bst")
        kontext["ziele"] += [p for p in bst.geometry if p is not None]
        nvt = gpd.read_file(gpkg, layer="hk_nvt")
        for _, r in nvt.iterrows():
            if r.geometry is not None:
                kontext["ziele"].append(r.geometry)
                kontext["nvt"].append((str(r["name"]), _s(r.get("hk")), r.geometry))
    except Exception as e:
        log("Bereinigen: NVT/BSt nicht lesbar ({!r}) - Regeln Luecken/Zufuehrung/Ueberstand laufen ohne Zielpunkte".format(e))
    stuecke, z, meld = bereinigen.normalisieren(a, toleranz, log, kontext=kontext)
    text = bereinigen.zusammenfassung_text(z)
    geschrieben = False
    if anwenden and z.get("geaendert"):
        b = bereinigen.stuecke_als_gdf(stuecke, PLANUNG_SPALTEN, CRS)
        planung_schreiben(gpkg, b)
        geschrieben = True
        for m in meld:
            log("  bereinigt: " + m)
    log("Trassen bereinigen{}: {}".format("" if anwenden else " (Vorschau)", text))
    return {"zusammen": z, "text": text, "meldungen": meld, "geschrieben": geschrieben}


def _bericht(gpkg, liste, dauer):
    p = os.path.splitext(gpkg)[0] + "_bericht.md"
    z = ["# Hauptkabel-Straenge - {}".format(liste["stamm"]), "",
         "Stand {}, {:.0f} s. BSt {} ({:.0f} m vom Netz). Deckel: {} NVT und {} Fasern je Strang (ZTV 21: Hk-Fasern je NVT aus Schritt 3). Nummernkreis {}{}..".format(
             datetime.now().strftime("%d.%m.%Y %H:%M"), dauer, liste["bst"]["name"], liste["bst"]["abstand_netz_m"], liste["max_nvt"], liste["max_fasern"], liste["hk_stamm"], liste["hk_start"]), "",
         "## Straenge", "", "| Strang | NVT | frei | Fasern | Kabel | Reserve | Weg km (Schaetzung) |", "|---|---|---|---|---|---|---|"]
    for s in liste["straenge"]:
        z.append("| {} | {} ({}) | {} | {} | {}E | {} | {} |".format(s["name"], s["nvt_anzahl"], s["nvt_liste"], s["nvt_frei"], s["fasern"], s["kabel"], s["reserve_fasern"], s["weg_km"]))
    z += ["", "Weg gesamt aus dem Clusterbaum (Schaetzung, Stamm nur einmal gezaehlt): {:.2f} km. Die Weg-Vorlage je Strang rechnet Schritt 7.".format(liste.get("weg_km_schaetzung", 0.0)), ""]
    if liste.get("bestand_weg"):
        bw = liste["bestand_weg"]
        z += ["Der Clusterbaum lief mit Bestand aus Schritt 1 als Weg: {} Bestandsstuecke, {:.1f} km Rohrtrassen mit potenziell freiem Hk-Rohr, {:.1f} km Telekom-Trassen.".format(
            bw["stuecke"], bw["km_rohr"], bw["km_trasse"]), ""]
    if liste.get("netzluecken"):
        z += ["## Netzluecken ueberbrueckt", "", "Das Netz aus Schritt 3 war in Teile zerfallen (OSM-Ausschnitt ohne Landstrassen). {} gerade Bruecken ({:.0f} m) verbinden "
              "sie; in Schritt 7 erscheinen sie rot gestrichelt (art Netzluecke) - dort den echten Weg zeichnen.".format(len(liste["netzluecken"]), sum(x["laenge_m"] for x in liste["netzluecken"])), ""]
    if liste["nicht_erreichbar"]:
        z += ["## Nicht erreichbar", "", "- " + ", ".join(liste["nicht_erreichbar"]), ""]
    z += ["## Vorgehen", "- Straenge sind Teilbaeume des kuerzesten Wegs von der BSt: ihre NVT liegen beieinander; Deckel NVT und Fasern je Strang.",
          "- Schritt 7 rechnet je Strang die Weg-Vorlage (Bestand als Weg), der Planer zeichnet die Hk-Trasse nach und prueft.",
          "- Rohre und Kabel legt der Planer in Plan[Goo]; nach Plan[Goo] gehen Hk-Trassen und Muffen ueber Schritt 10.", "", "GeoPackage: `{}`".format(os.path.basename(gpkg))]
    with open(p, "w", encoding="utf-8") as fh:
        fh.write("\n".join(z))
    return p
