# -*- coding: utf-8 -*-
"""Schritt 6 - Dialog "Hauptkabel clustern": NVT-Gebiete, Standorte, Vzk-Trassen, Bestand aus Schritt 1, Betriebsstelle, Nummernkreis, Deckel
-> Straenge (Polygone, NVT mit Strang, BSt) und die Strangtabelle. Die Weg-Vorlage je Strang, das Zeichnen und die Pruefung sind Schritt 7
(werkzeuge/hktrasse). Markus 22.09.2026: "Tool 6 muss naeher an die Funktionen ran wie beim Vzk: erstmal Hk clustern als ein Tool und dann
Wegefuehrung pro Hk als Trassenvorschlag und am Ende Einzeichnen vom Planer - zwei Tools."

Modulweite Helfer stil() und LAYER nutzt auch Schritt 7, damit beide Schritte dieselben Farben zeigen."""
import json
import os
import traceback

from qgis.core import (QgsCategorizedSymbolRenderer, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFillSymbol, QgsLineSymbol,
                       QgsMarkerSymbol, QgsPointXY, QgsProject, QgsRendererCategory, QgsRuleBasedRenderer, QgsVectorLayer)
from qgis.gui import QgsMapToolEmitPoint
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                                 QMessageBox, QProgressBar, QPushButton, QRadioButton, QSpinBox, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout)

from ... import ablauf, ci, dateiwahl, layerbaum, tabelle
from ...dialogbasis import WerkzeugDialog
from ...dateiwahl import DateiFeld

PALETTE = ["#1E6FB0", "#2E8B57", "#8E2A2A", "#6A4C93", "#D98A1E", "#00838F", "#7B1FA2", "#5D4037", "#C2185B", "#33691E", "#455A64", "#F57F17"]
GRUEN = "#2E8B57"
BLAU = "#1E6FB0"
LAYER = {"bst": "Betriebsstelle", "hk_nvt": "NVT mit Strang", "hk_muffen": "Muffen (Vorschlag)", "hk_vorlage": "Hk-Weg (Vorlage)",
         "hk_planung": "Hk-Trasse (Planung)", "hk_gebiete": "Hk-Straenge", "hk_pruefung": "Befunde"}
EBENEN_6 = ("bst", "hk_nvt", "hk_gebiete")                              # Schritt 6 zeigt die Straenge
EBENEN_7 = ("hk_pruefung", "hk_muffen", "hk_planung", "hk_vorlage")      # Schritt 7 den Weg und die Planung


def strangfarben(gpkg):
    """Strangname -> Farbe, stabil ueber die sortierte Namensliste."""
    farben = {}
    probe = QgsVectorLayer("{}|layername=hk_gebiete".format(gpkg), "p", "ogr")
    if probe.isValid():
        for i, n in enumerate(sorted(str(f["name"]) for f in probe.getFeatures())):
            farben[n] = PALETTE[i % len(PALETTE)]
    return farben


def stil(lyr, lname, farben):
    """Darstellung je Ebene (Schritt 6 und 7)."""
    if lname == "hk_gebiete":
        kats = [QgsRendererCategory(n, QgsFillSymbol.createSimple({"color": ci.rgba(f, 28), "outline_color": f, "outline_width": "1.2"}), n) for n, f in farben.items()]
        lyr.setRenderer(QgsCategorizedSymbolRenderer("name", kats))
        ci.label_kasten(lyr, "concat('<div><b>', \"name\", '</b></div><div>', \"nvt_anzahl\", ' NVT (', \"nvt_frei\", ' frei) | ', \"fasern\", ' Fs -> ', \"kabel\", 'E, Reserve ', \"reserve_fasern\", ' | ', \"status\", '</div>')",
                        groesse=7.5, rahmen=ci.farb_ausdruck("name", farben), min_massstab=20000, polygon=True)
    elif lname == "hk_vorlage":
        wurzel = QgsRuleBasedRenderer.Rule(None)
        wurzel.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": GRUEN, "width": "1.8", "line_style": "dash"}), 0, 0, '"art" = \'Weg\' AND "lage" = \'Bestandsrohr\'', "Weg im Bestandsrohr (Kabel einziehen)"))
        wurzel.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": BLAU, "width": "1.6", "line_style": "dash"}), 0, 0, '"art" = \'Weg\' AND "lage" = \'Telekom-Trasse\'', "Weg entlang Telekom-Trasse (Neubau)"))
        wurzel.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": "#8A8A8A", "width": "1.4", "line_style": "dash"}), 0, 0, '"art" = \'Weg\' AND coalesce("lage", \'\') NOT IN (\'Bestandsrohr\', \'Telekom-Trasse\')', "Weg (Vorlage)"))
        wurzel.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": "#C62828", "width": "1.6", "line_style": "dash"}), 0, 0, '"art" = \'Netzluecke\'', "Netzluecke - Weg nachzeichnen"))
        wurzel.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": "#8A8A8A", "width": "0.7", "line_style": "dot"}), 0, 0, '"art" NOT IN (\'Weg\', \'Netzluecke\')', "Zufuehrung (Vorlage)"))
        lyr.setRenderer(QgsRuleBasedRenderer(wurzel))
        lyr.setReadOnly(True)
        ci.label_kasten(lyr, "concat(\"hk\", ' | ', \"kabel\", 'E | ', \"fasern\", ' Fs', if(coalesce(\"lage\", '') = 'Bestandsrohr', ' | Rohr ' || coalesce(\"rohrklasse\", ''), ''))", groesse=6.5, rahmen="#8A8A8A", min_massstab=3000)
    elif lname == "hk_planung":
        wurzel = QgsRuleBasedRenderer.Rule(None)
        wurzel.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": ci.ORANGE, "width": "1.3"}), 0, 0, '"bestand" <> 1', "Hk-Trasse neu"))
        wurzel.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": GRUEN, "width": "1.6", "line_style": "dash"}), 0, 0, '"bestand" = 1', "Hk-Trasse im Bestand"))
        lyr.setRenderer(QgsRuleBasedRenderer(wurzel))
        ci.label_kasten(lyr, "concat(\"hk\", if(\"bestand\" = 1, ' | Bestand ' || coalesce(\"rohrklasse\", ''), ''))", groesse=6.5, rahmen=ci.ORANGE, min_massstab=3000)
    elif lname == "hk_nvt":
        kats = [QgsRendererCategory(n, ci.nvt_symbol(f, 5.0), n) for n, f in farben.items()]
        kats.append(QgsRendererCategory("", ci.nvt_symbol("#C62828", 5.0), "nicht erreichbar"))
        lyr.setRenderer(QgsCategorizedSymbolRenderer("hk", kats))
        ci.label_kasten(lyr, "concat(\"name\", ' | ', \"hk_fasern\", ' Fs | ', coalesce(\"hk\", 'kein Strang'), if(\"reihenfolge\" is null, '', ' #' || \"reihenfolge\"))",
                        groesse=7, rahmen=ci.farb_ausdruck("hk", farben, "#C62828"), abstand_mm=2.0)
    elif lname == "hk_muffen":
        lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({"name": "diamond", "color": "#FFFFFF", "outline_color": "#1A1A1A", "outline_width": "0.6", "size": "3.4"}))
        ci.label_kasten(lyr, "concat(\"name\", ' ', \"art\", ' | ', \"fasern_durch\", ' Fs')", groesse=6.5, rahmen="#1A1A1A", min_massstab=3000, abstand_mm=1.5)
    elif lname == "bst":
        lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({"name": "star", "color": ci.ORANGE, "outline_color": "#1A1A1A", "size": "6"}))
        ci.label_kasten(lyr, "\"name\"", groesse=8, rahmen=ci.ORANGE, abstand_mm=2.5)
    elif lname == "hk_pruefung":
        kats = [QgsRendererCategory(1, QgsMarkerSymbol.createSimple({"name": "triangle", "color": "#C62828", "outline_color": "#FFFFFF", "outline_width": "0.3", "size": "4.5"}), "blockiert"),
                QgsRendererCategory(0, QgsMarkerSymbol.createSimple({"name": "triangle", "color": "#E0A800", "outline_color": "#FFFFFF", "outline_width": "0.3", "size": "4"}), "Hinweis")]
        lyr.setRenderer(QgsCategorizedSymbolRenderer("blockiert", kats))
        ci.label_kasten(lyr, "\"art\"", groesse=7, rahmen="#C62828", min_massstab=5000, abstand_mm=2.0)


layer_finden = layerbaum.layer_aus_gpkg


def ebenen_laden(gpkg, st, schluessel, ebenen, gruppen_rest, neu=True):
    """Ebenen eines Hk-GeoPackages in die Gruppe des Schritts haengen. neu=True: Gruppe leeren und alles laden; neu=False: nur fehlende
    Ebenen in die vorhandene (oder neue) Gruppe - so holt Schritt 7 die Straenge aus Schritt 6 nach, ohne sie doppelt zu laden."""
    farben = strangfarben(gpkg)
    if neu:
        gruppe = layerbaum.gruppe(schluessel, gruppen_rest.format(st))
    else:
        gruppe = QgsProject.instance().layerTreeRoot().findGroup(layerbaum.gruppenname(schluessel, gruppen_rest.format(st)))
        if gruppe is None:
            gruppe = layerbaum.gruppe(schluessel, gruppen_rest.format(st))
    for lname in ebenen:
        if not neu and layer_finden(gpkg, lname) is not None:
            continue
        lyr = QgsVectorLayer("{}|layername={}".format(gpkg, lname), LAYER.get(lname, lname), "ogr")
        if not lyr.isValid():
            continue
        lyr.setCrs(QgsCoordinateReferenceSystem("EPSG:25832"))
        stil(lyr, lname, farben)
        layerbaum.einhaengen(gruppe, lyr, schluessel, sichtbar=True)
    return farben


class HkDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self.ergebnis = None
        self.bst = None                 # (x, y, name) in EPSG:25832
        self._werkzeug_alt = None
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel("hk").replace("  ", " ", 1))
        self.setMinimumWidth(900)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel("hk"), "NVT zu Hauptkabel-Straengen clustern (Deckel NVT und Fasern nach ZTV, Straenge liegen beieinander, Reserve). "
                                                       "Den Weg je Strang rechnet Schritt 7, dort zeichnet der Planer die Hk-Trasse.")
        lay.addWidget(self.kopf)

        # --- Eingaben ---------------------------------------------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Straenge bilden"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(6)
        g.addWidget(QLabel("NVT-Gebiete (Schritt 3):"), 0, 0)
        self.f_geb = DateiFeld("nvt_gebiete", "nvt_gebiete_....gpkg aus Schritt 3 (mit _graph.pkl daneben)", "GeoPackage (*.gpkg)", "NVT-Gebiete waehlen", ci.STIL_KNOPF_ZWEIT)
        self.f_geb.box.lineEdit().editingFinished.connect(self._vorschlaege)
        self.f_geb.box.activated.connect(lambda *_: self._vorschlaege())
        g.addWidget(self.f_geb, 0, 1, 1, 5)
        self.h_stosi = QCheckBox("Standorte aus Schritt 4:")
        self.h_stosi.setChecked(True)
        self.h_stosi.setToolTip("Gesicherte NVT-Standorte statt Sitzvorschlag als Ziel des Hk-Wegs, wenn eine Standortdatei zum Schnitt vorliegt")
        g.addWidget(self.h_stosi, 1, 0)
        self.f_sto = DateiFeld("nvt_standorte", "nvt_standorte_....gpkg (leer = zum Schnitt suchen)", "GeoPackage (*.gpkg)", "Standortdatei waehlen", ci.STIL_KNOPF_ZWEIT, vorbelegen=False)
        g.addWidget(self.f_sto, 1, 1, 1, 5)
        self.h_vzk = QCheckBox("Vzk-Trassen aus Schritt 5 bevorzugen:")
        self.h_vzk.setChecked(True)
        self.h_vzk.setToolTip("Netzkanten auf den Vzk-Trassen kosten fuer den Hk nur 10 % - Tiefbau wird nur einmal bezahlt, der Clusterbaum folgt den Vzk-Trassen")
        g.addWidget(self.h_vzk, 2, 0)
        self.f_tra = DateiFeld("trassen", "trassen_....gpkg (leer = zum Schnitt suchen)", "GeoPackage (*.gpkg)", "Trassen-Ergebnis waehlen", ci.STIL_KNOPF_ZWEIT, vorbelegen=False)
        g.addWidget(self.f_tra, 2, 1, 1, 5)
        self.h_bestand = QCheckBox("Bestand aus Schritt 1 als Weg:")
        self.h_bestand.setChecked(True)
        self.h_bestand.setToolTip("Die Wegefuehrung ist die Telekom-Trasse: Rohrtrassen mit potenziell freiem Hk-tauglichem Rohr kosten nur den Einzug (5,83 EUR/m, "
                                  "Ein-/Ausstieg ein Kopfloch), andere Telekom-Trassen bekommen als Neubau den Vorzug (70 %). Der Clusterbaum und spaeter die Vorlage je "
                                  "Strang (Schritt 7) laufen darauf. Leer = juengstes Schritt-1-Ergebnis.")
        g.addWidget(self.h_bestand, 3, 0)
        self.f_bestand = DateiFeld("bestand", "bestand_....gpkg aus Schritt 1 (leer = juengstes Ergebnis)", "GeoPackage (*.gpkg)", "Bestand aus Schritt 1 waehlen",
                                   ci.STIL_KNOPF_ZWEIT, vorbelegen=False)
        g.addWidget(self.f_bestand, 3, 1, 1, 5)
        self.h_bestand.toggled.connect(lambda an: self.f_bestand.setEnabled(an))
        g.addWidget(QLabel("Betriebsstelle:"), 4, 0)
        b = QHBoxLayout()
        b.setSpacing(8)
        self.r_bst_goo = QRadioButton("aus Plan[Goo]-Projekt")
        self.r_bst_goo.setToolTip("Punkt vom Typ bst im offenen Plan[Goo]-Projekt")
        self.r_bst_klick = QRadioButton("in der Karte setzen")
        self.r_bst_goo.setChecked(True)
        b.addWidget(self.r_bst_goo)
        b.addWidget(self.r_bst_klick)
        self.k_bst = QPushButton("Setzen")
        self.k_bst.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_bst.setToolTip("Dann in die Karte klicken - der Punkt wird die Betriebsstelle")
        self.k_bst.clicked.connect(self._bst_setzen)
        b.addWidget(self.k_bst)
        self.bst_name = QLineEdit()
        self.bst_name.setPlaceholderText("Name, z. B. BSt 5263/1 (leer = aus ONKZ/ASB)")
        self.bst_name.setMaximumWidth(220)
        b.addWidget(self.bst_name)
        self.lab_bst = QLabel("noch nicht gesetzt")
        self.lab_bst.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        b.addWidget(self.lab_bst, 1)
        g.addLayout(b, 4, 1, 1, 5)
        g.addWidget(QLabel("Hk-Nummernkreis (BVT):"), 5, 0)
        nk = QHBoxLayout()
        nk.setSpacing(6)
        self.nk_stamm = QLineEdit()
        self.nk_stamm.setPlaceholderText("Stamm, leer = aus ONKZ/ASB")
        self.nk_stamm.setMaximumWidth(150)
        self.nk_stamm.setToolTip("Stamm vor der Nummer nach Telekom-Muster {ONKZ}B-{ASB}/, z. B. 5263B-1/ -> 5263B-1/1, 5263B-1/2 ... Gibt der BVT nichts vor, vergibt der Planer ihn selbst.")
        nk.addWidget(self.nk_stamm)
        nk.addWidget(QLabel("von"))
        self.nk_von = self._spin(1, 999, 1, breite=70)
        nk.addWidget(self.nk_von)
        nk.addWidget(QLabel("bis"))
        self.nk_bis = self._spin(1, 999, 99, breite=70)
        self.nk_bis.setToolTip("Nur zur Kontrolle: mehr Straenge als Nummern werden gemeldet")
        nk.addWidget(self.nk_bis)
        nk.addSpacing(16)
        nk.addWidget(QLabel("hoechstens"))
        self.s_nvt = self._spin(1, 12, 5, breite=70)
        self.s_nvt.setToolTip("NVT je Strang (Reserve im Stamm; Vorgabe 5)")
        nk.addWidget(self.s_nvt)
        nk.addWidget(QLabel("NVT und"))
        self.s_fasern = self._spin(12, 192, 96, breite=70)
        self.s_fasern.setSingleStep(12)
        self.s_fasern.setToolTip("Fasern je Strang (groesstes Hk-Kabel 96E)")
        nk.addWidget(self.s_fasern)
        nk.addWidget(QLabel("Fasern je Strang"))
        nk.addStretch(1)
        g.addLayout(nk, 5, 1, 1, 5)
        g.addWidget(QLabel("Ausgabeordner:"), 6, 0)
        self.out = QLineEdit()
        self.out.setPlaceholderText("leer = neben dem Schnitt")
        g.addWidget(self.out, 6, 1, 1, 4)
        o = QPushButton("Waehlen")
        o.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        o.clicked.connect(self._out_waehlen)
        g.addWidget(o, 6, 5)
        g.setColumnStretch(1, 1)
        lay.addLayout(g)

        k = QHBoxLayout()
        self.k_start = QPushButton("Hk clustern")
        self.k_start.setStyleSheet(ci.STIL_KNOPF)
        self.k_start.setCursor(Qt.PointingHandCursor)
        self.k_start.clicked.connect(self._start)
        self.k_laden = dateiwahl.ErgebnisKnopf("hk", self._ergebnis_setzen, "Hk-Ergebnis (GeoPackage) waehlen", stil=ci.STIL_KNOPF_ZWEIT)
        self.k_bericht = QPushButton("Bericht oeffnen")
        self.k_bericht.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_bericht.setEnabled(False)
        self.k_bericht.clicked.connect(lambda: self._oeffnen(self.ergebnis and self.ergebnis.get("bericht")))
        self.k_weiter = QPushButton("Weiter: 7 Hk-Trasse je Strang")
        self.k_weiter.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_weiter.setToolTip("Schritt 7 mit diesem Ergebnis oeffnen: Weg-Vorlage je Strang rechnen, Hk-Trasse zeichnen, pruefen")
        self.k_weiter.setEnabled(False)
        self.k_weiter.clicked.connect(self._weiter)
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        for x in (self.k_start, self.k_laden, self.k_bericht, self.k_weiter, self.k_log):
            k.addWidget(x)
        k.addStretch(1)
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, "hk"))
        k.addWidget(hilfe)
        schl = QPushButton("Schliessen")
        self.k_schliessen = schl
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.close)
        k.addWidget(schl)
        lay.addLayout(k)
        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)

        self.tabelle = tabelle.Tabelle("hk_straenge", ["Strang", "NVT", "frei", "Fasern", "Kabel", "Reserve", "Weg km (Schaetzung)", "Status"], self.iface)
        self.tabelle.layer_finder(self._layer)
        self.tabelle.setMinimumHeight(180)
        self.tabelle.setToolTip("Doppelklick: auf den Strang zoomen")
        self.tabelle.itemDoubleClicked.connect(self._zeile_zoomen)
        self.tabelle.itemSelectionChanged.connect(self._strang_gewaehlt)
        lay.addWidget(self.tabelle, 1)

        # --- Planer-Aenderungen (Markus 22.09.2026: "Hks manuell aendern wie beim Vzk-Netz") -----------------------------------------------
        lay.addWidget(self._ueberschrift("Planer-Aenderungen"))
        pg = QGridLayout()
        pg.setHorizontalSpacing(10)
        pg.setVerticalSpacing(6)
        pg.addWidget(QLabel("Ausgewaehlte NVT nach Strang:"), 0, 0, Qt.AlignRight)
        self.ziel = QComboBox()
        self.ziel.setEditable(True)
        self.ziel.setInsertPolicy(QComboBox.NoInsert)
        self.ziel.lineEdit().setPlaceholderText("Strang waehlen oder neuen Namen tippen (z. B. 5263B-1/16)")
        self.ziel.setEnabled(False)
        pg.addWidget(self.ziel, 0, 1)
        self.k_versch = QPushButton("Verschieben")
        self.k_versch.setStyleSheet(ci.STIL_KNOPF)
        self.k_versch.setEnabled(False)
        self.k_versch.setToolTip("NVT im Layer '6 NVT mit Strang' mit den QGIS-Auswahlwerkzeugen markieren, Zielstrang waehlen, Verschieben. Ein neuer Name legt "
                                 "einen neuen Strang an. Polygone, Fasern, Kabel und Reserve werden neu gerechnet; die Weg-Vorlage der geaenderten Straenge (Schritt 7) "
                                 "wird geloescht und dort neu gerechnet.")
        self.k_versch.clicked.connect(self._auswahl_verschieben)
        pg.addWidget(self.k_versch, 0, 2)
        self.k_ripple = QPushButton("Nummern aufruecken")
        self.k_ripple.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_ripple.setEnabled(False)
        self.k_ripple.setToolTip("Faellt durch Verschieben ein Strang weg, ruecken die folgenden Nummern auf (Luecken schliessen). Zeigt die Liste und fragt vorher nach.")
        self.k_ripple.clicked.connect(self._nummern_aufruecken)
        pg.addWidget(self.k_ripple, 0, 3)
        pg.addWidget(QLabel("Gewaehlten Strang umbenennen:"), 1, 0, Qt.AlignRight)
        self.nb_name = QLineEdit()
        self.nb_name.setPlaceholderText("Strang in der Tabelle oder im Layer '6 Hk-Straenge' waehlen")
        self.nb_name.returnPressed.connect(self._umbenennen)
        pg.addWidget(self.nb_name, 1, 1)
        self.k_umb = QPushButton("Umbenennen")
        self.k_umb.setStyleSheet(ci.STIL_KNOPF)
        self.k_umb.setEnabled(False)
        self.k_umb.setToolTip("Benennt den Strang in allen Ebenen um (Straenge, NVT, Weg-Vorlage, Muffen, Hk-Trasse) und in der Liste fuer Schritt 7 und 8.")
        self.k_umb.clicked.connect(self._umbenennen)
        pg.addWidget(self.k_umb, 1, 2)
        pg.setColumnStretch(1, 1)
        lay.addLayout(pg)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(120)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log)
        self.setAcceptDrops(True)
        from ... import fenster
        fenster.einrichten(self, "hk", 900)

    # --- Hilfen ------------------------------------------------------------------------------------------------------------------------
    def _out_waehlen(self):
        p = dateiwahl.ordner_waehlen(self, "Ausgabeordner waehlen", "ausgabe", self.out.text())
        if p:
            self.out.setText(p)

    def _weiter(self):
        """Schritt 7 als Seite oeffnen und das Ergebnis dort laden."""
        try:
            from qgis.utils import plugins
            pl = plugins.get("fiberation_werkzeugkasten")
            seite = pl.zeige("hktrasse") if pl is not None else None
            if seite is not None and self.ergebnis and hasattr(seite, "ergebnis_setzen"):
                seite.ergebnis_setzen(self.ergebnis["gpkg"])
        except Exception as e:
            self._log("Schritt 7 nicht geoeffnet: {!r}".format(e))

    def _datei_fallen_gelassen(self, p):
        n = os.path.basename(p).lower()
        if not n.endswith(".gpkg"):
            return False
        if n.startswith("hk_"):
            self._ergebnis_setzen(p)
        elif n.startswith("nvt_gebiete_"):
            self.f_geb.setText(p)
            self._vorschlaege()
        elif n.startswith("nvt_standorte_"):
            self.f_sto.setText(p)
        elif n.startswith("trassen_"):
            self.f_tra.setText(p)
        elif n.startswith("bestand_"):
            self.f_bestand.setText(p)
        return True

    def _vorschlaege(self):
        """Stamm, BSt-Name, Standort-, Trassen- und Bestandsdatei zum gewaehlten Schnitt vorbelegen."""
        from . import kern
        geb = self.f_geb.text()
        if not geb or not os.path.exists(geb):
            return
        try:
            self.nk_stamm.setPlaceholderText("leer = " + kern.hk_stamm_vorschlag(geb))
            self.bst_name.setPlaceholderText("leer = " + kern.bst_name_vorschlag(geb))
        except Exception:
            pass
        stamm = kern.stamm_von(geb)
        for feld, art, praefix in ((self.f_sto, "nvt_standorte", "nvt_standorte_"), (self.f_tra, "trassen", "trassen_")):
            if feld.text():
                continue
            for p in dateiwahl.zuletzt(art) + [c for c in dateiwahl.kandidaten(art)]:
                if stamm.split("_20")[0] in os.path.basename(p):
                    feld.setText(p)
                    break
        if not self.f_bestand.text():
            juengst = dateiwahl.zuletzt("bestand")
            if juengst:
                self.f_bestand.setText(juengst[0])

    # --- Betriebsstelle ---------------------------------------------------------------------------------------------------------------
    def _bst_setzen(self):
        """Kartenwerkzeug: ein Klick setzt die Betriebsstelle."""
        canvas = self.iface.mapCanvas() if self.iface else None
        self.r_bst_klick.setChecked(True)
        if canvas is None:
            return
        self._werkzeug_alt = canvas.mapTool()
        self._bst_tool = QgsMapToolEmitPoint(canvas)
        self._bst_tool.canvasClicked.connect(self._bst_geklickt)
        canvas.setMapTool(self._bst_tool)
        self.lab_bst.setText("jetzt in die Karte klicken ...")

    def _bst_geklickt(self, punkt, knopf):
        canvas = self.iface.mapCanvas()
        try:
            tr = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(), QgsCoordinateReferenceSystem("EPSG:25832"), QgsProject.instance())
            p = tr.transform(QgsPointXY(punkt))
        except Exception:
            p = QgsPointXY(punkt)
        self.bst = (p.x(), p.y(), self.bst_name.text().strip() or None)
        self.lab_bst.setText("gesetzt: {:.0f} / {:.0f}".format(p.x(), p.y()))
        try:
            canvas.unsetMapTool(self._bst_tool)
            if self._werkzeug_alt is not None:
                canvas.setMapTool(self._werkzeug_alt)
        except Exception:
            pass

    BST_MAX_KM = 25.0     # weiter weg von den NVT-Gebieten kann die Betriebsstelle nicht sein - dann ist es die falsche (z. B. aus einem anderen Projekt)

    def _bst_ermitteln(self, geb):
        """(x, y, name) oder None. Nur das OFFENE Plan[Goo]-Projekt zaehlt (Markus 18.09.2026: nie ein zuletzt benutztes Projekt raten -
        das brachte die BSt aus Mannheim nach Barntrup). Ohne Treffer oder bei unplausibler Lage: auf 'in der Karte setzen' umschalten."""
        from . import kern
        if self.r_bst_klick.isChecked():
            if self.bst is None:
                self._bst_setzen()
                QMessageBox.information(self, "Betriebsstelle", "Bitte die Betriebsstelle in der Karte anklicken, dann erneut 'Hk clustern'.")
                return None
            return self.bst
        gpkg = dateiwahl.projekt_gpkg()
        grund = None
        if not gpkg:
            grund = "Es ist kein Plan[Goo]-Projekt geoeffnet."
        else:
            b = kern.bst_aus_plangoo(gpkg)
            if b is None:
                grund = "Das offene Plan[Goo]-Projekt hat keinen Punkt vom Typ bst."
            else:
                km = kern.bst_abstand_km(geb, b[0], b[1])
                if km is not None and km > self.BST_MAX_KM:
                    grund = "Die Betriebsstelle des offenen Projekts ({}) liegt {:.0f} km von den NVT-Gebieten entfernt - falsches Projekt?".format(b[2] or "ohne Name", km)
                else:
                    self.lab_bst.setText("{} aus {} ({:.0f} / {:.0f})".format(b[2] or "bst", os.path.basename(gpkg), b[0], b[1]))
                    return (b[0], b[1], self.bst_name.text().strip() or b[2])
        self.r_bst_klick.setChecked(True)
        self.lab_bst.setText(grund)
        self._bst_setzen()
        QMessageBox.information(self, "Betriebsstelle", grund + "\n\nBitte die Betriebsstelle in der Karte anklicken, dann erneut 'Hk clustern'.")
        return None

    # --- Clustern ----------------------------------------------------------------------------------------------------------------------
    def _start(self):
        from . import kern
        self.log.clear()
        self.k_start.setEnabled(False)
        try:
            geb = self.f_geb.text()
            if not geb or not os.path.exists(geb):
                self.k_log.setChecked(True)
                self._log("NVT-Gebiete nicht gefunden - Datei aus Schritt 3 waehlen.")
                return
            bst = self._bst_ermitteln(geb)
            if bst is None:
                return
            dateiwahl.merken("nvt_gebiete", geb)
            sto = self.f_sto.text() if self.h_stosi.isChecked() else ""
            tra = self.f_tra.text() if self.h_vzk.isChecked() else ""
            bestand = ""
            if self.h_bestand.isChecked():
                bestand = self.f_bestand.text().strip() or (dateiwahl.zuletzt("bestand") or [""])[0]
                if bestand and os.path.exists(bestand):
                    self._log("Bestand aus Schritt 1 als Weg: " + os.path.basename(bestand))
                else:
                    self._log("Kein Schritt-1-Ergebnis gefunden - Clusterbaum ohne Bestand (Schritt 1 ausfuehren oder Datei waehlen).")
                    bestand = ""
            r = kern.schneiden(geb, (bst[0], bst[1]), bst[2] or None, standorte_gpkg=sto or None, trassen_gpkg=tra or None,
                               out_dir=dateiwahl.ausgabeordner(self.out.text()), hk_stamm=self.nk_stamm.text().strip() or None, hk_start=self.nk_von.value(),
                               hk_bis=self.nk_bis.value(), max_nvt=self.s_nvt.value(), max_fasern=self.s_fasern.value(), bestand_gpkg=bestand or None,
                               log=self._log, fortschritt=self._fortschritt)
            dateiwahl.merken("hk", r["gpkg"])
            self.ergebnis = {k: v for k, v in r.items() if k != "netz"}
            self.k_bericht.setEnabled(True)
            self.k_weiter.setEnabled(True)
            self._tabelle_fuellen(r["kennzahlen"])
            self._layer_laden(r["gpkg"], r["stamm"])
            self._planer_freigeben()
            text = "{} Straenge fuer {} NVT (Weg aus dem Clusterbaum {} km, Schaetzung).".format(r["straenge"], r["nvt"], r["weg_km"])
            nl = r["kennzahlen"].get("netzluecken") or []
            if nl:
                text += chr(10) + chr(10) + "{} Netzluecken ueberbrueckt ({:.0f} m): das Netz aus Schritt 3 war dort unterbrochen - in Schritt 7 erscheinen sie rot gestrichelt.".format(
                    len(nl), sum(x["laenge_m"] for x in nl))
            if r["nicht_erreichbar"]:
                text += "\n\nNicht von der BSt erreichbar: {}".format(", ".join(r["nicht_erreichbar"]))
            QMessageBox.information(self, "Hauptkabel clustern", text + "\n\nWeiter mit Schritt 7: Weg-Vorlage je Strang rechnen, Hk-Trasse zeichnen, pruefen.")
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "Hauptkabel clustern - Fehler", "{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])
        finally:
            self.k_start.setEnabled(True)

    def _ergebnis_setzen(self, gpkg):
        dateiwahl.merken("hk", gpkg)
        basis = os.path.splitext(gpkg)[0]
        self.ergebnis = {"gpkg": gpkg, "bericht": basis + "_bericht.md", "liste": basis + "_liste.json"}
        self.k_bericht.setEnabled(os.path.exists(self.ergebnis["bericht"]))
        self.k_weiter.setEnabled(True)
        st = os.path.basename(basis).replace("hk_", "")
        try:
            with open(self.ergebnis["liste"], encoding="utf-8") as fh:
                daten = json.load(fh)
            st = daten.get("stamm", st)
            self._tabelle_fuellen(daten)
            if daten.get("quelle") and not self.f_geb.text():
                self.f_geb.setText(daten["quelle"])
        except Exception as e:
            self._log("Liste nicht gelesen ({!r}).".format(e))
        self.ergebnis["stamm"] = st
        self._layer_laden(gpkg, st)
        self._stand_aus_layer()
        self._planer_freigeben()
        self._log("Ergebnis geladen: " + gpkg)

    # --- Tabelle -----------------------------------------------------------------------------------------------------------------------
    def _tabelle_fuellen(self, daten, status=None):
        self.tabelle.setRowCount(0)
        for s in daten.get("straenge", []):
            i = self.tabelle.rowCount()
            self.tabelle.insertRow(i)
            st = (status or {}).get(s["name"], s.get("status", "offen"))
            werte = [s["name"], "{} ({})".format(s["nvt_anzahl"], s["nvt_liste"]), s["nvt_frei"], s["fasern"], "{}E".format(s["kabel"]), s["reserve_fasern"],
                     s["weg_km"], st]
            for j, w in enumerate(werte):
                it = QTableWidgetItem(str(w))
                if j in (2, 3, 5, 6):
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.tabelle.setItem(i, j, it)
            self.tabelle.karte_setzen(i, bezug=("hk_gebiete", {"name": str(s["name"])}))
        self.tabelle.resizeColumnsToContents()
        self.tabelle.fertig()

    def _zeile_zoomen(self, item):
        name = self.tabelle.item(item.row(), 0).text()
        lyr = self._layer("hk_gebiete")
        if lyr is None:
            return
        lyr.selectByExpression("\"name\" = '{}'".format(name.replace("'", "''")))
        try:
            self.iface.mapCanvas().zoomToSelected(lyr)
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def _stand_aus_layer(self):
        """Status je Strang aus hk_gebiete in die Tabelle (Schritt 7 setzt ihn beim Pruefen)."""
        lyr = self._layer("hk_gebiete")
        if lyr is None:
            return
        st = {str(f["name"]): str(f["status"]) for f in lyr.getFeatures()}
        for i in range(self.tabelle.rowCount()):
            n = self.tabelle.item(i, 0).text()
            if n in st:
                self.tabelle.item(i, 7).setText(st[n])

    # --- Planer-Aenderungen ------------------------------------------------------------------------------------------------------------
    def _planer_freigeben(self):
        for w in (self.ziel, self.k_versch, self.k_ripple):
            w.setEnabled(bool(self.ergebnis))
        self._ziele_fuellen()
        lyr = self._layer("hk_gebiete")
        if lyr is not None:
            try:
                lyr.selectionChanged.disconnect(self._strang_gewaehlt)
            except Exception:
                pass
            lyr.selectionChanged.connect(self._strang_gewaehlt)
        self._strang_gewaehlt()

    def _ziele_fuellen(self):
        from . import kern
        aktuell = self.ziel.currentText()
        self.ziel.blockSignals(True)
        self.ziel.clear()
        try:
            for n in kern.hk_namen(self.ergebnis["gpkg"]) if self.ergebnis else []:
                self.ziel.addItem(n)
        except Exception:
            pass
        self.ziel.setCurrentText(aktuell)
        self.ziel.blockSignals(False)

    def _strang_gewaehlt(self, *_):
        """Genau ein Strang gewaehlt (Polygon im Layer oder Zeile in der Tabelle): Name ins Feld, Umbenennen frei."""
        namen = []
        lyr = self._layer("hk_gebiete")
        if lyr is not None and lyr.selectedFeatureCount():
            namen = [str(f["name"]) for f in lyr.selectedFeatures()]
        elif self.tabelle.selectionModel() is not None:
            namen = [self.tabelle.zelle(i, 0).text() for i in self.tabelle.auswahl_indizes() if self.tabelle.zelle(i, 0) is not None]
        self.k_umb.setEnabled(len(namen) == 1 and bool(self.ergebnis))
        if len(namen) == 1:
            self.nb_name.setText(namen[0])
            self.nb_name.setPlaceholderText("")
        else:
            self.nb_name.setPlaceholderText("genau einen Strang waehlen" if not namen else "{} Straenge gewaehlt - genau einen waehlen".format(len(namen)))

    def _nach_aenderung(self, text):
        """Liste neu lesen, Tabelle und Layer auffrischen."""
        from . import kern
        try:
            daten = kern.liste_lesen(self.ergebnis["gpkg"])
            self._tabelle_fuellen(daten)
        except Exception as e:
            self._log("Liste nicht gelesen ({!r}).".format(e))
        self._layer_laden(self.ergebnis["gpkg"], self.ergebnis.get("stamm", ""))
        self._stand_aus_layer()
        self._planer_freigeben()
        self._log(text)

    def _auswahl_verschieben(self):
        from . import kern
        if not self.ergebnis:
            return
        self.k_versch.setEnabled(False)
        try:
            lyr = self._layer("hk_nvt")
            if lyr is None:
                self._log("Layer 'NVT mit Strang' nicht gefunden - Ergebnis erneut laden.")
                return
            namen = [str(f["name"]) for f in lyr.selectedFeatures()]
            if not namen:
                QMessageBox.information(self, "NVT verschieben", "Keine NVT ausgewaehlt.\n\nIm Layer '6 NVT mit Strang' mit den QGIS-Auswahlwerkzeugen markieren, dann Zielstrang waehlen.")
                return
            ziel = self.ziel.currentText().strip()
            if not ziel:
                QMessageBox.information(self, "NVT verschieben", "Zielstrang waehlen oder einen neuen Namen eintippen.")
                return
            n, betroffen = kern.nvt_verschieben(self.ergebnis["gpkg"], namen, ziel, log=self._log)
            if n == 0:
                self._log("Alle ausgewaehlten NVT lagen schon in '{}'.".format(ziel))
                return
            r = kern.nachrechnen(self.ergebnis["gpkg"], betroffen, log=self._log)
            self._nach_aenderung("{} NVT nach '{}' verschoben; Straenge {} neu gerechnet.".format(n, ziel, ", ".join(r["betroffen"])))
            text = "{} NVT nach '{}' verschoben. Straenge neu gerechnet: {}.".format(n, ziel, ", ".join(r["betroffen"]))
            if r["hinweise"]:
                text += "\n\nACHTUNG:\n" + "\n".join("- " + h for h in r["hinweise"])
            if r["geloescht_vorlage"]:
                text += "\n\nDie Weg-Vorlage dieser Straenge wurde geloescht ({} Zeilen) - in Schritt 7 neu rechnen.".format(r["geloescht_vorlage"])
            QMessageBox.information(self, "NVT verschieben", text)
        except Exception as e:
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "NVT verschieben - Fehler", "{!r}".format(e)[:600])
        finally:
            self.k_versch.setEnabled(bool(self.ergebnis))

    def _umbenennen(self):
        from . import kern
        if not self.ergebnis:
            return
        namen = []
        lyr = self._layer("hk_gebiete")
        if lyr is not None and lyr.selectedFeatureCount():
            namen = [str(f["name"]) for f in lyr.selectedFeatures()]
        else:
            namen = [self.tabelle.zelle(i, 0).text() for i in self.tabelle.auswahl_indizes() if self.tabelle.zelle(i, 0) is not None]
        neu = self.nb_name.text().strip()
        if len(namen) != 1 or not neu:
            QMessageBox.information(self, "Umbenennen", "Genau einen Strang (Tabelle oder Layer '6 Hk-Straenge') waehlen und den neuen Namen eintragen.")
            return
        if namen[0] == neu:
            return
        try:
            erg = kern.hk_umbenennen(self.ergebnis["gpkg"], {namen[0]: neu}, log=self._log)
            if not erg:
                QMessageBox.information(self, "Umbenennen", "Nichts geaendert.")
                return
            self._nach_aenderung("'{}' heisst jetzt '{}'.".format(namen[0], neu))
        except Exception as e:
            self._log("Umbenennen: {!r}".format(e))
            QMessageBox.critical(self, "Umbenennen", "{}".format(e)[:400])

    def _nummern_aufruecken(self):
        from . import kern
        if not self.ergebnis:
            return
        try:
            stamm = self.nk_stamm.text().strip() or None
            paare, luecken = kern.nummern_vorschlag(self.ergebnis["gpkg"], stamm=stamm, start=self.nk_von.value() if stamm else None)
            if not paare:
                QMessageBox.information(self, "Nummern aufruecken", "Die Nummern sind lueckenlos - nichts zu tun.")
                return
            liste = "\n".join("{}  ->  {}".format(a, b) for a, b in sorted(paare.items(), key=lambda t: kern._natsort(t[0])))
            text = "{}Diese {} Straenge werden umbenannt:\n\n{}\n\nUebernehmen?".format("Luecke: {}\n\n".format(", ".join(luecken)) if luecken else "", len(paare), liste[:1500])
            if QMessageBox.question(self, "Nummern aufruecken", text, QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                self._log("Nummern aufruecken: vom Planer abgelehnt.")
                return
            kern.hk_umbenennen(self.ergebnis["gpkg"], paare, log=self._log)
            self._nach_aenderung("{} Straenge umbenannt (Nummern aufgerueckt).".format(len(paare)))
        except Exception as e:
            self._log("Nummern aufruecken: {!r}".format(e))
            QMessageBox.critical(self, "Nummern aufruecken", "{}".format(e)[:400])

    # --- Layer -------------------------------------------------------------------------------------------------------------------------
    def _layer(self, name):
        if not self.ergebnis:
            return None
        return layer_finden(self.ergebnis["gpkg"], name)

    def _layer_laden(self, gpkg, st):
        self.ergebnis = dict(self.ergebnis or {}, gpkg=gpkg, stamm=st)
        ebenen_laden(gpkg, st, "hk", EBENEN_6, "Hauptkabel {}", neu=True)
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass
