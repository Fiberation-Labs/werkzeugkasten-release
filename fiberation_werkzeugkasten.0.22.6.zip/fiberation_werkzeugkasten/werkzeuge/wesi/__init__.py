# -*- coding: utf-8 -*-
"""Werkzeug 9 - WeSi-Spezialfaelle (Wegesicherung): Gewaesserquerungen und Landesstrassen-Flurstuecke ausserhalb der Ortsdurchfahrt."""
