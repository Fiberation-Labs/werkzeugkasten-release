# -*- coding: utf-8 -*-
"""Werkzeug 9 - Dialog "WeSi-Spezialfaelle": Tiefbautrassen gegen Gewaesser (Querungen) und Landesstrassen-Flurstuecke ausserhalb der
Ortsdurchfahrt (Strassen.NRW) pruefen, drei Layer mit den mitgelieferten Stilen laden, Bericht."""
import os
import traceback

from qgis.core import QgsCoordinateReferenceSystem, QgsProject, QgsVectorLayer
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QApplication, QComboBox, QDialog, QDoubleSpinBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                                 QProgressBar, QPushButton, QRadioButton, QTextEdit, QVBoxLayout)

from ... import ablauf, ci, dateiwahl, layerbaum
from ...dialogbasis import WerkzeugDialog
from ...dateiwahl import DateiFeld
from ..adressen import alkis

HERE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
STILE = os.path.join(HERE, "resources", "wesi")


class WesiDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self.ergebnis = None
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel("wesi").replace("  ", " ", 1))
        self.setMinimumWidth(820)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel("wesi"), "Gewaesserquerungen und Landesstrassen ausserhalb der Ortsdurchfahrt - drei Layer, Liste und Bericht fuer die Antraege.")
        lay.addWidget(self.kopf)

        lay.addWidget(self._ueberschrift("Pruefen"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(6)
        g.addWidget(QLabel("Tiefbautrassen:"), 0, 0)
        q = QHBoxLayout()
        self.r_goo = QRadioButton("offenes Plan[Goo]-Projekt")
        self.r_datei = QRadioButton("Plan[Goo]-GeoPackage:")
        self.r_goo.setChecked(True)
        q.addWidget(self.r_goo)
        q.addWidget(self.r_datei)
        self.f_netz = DateiFeld("plangoo", "Projekt.gpkg (mit .db daneben) - aufklappen fuer bekannte Projekte", "GeoPackage (*.gpkg)",
                                "Plan[Goo]-GeoPackage waehlen", ci.STIL_KNOPF_ZWEIT)
        self.f_netz.setEnabled(False)
        q.addWidget(self.f_netz, 1)
        self.r_datei.toggled.connect(self.f_netz.setEnabled)
        g.addLayout(q, 0, 1, 1, 5)
        self.s_wasser = self._spin(2.0, 50.0, 10.0)
        self.s_od = self._spin(2.0, 50.0, 12.0)
        self.s_min = self._spin(0.5, 20.0, 1.0)
        g.addWidget(QLabel("Regeln:"), 1, 0)
        rg = QHBoxLayout()
        rg.setSpacing(6)
        for txt, s, tipp in (("Kreis um Querung m", self.s_wasser, "Suchkreis um den Schnittpunkt Trasse/Gewaesser fuer Durchlaesse und Bruecken"),
                             ("Achsabstand ATKIS-OSM m", self.s_od, "Bis zu diesem Abstand gilt die OSM-Landesstrasse als dieselbe Achse wie in ATKIS"),
                             ("min. Laenge im Flurstueck m", self.s_min, "Kuerzere Trassenstuecke auf einem Strassenflurstueck werden nicht gemeldet")):
            lab = QLabel(txt + ":")
            lab.setToolTip(tipp)
            s.setToolTip(tipp)
            s.setMaximumWidth(70)
            rg.addWidget(lab)
            rg.addWidget(s)
        rg.addStretch(1)
        g.addLayout(rg, 1, 1, 1, 5)
        g.addWidget(QLabel("Land:"), 2, 0)
        self.land = QComboBox()
        self.land.addItem("automatisch", "")
        for k in sorted(alkis.LAENDER, key=lambda x: alkis.LAENDER[x]):
            self.land.addItem("{} ({})".format(alkis.LAENDER[k], k), k)
        g.addWidget(self.land, 2, 1)
        g.addWidget(QLabel("Ausgabeordner:"), 2, 2)
        self.out = QLineEdit()
        self.out.setPlaceholderText("leer = neben dem Projekt")
        g.addWidget(self.out, 2, 3, 1, 2)
        o = QPushButton("Waehlen")
        o.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        o.clicked.connect(self._out_waehlen)
        g.addWidget(o, 2, 5)
        g.setColumnStretch(3, 1)
        lay.addLayout(g)

        k = QHBoxLayout()
        self.k_start = QPushButton("Spezialfaelle pruefen")
        self.k_start.setStyleSheet(ci.STIL_KNOPF)
        self.k_start.setCursor(Qt.PointingHandCursor)
        self.k_start.clicked.connect(self._start)
        self.k_abbruch = QPushButton("Abbrechen")
        self.k_abbruch.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_abbruch.setEnabled(False)
        self.k_abbruch.setToolTip("Laufenden OpenStreetMap-Abruf (Overpass) abbrechen - der Schritt endet dann ohne Ergebnis.")
        self.k_abbruch.clicked.connect(self._abbrechen)
        self.k_laden = dateiwahl.ErgebnisKnopf("wesi", self._ergebnis_setzen, "WeSi-Ergebnis (GeoPackage) waehlen", stil=ci.STIL_KNOPF_ZWEIT)
        self.k_bericht = QPushButton("Bericht oeffnen")
        self.k_bericht.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_bericht.setEnabled(False)
        self.k_bericht.clicked.connect(lambda: self._oeffnen(self.ergebnis and self.ergebnis.get("bericht")))
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.setToolTip("Protokoll ein- und ausblenden; bei Fehlern klappt es von selbst auf")
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        for b in (self.k_start, self.k_abbruch, self.k_laden, self.k_bericht, self.k_log):
            k.addWidget(b)
        k.addStretch(1)
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, "wesi"))
        k.addWidget(hilfe)
        schl = QPushButton("Schliessen")
        self.k_schliessen = schl
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.close)
        k.addWidget(schl)
        lay.addLayout(k)
        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(160)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log, 1)
        self.setAcceptDrops(True)
        from ... import fenster
        fenster.einrichten(self, "wesi", 820)

    # --- Hilfen ------------------------------------------------------------------------------------------------------------------------
    def _out_waehlen(self):
        p = dateiwahl.ordner_waehlen(self, "Ausgabeordner waehlen", "ausgabe", self.out.text())
        if p:
            self.out.setText(p)

    def _datei_fallen_gelassen(self, p):
        if not p.lower().endswith(".gpkg"):
            return False
        if "wesi_spezialfaelle" in os.path.basename(p).lower():
            self._ergebnis_setzen(p)
        else:
            self.r_datei.setChecked(True)
            self.f_netz.setText(p)
        return True

    # --- Aktionen ----------------------------------------------------------------------------------------------------------------------
    def _start(self):
        from . import kern
        self.log.clear()
        self.k_start.setEnabled(False)
        from ..cluster import osm
        osm.lauf_beginnen(status=lambda txt: self._fortschritt(self.balken.value(), txt))
        self.k_abbruch.setEnabled(True)
        try:
            if self.r_goo.isChecked():
                quelle = "plangoo"
                out_dir = dateiwahl.ausgabeordner(self.out.text()) or (os.path.dirname(dateiwahl.projekt_gpkg() or "") or None)
                if not dateiwahl.projekt_gpkg():
                    self._log("Kein Plan[Goo]-Projekt geoeffnet - GeoPackage waehlen.")
                    return
            else:
                quelle = self.f_netz.text()
                if not quelle or not os.path.exists(quelle):
                    self._log("Plan[Goo]-GeoPackage nicht gefunden.")
                    return
                dateiwahl.merken("plangoo", quelle)
                out_dir = dateiwahl.ausgabeordner(self.out.text())
            r = kern.pruefen(quelle, out_dir=out_dir, land=self.land.currentData() or None, log=self._log, fortschritt=self._fortschritt,
                             water_buf=self.s_wasser.value(), od_buf=self.s_od.value(), min_in_parcel=self.s_min.value())
            dateiwahl.merken("wesi", r["gpkg"])
            self.ergebnis = r
            self.k_bericht.setEnabled(True)
            self._layer_laden(r["gpkg"])
            QMessageBox.information(self, "WeSi-Spezialfaelle", "{} Trassen queren ein Gewaesser ({} Querungspunkte).\n{} Trassen liegen auf "
                                    "Landesstrassen-Flurstuecken ausserhalb der Ortsdurchfahrt.\n{} Flaechen.\n\nLayer sind geladen, Bericht ueber den Knopf."
                                    .format(len(r["gewaesser"]), int(r["gewaesser"]["querungen"].sum()) if len(r["gewaesser"]) else 0,
                                            len(r["landesstrasse"]), len(r["flaechen"])))
        except osm.Abgebrochen as e:
            self._fortschritt(0, "Abgebrochen")
            self._log("Abgebrochen: {}".format(e))
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "WeSi-Spezialfaelle - Fehler", "{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])
        finally:
            self.k_start.setEnabled(True)
            self.k_abbruch.setEnabled(False)
            osm.lauf_beenden()

    def _ergebnis_setzen(self, gpkg):
        dateiwahl.merken("wesi", gpkg)
        self.ergebnis = {"gpkg": gpkg, "bericht": os.path.splitext(gpkg)[0] + "_bericht.md"}
        self.k_bericht.setEnabled(os.path.exists(self.ergebnis["bericht"]))
        self._layer_laden(gpkg)
        self._log("Ergebnis geladen: " + gpkg)

    # --- Layer -------------------------------------------------------------------------------------------------------------------------
    def _layer_laden(self, gpkg):
        gruppe = layerbaum.gruppe("wesi", "Wegesicherung {}".format(os.path.basename(gpkg).replace("wesi_spezialfaelle_", "").replace(".gpkg", "")))
        for lname, titel, qml in (("Trassen_Gewaesserquerung", "Trassen mit Gewaesserquerung", "Trassen_Gewaesserquerung.qml"),
                                  ("Trassen_Landesstrasse_freie_Strecke", "Trassen auf Landesstrasse (freie Strecke)", "Trassen_Landesstrasse_freie_Strecke.qml"),
                                  ("WeSi_Spezialfaelle_Flaechen", "WeSi-Flaechen", "WeSi_Spezialfaelle_Flaechen.qml"),
                                  ("Trassen_geprueft", "Tiefbautrassen (geprueft)", None)):
            lyr = QgsVectorLayer("{}|layername={}".format(gpkg, lname), titel, "ogr")
            if not lyr.isValid():
                continue
            lyr.setCrs(QgsCoordinateReferenceSystem("EPSG:25832"))
            if qml and os.path.exists(os.path.join(STILE, qml)):
                lyr.loadNamedStyle(os.path.join(STILE, qml))
            elif lname == "Trassen_geprueft":
                from qgis.core import QgsLineSymbol
                lyr.renderer().setSymbol(QgsLineSymbol.createSimple({"color": "#9E9E9E", "width": "0.3"}))
            layerbaum.einhaengen(gruppe, lyr, "wesi", sichtbar=lname != "Trassen_geprueft")
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass
