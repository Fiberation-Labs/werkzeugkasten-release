# -*- coding: utf-8 -*-
"""Werkzeug 9 - Kern ohne Qt: WeSi-Spezialfaelle (Wegesicherung) fuer die Tiefbautrassen eines Plan[Goo]-Projekts.

Herkunft: Einzelauswertung Bielefeld-Eckardtsheim (WeSi_Spezialfaelle.zip, 10.09.2026, build_wesi.py) - hier verallgemeinert:
Trassen aus dem offenen Plan[Goo]-Projekt oder einem Plan[Goo]-GeoPackage, ALKIS/ATKIS per WFS fuer das Gebiet, OSM per Overpass.

Drei Ergebnislayer (EPSG:25832):
  1. Trassen_Gewaesserquerung: Tiefbautrassen (TYPE underground, ohne rohrfreie/blaue Trassen, mit Hauszufuehrungen), die ein Gewaesser
     kreuzen. Gewaesser = ALKIS/ATKIS Gewaesserachsen (auch Graeben), ALKIS Gewaesserflaechen (Fliessgewaesser, StehendesGewaesser) und
     OSM (waterway river/stream/canal/ditch/drain, natural=water). Felder: uid, nvt, sub_type, location_hint, bauverfahren, laenge_m,
     gewaesser_quelle, gewaesser_name, querungen, durchlass_5m (ALKIS Bauwerk im Gewaesserbereich in <= 5 m: Trasse quert vermutlich im
     Strassendamm ueber dem Durchlass), hinweis.
  2. Trassen_Landesstrasse_freie_Strecke: Tiefbautrassen auf einem Flurstueck einer Landesstrasse ausserhalb der Ortsdurchfahrt
     (Strassen.NRW). Landesstrasse = OSM ref "L ..." + ATKIS-Strassenachse; Ortsdurchfahrt ~ Achse in der geschlossenen Ortslage
     (ATKIS AX_Ortslage, Naeherung - die amtlichen OD-Grenzen sind keine offenen Daten); Flurstueck der Landesstrasse = ALKIS-Flurstueck,
     das die freie Achse >= 5 m durchlaeuft; Trasse zaehlt ab 1 m im Flurstueck. Felder: uid, nvt, sub_type, location_hint, bauverfahren,
     surface, laenge_m, laenge_im_flurstueck_m, landesstrasse, flurstueck, hinweis.
  3. WeSi_Spezialfaelle_Flaechen: Gewaesser (10-m-Kreis je Querungspunkt, vereinigt mit der Gewaesserflaeche im 25-m-Umkreis) und
     Strassen.NRW-Flurstuecke der freien Strecke. Felder: art, bezeichnung, trassen, nvt, quelle, hinweis.
Dazu <stamm>_liste.json und <stamm>_bericht.md. ALKIS/ATKIS im AAA-Modell gibt es offen nur in NRW; in anderen Laendern laeuft die
Gewaesserpruefung mit OSM, die Landesstrassenpruefung entfaellt (Hinweis im Bericht).
"""
import json
import math
import os
import re
import time
from datetime import datetime

from ..adressen import alkis as a_alkis
from ..standort import alkis_flaechen

CRS = 25832
WFS_AAA = {"NW": {"alkis": "https://www.wfs.nrw.de/geobasis/wfs_nw_alkis_aaa-modell-basiert",
                  "atkis": "https://www.wfs.nrw.de/geobasis/wfs_nw_atkis-basis-dlm_aaa-modell-basiert"}}
WATER_BUF = 10.0      # m Kreis um den Querungspunkt
OD_BUF = 12.0         # m: ATKIS-Achse gilt als dieselbe Strasse wie die OSM-L-Achse (zweibahnige Strassen)
MIN_IN_PARCEL = 1.0   # m Trassenlaenge im Flurstueck
MIN_ACHSE_IM_FLST = 5.0
DURCHLASS_M = 5.0
LANDESSTRASSE = re.compile(r"^L\s*\d+", re.I)


from ... import gemeinsam, plangoo_api
_s = gemeinsam.s


# --- Trassen ------------------------------------------------------------------------------------------------------------------------
def _blau(f):
    """Rohrfreie ('blaue') Trasse: kein neues, aber ein vorhandenes hoechstes Rohr, oder externes leeres Objekt."""
    def w(k):
        v = f[k] if k in f else None
        return not (v is None or v == "" or (isinstance(v, float) and math.isnan(v)) or v == 0 or str(v) in ("0", "NULL", "None", "nan", "False"))
    return (not w("NEW_HIGHEST_PIPE") and w("EXISTING_HIGHEST_PIPE")) or (w("IS_EXTERNAL_OBJECT") and w("EMPTY"))


def trassen_laden(quelle, log=print):
    """quelle 'plangoo' (offenes Projekt) oder Pfad eines Plan[Goo]-GeoPackages. -> (trassen GeoDataFrame 25832, nvt_polygone oder None)"""
    import geopandas as gpd
    if str(quelle).lower() == "plangoo":
        return _aus_plangoo(log)
    g = gpd.read_file(quelle, layer="GEOMETRY_LINE")
    g = g.set_crs(3857, allow_override=True) if g.crs is None else g
    g = g.to_crs(CRS)
    try:
        polys = gpd.read_file(quelle, layer="GEOMETRY_POLYGON")
        polys = (polys.set_crs(3857, allow_override=True) if polys.crs is None else polys).to_crs(CRS)
    except Exception:
        polys = None
    return _aufbereiten(g, polys, log)


def _aus_plangoo(log):
    import importlib
    import geopandas as gpd
    from shapely import wkt
    from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject
    inst = plangoo_api.instanz()
    if inst is None:
        raise RuntimeError("Kein Plan[Goo]-Projekt geoeffnet.")

    def lesen(layer):
        ct = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:{}".format(CRS)), QgsProject.instance())
        namen = layer.fields().names()
        rows, geoms = [], []
        for f in layer.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = g if ct.isShortCircuited() else (lambda q: (q.transform(ct), q)[1])(g)
            rows.append({n: f[n] for n in namen})
            geoms.append(wkt.loads(g.asWkt()))
        return gpd.GeoDataFrame(rows, geometry=geoms, crs=CRS)
    tr = lesen(inst.get_tranch_layer())
    try:
        polys = lesen(inst.get_polygon_layer())
    except Exception:
        polys = None
    return _aufbereiten(tr, polys, log)


def _aufbereiten(g, polys, log):
    import geopandas as gpd
    from shapely.strtree import STRtree
    n0 = len(g)
    if "TYPE" in g:
        g = g[g["TYPE"].astype(str) == "underground"].copy()
    blau = g.apply(_blau, axis=1) if len(g) else []
    g = g[~blau].copy() if len(g) else g
    g = g[g.geometry.notna() & ~g.geometry.is_empty].explode(index_parts=False, ignore_index=True)
    out = gpd.GeoDataFrame({
        "uid": [_s(v) for v in (g["UID"] if "UID" in g else range(len(g)))],
        "sub_type": [_s(v) for v in (g["SUB_TYPE"] if "SUB_TYPE" in g else [""] * len(g))],
        "location_hint": [_s(v) for v in (g["LOCATION_HINT"] if "LOCATION_HINT" in g else [""] * len(g))],
        "bauverfahren": [_s(v) for v in (g["BAUVERFAHREN"] if "BAUVERFAHREN" in g else [""] * len(g))],
        "surface": [_s(v) for v in (g["SURFACE"] if "SURFACE" in g else [""] * len(g))],
        "laenge_m": [round(x, 1) for x in g.geometry.length],
    }, geometry=list(g.geometry), crs=CRS)
    # NVT: Versorgungsbereich (Polygon Typ nvt), in dem die Trassenmitte liegt
    out["nvt"] = ""
    if polys is not None and len(polys):
        pv = polys[polys["TYPE"].astype(str).str.lower() == "nvt"] if "TYPE" in polys else polys
        pv = pv[pv.geometry.notna() & ~pv.geometry.is_empty]
        if len(pv):
            namen = [_s(v) for v in (pv["NAME"] if "NAME" in pv else pv.index)]
            geoms = list(pv.geometry)
            tree = STRtree(geoms)
            nvt = []
            for line in out.geometry:
                m = line.interpolate(0.5, normalized=True)
                hit = [namen[i] for i in tree.query(m, predicate="within")]
                nvt.append(hit[0] if hit else "")
            out["nvt"] = nvt
    log("Trassen: {} gesamt, {} Tiefbau ohne rohrfreie, davon {} Hauszufuehrungen, {} mit NVT-Bereich".format(
        n0, len(out), int((out["sub_type"] != "").sum()), int((out["nvt"] != "").sum())))
    return out


# --- Geodaten -----------------------------------------------------------------------------------------------------------------------
def _wfs(url, typ, bbox, log):
    t0 = time.time()
    try:
        g = alkis_flaechen._abruf(url, typ, bbox, log)
    except Exception as e:
        log("WFS {} nicht geladen: {}".format(typ, str(e)[:100]))
        return None
    log("WFS {}: {} Objekte ({:.0f} s)".format(typ.split(":")[-1], 0 if g is None else len(g), time.time() - t0))
    return g


def _osm(bbox, out_dir, log):
    """OSM Gewaesser (Linien und Flaechen) und Strassen mit ref. -> (wasser_linien, wasser_flaechen, strassen_ref) GeoDataFrames"""
    import geopandas as gpd
    from shapely.geometry import LineString, Point, Polygon
    from ..cluster import osm
    minx, miny, maxx, maxy = bbox
    box = gpd.GeoSeries([Point(minx, miny), Point(maxx, maxy)], crs="EPSG:25832").to_crs(4326).total_bounds
    s, w, n, e = box[1], box[0], box[3], box[2]
    bb = "{:.6f},{:.6f},{:.6f},{:.6f}".format(s, w, n, e)
    q = ("[out:json][timeout:120];(" 'way["waterway"~"^(river|canal|stream|ditch|drain)$"](' + bb + ");" 'way["natural"="water"](' + bb + ");"
         'way["highway"]["ref"](' + bb + ");" ");out geom;")
    cache = os.path.join(out_dir, "osm_wesi_cache.json") if out_dir else None
    js = osm.fetch((s, w, n, e), cache, query=q)
    wl, wf, st = [], [], []
    for el in js.get("elements", []):
        if el.get("type") != "way" or "geometry" not in el or len(el["geometry"]) < 2:
            continue
        t = el.get("tags", {})
        pts = [(p["lon"], p["lat"]) for p in el["geometry"]]
        if t.get("natural") == "water" and len(pts) > 3 and pts[0] == pts[-1]:
            wf.append({"name": t.get("name"), "typ": "water", "geometry": Polygon(pts)})
        elif "waterway" in t:
            wl.append({"name": t.get("name"), "typ": t["waterway"], "geometry": LineString(pts)})
        elif "highway" in t and t.get("ref"):
            st.append({"ref": t["ref"].strip(), "name": t.get("name"), "highway": t["highway"], "geometry": LineString(pts)})
    mk = lambda rows, cols: gpd.GeoDataFrame(rows, crs=4326).to_crs(CRS) if rows else gpd.GeoDataFrame({c: [] for c in cols}, geometry=[], crs=CRS)
    log("OSM: {} Gewaesserlinien, {} Gewaesserflaechen, {} Strassen mit ref".format(len(wl), len(wf), len(st)))
    return mk(wl, ["name", "typ"]), mk(wf, ["name", "typ"]), mk(st, ["ref", "name", "highway"])


def _tree(gdf):
    from shapely.strtree import STRtree
    geoms = list(gdf.geometry) if gdf is not None and len(gdf) else []
    return (STRtree(geoms) if geoms else None), geoms


# --- Auswertung ---------------------------------------------------------------------------------------------------------------------
def pruefen(quelle, out_dir=None, land=None, log=print, fortschritt=None, water_buf=WATER_BUF, od_buf=OD_BUF, min_in_parcel=MIN_IN_PARCEL):
    """-> dict(gpkg, bericht, liste, gewaesser (GeoDataFrame), landesstrasse, flaechen, land, stamm, out_dir)"""
    import geopandas as gpd
    import pandas as pd
    from shapely.geometry import Point
    from shapely.ops import unary_union
    f = fortschritt or (lambda p, t: None)
    t_start = time.time()
    f(2, "Trassen lesen")
    trs = trassen_laden(quelle, log)
    if not len(trs):
        raise RuntimeError("Keine Tiefbautrassen gefunden.")
    minx, miny, maxx, maxy = trs.total_bounds
    bbox = (minx - 100, miny - 100, maxx + 100, maxy + 100)
    if land is None:
        kand = a_alkis.laender_fuer_bbox(minx, miny, maxx, maxy)
        land = kand[0] if kand else "NW"
    log("Land: {} ({})".format(a_alkis.LAENDER.get(land, land), land))
    if out_dir is None:
        out_dir = os.path.dirname(os.path.abspath(str(quelle))) if os.path.exists(str(quelle)) else os.path.expanduser("~")
    os.makedirs(out_dir, exist_ok=True)
    stamm = re.sub(r"[^A-Za-z0-9_\-]+", "_", os.path.splitext(os.path.basename(str(quelle)))[0])[:40] if os.path.exists(str(quelle)) else "Projekt"
    try:
        if str(quelle).lower() == "plangoo":
            import importlib
            inst = plangoo_api.instanz()
            stamm = re.sub(r"[^A-Za-z0-9_\-]+", "_", os.path.splitext(os.path.basename(inst.gpkg_path))[0])[:40]
            out_dir = out_dir or os.path.dirname(inst.gpkg_path)
    except Exception:
        pass

    # --- Geodaten ---
    aaa = WFS_AAA.get(land)
    gew_l, gew_p, durchl, atk, ortslage = None, None, None, None, None
    if aaa:
        f(8, "ALKIS Gewaesser")
        gew_l = _wfs(aaa["alkis"], "adv:AX_Gewaesserachse", bbox, log)
        gew_p1 = _wfs(aaa["alkis"], "adv:AX_Fliessgewaesser", bbox, log)
        gew_p2 = _wfs(aaa["alkis"], "adv:AX_StehendesGewaesser", bbox, log)
        gew_p = pd.concat([x for x in (gew_p1, gew_p2) if x is not None], ignore_index=True) if (gew_p1 is not None or gew_p2 is not None) else None
        durchl = _wfs(aaa["alkis"], "adv:AX_BauwerkImGewaesserbereich", bbox, log)
        f(22, "ATKIS Strassen")
        atk = _wfs(aaa["atkis"], "adv:AX_Strassenachse", bbox, log)
        ortslage = _wfs(aaa["atkis"], "adv:AX_Ortslage", bbox, log)
        gew_l2 = _wfs(aaa["atkis"], "adv:AX_Gewaesserachse", bbox, log)
        if gew_l2 is not None:
            gew_l = pd.concat([x for x in (gew_l, gew_l2) if x is not None], ignore_index=True)
    else:
        log("Kein offener ALKIS/ATKIS-AAA-Dienst fuer {} - Gewaesser nur aus OSM, Landesstrassenpruefung entfaellt.".format(land))
    f(36, "OSM")
    try:
        osm_wl, osm_wf, osm_st = _osm(bbox, out_dir, log)
    except Exception as e:
        log("OSM nicht geladen: {}".format(str(e)[:120]))
        osm_wl = osm_wf = osm_st = gpd.GeoDataFrame({"name": [], "typ": [], "ref": []}, geometry=[], crs=CRS)

    # --- 1. Gewaesserquerungen ---
    f(48, "Gewaesserquerungen")
    w_items = []
    if gew_l is not None:
        w_items += [(g, "ALKIS/ATKIS Gewaesserachse", _s(a.get("name")) if hasattr(a, "get") else "") for g, a in zip(gew_l.geometry, gew_l.to_dict("records"))]
    if gew_p is not None:
        w_items += [(g, "ALKIS Gewaesserflaeche", _s(a.get("name"))) for g, a in zip(gew_p.geometry, gew_p.to_dict("records"))]
    w_items += [(g, "OSM " + _s(a.get("typ")), _s(a.get("name"))) for g, a in zip(osm_wl.geometry, osm_wl.to_dict("records"))]
    w_items += [(g, "OSM water", _s(a.get("name"))) for g, a in zip(osm_wf.geometry, osm_wf.to_dict("records"))]
    w_items = [(g, q, n) for g, q, n in w_items if g is not None and not g.is_empty]
    from shapely.strtree import STRtree
    wtree = STRtree([g for g, _, _ in w_items]) if w_items else None
    dtree, dgeoms = _tree(durchl)
    rows1, water_polys = [], []
    for r in trs.itertuples():
        g = r.geometry
        if wtree is None:
            break
        hits = [w_items[i] for i in wtree.query(g, predicate="intersects")]
        if not hits:
            continue
        ips = []
        for wg, _, _ in hits:
            ip = g.intersection(wg)
            if ip.is_empty:
                continue
            if ip.geom_type in ("Point", "MultiPoint"):
                ips += list(ip.geoms) if ip.geom_type == "MultiPoint" else [ip]
            elif ip.geom_type in ("LineString", "MultiLineString"):   # Trasse laeuft im Gewaesserpolygon
                ips.append(ip.centroid)
            elif ip.geom_type == "GeometryCollection":
                for part in ip.geoms:
                    ips.append(part if part.geom_type == "Point" else part.centroid)
        quellen = sorted(set(q for _, q, _ in hits))
        namen = sorted(set(n for _, _, n in hits if n))
        dl = bool(dtree is not None and any(dgeoms[i].distance(g) <= DURCHLASS_M for i in dtree.query(g.buffer(DURCHLASS_M))))
        rows1.append({"uid": r.uid, "nvt": r.nvt, "sub_type": r.sub_type, "location_hint": r.location_hint, "bauverfahren": r.bauverfahren,
                      "laenge_m": r.laenge_m, "gewaesser_quelle": "; ".join(quellen), "gewaesser_name": "; ".join(namen), "querungen": len(ips),
                      "durchlass_5m": "ja" if dl else "nein",
                      "hinweis": "Gewaesserquerung (WeSi): Kreuzung mit " + "; ".join(quellen) + ("; Durchlass/Bauwerk im Gewaesserbereich in <= 5 m" if dl else ""),
                      "geometry": g})
        for p in ips:
            poly = p.buffer(water_buf, 16)
            for wg, _, _ in hits:
                if wg.geom_type in ("Polygon", "MultiPolygon") and wg.intersects(poly):
                    poly = unary_union([poly, wg.intersection(p.buffer(25.0, 16))])
            water_polys.append((poly, r.uid, r.nvt, "; ".join(quellen), "; ".join(namen)))
    l1 = gpd.GeoDataFrame(rows1, crs=CRS) if rows1 else gpd.GeoDataFrame({"uid": []}, geometry=[], crs=CRS)
    log("1 Gewaesserquerungen: {} Trassen, {} Querungspunkte".format(len(l1), len(water_polys)))

    # --- 2. Landesstrassen ausserhalb der Ortsdurchfahrt ---
    f(62, "Landesstrassen")
    rows2, road_parcels, frei_m, od_m = [], {}, 0.0, 0.0
    osm_l = osm_st[osm_st["ref"].astype(str).str.match(LANDESSTRASSE.pattern, case=False)] if len(osm_st) else osm_st
    osm_l = osm_l[~osm_l["highway"].isin(["footway", "path", "cycleway"])] if len(osm_l) else osm_l
    if aaa and atk is not None and len(osm_l):
        ltree, lgeoms = _tree(osm_l)
        lrefs = [_s(v) for v in osm_l["ref"]]
        orts = [g for g in ortslage.geometry if g is not None] if ortslage is not None else []
        otree = STRtree(orts) if orts else None
        frei, od = [], []
        for g in atk.geometry:
            if g is None or g.is_empty:
                continue
            c, m = g.centroid, g.interpolate(0.5, normalized=True)
            nahe = [i for i in ltree.query(g.buffer(od_buf)) if lgeoms[i].distance(c) <= od_buf and lgeoms[i].distance(m) <= od_buf]
            if not nahe:
                continue
            ref = lrefs[nahe[0]]
            in_ort = False
            if otree is not None:
                for i in otree.query(g):
                    if orts[i].intersects(g) and orts[i].intersection(g).length > 0.5 * g.length:
                        in_ort = True
                        break
            (od if in_ort else frei).append((g, ref))
        frei_m, od_m = sum(g.length for g, _ in frei), sum(g.length for g, _ in od)
        log("Landesstrassen ({}): freie Strecke {:.0f} m in {} Segmenten, Ortsdurchfahrt {:.0f} m".format(
            ", ".join(sorted(set(r for _, r in frei + od))) or "-", frei_m, len(frei), od_m))
        if frei:
            fx = gpd.GeoSeries([g for g, _ in frei], crs=CRS).total_bounds
            d = a_alkis.dienst(land)
            fl = None
            if d is not None:
                typen = alkis_flaechen.TYPEN.get(land)
                if typen:
                    f(70, "Flurstuecke")
                    fl = _wfs(d[0], typen[0], (fx[0] - 60, fx[1] - 60, fx[2] + 60, fx[3] + 60), log)
            if fl is not None and len(fl):
                ftree, fgeoms = _tree(frei_gdf := gpd.GeoDataFrame({"ref": [r for _, r in frei]}, geometry=[g for g, _ in frei], crs=CRS))
                kz_sp = next((c for c in ("flstkennz", "flurstueckskennzeichen", "kennzeichen") if c in fl.columns), None)
                for i_, (fg, rec) in enumerate(zip(fl.geometry, fl.to_dict("records"))):
                    if fg is None or fg.is_empty:
                        continue
                    segs = [j for j in ftree.query(fg, predicate="intersects")]
                    if not segs:
                        continue
                    ln = sum(fgeoms[j].intersection(fg).length for j in segs)
                    if ln >= MIN_ACHSE_IM_FLST:
                        kz = _s(rec.get(kz_sp)) if kz_sp else ""
                        if not kz:
                            kz = "{}-{}-{}{}".format(_s(rec.get("gemarkung")), _s(rec.get("flur")), _s(rec.get("flstnrzae")),
                                                     "/" + _s(rec.get("flstnrnen")) if _s(rec.get("flstnrnen")) else "").strip("-")
                        road_parcels[kz or "FL{}".format(i_)] = (fg, sorted(set(frei_gdf["ref"].iloc[j] for j in segs)), round(ln, 1))
            log("Flurstuecke der Landesstrasse (freie Strecke): {}".format(len(road_parcels)))
            if road_parcels:
                ptree = STRtree([v[0] for v in road_parcels.values()])
                keys = list(road_parcels.keys())
                for r in trs.itertuples():
                    g = r.geometry
                    hits = [keys[i] for i in ptree.query(g, predicate="intersects")]
                    if not hits:
                        continue
                    lin = sum(road_parcels[k][0].intersection(g).length for k in hits)
                    if lin < min_in_parcel:
                        continue
                    refs = sorted(set(x for k in hits for x in road_parcels[k][1]))
                    rows2.append({"uid": r.uid, "nvt": r.nvt, "sub_type": r.sub_type, "location_hint": r.location_hint, "bauverfahren": r.bauverfahren,
                                  "surface": r.surface, "laenge_m": r.laenge_m, "laenge_im_flurstueck_m": round(lin, 1),
                                  "landesstrasse": "; ".join(refs), "flurstueck": "; ".join(sorted(hits)),
                                  "hinweis": "Landesstrasse {}, freie Strecke (keine OD) - Strassen.NRW / WeSi".format("; ".join(refs)), "geometry": g})
    elif aaa and len(osm_l) == 0:
        log("Keine Landesstrasse (OSM ref 'L ...') im Gebiet.")
    l2 = gpd.GeoDataFrame(rows2, crs=CRS) if rows2 else gpd.GeoDataFrame({"uid": []}, geometry=[], crs=CRS)
    log("2 Trassen auf Landesstrassen-Flurstuecken: {} ({:.0f} m im Flurstueck)".format(len(l2), sum(r["laenge_im_flurstueck_m"] for r in rows2)))

    # --- 3. Flaechen ---
    f(84, "Flaechen")
    rows3 = []
    if water_polys:
        merged = unary_union([p for p, *_ in water_polys])
        for poly in (merged.geoms if merged.geom_type == "MultiPolygon" else [merged]):
            inside = [w for w in water_polys if poly.intersects(w[0])]
            rows3.append({"art": "Gewaesser", "bezeichnung": "; ".join(sorted(set(w[4] for w in inside if w[4]))) or "Gewaesser (ohne Namen)",
                          "trassen": "; ".join(sorted(set(w[1] for w in inside))), "nvt": "; ".join(sorted(set(w[2] for w in inside if w[2]))),
                          "quelle": "; ".join(sorted(set(w[3] for w in inside))), "hinweis": "WeSi-Spezialfall Gewaesserquerung", "geometry": poly})
    for kz, (fg, refs, ln) in road_parcels.items():
        tr_in = [r.uid for r in trs.itertuples() if fg.intersects(r.geometry) and fg.intersection(r.geometry).length >= min_in_parcel]
        nv = sorted(set(r.nvt for r in trs.itertuples() if r.uid in tr_in and r.nvt))
        rows3.append({"art": "Strassen.NRW Landesstrasse", "bezeichnung": "; ".join(refs) + " Flurstueck " + kz, "trassen": "; ".join(tr_in),
                      "nvt": "; ".join(nv), "quelle": "ALKIS Flurstueck + ATKIS/OSM Landesstrassenachse ausserhalb Ortsdurchfahrt",
                      "hinweis": "WeSi-Spezialfall Landesstrasse freie Strecke (Strassen.NRW)" + ("" if tr_in else " - keine Trasse im Flurstueck"),
                      "geometry": fg})
    l3 = gpd.GeoDataFrame(rows3, crs=CRS) if rows3 else gpd.GeoDataFrame({"art": []}, geometry=[], crs=CRS)

    # --- schreiben ---
    f(92, "Schreiben")
    gpkg = os.path.join(out_dir, "wesi_spezialfaelle_{}_{}.gpkg".format(stamm, datetime.now().strftime("%Y%m%d_%H%M")))
    for name, df in (("Trassen_Gewaesserquerung", l1), ("Trassen_Landesstrasse_freie_Strecke", l2), ("WeSi_Spezialfaelle_Flaechen", l3), ("Trassen_geprueft", trs)):
        if len(df):
            df.to_file(gpkg, layer=name, driver="GPKG")
        else:
            gpd.GeoDataFrame({"hinweis": ["keine Treffer"]}, geometry=[Point(minx, miny)], crs=CRS).to_file(gpkg, layer=name + "_leer", driver="GPKG")
    liste = os.path.splitext(gpkg)[0] + "_liste.json"
    with open(liste, "w", encoding="utf-8") as fh:
        json.dump({"gewaesser": [{k: v for k, v in r.items() if k != "geometry"} for r in rows1],
                   "landesstrasse": [{k: v for k, v in r.items() if k != "geometry"} for r in rows2],
                   "achsen_frei_m": round(frei_m), "achsen_od_m": round(od_m), "land": land, "quelle": str(quelle)}, fh, indent=1, ensure_ascii=False)
    md = _bericht(gpkg, quelle, land, trs, rows1, rows2, rows3, frei_m, od_m, aaa is not None, time.time() - t_start)
    f(100, "Fertig")
    return {"gpkg": gpkg, "bericht": md, "liste": liste, "gewaesser": l1, "landesstrasse": l2, "flaechen": l3, "land": land, "stamm": stamm,
            "out_dir": out_dir, "trassen": trs}


def _bericht(gpkg, quelle, land, trs, rows1, rows2, rows3, frei_m, od_m, mit_aaa, dauer):
    from collections import Counter
    p = os.path.splitext(gpkg)[0] + "_bericht.md"
    z1 = Counter(r["nvt"] or "ohne NVT" for r in rows1)
    z2 = Counter(r["nvt"] or "ohne NVT" for r in rows2)
    zeilen = ["# WeSi-Spezialfaelle (Wegesicherung) - {}".format(os.path.basename(str(quelle))), "",
              "Stand {}, Land {}, {} Tiefbautrassen geprueft ({:.0f} s). Quellen: {}".format(
                  datetime.now().strftime("%d.%m.%Y %H:%M"), a_alkis.LAENDER.get(land, land), len(trs), dauer,
                  "ALKIS/ATKIS AAA (WFS NRW), ALKIS Flurstuecke, OSM" if mit_aaa else "OSM (kein offener ALKIS/ATKIS-AAA-Dienst)"), "",
              "## 1. Gewaesserquerungen: {} Trassen, {} Querungspunkte".format(len(rows1), sum(r["querungen"] for r in rows1)),
              "Je NVT: " + (", ".join("{} ({})".format(k, v) for k, v in z1.most_common()) or "-"),
              "Hauszufuehrungen: {}; mit Durchlass/Bauwerk in <= 5 m: {}".format(sum(1 for r in rows1 if r["sub_type"]), sum(1 for r in rows1 if r["durchlass_5m"] == "ja")), ""]
    for r in sorted(rows1, key=lambda x: (x["nvt"], x["uid"])):
        zeilen.append("- {} | NVT {} | {} m | {}{} | {} Querungen | Durchlass {}{}".format(
            r["uid"][:8], r["nvt"] or "-", r["laenge_m"], r["gewaesser_quelle"], " ({})".format(r["gewaesser_name"]) if r["gewaesser_name"] else "",
            r["querungen"], r["durchlass_5m"], " | Hauszufuehrung" if r["sub_type"] else ""))
    zeilen += ["", "## 2. Landesstrasse freie Strecke (Strassen.NRW): {} Trassen, {:.0f} m im Flurstueck".format(
        len(rows2), sum(r["laenge_im_flurstueck_m"] for r in rows2))]
    if mit_aaa:
        zeilen.append("Landesstrassenachse: freie Strecke {:.0f} m, Ortsdurchfahrt (Naeherung ueber ATKIS-Ortslage) {:.0f} m.".format(frei_m, od_m))
        zeilen.append("Je NVT: " + (", ".join("{} ({})".format(k, v) for k, v in z2.most_common()) or "-"))
        zeilen.append("")
        for r in sorted(rows2, key=lambda x: (x["nvt"], -x["laenge_im_flurstueck_m"])):
            zeilen.append("- {} | NVT {} | {} m, davon {} m im Flurstueck {} | {}".format(r["uid"][:8], r["nvt"] or "-", r["laenge_m"],
                                                                                          r["laenge_im_flurstueck_m"], r["flurstueck"], r["landesstrasse"]))
    else:
        zeilen.append("Entfaellt: kein offener ALKIS/ATKIS-AAA-Dienst fuer {} (Strassenachsen, Ortslage).".format(land))
    zeilen += ["", "## 3. Flaechen: {} ({} Gewaesser, {} Strassen.NRW)".format(len(rows3), sum(1 for r in rows3 if r["art"] == "Gewaesser"),
                                                                          sum(1 for r in rows3 if r["art"] != "Gewaesser")), "",
               "## Fallstricke", "- Ortsdurchfahrt = Achse innerhalb der geschlossenen ATKIS-Ortslage (Naeherung); amtliche OD-Grenzen von Strassen.NRW sind nicht offen.",
               "- Eigentuemer stehen nicht im offenen ALKIS: Flurstuecke daneben (Bankett, Boeschung, Graben) koennen ebenfalls Strassen.NRW gehoeren.",
               "- ATKIS besondereVerkehrsbedeutung=1000 steht an allen Landesstrassenachsen und taugt nicht als OD-Kennung.",
               "- Rohrfreie (blaue) Trassen sind nicht enthalten; Hauszufuehrungen sind enthalten (Feld sub_type).",
               "", "GeoPackage: `{}`".format(os.path.basename(gpkg))]
    with open(p, "w", encoding="utf-8") as fh:
        fh.write("\n".join(zeilen))
    return p
