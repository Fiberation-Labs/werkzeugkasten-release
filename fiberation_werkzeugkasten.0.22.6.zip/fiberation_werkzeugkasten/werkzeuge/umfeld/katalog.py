# -*- coding: utf-8 -*-
"""Katalog der Umfeld- und Grundkarten-Dienste.

Zwei Quellen: (1) der Katalog des QGIS-Plugins GeoBasis_Loader (Anton May, Mike Elstermann), wenn installiert - dort stehen ALKIS,
Orthofotos, basemap.de je Land und werden vom Loader-Team gepflegt; (2) die eingebaute Tabelle (Stand 16.09.2026) als Fallback und
fuer die Dienste, die der Loader nicht kennt (BfN-Schutzgebiete, LINFOS NRW, Wasserschutzgebiete NRW, Gewaesserstationierung NRW).

Alle WMS werden in EPSG:3857 angefordert (Plan[Goo] speichert seine Geometrien in EPSG:3857). Kann ein Dienst kein 3857, wird sein
erstes gueltiges KBS genommen und QGIS projiziert um.
"""
import glob
import json
import os
import re

KBS = "EPSG:3857"
GRUPPEN = (("grund", "Grundkarten (WMS)"), ("schutz", "Schutzgebiete und Natur (WMS, amtlich)"), ("wasser", "Gewaesser (WMS, amtlich)"),
           ("verkehr", "Strassen und Verkehr (WMS, Strassen.NRW / NWSIB)"),
           ("osm", "OSM-Vektoren (als GeoPackage, EPSG:3857)"))

BFN = "https://geodienste.bfn.de/ogc/wms/schutzgebiet"
# Strasseninformationsbank NRW (NWSIB-online, Landesbetrieb Strassenbau NRW): WMS 1.1.1, kann EPSG:3857 (Markus 21.09.2026 "nwsib in die
# Grundkarten": Kreis- und Landesstrassen, Ortsdurchfahrten). Klassifizierte Strassen (BAB, B, L, K), OD = Ortsdurchfahrt (Kommune zustaendig,
# Strassen.NRW nur freie Strecke = Wegesicherung Werkzeug 9), Bauwerke/Durchlaesse, Verkehrsmengen DTV (ZTV 21: keine oi an stark befahrenen
# Strassen ausserorts, RPS-Abstand nach Tempo).
NWSIB = "https://www.nwsib-online.nrw.de/GCGisService"
LINFOS = "https://www.wms.nrw.de/umwelt/linfos"
WSG_NW = "https://www.wms.nrw.de/umwelt/wsg"
GSK_NW = "https://www.wms.nrw.de/umwelt/gsk3c"
ALKIS_NW = "https://www.wms.nrw.de/geobasis/wms_nw_alkis"


def _wms(url, layers, kbs=KBS, styles=None):
    """QGIS-WMS-URI: gleiche Anzahl layers und styles, Identifizieren an."""
    if isinstance(layers, str):
        layers = [layers]
    styles = styles or [""] * len(layers)
    teile = ["crs=" + kbs, "dpiMode=7", "featureCount=10", "format=image/png"]
    teile += ["layers=" + l for l in layers]
    teile += ["styles=" + s for s in styles]
    teile.append("url=" + _url_kodieren(url))
    return "&".join(teile)


def _url_kodieren(url):
    """Im QGIS-URI muessen '&' und '=' innerhalb der Dienst-URL kodiert sein (wie im GeoBasis-Loader-Katalog: %26, %3D)."""
    if "?" not in url:
        return url
    basis, frage = url.split("?", 1)
    return basis + "?" + frage.replace("&", "%26").replace("=", "%3D")


# Ein Eintrag: schluessel, gruppe, titel, laender (None = alle), katalog (Land -> Regex auf den GeoBasis-Loader-Namen, "*" = fuer alle
# Laender), uri (Land -> Fallback-URI, "*" = alle), vorgewaehlt, sichtbar (Haken im Layerbaum), hinweis.
EINTRAEGE = [
    # --- Grundkarten -------------------------------------------------------------------------------------------------------------------
    dict(schluessel="basemap", gruppe="grund", titel="basemap.de farbig (bundesweit)", laender=None,
         katalog={"*": r"^DE: basemap\.de farbig \(WMS\)$"},
         uri={"*": _wms("https://sgx.geodatenzentrum.de/wms_basemapde", "de_basemapde_web_raster_farbe")},
         vorgewaehlt=True, sichtbar=True, hinweis="Topographische Web-Karte des BKG, alle Massstaebe."),
    dict(schluessel="dop", gruppe="grund", titel="Digitales Orthofoto (Land)", laender=["NW", "SL", "BW", "NI", "HE", "RP"],
         katalog={"*": r"^{land}: Digitale Orthophotos - DOP\d+ +\(WMS\)"},
         uri={"NW": _wms("https://www.wms.nrw.de/geobasis/wms_nw_dop", "nw_dop_rgb"),
              "SL": _wms("https://geoportal.saarland.de/mapbender/php/wms.php?inspire=1&layer_id=43492&withChilds=1", "sl_dop2020"),
              "BW": _wms("https://owsproxy.lgl-bw.de/owsproxy/ows/WMS_LGL-BW_ATKIS_DOP_20_C", "IMAGES_DOP_20_RGB"),
              "NI": _wms("https://opendata.lgln.niedersachsen.de/doorman/noauth/dop_wms", "ni_dop20"),
              "HE": _wms("https://www.gds-srv.hessen.de/cgi-bin/lika-services/ogc-free-images.ows?language=ger&VERSION=1.3.0", "he_dop20_rgb"),
              "RP": _wms("https://www.geoportal.rlp.de/mapbender/php/wms.php?layer_id=61675&VERSION=1.1.1&withChilds=1", "rp_dop20")},
         vorgewaehlt=True, sichtbar=False, hinweis="Wird geladen, aber ausgeblendet, damit die basemap sichtbar bleibt. Haken setzen zum Einblenden."),
    dict(schluessel="alkis_flur", gruppe="grund", titel="ALKIS Flurstuecke (Land)", laender=["NW", "SL", "RP", "NI", "HE", "BW"],
         katalog={"NW": r"^NW: ALKIS Flurstücke \(WMS\)$", "SL": r"^SL: ALKIS Flurstücke \(WMS\)$", "RP": r"^RP: ALKIS Flurstücke \(WMS\)$",
                  "NI": r"^NI: ALKIS Flurstücke, Gebäude, Nutzung \(WMS\)$", "HE": r"^HE: ALKIS Flurstücke, Gebäude, Nutzung \(WMS\)$",
                  "BW": r"^BW: ALKIS Flurstücke, Gebäude, Nutzung \(WMTS\)$"},
         uri={"NW": _wms(ALKIS_NW, "adv_alkis_flurstuecke"),
              "SL": _wms("https://geoportal.saarland.de/mapbender/php/wms.php?inspire=1&layer_id=42092&withChilds=1", "CP.CadastralParcel"),
              "RP": _wms("https://www.geoportal.rlp.de/mapbender/php/wms.php?layer_id=61680&withChilds=1&VERSION=1.1.1", "Flurstueck"),
              "NI": _wms("https://opendata.lgln.niedersachsen.de/doorman/noauth/alkis_wms", "ALKIS", styles=["Farbe"]),
              "HE": _wms("https://www.gds-srv.hessen.de/cgi-bin/lika-services/ogc-free-maps.ows?language=ger&VERSION=1.3.0", "he_alk")},
         vorgewaehlt=True, sichtbar=True, hinweis="NI, HE und BW liefern Flurstuecke, Gebaeude und Nutzung in einem Dienst."),
    dict(schluessel="alkis_geb", gruppe="grund", titel="ALKIS Gebaeude (Land)", laender=["NW", "SL", "RP"],
         katalog={"NW": r"^NW: ALKIS Gebäude \(WMS\)$", "SL": r"^SL: ALKIS Gebäude \(WMS\)$", "RP": r"^RP: ALKIS Gebäude \(WMS\)$"},
         uri={"NW": _wms(ALKIS_NW, "adv_alkis_gebaeude"),
              "SL": _wms("https://geoportal.saarland.de/mapbender/php/wms.php?layer_id=44400&VERSION=1.1.1&withChilds=1", "BU.Building"),
              "RP": _wms("https://www.geoportal.rlp.de/mapbender/php/wms.php?layer_id=61680&withChilds=1&VERSION=1.1.1", "GebaeudeBauwerke")},
         vorgewaehlt=True, sichtbar=True, hinweis=""),
    dict(schluessel="topo", gruppe="grund", titel="Topographische Karte des Landes (P10 / DTK 25)", laender=["NW", "BW", "HE"],
         katalog={"NW": r"^NW: Basemap P10 farbig \(WMS\)$", "BW": r"^BW: DTK 25 farbig \(WMS\)$", "HE": r"^HE: DTK 25 farbig \(WMS\)$"},
         uri={"NW": _wms("https://www.wms.nrw.de/geobasis/wms_nw_p10", "nw_p10_col"),
              "BW": _wms("https://owsproxy.lgl-bw.de/owsproxy/ows/WMS_LGL-BW_ATKIS_DTK_25_K_A", "RDS_LY_DTK25K_COL"),
              "HE": _wms("https://www.gds-srv.hessen.de/cgi-bin/lika-services/ogc-free-maps.ows?language=ger&VERSION=1.3.0", "he_dtk25")},
         vorgewaehlt=False, sichtbar=False, hinweis=""),
    # --- Schutzgebiete -----------------------------------------------------------------------------------------------------------------
    dict(schluessel="bfn", gruppe="schutz", titel="Schutzgebiete bundesweit (BfN): NSG, LSG, FFH, Vogelschutz, Nationalpark, Naturpark",
         laender=None, katalog={},
         uri={"*": _wms(BFN, ["Naturschutzgebiete", "Landschaftsschutzgebiete", "Fauna_Flora_Habitat_Gebiete", "Vogelschutzgebiete",
                              "Nationalparke", "Naturparke", "Biosphaerenreservate"])},
         vorgewaehlt=True, sichtbar=True, hinweis="Bundesamt fuer Naturschutz, Stand der Laendermeldungen. Fuer NRW ist LINFOS aktueller."),
    dict(schluessel="linfos_schutz", gruppe="schutz", titel="Schutzgebiete NRW (LINFOS): NSG, LSG, FFH, Vogelschutz, Nationalpark, Naturpark",
         laender=["NW"], katalog={},
         uri={"NW": _wms(LINFOS, ["Naturschutzgebiete", "Landschaftsschutzgebiet", "FFH-Gebiete", "Vogelschutzgebiete", "Nationalpark", "Naturpark"])},
         vorgewaehlt=True, sichtbar=True, hinweis="LANUV NRW, Landschaftsinformationssammlung."),
    dict(schluessel="linfos_biotope", gruppe="schutz", titel="Geschuetzte Biotope und Biotopkataster NRW (LINFOS)", laender=["NW"], katalog={},
         uri={"NW": _wms(LINFOS, ["geschuetzteBiotope", "Biotopkataster_Flaeche"])},
         vorgewaehlt=False, sichtbar=True, hinweis="Paragraf 30/42 BNatSchG/LNatSchG - Tiefbau dort nur mit Befreiung."),
    dict(schluessel="linfos_alleen", gruppe="schutz", titel="Alleenkataster NRW (LINFOS)", laender=["NW"], katalog={},
         uri={"NW": _wms(LINFOS, "Alleen-Kataster")},
         vorgewaehlt=True, sichtbar=True, hinweis="Gesetzlich geschuetzte Alleen (Paragraf 41 LNatSchG NRW): Wurzelbereich beachten."),
    dict(schluessel="wsg_nw", gruppe="schutz", titel="Wasserschutzgebiete NRW (Trinkwasser fest/geplant, Heilquellen)", laender=["NW"], katalog={},
         uri={"NW": _wms(WSG_NW, ["4", "3", "2", "1"])},
         vorgewaehlt=True, sichtbar=True, hinweis="ELWAS/LANUV. Zone I bis III: Auflagen fuer Tiefbau und Baustoffe."),
    # --- Gewaesser ---------------------------------------------------------------------------------------------------------------------
    dict(schluessel="gsk_nw", gruppe="wasser", titel="Gewaesserstationierung NRW: Fliessgewaesser, Gewaesserflaechen, Kanaele", laender=["NW"], katalog={},
         uri={"NW": _wms(GSK_NW, ["10", "9", "8", "7", "4"])},
         vorgewaehlt=True, sichtbar=True, hinweis="LANUV GSK3C - amtliches Gewaessernetz, Grundlage fuer die Wasserbehoerde (Werkzeug 9)."),
    dict(schluessel="alkis_wasser_nw", gruppe="wasser", titel="ALKIS Gewaesser NRW", laender=["NW"], katalog={},
         uri={"NW": _wms(ALKIS_NW, "adv_alkis_gewaesser")},
         vorgewaehlt=False, sichtbar=True, hinweis="Tatsaechliche Nutzung Gewaesser aus dem Liegenschaftskataster."),
    dict(schluessel="wsv", gruppe="wasser", titel="Bundeswasserstrassen (WSV Gewaessernetz)", laender=None,
         katalog={"*": r"^DE: Gewaessernetz \(WMS\)$"},
         uri={"*": _wms("https://via.bund.de/wsv/bwastr/wms", "Gewaessernetz")},
         vorgewaehlt=False, sichtbar=True, hinweis="Nur schiffbare Bundeswasserstrassen."),
    # --- Strassen und Verkehr (NWSIB) --------------------------------------------------------------------------------------------------
    dict(schluessel="nwsib_netz", gruppe="verkehr", titel="Klassifizierte Strassen NRW: Autobahn, Bundes-, Landes-, Kreisstrasse mit Bezeichnung (NWSIB)",
         laender=["NW"], katalog={},
         uri={"NW": _wms(NWSIB, ["Strasse:Strassenklassen", "Strasse:Strassenbezeichnung"])},
         vorgewaehlt=True, sichtbar=True, hinweis="Strassen.NRW, Straßeninformationsbank. Blau Bundesstrasse, gruen Landesstrasse, braun Kreisstrasse; "
                                                  "Identifizieren liefert Strassennummer, Abschnitt, Stadium."),
    dict(schluessel="nwsib_od", gruppe="verkehr", titel="Ortsdurchfahrten (OD) und freie Strecke NRW (NWSIB)", laender=["NW"], katalog={},
         uri={"NW": _wms(NWSIB, "Strasse:Ortsdurchfahrt")},
         vorgewaehlt=True, sichtbar=True, hinweis="Gelb = Ortsdurchfahrt: dort ist die Kommune Traeger der Strassenbaulast (Gehwege) und Ansprechpartner "
                                                  "der Wegesicherung. Ausserhalb der OD = freie Strecke: Strassen.NRW, RPS-Abstaende, Antrag nach § 127 TKG dort."),
    dict(schluessel="nwsib_bauwerke", gruppe="verkehr", titel="Bauwerke und Durchlaesse an klassifizierten Strassen NRW (NWSIB)", laender=["NW"], katalog={},
         uri={"NW": _wms(NWSIB, ["Strasse:Bauwerkslage", "Strasse:Bauwerksname", "Strasse:Durchlass"])},
         vorgewaehlt=False, sichtbar=True, hinweis="Bruecken, Stuetzwaende, Durchlaesse mit Bauwerksnummer - Kandidaten fuer Querungen (Mitnutzung) und "
                                                   "Pflichtabstimmung mit Strassen.NRW."),
    dict(schluessel="nwsib_dtv", gruppe="verkehr", titel="Verkehrsmenge DTV Kfz 2021 an klassifizierten Strassen NRW (NWSIB)", laender=["NW"], katalog={},
         uri={"NW": _wms(NWSIB, ["Strasse:DTV Kfz 2021", "Strasse:DTV Kfz 2021 Beschriftung"])},
         vorgewaehlt=False, sichtbar=True, hinweis="Durchschnittliche taegliche Verkehrsstaerke. ZTV 21 Kap. 10: keine oberirdische Bauweise an stark "
                                                   "befahrenen Strassen ausserorts - hier ablesbar."),
    dict(schluessel="nwsib_zustaendig", gruppe="verkehr", titel="Zustaendigkeit Strassen.NRW und Strassenmeistereien (NWSIB)", laender=["NW"], katalog={},
         uri={"NW": _wms(NWSIB, ["Strasse:zustaendigkeit_strassen_nrw", "Strasse:Strassenmeisterei"])},
         vorgewaehlt=False, sichtbar=False, hinweis="Welche Regionalniederlassung / Strassenmeisterei den Abschnitt betreut - Adressat der Antraege."),
    # --- OSM ---------------------------------------------------------------------------------------------------------------------------
    dict(schluessel="osm_baeume", gruppe="osm", titel="Baeume und Baumreihen (natural=tree, tree_row)", laender=None, katalog={}, uri={},
         vorgewaehlt=True, sichtbar=True, hinweis="Strassenbaeume in OSM sind lueckenhaft; wo ein Baumkataster der Kommune existiert, ist das besser."),
    dict(schluessel="osm_gewaesser", gruppe="osm", titel="Gewaesser (natural=water, waterway)", laender=None, katalog={}, uri={},
         vorgewaehlt=True, sichtbar=True, hinweis="Fluesse, Baeche, Graeben, Teiche als Linien und Flaechen."),
    dict(schluessel="osm_schutz", gruppe="osm", titel="Schutzgebiete (boundary=protected_area, leisure=nature_reserve)", laender=None, katalog={}, uri={},
         vorgewaehlt=True, sichtbar=True, hinweis="Nicht rechtsverbindlich - fuer die Vorpruefung; amtlich sind BfN und LINFOS."),
    dict(schluessel="osm_gruen", gruppe="osm", titel="Wald und Gruenflaechen (landuse, natural)", laender=None, katalog={}, uri={},
         vorgewaehlt=False, sichtbar=True, hinweis="Wald, Wiese, Kleingaerten, Friedhoefe, Streuobst."),
    dict(schluessel="osm_bahn", gruppe="osm", titel="Bahnanlagen (railway)", laender=None, katalog={}, uri={},
         vorgewaehlt=True, sichtbar=True, hinweis="Kreuzung Bahn = Zustimmung DB/Bahnbetreiber, eigene Bauverfahren. Auch U-Bahn, Museums-, Bau-, stillgelegte und aufgegebene Strecken (Spalte typ)."),
    dict(schluessel="osm_strom", gruppe="osm", titel="Freileitungen und Masten (power)", laender=None, katalog={}, uri={},
         vorgewaehlt=True, sichtbar=True, hinweis="Hoch- und Mittelspannung; Schutzstreifen der Netzbetreiber beachten."),
    dict(schluessel="osm_bruecken", gruppe="osm", titel="Bruecken und Durchlaesse (bridge, tunnel=culvert)", laender=None, katalog={}, uri={},
         vorgewaehlt=True, sichtbar=True, hinweis="Kandidaten fuer Querungen: Bruecke mitnutzen oder Duekern."),
]

# Overpass-Abfragen je OSM-Thema (bb wird eingesetzt). wege = Knoten und Wege (volle Geometrie), relationen = Multipolygone; deren
# Geometrie wird auf den Umgriff beschnitten (out geom(bb)), sonst dauert ein Naturpark oder Wald ueber 5 Minuten (Witten 16.09.2026:
# Schutzgebiete 339 s). Beschnittene Ringe werden zu Grenzlinien.
OSM_THEMEN = {
    "osm_baeume": dict(wege='node["natural"="tree"]({bb});way["natural"="tree_row"]({bb});', relationen="", flaechen=False),
    "osm_gewaesser": dict(wege='way["natural"="water"]({bb});way["waterway"]({bb});way["landuse"~"^(reservoir|basin)$"]({bb});',
                          relationen='relation["natural"="water"]({bb});', flaechen=True),
    "osm_schutz": dict(wege='way["boundary"="protected_area"]({bb});way["leisure"="nature_reserve"]({bb});',
                       relationen='relation["boundary"="protected_area"]({bb});relation["leisure"="nature_reserve"]({bb});'
                                  'relation["boundary"="national_park"]({bb});', flaechen=True),
    "osm_gruen": dict(wege='way["landuse"~"^(forest|grass|meadow|orchard|cemetery|allotments|village_green|recreation_ground)$"]({bb});'
                           'way["natural"~"^(wood|scrub|heath|wetland|grassland)$"]({bb});way["leisure"~"^(park|garden)$"]({bb});',
                      relationen='relation["landuse"="forest"]({bb});relation["natural"="wood"]({bb});', flaechen=True),
    "osm_bahn": dict(wege='way["railway"~"^(rail|tram|light_rail|subway|narrow_gauge|preserved|construction|disused|abandoned)$"]({bb});way["landuse"="railway"]({bb});',
                     relationen="", flaechen=True),
    "osm_strom": dict(wege='way["power"~"^(line|minor_line|cable)$"]({bb});node["power"~"^(tower|pole|portal)$"]({bb});'
                           'way["power"="substation"]({bb});', relationen="", flaechen=True),
    "osm_bruecken": dict(wege='way["bridge"]["bridge"!="no"]({bb});way["tunnel"="culvert"]({bb});way["man_made"="bridge"]({bb});',
                         relationen="", flaechen=False),
}
OSM_TIMEOUT_S = 60


def overpass_abfrage(themen, bb):
    """EINE Abfrage fuer alle gewaehlten Themen. Sieben Einzelabfragen hintereinander loesen auf overpass-api.de die Drosselung je IP aus
    (Witten 16.09.2026: 445 s fuer Schutzgebiete, 147 s fuer Freileitungen - Wartezeit, nicht Rechenzeit)."""
    if isinstance(themen, str):
        themen = [themen]
    wege = "".join(OSM_THEMEN[t]["wege"].format(bb=bb) for t in themen)
    rel = "".join(OSM_THEMEN[t]["relationen"].format(bb=bb) for t in themen)
    q = "[out:json][timeout:{}];".format(OSM_TIMEOUT_S)
    q += "(" + wege + ")->.w;.w out geom;"
    if rel:
        q += "(" + rel + ")->.r;.r out geom({bb});".format(bb=bb)
    return q


_GRUEN_LANDUSE = {"forest", "grass", "meadow", "orchard", "cemetery", "allotments", "village_green", "recreation_ground"}
_GRUEN_NATURAL = {"wood", "scrub", "heath", "wetland", "grassland"}
_BAHN = {"rail", "tram", "light_rail", "subway", "narrow_gauge", "preserved", "construction", "disused", "abandoned"}
_STROM = {"line", "minor_line", "cable", "tower", "pole", "portal", "substation"}


def themen_fuer(tags):
    """Themen, zu denen ein Element nach seinen Tags gehoert (Spiegel der Overpass-Filter). Ein Element kann mehrere treffen
    (Eisenbahnbruecke: Bahn und Bruecke)."""
    t = set()
    nat, lu, lei = tags.get("natural"), tags.get("landuse"), tags.get("leisure")
    if nat in ("tree", "tree_row"):
        t.add("osm_baeume")
    if nat == "water" or "waterway" in tags or lu in ("reservoir", "basin"):
        t.add("osm_gewaesser")
    if tags.get("boundary") in ("protected_area", "national_park") or lei == "nature_reserve":
        t.add("osm_schutz")
    if lu in _GRUEN_LANDUSE or nat in _GRUEN_NATURAL or lei in ("park", "garden"):
        t.add("osm_gruen")
    if tags.get("railway") in _BAHN or lu == "railway":
        t.add("osm_bahn")
    if tags.get("power") in _STROM:
        t.add("osm_strom")
    if (tags.get("bridge") and tags.get("bridge") != "no") or tags.get("tunnel") == "culvert" or tags.get("man_made") == "bridge":
        t.add("osm_bruecken")
    return t
# Tags, die als Attribute mitkommen
OSM_TAGS = ("name", "natural", "waterway", "water", "landuse", "leisure", "boundary", "protect_class", "protection_title", "railway",
            "power", "voltage", "bridge", "tunnel", "man_made", "highway", "species", "genus", "denotation", "height", "circumference",
            "diameter_crown", "operator", "ref", "layer")


def eintrag(schluessel):
    for e in EINTRAEGE:
        if e["schluessel"] == schluessel:
            return e
    return None


def passt_zu_land(e, land):
    return e["laender"] is None or (land in e["laender"])


# --- GeoBasis-Loader-Katalog ----------------------------------------------------------------------------------------------------------------
_KATALOG = None


def _katalog_eintraege():
    """Alle Eintraege mit name/uri aus katalog_*.json des GeoBasis Loaders (einmal gelesen)."""
    global _KATALOG
    if _KATALOG is not None:
        return _KATALOG
    wurzeln = []
    try:
        from qgis.core import QgsApplication
        wurzeln.append(os.path.join(QgsApplication.qgisSettingsDirPath(), "python", "plugins", "GeoBasis_Loader", "catalogs"))
    except Exception:
        pass
    wurzeln.append(os.path.join(os.environ.get("APPDATA", ""), "QGIS", "QGIS3", "profiles", "default", "python", "plugins", "GeoBasis_Loader",
                                "catalogs"))
    alle = []
    for w in wurzeln:
        for p in glob.glob(os.path.join(w, "katalog_*.json")):
            try:
                with open(p, encoding="utf-8") as f:
                    alle.extend(_walk(json.load(f)))
            except Exception:
                continue
        if alle:
            break
    _KATALOG = alle
    return alle


def _walk(obj):
    if isinstance(obj, dict):
        if "uri" in obj and "name" in obj:
            yield obj
        for v in obj.values():
            yield from _walk(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _walk(v)


def aus_katalog(muster):
    """Erster WMS-Eintrag des GeoBasis-Loader-Katalogs, dessen Name auf das Muster passt -> (uri, valid_epsg) oder None."""
    try:
        rx = re.compile(muster)
    except re.error:
        return None
    for e in _katalog_eintraege():
        if e.get("type") == "ogc_wms" and rx.search(e.get("name", "")):
            return e.get("uri", ""), list(e.get("valid_epsg") or [])
    return None


def wms_uri(e, land):
    """(uri, quelle) fuer einen WMS-Eintrag und ein Land; quelle = 'GeoBasis Loader' oder 'Tabelle'. None, wenn nichts passt."""
    muster = e["katalog"].get(land) or e["katalog"].get("*")
    if muster:
        treffer = aus_katalog(muster.replace("{land}", land or ""))
        if treffer:
            uri, epsg = treffer
            kbs = KBS if (KBS in epsg or not epsg) else epsg[0]
            uri = uri.replace("EPSG:placeholder", kbs)
            return uri, "GeoBasis Loader"
    uri = e["uri"].get(land) or e["uri"].get("*")
    if uri:
        return uri, "Tabelle"
    return None
