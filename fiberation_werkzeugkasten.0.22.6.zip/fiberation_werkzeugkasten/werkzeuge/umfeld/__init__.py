# -*- coding: utf-8 -*-
"""Werkzeug 0 - Umfeld und Grundkarten laden: amtliche WMS (ALKIS, Orthofoto, basemap.de, Schutzgebiete, Gewaesser) und OSM-Vektoren
(Baeume, Gewaesser, Schutzgebiete, Bahn, Freileitungen, Bruecken) mit einem Knopf in das offene Projekt, alles in EPSG:3857."""
