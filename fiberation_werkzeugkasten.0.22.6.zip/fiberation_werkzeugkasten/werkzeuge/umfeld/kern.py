# -*- coding: utf-8 -*-
"""Werkzeug 0 - Kern: Umgriff und Land bestimmen, WMS-Layer bauen, OSM-Themen per Overpass holen, als GeoPackage (EPSG:3857) schreiben,
Layer mit Stil in drei Gruppen am unteren Ende des Layerbaums einhaengen (Grundkarten ganz unten, darueber Umfeld amtlich, darueber OSM).
Kein geopandas noetig - alles ueber die QGIS-API."""
import json
import os
import time
from datetime import datetime

from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsField, QgsFields, QgsFillSymbol, QgsGeometry,
                       QgsLineSymbol, QgsMarkerSymbol, QgsPointXY, QgsProject, QgsRasterLayer, QgsRectangle, QgsVectorFileWriter,
                       QgsVectorLayer, QgsWkbTypes)
from qgis.PyQt.QtCore import QVariant

from ... import ci
from ..adressen import alkis
from ..cluster import osm as osm_modul
from . import katalog

KBS = QgsCoordinateReferenceSystem("EPSG:3857")
KBS_4326 = QgsCoordinateReferenceSystem("EPSG:4326")
KBS_25832 = QgsCoordinateReferenceSystem("EPSG:25832")
GRUPPE_GRUND = "0 Grundkarten"        # Schrittnummer vorn wie bei allen Schritten (layerbaum); Schritt 0 liegt ganz unten
GRUPPE_AMT = "0 Umfeld amtlich"
GRUPPE_OSM = "0 Umfeld OSM"
GRUND_REIHENFOLGE = ["alkis_geb", "alkis_flur", "topo", "dop", "basemap"]  # oben -> unten im Layerbaum
MAX_UMGRIFF_KM2 = 400.0


# --- Umgriff und Land ---------------------------------------------------------------------------------------------------------------------
def _transform(rect, von, nach):
    ct = QgsCoordinateTransform(von, nach, QgsProject.instance())
    return ct.transformBoundingBox(rect)


def umgriff_karte(iface):
    """Kartenausschnitt in EPSG:3857."""
    canvas = iface.mapCanvas()
    rect = canvas.extent()
    kbs = canvas.mapSettings().destinationCrs()
    if kbs.isValid() and kbs != KBS:
        rect = _transform(rect, kbs, KBS)
    return rect


def umgriff_plangoo(gpkg, rand_m=200.0):
    """Umgriff der Plan[Goo]-Trassen und -Punkte (liegen in EPSG:3857) plus Rand; None, wenn das Projekt noch leer ist."""
    gesamt = None
    for lname in ("GEOMETRY_LINE", "GEOMETRY_POINT", "GEOMETRY_POLYGON"):
        lyr = QgsVectorLayer("{}|layername={}".format(gpkg, lname), lname, "ogr")
        if not lyr.isValid() or lyr.featureCount() == 0:
            continue
        r = lyr.extent()
        if r.isEmpty():
            continue
        if lyr.crs().isValid() and lyr.crs() != KBS:
            r = _transform(r, lyr.crs(), KBS)
        if gesamt is None:
            gesamt = QgsRectangle(r)
        else:
            gesamt.combineExtentWith(r)
    if gesamt is None:
        return None
    gesamt.grow(rand_m)
    return gesamt


def land_erkennen(rect3857):
    """Laenderkuerzel mit der groessten Ueberdeckung oder None."""
    try:
        r = _transform(rect3857, KBS, KBS_25832)
        treffer = alkis.laender_fuer_bbox(r.xMinimum(), r.yMinimum(), r.xMaximum(), r.yMaximum())
        return treffer[0] if treffer else None
    except Exception:
        return None


def bbox4326(rect3857):
    r = _transform(rect3857, KBS, KBS_4326)
    return (r.yMinimum(), r.xMinimum(), r.yMaximum(), r.xMaximum())  # s, w, n, e


def flaeche_km2(rect3857):
    """Naeherung: Web-Mercator-Flaeche mit Breitenkorrektur."""
    import math
    r = _transform(rect3857, KBS, KBS_4326)
    lat = math.radians((r.yMinimum() + r.yMaximum()) / 2)
    k = math.cos(lat)
    return rect3857.width() * k * rect3857.height() * k / 1e6


# --- WMS ---------------------------------------------------------------------------------------------------------------------------------------
def wms_layer(e, land):
    """(QgsRasterLayer oder None, Quelle, Fehlertext)."""
    treffer = katalog.wms_uri(e, land)
    if treffer is None:
        return None, "", "kein Dienst fuer {}".format(alkis.LAENDER.get(land, land))
    uri, quelle = treffer
    lyr = QgsRasterLayer(uri, e["titel"], "wms")
    if not lyr.isValid():
        # Dienste antworten gelegentlich beim ersten Mal nicht (WSV, basemap.de am 16.09.2026) - einmal kurz warten und neu versuchen,
        # danach die eingebaute Tabelle, falls der Katalog-Eintrag die Ursache ist
        time.sleep(2)
        lyr = QgsRasterLayer(uri, e["titel"], "wms")
    if not lyr.isValid() and quelle != "Tabelle":
        ersatz = e["uri"].get(land) or e["uri"].get("*")
        if ersatz:
            lyr = QgsRasterLayer(ersatz, e["titel"], "wms")
            quelle = "Tabelle"
    if not lyr.isValid():
        return None, quelle, (lyr.error().summary() or "Dienst antwortet nicht")[:160]
    return lyr, quelle, ""


# --- OSM -----------------------------------------------------------------------------------------------------------------------------------------
def _felder():
    f = QgsFields()
    f.append(QgsField("osm_id", QVariant.String, len=24))
    f.append(QgsField("typ", QVariant.String, len=40))
    for t in katalog.OSM_TAGS:
        f.append(QgsField(t, QVariant.String, len=120))
    f.append(QgsField("tags", QVariant.String, len=2000))
    return f


def _typ(tags, thema):
    for k in ("natural", "waterway", "boundary", "leisure", "landuse", "railway", "power", "man_made", "bridge", "tunnel"):
        v = tags.get(k)
        if v and v != "yes":
            return v
        if v == "yes" and k in ("bridge",):
            return "bridge"
    return thema.replace("osm_", "")


def _ist_flaeche(tags, thema):
    if not katalog.OSM_THEMEN[thema]["flaechen"]:
        return False
    if tags.get("waterway") and tags.get("natural") != "water":
        return tags.get("waterway") in ("riverbank", "dock", "boatyard")
    if tags.get("railway") and not tags.get("landuse"):
        return False
    if tags.get("power") in ("line", "minor_line", "cable"):
        return False
    if tags.get("natural") == "tree_row":
        return False
    return True


def _ringe(teile):
    """Wege (Koordinatenlisten) zu geschlossenen Ringen zusammenfuegen (Relationen). -> (ringe, offene_reste)"""
    segs = [list(c) for c in teile if len(c) >= 2]
    ringe, reste = [], []
    while segs:
        ring = segs.pop(0)
        weiter = True
        while ring[0] != ring[-1] and weiter and segs:
            weiter = False
            for i, s in enumerate(segs):
                if s[0] == ring[-1]:
                    ring += s[1:]
                elif s[-1] == ring[-1]:
                    ring += list(reversed(s))[1:]
                elif s[-1] == ring[0]:
                    ring = s[:-1] + ring
                elif s[0] == ring[0]:
                    ring = list(reversed(s))[:-1] + ring
                else:
                    continue
                segs.pop(i)
                weiter = True
                break
        if ring[0] == ring[-1] and len(ring) >= 4:
            ringe.append(ring)
        else:
            reste.append(ring)
    return ringe, reste


def _punkte(coords):
    return [QgsPointXY(x, y) for x, y in coords]


def _geometrien(el, thema):
    """Element -> Liste (geomtyp, QgsGeometry in EPSG:4326); geomtyp in 'punkt', 'linie', 'flaeche'."""
    tags = el.get("tags") or {}
    typ = el.get("type")
    if typ == "node":
        return [("punkt", QgsGeometry.fromPointXY(QgsPointXY(el["lon"], el["lat"])))]
    if typ == "way":
        coords = [(p["lon"], p["lat"]) for p in el.get("geometry") or [] if p]
        if len(coords) < 2:
            return []
        geschlossen = coords[0] == coords[-1] and len(coords) >= 4
        if geschlossen and _ist_flaeche(tags, thema):
            return [("flaeche", QgsGeometry.fromPolygonXY([_punkte(coords)]))]
        return [("linie", QgsGeometry.fromPolylineXY(_punkte(coords)))]
    if typ == "relation":
        if not katalog.OSM_THEMEN[thema]["flaechen"]:
            return []
        aussen, innen = [], []
        for m in el.get("members") or []:
            if m.get("type") != "way" or not m.get("geometry"):
                continue
            c = [(p["lon"], p["lat"]) for p in m["geometry"] if p]
            (innen if m.get("role") == "inner" else aussen).append(c)
        ringe_aussen, reste = _ringe(aussen)
        polys = [QgsGeometry.fromPolygonXY([_punkte(r)]) for r in ringe_aussen]
        ringe_innen, reste_innen = _ringe(innen)
        for r in ringe_innen:
            p0 = QgsGeometry.fromPointXY(QgsPointXY(*r[0]))
            for g in polys:
                if g.contains(p0):
                    g.addRing(_punkte(r))
                    break
        erg = []
        if len(polys) == 1:
            erg.append(("flaeche", polys[0]))
        elif polys:
            erg.append(("flaeche", QgsGeometry.collectGeometry(polys)))
        # am Umgriff beschnittene Ringe (out geom(bbox)) -> Grenzlinien, damit die Grenze im Ausschnitt trotzdem sichtbar ist
        for r in reste + reste_innen:
            if len(r) >= 2:
                erg.append(("linie", QgsGeometry.fromPolylineXY(_punkte(r))))
        return erg
    return []


def _fetch_im_hintergrund(bbox, abfrage, warte=None, abbruch=None, fortschritt_text=None):
    """Overpass-Abruf, QGIS bleibt bedienbar (Witten 16.09.2026: bis 339 s je Thema im Vordergrund = 'QGIS haengt').
    Seit 29.09.2026 macht osm.fetch() den Thread selbst (fuer alle Schritte); hier bleibt nur die Weitergabe von warte/abbruch/Text."""
    return osm_modul.fetch(bbox, None, query=abfrage, warte=warte, abbruch=abbruch,
                           status=(lambda txt: fortschritt_text(txt.split(", ")[-1])) if fortschritt_text else None)


def osm_laden(rect3857, themen, gpkg_pfad, log=print, fortschritt=None, warte=None, abbruch=None):
    """Alle Themen mit EINER Overpass-Abfrage holen (im Hintergrund-Thread), Elemente nach Tags auf die Themen verteilen, je Thema und
    Geometrietyp einen Layer ins GeoPackage schreiben. -> Liste dict(thema, layer, geom, anzahl). Abbruch -> leere Liste."""
    s, w, n, e = bbox4326(rect3857)
    bb = "{:.6f},{:.6f},{:.6f},{:.6f}".format(s, w, n, e)
    ct = QgsCoordinateTransform(KBS_4326, KBS, QgsProject.instance())
    felder = _felder()
    ergebnis = []
    if not themen:
        return ergebnis
    if fortschritt:
        fortschritt(10, "OSM-Abruf ({} Themen)".format(len(themen)))
    t0 = time.time()
    try:
        js = _fetch_im_hintergrund((s, w, n, e), katalog.overpass_abfrage(themen, bb), warte=warte, abbruch=abbruch,
                                   fortschritt_text=(lambda txt: fortschritt(10, "OSM-Abruf ({} Themen, {})".format(len(themen), txt))) if fortschritt else None)
    except RuntimeError as ex:
        if "abgebrochen" in str(ex):
            log("OSM: abgebrochen.")
            return ergebnis
        log("OSM: Abruf fehlgeschlagen ({}).".format(str(ex)[:160]))
        return ergebnis
    except Exception as ex:
        log("OSM: Abruf fehlgeschlagen ({}).".format(str(ex)[:160]))
        return ergebnis
    elemente = js.get("elements") or []
    log("OSM: {} Elemente in {:.0f} s".format(len(elemente), time.time() - t0))

    # Elemente auf Themen verteilen (ein Element kann zu mehreren gehoeren)
    je_thema = {t: [] for t in themen}
    for el in elemente:
        tags = el.get("tags") or {}
        if not tags:
            continue
        for t in katalog.themen_fuer(tags):
            if t in je_thema:
                je_thema[t].append(el)

    erstes = not os.path.exists(gpkg_pfad)
    for i, thema in enumerate(themen):
        kurz = katalog.eintrag(thema)["titel"].split(" (")[0]
        if fortschritt:
            fortschritt(50 + 45 * i / max(1, len(themen)), "OSM " + kurz)
        if warte:
            warte()
        sammlung = {"punkt": [], "linie": [], "flaeche": []}
        for el in je_thema[thema]:
            tags = el.get("tags") or {}
            for gtyp, geom in _geometrien(el, thema):
                if geom is None or geom.isEmpty():
                    continue
                try:
                    geom.transform(ct)
                except Exception:
                    continue
                f = QgsFeature(felder)
                f.setGeometry(geom)
                f["osm_id"] = "{}{}".format(el["type"][0], el["id"])
                f["typ"] = _typ(tags, thema)
                for t in katalog.OSM_TAGS:
                    if t in tags:
                        f[t] = str(tags[t])[:120]
                f["tags"] = json.dumps(tags, ensure_ascii=False)[:2000]
                sammlung[gtyp].append(f)
        for gtyp, wkb, kurz_g in (("punkt", "Point", "P"), ("linie", "LineString", "L"), ("flaeche", "Polygon", "F")):
            feats = sammlung[gtyp]
            if not feats:
                continue
            if gtyp == "flaeche" and any(f.geometry().isMultipart() for f in feats):
                wkb = "MultiPolygon"
                for f in feats:
                    g = f.geometry()
                    if not g.isMultipart():
                        g.convertToMultiType()
                        f.setGeometry(g)
            lname = "{}_{}".format(thema.replace("osm_", ""), kurz_g)
            mem = QgsVectorLayer("{}?crs=EPSG:3857".format(wkb), lname, "memory")
            mem.dataProvider().addAttributes(list(felder))
            mem.updateFields()
            mem.dataProvider().addFeatures(feats)
            mem.updateExtents()
            fehler = _schreiben(mem, gpkg_pfad, lname, erstes)
            erstes = False
            if fehler:
                log("OSM {}: GeoPackage nicht geschrieben ({}).".format(lname, fehler))
                continue
            ergebnis.append(dict(thema=thema, layer=lname, geom=gtyp, anzahl=len(feats)))
        n_ges = sum(len(v) for v in sammlung.values())
        if n_ges:
            log("OSM {}: {} Objekte".format(kurz, n_ges))
        else:
            # 30.09.2026 (Dornberg, Markus: "Bahnanlagen werden nicht geladen"): im Umgriff gab es keine Bahn - das sah aus wie ein Fehler
            log("OSM {}: keine Objekte im Umgriff, kein Layer angelegt.".format(kurz))
    return ergebnis


def _schreiben(layer, gpkg, lname, neu):
    opt = QgsVectorFileWriter.SaveVectorOptions()
    opt.driverName = "GPKG"
    opt.layerName = lname
    opt.fileEncoding = "UTF-8"
    opt.actionOnExistingFile = (QgsVectorFileWriter.CreateOrOverwriteFile if neu else QgsVectorFileWriter.CreateOrOverwriteLayer)
    r = QgsVectorFileWriter.writeAsVectorFormatV3(layer, gpkg, QgsProject.instance().transformContext(), opt)
    code, text = r[0], r[1]
    if code != QgsVectorFileWriter.NoError:
        return text or str(code)
    return ""


# --- Stile ---------------------------------------------------------------------------------------------------------------------------------------
STIL = {
    "osm_baeume": dict(punkt=("circle", "#2E7D32", 1.8), linie=("#2E7D32", 0.7, "dash")),
    "osm_gewaesser": dict(linie=("#1E88E5", 0.7, "solid"), flaeche=("#64B5F6", 150, "#1E88E5", 0.3, "solid")),
    "osm_schutz": dict(linie=("#2E7D32", 0.8, "dash"), flaeche=("#43A047", 255, "#2E7D32", 0.6, "b_diagonal")),
    "osm_gruen": dict(flaeche=("#A5D6A7", 90, "#81C784", 0.2, "solid"), linie=("#81C784", 0.4, "solid")),
    "osm_bahn": dict(linie=("#212121", 0.9, "dash"), flaeche=("#9E9E9E", 70, "#616161", 0.3, "solid")),
    "osm_strom": dict(punkt=("triangle", "#7B1FA2", 2.4), linie=("#AB47BC", 0.7, "solid"), flaeche=("#CE93D8", 110, "#7B1FA2", 0.4, "solid")),
    "osm_bruecken": dict(linie=("#FB8C00", 1.3, "solid"), punkt=("square", "#FB8C00", 2.0)),
}


def stil_setzen(lyr, thema, gtyp):
    s = STIL.get(thema, {}).get(gtyp)
    if not s:
        return
    if gtyp == "punkt":
        form, farbe, groesse = s
        sym = QgsMarkerSymbol.createSimple({"name": form, "color": ci.rgba(farbe), "outline_color": ci.rgba("#FFFFFF", 200),
                                            "outline_width": "0.2", "size": str(groesse)})
    elif gtyp == "linie":
        farbe, breite, linienstil = s
        sym = QgsLineSymbol.createSimple({"color": ci.rgba(farbe), "width": str(breite), "line_style": linienstil, "capstyle": "round"})
    else:
        farbe, alpha, rand, randbreite, fuellstil = s
        sym = QgsFillSymbol.createSimple({"color": ci.rgba(farbe, alpha), "outline_color": ci.rgba(rand), "outline_width": str(randbreite),
                                          "style": fuellstil})
    lyr.renderer().setSymbol(sym)
    if thema == "osm_bruecken" and gtyp == "linie":
        # Durchlaesse braun gestrichelt, Bruecken orange
        from qgis.core import QgsRuleBasedRenderer
        wurzel = QgsRuleBasedRenderer.Rule(None)
        r1 = QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": ci.rgba("#8D6E63"), "width": "0.8", "line_style": "dash"}),
                                       0, 0, '"tunnel" = \'culvert\'', "Durchlass")
        r2 = QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": ci.rgba("#FB8C00"), "width": "1.3"}), 0, 0, "ELSE", "Bruecke")
        wurzel.appendChild(r1)
        wurzel.appendChild(r2)
        lyr.setRenderer(QgsRuleBasedRenderer(wurzel))
    lyr.triggerRepaint()


# --- Layerbaum -----------------------------------------------------------------------------------------------------------------------------------
def _gruppe_leeren(name):
    wurzel = QgsProject.instance().layerTreeRoot()
    alt = wurzel.findGroup(name)
    if alt is not None:
        for l in alt.findLayers():
            QgsProject.instance().removeMapLayer(l.layerId())
        wurzel.removeChildNode(alt)


def _gruppe(name, ueber=None):
    """Gruppe neu anlegen: nach der Layerbaum-Regel (Schritt 0 unten), oder direkt ueber den Gruppen `ueber` (falls vorhanden)."""
    from ... import layerbaum
    layerbaum.leeren(name)
    wurzel = QgsProject.instance().layerTreeRoot()
    return wurzel.insertGroup(layerbaum.einfuegeindex(0, ueber), name)


def _einhaengen(gruppe, lyr, sichtbar=True):
    from ... import layerbaum
    return layerbaum.einhaengen(gruppe, lyr, "umfeld", sichtbar)


# --- Gesamtlauf ----------------------------------------------------------------------------------------------------------------------------------
def laden(iface, auswahl, land, rect3857, out_dir=None, projekt_kbs=True, log=print, fortschritt=None, warte=None, abbruch=None):
    """auswahl: Schluessel der gewaehlten Eintraege. warte/abbruch: Callbacks fuer den OSM-Abruf im Hintergrund (Dialog).
    -> dict(wms=[(titel, quelle)], fehler=[(titel, text)], osm=[...], gpkg, land)."""
    t0 = time.time()
    if fortschritt:
        fortschritt(2, "Start")
    r = dict(wms=[], fehler=[], osm=[], gpkg=None, land=land)
    projekt = QgsProject.instance()
    if projekt_kbs and projekt.crs() != KBS:
        projekt.setCrs(KBS)
        log("Projekt-KBS auf EPSG:3857 gesetzt (Plan[Goo] speichert in 3857).")

    grund = [k for k in GRUND_REIHENFOLGE if k in auswahl]
    amt = [e["schluessel"] for e in katalog.EINTRAEGE if e["gruppe"] in ("schutz", "wasser", "verkehr") and e["schluessel"] in auswahl]
    osm = [e["schluessel"] for e in katalog.EINTRAEGE if e["gruppe"] == "osm" and e["schluessel"] in auswahl]

    # Grundkarten ganz unten
    if grund:
        g = _gruppe(GRUPPE_GRUND)
        for i, k in enumerate(grund):
            e = katalog.eintrag(k)
            if fortschritt:
                fortschritt(4 + 3 * i, e["titel"][:40])
            lyr, quelle, fehler = wms_layer(e, land)
            if lyr is None:
                r["fehler"].append((e["titel"], fehler))
                log("WMS {}: {}".format(e["titel"], fehler))
                continue
            _einhaengen(g, lyr, e["sichtbar"])
            r["wms"].append((e["titel"], quelle))
            log("WMS {} ({})".format(e["titel"], quelle))
    # Umfeld amtlich darueber
    if amt:
        g = _gruppe(GRUPPE_AMT, ueber=[GRUPPE_GRUND])
        for i, k in enumerate(amt):
            e = katalog.eintrag(k)
            if fortschritt:
                fortschritt(6 + 3 * len(grund) + 2 * i, e["titel"][:40])
            lyr, quelle, fehler = wms_layer(e, land)
            if lyr is None:
                r["fehler"].append((e["titel"], fehler))
                log("WMS {}: {}".format(e["titel"], fehler))
                continue
            _einhaengen(g, lyr, e["sichtbar"])
            r["wms"].append((e["titel"], quelle))
            log("WMS {} ({})".format(e["titel"], quelle))
    # OSM darueber
    if osm:
        if rect3857 is None or rect3857.isEmpty():
            log("OSM: kein Umgriff - Kartenausschnitt oder Plan[Goo]-Projekt waehlen.")
        else:
            km2 = flaeche_km2(rect3857)
            if km2 > MAX_UMGRIFF_KM2:
                log("OSM: Umgriff {:.0f} km2 ist zu gross (max. {:.0f}) - naeher heranzoomen.".format(km2, MAX_UMGRIFF_KM2))
            else:
                out_dir = out_dir or _standard_ordner()
                os.makedirs(out_dir, exist_ok=True)
                gpkg = os.path.join(out_dir, "umfeld_osm_{}.gpkg".format(datetime.now().strftime("%Y-%m-%d_%H-%M")))
                r["osm"] = osm_laden(rect3857, osm, gpkg, log=log, fortschritt=fortschritt, warte=warte, abbruch=abbruch)
                if r["osm"]:
                    r["gpkg"] = gpkg
                    osm_layer_laden(gpkg, r["osm"])
    if fortschritt:
        fortschritt(100, "Fertig")
    log("Fertig in {:.0f} s: {} WMS-Layer, {} OSM-Layer, {} Fehler.".format(time.time() - t0, len(r["wms"]), len(r["osm"]), len(r["fehler"])))
    try:
        iface.mapCanvas().refresh()
    except Exception:
        pass
    return r


def osm_layer_laden(gpkg, eintraege=None):
    """OSM-GeoPackage (neu oder vorhanden) als Gruppe laden; eintraege optional (sonst alle Layer der Datei)."""
    if eintraege is None:
        eintraege = []
        from qgis.core import QgsProviderRegistry
        md = QgsProviderRegistry.instance().providerMetadata("ogr")
        try:
            for sub in md.querySublayers(gpkg):
                lname = sub.name()
                thema = "osm_" + lname.rsplit("_", 1)[0]
                gtyp = {"P": "punkt", "L": "linie", "F": "flaeche"}.get(lname.rsplit("_", 1)[-1], "linie")
                eintraege.append(dict(thema=thema, layer=lname, geom=gtyp, anzahl=sub.featureCount()))
        except Exception:
            return []
    name = "{} {}".format(GRUPPE_OSM, os.path.basename(gpkg).replace("umfeld_osm_", "").replace(".gpkg", ""))
    for alt in list(QgsProject.instance().layerTreeRoot().children()):
        if alt.nodeType() == alt.NodeGroup and alt.name().startswith(GRUPPE_OSM):
            _gruppe_leeren(alt.name())
    g = _gruppe(name, ueber=[GRUPPE_AMT, GRUPPE_GRUND])
    reihenfolge = {"punkt": 0, "linie": 1, "flaeche": 2}
    for e in sorted(eintraege, key=lambda x: (reihenfolge.get(x["geom"], 9), x["thema"])):
        ke = katalog.eintrag(e["thema"])
        titel = "{} ({})".format(ke["titel"].split(" (")[0] if ke else e["thema"], {"punkt": "Punkte", "linie": "Linien", "flaeche": "Flaechen"}[e["geom"]])
        lyr = QgsVectorLayer("{}|layername={}".format(gpkg, e["layer"]), titel, "ogr")
        if not lyr.isValid():
            continue
        stil_setzen(lyr, e["thema"], e["geom"])
        _einhaengen(g, lyr, ke["sichtbar"] if ke else True)
    return eintraege


def _standard_ordner():
    from ... import dateiwahl
    p = dateiwahl.projekt_gpkg()
    if p:
        return os.path.join(os.path.dirname(p), "umfeld")
    return os.path.join(os.path.expanduser("~"), "PlanGoo", "umfeld")
