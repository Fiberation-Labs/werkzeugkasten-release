# -*- coding: utf-8 -*-
"""Werkzeug 0 - Dialog "Umfeld und Grundkarten laden": Haken setzen, Land wird aus dem Kartenausschnitt erkannt, ein Knopf laedt alles
in drei Gruppen am unteren Ende des Layerbaums. WMS in EPSG:3857, OSM als GeoPackage in EPSG:3857."""
import os
import traceback

from qgis.PyQt.QtCore import QSettings, Qt
from qgis.PyQt.QtWidgets import (QFrame, QApplication, QCheckBox, QComboBox, QDialog, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                                 QProgressBar, QPushButton, QRadioButton, QTextEdit, QVBoxLayout)

from ... import ablauf, ci, dateiwahl, layerbaum
from ...dialogbasis import WerkzeugDialog
from ..adressen import alkis
from . import katalog

EINSTELLUNG_AUSWAHL = "fiberation_werkzeugkasten/umfeld/auswahl"
EINSTELLUNG_KBS = "fiberation_werkzeugkasten/umfeld/projekt_kbs"


class UmfeldDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self.haken = {}
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel("umfeld").replace("  ", " ", 1))
        self.setMinimumWidth(860)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel("umfeld"), "Amtliche Karten und Schutzgebiete als WMS, OSM-Umfeld als GeoPackage - fuer den Kartenausschnitt, in EPSG:3857.")
        lay.addWidget(self.kopf)

        z = QHBoxLayout()
        self.l_umgriff = QLabel("")
        self.l_umgriff.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        self.l_umgriff.setToolTip("Geladen wird, was der Kartenausschnitt zeigt - vorher hinzoomen. Das Land bestimmt die amtlichen Dienste.")
        z.addWidget(self.l_umgriff, 1)
        z.addWidget(QLabel("Land:"))
        self.land = QComboBox()
        self.land.addItem("automatisch", "")
        for k in sorted(alkis.LAENDER, key=lambda x: alkis.LAENDER[x]):
            self.land.addItem("{} ({})".format(alkis.LAENDER[k], k), k)
        self.land.setMinimumWidth(200)
        z.addWidget(self.land)
        lay.addLayout(z)
        self.land.currentIndexChanged.connect(lambda *_: self._land_anwenden())

        gemerkt = QSettings().value(EINSTELLUNG_AUSWAHL, None)
        gemerkt = set(gemerkt) if gemerkt else None
        for schl, titel_ in katalog.GRUPPEN:
            kopf_g = QHBoxLayout()
            kopf_g.addWidget(self._ueberschrift(titel_))
            kopf_g.addStretch(1)
            for txt, wert in (("alle", True), ("keine", False)):
                b_ = QPushButton(txt)
                b_.setFlat(True)
                b_.setCursor(Qt.PointingHandCursor)
                b_.setStyleSheet("color:{}; border:none; padding:0 6px; font-size:11px;".format(ci.ORANGE_DUNKEL))
                b_.clicked.connect(lambda *_, g=schl, w=wert: self._alle(g, w))
                kopf_g.addWidget(b_)
            lay.addLayout(kopf_g)
            g = QGridLayout()
            g.setHorizontalSpacing(14)
            g.setVerticalSpacing(2)
            eintraege = [e for e in katalog.EINTRAEGE if e["gruppe"] == schl]
            for i, e in enumerate(eintraege):
                cb = QCheckBox(e["titel"])
                cb.setChecked(e["schluessel"] in gemerkt if gemerkt is not None else e["vorgewaehlt"])
                if e["hinweis"]:
                    cb.setToolTip(e["hinweis"])
                self.haken[e["schluessel"]] = cb
                g.addWidget(cb, i // 2, i % 2)
            lay.addLayout(g)

        o = QHBoxLayout()
        self.cb_kbs = QCheckBox("Projekt-KBS auf EPSG:3857 setzen, falls abweichend")
        self.cb_kbs.setChecked(QSettings().value(EINSTELLUNG_KBS, True, type=bool))
        o.addWidget(self.cb_kbs)
        o.addSpacing(16)
        o.addWidget(QLabel("OSM-Ausgabeordner:"))
        self.out = QLineEdit()
        self.out.setPlaceholderText("leer = Ordner 'umfeld' neben dem Plan[Goo]-Projekt, sonst C:\\Users\\...\\PlanGoo\\umfeld")
        b = QPushButton("Waehlen")
        b.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        b.clicked.connect(self._out_waehlen)
        o.addWidget(self.out, 1)
        o.addWidget(b)
        lay.addLayout(o)

        k = QHBoxLayout()
        self.k_start = QPushButton("Layer laden")
        self.k_start.setStyleSheet(ci.STIL_KNOPF)
        self.k_start.setCursor(Qt.PointingHandCursor)
        self.k_start.clicked.connect(self._start)
        k.addWidget(self.k_start)
        self.k_abbruch = QPushButton("Abbrechen")
        self.k_abbruch.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_abbruch.setEnabled(False)
        self.k_abbruch.setToolTip("Laufenden OSM-Abruf abbrechen; fertige Themen bleiben erhalten.")
        self._abbruch = False
        self.k_abbruch.clicked.connect(self._abbrechen)
        k.addWidget(self.k_abbruch)
        self.k_osm = QPushButton("Vorhandenes OSM-GeoPackage laden")
        self.k_osm.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_osm.setToolTip("Frueheren OSM-Abruf ohne neuen Download in den Layerbaum holen")
        self.k_osm.clicked.connect(self._osm_laden)
        k.addWidget(self.k_osm)
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.setToolTip("Protokoll ein- und ausblenden; bei Fehlern klappt es von selbst auf")
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        k.addWidget(self.k_log)
        k.addStretch(1)
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, "umfeld"))
        k.addWidget(hilfe)
        schl_ = QPushButton("Schliessen")
        self.k_schliessen = schl_
        schl_.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl_.clicked.connect(self.close)
        k.addWidget(schl_)
        lay.addLayout(k)
        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(140)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log, 1)
        from ... import fenster
        fenster.einrichten(self, "umfeld", 860)
        self._umgriff_anzeigen()

    # --- Hilfen ------------------------------------------------------------------------------------------------------------------------
    def _alle(self, gruppe, wert):
        for e in katalog.EINTRAEGE:
            if e["gruppe"] == gruppe and self.haken[e["schluessel"]].isEnabled():
                self.haken[e["schluessel"]].setChecked(wert)

    def _out_waehlen(self):
        p = dateiwahl.ordner_waehlen(self, "OSM-Ausgabeordner waehlen", "umfeld_ordner", self.out.text())
        if p:
            self.out.setText(p)

    def _datei_fallen_gelassen(self, p):
        if p.lower().endswith(".gpkg") and "umfeld_osm" in os.path.basename(p).lower():
            self._osm_setzen(p)
            return True
        return False

    # --- Umgriff / Land --------------------------------------------------------------------------------------------------------------------
    def _umgriff(self):
        from . import kern
        return kern.umgriff_karte(self.iface), "Kartenausschnitt"

    def _umgriff_anzeigen(self):
        from . import kern
        try:
            rect, quelle = self._umgriff()
            land = self.land.currentData() or kern.land_erkennen(rect)
            km2 = kern.flaeche_km2(rect)
            txt = "Umgriff: {} ({:.1f} km2)".format(quelle, km2)
            txt += "   Land: {}".format(alkis.LAENDER.get(land, "nicht erkannt") if land else "nicht erkannt")
            if km2 > kern.MAX_UMGRIFF_KM2:
                txt += "   - fuer OSM zu gross, bitte heranzoomen"
            self.l_umgriff.setText(txt)
            self._erkanntes_land = land
        except Exception as e:
            self.l_umgriff.setText("Umgriff nicht bestimmbar: {!r}".format(e)[:160])
            self._erkanntes_land = None
        self._land_anwenden(nur_haken=True)

    def _land_anwenden(self, nur_haken=False):
        land = self.land.currentData() or getattr(self, "_erkanntes_land", None)
        for e in katalog.EINTRAEGE:
            cb = self.haken[e["schluessel"]]
            ok = e["gruppe"] == "osm" or katalog.passt_zu_land(e, land) if land else e["laender"] is None or e["gruppe"] == "osm"
            cb.setEnabled(bool(ok))
            grund = e["titel"] if ok else "{}   (nicht fuer {})".format(e["titel"], alkis.LAENDER.get(land, "dieses Land"))
            cb.setText(grund)
        if not nur_haken:
            self._umgriff_anzeigen()

    # --- Aktionen ----------------------------------------------------------------------------------------------------------------------
    def _abbrechen(self):
        self._abbruch = True
        self._log("Abbruch angefordert - laufender Abruf wird beendet ...")

    def _start(self):
        from . import kern
        self.log.clear()
        self.k_start.setEnabled(False)
        self.k_abbruch.setEnabled(True)
        self._abbruch = False
        try:
            auswahl = [k for k, cb in self.haken.items() if cb.isChecked() and cb.isEnabled()]
            QSettings().setValue(EINSTELLUNG_AUSWAHL, [k for k, cb in self.haken.items() if cb.isChecked()])
            QSettings().setValue(EINSTELLUNG_KBS, self.cb_kbs.isChecked())
            if not auswahl:
                self._log("Nichts gewaehlt.")
                return
            rect, quelle = self._umgriff()
            land = self.land.currentData() or kern.land_erkennen(rect)
            if not land:
                self._log("Land nicht erkannt - bitte oben waehlen. WMS des Landes werden uebersprungen.")
            self._log("Umgriff: {}; Land: {}".format(quelle, alkis.LAENDER.get(land, land)))
            r = kern.laden(self.iface, auswahl, land, rect, out_dir=dateiwahl.ausgabeordner(self.out.text()), projekt_kbs=self.cb_kbs.isChecked(),
                           log=self._log, fortschritt=self._fortschritt, warte=QApplication.processEvents, abbruch=lambda: self._abbruch)
            if r["gpkg"]:
                dateiwahl.merken("umfeld", r["gpkg"])
            osm_n = sum(x["anzahl"] for x in r["osm"])
            text = "{} WMS-Layer geladen.\n{} OSM-Layer mit {} Objekten.".format(len(r["wms"]), len(r["osm"]), osm_n)
            if r["gpkg"]:
                text += "\nOSM-GeoPackage: {}".format(r["gpkg"])
            if r["fehler"]:
                text += "\n\nNicht geladen:\n" + "\n".join("- {}: {}".format(t, f) for t, f in r["fehler"])
            QMessageBox.information(self, "Umfeld und Grundkarten", text)
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "Umfeld und Grundkarten - Fehler", "{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])
        finally:
            self.k_start.setEnabled(True)
            self.k_abbruch.setEnabled(False)

    def _osm_laden(self):
        p = dateiwahl.datei_waehlen(self, "OSM-GeoPackage (umfeld_osm_*.gpkg) waehlen", "GeoPackage (*.gpkg)", "umfeld")
        if p:
            self._osm_setzen(p)

    def _osm_setzen(self, gpkg):
        from . import kern
        dateiwahl.merken("umfeld", gpkg)
        eintraege = kern.osm_layer_laden(gpkg)
        self._log("OSM-GeoPackage geladen: {} ({} Layer)".format(gpkg, len(eintraege)))
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass
