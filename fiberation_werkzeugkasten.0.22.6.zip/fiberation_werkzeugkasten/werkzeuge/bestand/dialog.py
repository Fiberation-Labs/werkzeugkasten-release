# -*- coding: utf-8 -*-
"""Werkzeug 1 - Dialog "Bestand aus Telekom-Lieferung": Quelle (Extern-Export, Plan[Goo]-Projekt, MegaPlan-Rohranlage, Comsof-Rohrliste) waehlen, Bestand aufbereiten, Layer mit Stil laden, Tabelle der
Kennzahlen (Doppelklick zoomt auf die Gruppe), Bericht. Gleicher Aufbau wie die anderen Schritte (Kopf, Block, Knopfzeile, Balken,
Tabelle, Protokoll eingeklappt)."""
import json
import os
import traceback

from qgis.core import (QgsCategorizedSymbolRenderer, QgsCoordinateReferenceSystem, QgsLineSymbol, QgsMarkerSymbol, QgsProject,
                       QgsRendererCategory, QgsVectorLayer)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QDialog, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                                 QMessageBox, QProgressBar, QPushButton, QRadioButton, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout)

from ... import ablauf, ci, dateiwahl, layerbaum, tabelle
from ...dialogbasis import WerkzeugDialog
from ...dateiwahl import DateiFeld

GRUEN = "#2E8B57"
BLAU = "#1E6FB0"
ROT_DUNKEL = "#8E2A2A"
LAYER_TITEL = {"bestand_rohre": "Bestandsrohre", "bestand_rohrzuege": "Bestandsrohre als Rohrzuege", "bestand_apl": "Versorgte Adressen (APL)", "bestand_kabel": "Bestandskabel", "bestand_anschluss": "Anschlussstuecke Schacht-Rohr",
               "bestand_punkte": "Bestandspunkte (Schaechte, Masten, KVz)", "bestand_muffen": "Bestandsmuffen",
               "bestand_hauptkabel": "Vorhandene Hauptkabel im Plan", "hvt": "HVt", "bestand_trassen": "Telekom-Trassen (MegaPlan, Verlegeart)"}
QUELL_FILTER = "Bestandsquellen (*.gpkg *.shp *.zip);;GeoPackage (*.gpkg);;Shapefile (*.shp);;Zip mit Shapefile (*.zip)"
ROHRLISTE_FILTER = "Comsof-Rohrliste (*.shp *.zip *.gpkg)"


class BestandDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self.ergebnis = None
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel("bestand").replace("  ", " ", 1))
        self.setMinimumWidth(860)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel("bestand"),
                                   "Telekom-Bestand zeigen und aufbereiten: Rohre mit Kapazitaet, Kabel, Schaechte, Masten und Trassen mit Verlegeart - aus dem "
                                   "Comsof-Extern-Export (*_extern.gpkg), einem Plan[Goo]-Projekt, dem MegaPlan-Export 'Rohranlage' (Trassennetz) oder der "
                                   "Comsof-Rohrliste IN_ExistingPipes (Shape/Zip).")
        lay.addWidget(self.kopf)

        lay.addWidget(self._ueberschrift("Quelle"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(6)
        g.addWidget(QLabel("Bestand aus:"), 0, 0)
        q = QHBoxLayout()
        self.r_goo = QRadioButton("offenes Plan[Goo]-Projekt")
        self.r_goo.setToolTip("Bestand = Objekte mit Kennzeichen 'extern' (Megaplan-As-built-Import) im gerade geoeffneten Projekt")
        self.r_datei = QRadioButton("Datei:")
        q.addWidget(self.r_goo)
        q.addWidget(self.r_datei)
        self.f_quelle = DateiFeld("plangoo", "Extern-Export (*_extern.gpkg), Plan[Goo]-GeoPackage (.db daneben), MegaPlan-Export Rohranlage (.gpkg) oder "
                                  "Comsof-Rohrliste IN_ExistingPipes (.shp/.zip) hineinziehen oder waehlen ...",
                                  QUELL_FILTER, "Bestandsquelle waehlen", ci.STIL_KNOPF_ZWEIT)
        q.addWidget(self.f_quelle, 1)
        g.addLayout(q, 0, 1, 1, 5)
        if dateiwahl.projekt_gpkg():
            self.r_goo.setChecked(True)
        else:
            self.r_datei.setChecked(True)
        self.f_quelle.setEnabled(self.r_datei.isChecked())
        self.r_datei.toggled.connect(self.f_quelle.setEnabled)
        lab_rohre = QLabel("Rohrliste dazu:")
        lab_rohre.setToolTip("Nur fuer den MegaPlan-Export Rohranlage: die Comsof-Rohrliste IN_ExistingPipes (Shape oder Zip) derselben Lieferung. "
                             "Dann bekommen die Rohrtrassen 'Rohr in Rohrliste' ja/nein und die Rohre ihre MegaPlan-Trasse.")
        g.addWidget(lab_rohre, 1, 0)
        self.f_rohre = DateiFeld("comsof_in", "optional, nur beim MegaPlan-Export: IN_ExistingPipes.shp oder .zip derselben Lieferung - Trassen bekommen 'Rohr in Rohrliste' ja/nein",
                                 ROHRLISTE_FILTER, "Comsof-Rohrliste IN_ExistingPipes waehlen", ci.STIL_KNOPF_ZWEIT, vorbelegen=False)
        self.f_rohre.setToolTip(lab_rohre.toolTip())
        g.addWidget(self.f_rohre, 1, 1, 1, 5)
        self.f_rohre.setEnabled(self.r_datei.isChecked())
        self.r_datei.toggled.connect(self.f_rohre.setEnabled)
        g.addWidget(QLabel("Bestand ist:"), 2, 0)
        b = QHBoxLayout()
        b.setSpacing(12)
        self.r_kennz = QRadioButton("nur Objekte mit Bestandskennzeichen")
        self.r_kennz.setToolTip("Plan[Goo]: Trassen, Rohre und Punkte aus dem Megaplan-As-built-Import (Kennzeichen extern). FPF-Export: EXISTING*-Objekte.")
        self.r_alles = QRadioButton("das ganze Projekt (gebautes Netz)")
        self.r_alles.setToolTip("Nur Plan[Goo]: ein fertig gebautes Netz liegt als Projekt vor - alle Trassen, Hauptrohre, NVT, Schaechte, Muffen, "
                                "Hausuebergabepunkte und die versorgten APL (Ausbauzustand) gelten als Bestand.")
        self.r_kennz.setChecked(True)
        b.addWidget(self.r_kennz)
        b.addWidget(self.r_alles)
        b.addStretch(1)
        g.addLayout(b, 2, 1, 1, 5)
        g.addWidget(QLabel("Mitnehmen:"), 3, 0)
        h = QHBoxLayout()
        h.setSpacing(12)
        self.c_kabel = QCheckBox("Bestandskabel (Kabellinien, freie Fasern)")
        self.c_kabel.setChecked(True)
        self.c_kabel.setToolTip("Nur im FPF-Extern-Export enthalten - Plan[Goo] fuehrt keine Kabel als Objekte")
        self.c_punkte = QCheckBox("Schaechte, Masten, KVz, Muffen")
        self.c_punkte.setChecked(True)
        self.c_anschluss = QCheckBox("Anschlussstuecke Schacht-Rohr")
        self.c_anschluss.setToolTip("Nur FPF-Extern-Export: kurze Verbindungsstuecke (0-30 m) zwischen Schacht und Rohr - tragen nur die Topologie, meist nicht noetig")
        for c in (self.c_kabel, self.c_punkte, self.c_anschluss):
            h.addWidget(c)
        h.addStretch(1)
        g.addLayout(h, 3, 1, 1, 5)
        g.addWidget(QLabel("Ausgabeordner:"), 4, 0)
        self.out = QLineEdit()
        self.out.setPlaceholderText("leer = neben der Quelle; bei zu langem Pfad (Windows 259 Zeichen) unter C:\\Users\\<Name>\\PlanGoo\\Werkzeugkasten")
        g.addWidget(self.out, 4, 1, 1, 4)
        o = QPushButton("Waehlen")
        o.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        o.clicked.connect(self._out_waehlen)
        g.addWidget(o, 4, 5)
        g.setColumnStretch(1, 1)
        lay.addLayout(g)

        k = QHBoxLayout()
        self.k_start = QPushButton("Bestand aufbereiten")
        self.k_start.setStyleSheet(ci.STIL_KNOPF)
        self.k_start.setCursor(Qt.PointingHandCursor)
        self.k_start.clicked.connect(self._start)
        self.k_laden = dateiwahl.ErgebnisKnopf("bestand", self._ergebnis_setzen, "Bestand (GeoPackage) waehlen", stil=ci.STIL_KNOPF_ZWEIT)
        self.k_bericht = QPushButton("Bericht oeffnen")
        self.k_bericht.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_bericht.setEnabled(False)
        self.k_bericht.clicked.connect(lambda: self._oeffnen(self.ergebnis and self.ergebnis.get("bericht")))
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.setToolTip("Protokoll ein- und ausblenden; bei Fehlern klappt es von selbst auf")
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        for b in (self.k_start, self.k_laden, self.k_bericht, self.k_log):
            k.addWidget(b)
        k.addStretch(1)
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, "bestand"))
        k.addWidget(hilfe)
        schl = QPushButton("Schliessen")
        self.k_schliessen = schl
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.close)
        k.addWidget(schl)
        lay.addLayout(k)
        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)

        lay.addWidget(self._ueberschrift("Bestand im Ueberblick"))
        self.lab_summe = QLabel("Noch kein Bestand geladen.")
        self.lab_summe.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        self.lab_summe.setWordWrap(True)
        lay.addWidget(self.lab_summe)
        self.tabelle = tabelle.Tabelle("bestand_kennzahlen", ["Gruppe", "Art", "Anzahl", "Laenge km", "genutzt km", "frei"], self.iface)
        self.tabelle.layer_finder(self._layer)
        self.tabelle.setMinimumHeight(240)
        self.tabelle.setToolTip("Doppelklick: die Stuecke dieser Zeile im Kartenfenster waehlen und darauf zoomen")
        self.tabelle.itemDoubleClicked.connect(self._zeile_zoomen)
        lay.addWidget(self.tabelle, 1)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(140)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log)
        self.setAcceptDrops(True)
        from ... import fenster
        fenster.einrichten(self, "bestand", 860)

    # --- Hilfen ------------------------------------------------------------------------------------------------------------------------
    def _out_waehlen(self):
        p = dateiwahl.ordner_waehlen(self, "Ausgabeordner waehlen", "ausgabe", self.out.text())
        if p:
            self.out.setText(p)

    def _datei_fallen_gelassen(self, p):
        from . import kern
        if not p.lower().endswith((".gpkg", ".shp", ".zip")):
            return False
        if os.path.basename(p).lower().startswith("bestand_") and p.lower().endswith(".gpkg"):
            self._ergebnis_setzen(p)
            return True
        self.r_datei.setChecked(True)
        art = kern.quelle_art(p)
        quelle_art = kern.quelle_art(self.f_quelle.text()) if self.f_quelle.text() else None
        if art == "comsof_in" and quelle_art == "megaplan":
            self.f_rohre.setText(p)          # Rohrliste zum schon gewaehlten MegaPlan-Export
        else:
            self.f_quelle.setText(p)
        self._log("Art: {}".format(kern.QUELLE_TEXT.get(art, "Art unbekannt")))
        return True

    # --- Aktionen ----------------------------------------------------------------------------------------------------------------------
    def _start(self):
        from . import kern
        self.log.clear()
        self.k_start.setEnabled(False)
        try:
            if self.r_goo.isChecked():
                quelle = dateiwahl.projekt_gpkg()
                if not quelle:
                    self.k_log.setChecked(True)
                    self._log("Kein Plan[Goo]-Projekt geoeffnet - Datei waehlen oder hineinziehen.")
                    QMessageBox.information(self, "Bestand", "Es ist kein Plan[Goo]-Projekt geoeffnet. Bitte 'Datei' waehlen.")
                    return
            else:
                quelle = self.f_quelle.text()
                if not quelle or not os.path.exists(quelle):
                    self.k_log.setChecked(True)
                    self._log("Quelle nicht gefunden - Datei waehlen oder hineinziehen.")
                    return
            art = kern.quelle_art(quelle)
            if art is None:
                from . import plangoo as pg
                self.k_log.setChecked(True)
                self._log("Keine bekannte Bestandsquelle: " + quelle)
                if os.path.basename(quelle).lower().startswith("plgov2") and not os.path.exists(pg.db_pfad(quelle)):
                    QMessageBox.warning(self, "Bestand", "Das Plan[Goo]-GeoPackage braucht seine Datenbank daneben:\n{}\n\nBitte den ganzen Projektordner "
                                        "(GeoPackage + .db) verwenden, z. B. das entpackte Backup.".format(os.path.basename(pg.db_pfad(quelle))))
                else:
                    QMessageBox.warning(self, "Bestand", "Die Datei ist keine bekannte Bestandsquelle. Erwartet wird eine von vier:\n"
                                        "- FPF-Extern-Export <Workspace>_extern.gpkg (Comsof-Layer 'Verwendbare Trassen')\n"
                                        "- Plan[Goo]-Projekt PlGoV2_..._.gpkg mit gleichnamiger .db daneben\n"
                                        "- MegaPlan-Export Rohranlage (.gpkg mit UNDERGROUND_ROUTE_TYPE / INSTALLATION_TYPE)\n"
                                        "- Comsof-Rohrliste IN_ExistingPipes (.shp oder .zip mit DUCT_CLASS / MAX_DUCTS)")
                return
            self._log("Quelle erkannt: {}".format(kern.QUELLE_TEXT.get(art, art)))
            dateiwahl.merken({"fpf": "comsof", "plangoo": "plangoo", "megaplan": "megaplan", "comsof_in": "comsof_in"}[art], quelle)
            if art == "fpf" and self.r_alles.isChecked():
                self._log("Hinweis: 'ganzes Projekt' gilt nur fuer Plan[Goo]-Projekte - beim FPF-Export zaehlen die EXISTING-Kennzeichen.")
            rohre_pfad = self.f_rohre.text() if self.r_datei.isChecked() else ""
            if rohre_pfad and art != "megaplan":
                self._log("Hinweis: 'Rohrliste dazu' wird nur beim MegaPlan-Export Rohranlage benutzt - hier ignoriert.")
                rohre_pfad = ""
            if rohre_pfad:
                if not os.path.exists(rohre_pfad):
                    self._log("Rohrliste nicht gefunden, ohne Rohrliste weiter: " + rohre_pfad)
                    rohre_pfad = ""
                elif kern.quelle_art(rohre_pfad) != "comsof_in":
                    self._log("Rohrliste ist keine Comsof-Rohrliste (IN_ExistingPipes), ohne Rohrliste weiter: " + rohre_pfad)
                    rohre_pfad = ""
                else:
                    dateiwahl.merken("comsof_in", rohre_pfad)
            r = kern.aufbereiten(quelle, out_dir=dateiwahl.ausgabeordner(self.out.text()), log=self._log, fortschritt=self._fortschritt,
                                 mit_kabeln=self.c_kabel.isChecked(), mit_punkten=self.c_punkte.isChecked(), mit_anschluss=self.c_anschluss.isChecked(),
                                 alles=self.r_alles.isChecked(), rohre_pfad=rohre_pfad or None)
            dateiwahl.merken("bestand", r["gpkg"])
            self.ergebnis = r
            self.k_bericht.setEnabled(True)
            self._tabelle_fuellen(r["kennzahlen"])
            self._layer_laden(r["gpkg"], r["stamm"])
            n = r["netz"]
            if r.get("quelle_art") == "megaplan":
                ohne = r.get("rohrtrassen_ohne_rohr_km")
                text = ("Telekom-Trassen (MegaPlan Rohranlage): {} Stuecke, {} km\n- Rohrtrassen (Rohr vorhanden): {} km\n- erdverlegte Kabel (kein Rohr): {} km\n"
                        "{}Rohrtrassen-Netz: {} Teile, groesstes {} % der Laenge\n\n"
                        "Dieser Export kennt nur Trassen und Verlegeart - keine Rohrklasse, keine freien Rohre, keine Schaechte. "
                        "{}\n\nLayer sind geladen, Kennzahlen in der Tabelle, Bericht ueber den Knopf.\nAusgabe: {}").format(
                            r["trassen"], r["trassen_km"], r["rohrtrassen_km"], r["erdverlegt_km"],
                            "- Rohre aus der Rohrliste: {} Stuecke, {} km; Rohrtrassen OHNE Rohr in der Rohrliste: {} km (orange)\n".format(
                                r["rohre"], r["rohre_km"], ohne) if ohne is not None else "",
                            n.get("komponenten", 0), n.get("groesste_anteil", 0),
                            "Rohre kamen aus der Rohrliste dazu." if ohne is not None else "Fuer Rohre die Comsof-Rohrliste IN_ExistingPipes unter 'Rohrliste dazu' angeben.",
                            r["gpkg"])
            elif r.get("quelle_art") == "comsof_in":
                text = ("Comsof-Rohrliste IN_ExistingPipes: {} Rohre, {} km (Rohr einziehbar {} km, nur Kabel einblasen {} km)\n"
                        "Rohrnetz: {} Teile, groesstes {} % der Laenge\n\nKeine Schaechte, Kabel oder Nutzung im Plan: die Rohrliste ist die Comsof-EINGABE, "
                        "nicht der Extern-Export. Wo Telekom sonst noch im Boden liegt (erdverlegte Kabel), zeigt der MegaPlan-Export Rohranlage.\n\n"
                        "Layer sind geladen, Kennzahlen in der Tabelle, Bericht ueber den Knopf.\nAusgabe: {}").format(
                            r["rohre"], r["rohre_km"],
                            sum(z["laenge_km"] for z in r["kennzahlen"]["zeilen"] if z["gruppe"] == "Nutzbarkeit" and z["art"] == kern.NUTZBAR_ROHR),
                            sum(z["laenge_km"] for z in r["kennzahlen"]["zeilen"] if z["gruppe"] == "Nutzbarkeit" and z["art"] == kern.NUTZBAR_KABEL),
                            n.get("komponenten", 0), n.get("groesste_anteil", 0), r["gpkg"])
            elif r.get("quelle_art") == "plangoo" and r.get("alles"):
                text = ("Ganzes Projekt als Bestand:\nTrassen: {} Stuecke, {} km\nHauptrohre als Rohrzuege: {}\nBauwerke (NVT, Schaechte, Muffen, KUEG, HUeP): {}\n"
                        "Versorgte Adressen (APL): {}\nRohrnetz: {} Teile, groesstes {} % der Laenge\n\nLayer sind geladen, Kennzahlen in der Tabelle, "
                        "Bericht ueber den Knopf.\nAusgabe: {}").format(r["rohre"], r["rohre_km"], r.get("rohrzuege", 0), r["punkte"], r.get("apl", 0),
                                                                      n.get("komponenten", 0), n.get("groesste_anteil", 0), r["gpkg"])
            elif r.get("quelle_art") == "plangoo":
                text = ("Bestandstrassen: {} Stuecke, {} km (davon {} km mit neuem Rohr)\nBestandsrohre als Rohrzuege: {} (davon {} mit neuem Innenrohr)\n"
                        "Bestandspunkte: {}\nRohrnetz: {} Teile, groesstes {} % der Laenge\n\nKeine Kabel: Plan[Goo] fuehrt keine Kabel als Objekte.\n"
                        "Layer sind geladen, Kennzahlen in der Tabelle, Bericht ueber den Knopf.\nAusgabe: {}").format(
                            r["rohre"], r["rohre_km"], r["kennzahlen"]["summe"]["rohre_genutzt_km"], r.get("rohrzuege", 0),
                            r["kennzahlen"]["summe"].get("rohrzuege_genutzt", 0), r["punkte"], n.get("komponenten", 0), n.get("groesste_anteil", 0), r["gpkg"])
            else:
                text = ("Bestandsrohre: {} Stuecke, {} km (davon {} km im Comsof-Plan genutzt)\nBestandskabel: {} Stuecke, {} km\n"
                        "Bestandspunkte: {}, Muffen: {}, vorhandene Hauptkabel: {}\nRohrnetz: {} Teile, groesstes {} % der Laenge\n\n"
                        "Layer sind geladen, Kennzahlen in der Tabelle, Bericht ueber den Knopf.").format(
                            r["rohre"], r["rohre_km"], r["kennzahlen"]["summe"]["rohre_genutzt_km"], r["kabel"], r["kabel_km"],
                            r["punkte"], r["muffen"], r["hauptkabel"], n.get("komponenten", 0), n.get("groesste_anteil", 0))
            QMessageBox.information(self, "Bestand", text)
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "Bestand aus Telekom-Lieferung - Fehler", "{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])
        finally:
            self.k_start.setEnabled(True)

    def _ergebnis_setzen(self, gpkg):
        from . import kern
        dateiwahl.merken("bestand", gpkg)
        basis = os.path.splitext(gpkg)[0]
        self.ergebnis = {"gpkg": gpkg, "bericht": basis + "_bericht.md", "liste": basis + "_liste.json"}
        self.k_bericht.setEnabled(os.path.exists(self.ergebnis["bericht"]))
        st = os.path.basename(basis).replace("bestand_", "")
        try:
            with open(self.ergebnis["liste"], encoding="utf-8") as fh:
                daten = json.load(fh)
            st = daten.get("stamm", st)
            self._tabelle_fuellen(daten)
        except Exception as e:
            self._log("Liste nicht gelesen ({!r}) - Tabelle bleibt leer.".format(e))
        self._layer_laden(gpkg, st)
        self._log("Ergebnis geladen: " + gpkg)

    # --- Tabelle -----------------------------------------------------------------------------------------------------------------------
    def _tabelle_fuellen(self, daten):
        zeilen = daten.get("zeilen", [])
        su = daten.get("summe", {})
        netz = daten.get("netz", {})
        if su.get("quelle_art") == "megaplan":
            self.lab_summe.setText("MegaPlan Rohranlage: Telekom-Trassen {} Stuecke / {} km | Rohrtrassen {} km | erdverlegte Kabel {} km{} | "
                                   "Rohrtrassen-Netz {} Teile, groesstes {} % der Laenge".format(
                                       su.get("trassen", 0), su.get("trassen_km", 0), su.get("rohrtrassen_km", 0), su.get("erdverlegt_km", 0),
                                       " | Rohre aus Rohrliste {} / {} km, Rohrtrassen ohne Rohr in der Liste {} km".format(
                                           su.get("rohre", 0), su.get("rohre_km", 0), su.get("rohrtrassen_ohne_rohr_km", 0)) if "rohrtrassen_ohne_rohr_km" in su else "",
                                       netz.get("komponenten", 0), netz.get("groesste_anteil", 0)))
        elif su.get("quelle_art") == "comsof_in":
            self.lab_summe.setText("Comsof-Rohrliste IN_ExistingPipes: Rohre {} Stuecke / {} km (ohne Nutzung im Plan, ohne Punkte) | "
                                   "Rohrnetz {} Teile, groesstes {} % der Laenge".format(su.get("rohre", 0), su.get("rohre_km", 0),
                                                                                          netz.get("komponenten", 0), netz.get("groesste_anteil", 0)))
        elif su.get("alles"):
            self.lab_summe.setText("Plan[Goo], ganzes Projekt als Bestand: Trassen {} Stuecke / {} km | Hauptrohre als Rohrzuege {} | Bauwerke {} | "
                                   "versorgte Adressen {} | Rohrnetz {} Teile, groesstes {} % der Laenge".format(
                                       su.get("rohre", 0), su.get("rohre_km", 0), su.get("rohrzuege", 0), su.get("punkte", 0), su.get("apl", 0),
                                       netz.get("komponenten", 0), netz.get("groesste_anteil", 0)))
        elif "rohrzuege" in su:
            self.lab_summe.setText("Plan[Goo]: Bestandstrassen {} Stuecke / {} km (mit neuem Rohr {} km) | Bestandsrohre als Rohrzuege {} (mit neuem Innenrohr {}) | "
                                   "Punkte {} (angeschlossen {}) | Rohrnetz {} Teile, groesstes {} % der Laenge".format(
                                       su.get("rohre", 0), su.get("rohre_km", 0), su.get("rohre_genutzt_km", 0), su.get("rohrzuege", 0),
                                       su.get("rohrzuege_genutzt", 0), su.get("punkte", 0), su.get("punkte_genutzt", 0),
                                       netz.get("komponenten", 0), netz.get("groesste_anteil", 0)))
        else:
            self.lab_summe.setText("Rohre {} Stuecke / {} km (genutzt {} km) | Kabel {} Stuecke / {} km (genutzt {} km) | Punkte {} (genutzt {}) | "
                                   "Muffen {} | Hauptkabel {} | Rohrnetz {} Teile, groesstes {} % der Laenge".format(
                                       su.get("rohre", 0), su.get("rohre_km", 0), su.get("rohre_genutzt_km", 0), su.get("kabel", 0), su.get("kabel_km", 0),
                                       su.get("kabel_genutzt_km", 0), su.get("punkte", 0), su.get("punkte_genutzt", 0), su.get("muffen", 0),
                                       su.get("hauptkabel", 0), netz.get("komponenten", 0), netz.get("groesste_anteil", 0)))
        self.tabelle.setRowCount(0)
        reihenfolge = {"Trassen": 0, "Trassenart": 1, "Rohre": 2, "Rohrzuege": 3, "Nutzbarkeit": 4, "Buendel": 5, "Kabel": 6, "Punkte": 7, "Adressen": 8, "Hauptkabel": 9}
        for z in sorted(zeilen, key=lambda x: (reihenfolge.get(x["gruppe"], 9), -(x["laenge_km"] or 0), x["art"])):
            i = self.tabelle.rowCount()
            self.tabelle.insertRow(i)
            werte = [z["gruppe"], z["art"], z["anzahl"], z["laenge_km"] if z["laenge_km"] is not None else "",
                     z["genutzt_km"] if z["genutzt_km"] is not None else "", z.get("frei") or ""]
            for j, w in enumerate(werte):
                it = QTableWidgetItem(str(w))
                if j in (2, 3, 4):
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                it.setData(Qt.UserRole, json.dumps({"layer": z.get("layer"), "feld": z.get("feld"), "wert": z["art"]}))
                self.tabelle.setItem(i, j, it)
            if z.get("layer") and z.get("feld"):
                self.tabelle.karte_setzen(i, bezug=(z["layer"], {z["feld"]: str(z["art"])}))
        self.tabelle.resizeColumnsToContents()
        self.tabelle.fertig()

    def _zeile_zoomen(self, item):
        try:
            d = json.loads(self.tabelle.item(item.row(), 0).data(Qt.UserRole))
        except Exception:
            return
        lyr = self._layer(d.get("layer"))
        if lyr is None:
            self._log("Layer {} ist nicht geladen.".format(d.get("layer")))
            return
        if d.get("feld"):
            lyr.selectByExpression("\"{}\" = '{}'".format(d["feld"], str(d["wert"]).replace("'", "''")))
        else:
            lyr.selectAll()
        try:
            self.iface.setActiveLayer(lyr)
            self.iface.mapCanvas().zoomToSelected(lyr)
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    # --- Layer -------------------------------------------------------------------------------------------------------------------------
    def _gruppenname(self):
        return layerbaum.gruppenname("bestand", "Bestand {}".format((self.ergebnis or {}).get("stamm") or ""))

    def _layer(self, name):
        return layerbaum.layer_aus_gpkg((self.ergebnis or {}).get("gpkg"), name)

    def _layer_laden(self, gpkg, st):
        self.ergebnis = dict(self.ergebnis or {}, gpkg=gpkg, stamm=st)
        gruppe = layerbaum.gruppe("bestand", "Bestand {}".format(st))
        for lname in ("hvt", "bestand_punkte", "bestand_muffen", "bestand_apl", "bestand_hauptkabel", "bestand_kabel", "bestand_rohre", "bestand_rohrzuege", "bestand_anschluss",
                      "bestand_trassen"):
            lyr = QgsVectorLayer("{}|layername={}".format(gpkg, lname), LAYER_TITEL.get(lname, lname), "ogr")
            if not lyr.isValid():
                continue
            lyr.setCrs(QgsCoordinateReferenceSystem("EPSG:25832"))
            self._stil(lyr, lname)
            layerbaum.einhaengen(gruppe, lyr, "bestand", sichtbar=lname not in ("bestand_anschluss", "bestand_muffen", "bestand_rohrzuege"))
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def _stil(self, lyr, lname):
        from . import kern
        if lname == "bestand_rohre":
            kats = [QgsRendererCategory(kern.NUTZBAR_ROHR, QgsLineSymbol.createSimple({"color": GRUEN, "width": "0.7"}), "Rohr einziehbar (freie Rohre)"),
                    QgsRendererCategory(kern.NUTZBAR_KABEL, QgsLineSymbol.createSimple({"color": BLAU, "width": "0.5"}), "nur Kabel einblasen (Speednet 8 mm)"),
                    QgsRendererCategory(kern.NUTZBAR_UNBEKANNT, QgsLineSymbol.createSimple({"color": ci.GRAU, "width": "0.5", "line_style": "dash"}), "Kapazitaet unbekannt"),
                    QgsRendererCategory(kern.NUTZBAR_VOLL, QgsLineSymbol.createSimple({"color": ROT_DUNKEL, "width": "0.5"}), "kein freies Rohr")]
            lyr.setRenderer(QgsCategorizedSymbolRenderer("nutzbarkeit", kats))
            ci.label_kasten(lyr, "concat(\"rohrklasse\", if(\"freie_rohre\" is null, '', ' | ' || \"freie_rohre\" || ' frei'), if(\"genutzt\" = 1, ' | im Plan', ''))",
                            groesse=6.5, rahmen=GRUEN, min_massstab=1500)
        elif lname == "bestand_rohrzuege":
            kats = [QgsRendererCategory(kern.NUTZBAR_ROHR, QgsLineSymbol.createSimple({"color": GRUEN, "width": "1.6"}), "Rohr einziehbar"),
                    QgsRendererCategory(kern.NUTZBAR_KABEL, QgsLineSymbol.createSimple({"color": BLAU, "width": "1.4"}), "nur Kabel einblasen"),
                    QgsRendererCategory(kern.NUTZBAR_UNBEKANNT, QgsLineSymbol.createSimple({"color": ci.GRAU, "width": "1.4", "line_style": "dash"}), "Kapazitaet unbekannt")]
            lyr.setRenderer(QgsCategorizedSymbolRenderer("nutzbarkeit", kats))
            lyr.setOpacity(0.6)
            ci.label_kasten(lyr, "concat(\"rohrklasse\", if(\"mp_id\" is null, '', ' | MP ' || \"mp_id\"), if(\"genutzt\" = 1, ' | Innenrohr neu', ''))",
                            groesse=6.5, rahmen=GRUEN, min_massstab=3000)
        elif lname == "bestand_trassen":
            from . import telekom
            kats = [QgsRendererCategory(telekom.VERLEGEART["Rohrverlegt"], QgsLineSymbol.createSimple({"color": GRUEN, "width": "1.1"}), "Rohrtrasse (Rohr vorhanden)"),
                    QgsRendererCategory(telekom.BESTANDSART_MIT_ROHR, QgsLineSymbol.createSimple({"color": GRUEN, "width": "1.1"}), "Rohrtrasse, Rohr in Rohrliste"),
                    QgsRendererCategory(telekom.BESTANDSART_OHNE_ROHR, QgsLineSymbol.createSimple({"color": ci.ORANGE, "width": "1.3"}), "Rohrtrasse, KEIN Rohr in Rohrliste (klaeren)"),
                    QgsRendererCategory(telekom.VERLEGEART["Erdverlegt"], QgsLineSymbol.createSimple({"color": ROT_DUNKEL, "width": "0.6"}), "erdverlegtes Kabel (kein Rohr)"),
                    QgsRendererCategory(telekom.VERLEGEART["Im Haus"], QgsLineSymbol.createSimple({"color": ci.GRAU, "width": "0.4", "line_style": "dot"}), "Hauseinfuehrung"),
                    QgsRendererCategory("Sonderbau (Spuelbohrung)", QgsLineSymbol.createSimple({"color": BLAU, "width": "1.1", "line_style": "dash"}), "Spuelbohrung"),
                    QgsRendererCategory("Sonderbau (Bodenverdraengung)", QgsLineSymbol.createSimple({"color": BLAU, "width": "1.1", "line_style": "dash dot"}), "Bodenverdraengung"),
                    QgsRendererCategory("", QgsLineSymbol.createSimple({"color": ci.GRAU, "width": "0.5", "line_style": "dash"}), "sonstige / unbekannt")]
            lyr.setRenderer(QgsCategorizedSymbolRenderer("bestandsart", kats))
            lyr.setOpacity(0.85)
            ci.label_kasten(lyr, "concat(\"verlegeart\", if(\"verlegetiefe_cm\" is null, '', ' | ' || \"verlegetiefe_cm\" || ' cm'), if(\"mp_id\" is null, '', ' | MP ' || \"mp_id\"))",
                            groesse=6.5, rahmen=GRUEN, min_massstab=1500)
        elif lname == "bestand_kabel":
            lyr.renderer().setSymbol(QgsLineSymbol.createSimple({"color": ROT_DUNKEL, "width": "0.4", "line_style": "dash"}))
            ci.label_kasten(lyr, "concat(coalesce(\"kabellinie\", ''), if(\"freie_fasern\" is null, '', ' | ' || \"freie_fasern\" || ' F frei'))",
                            groesse=6.5, rahmen=ROT_DUNKEL, min_massstab=1500)
        elif lname == "bestand_hauptkabel":
            lyr.renderer().setSymbol(QgsLineSymbol.createSimple({"color": "#1A1A1A", "width": "1.1"}))
        elif lname == "bestand_anschluss":
            lyr.renderer().setSymbol(QgsLineSymbol.createSimple({"color": ci.GRAU, "width": "0.3", "line_style": "dot"}))
        elif lname == "bestand_punkte":
            kats = [QgsRendererCategory("Kabelschacht (Zugschacht)", QgsMarkerSymbol.createSimple({"name": "square", "color": "#FFFFFF", "outline_color": "#1A1A1A", "size": "2.4"}), "Kabelschacht (Zugschacht)"),
                    QgsRendererCategory("Kabelschacht", QgsMarkerSymbol.createSimple({"name": "square", "color": "#FFFFFF", "outline_color": "#1A1A1A", "size": "2.6"}), "Kabelschacht"),
                    QgsRendererCategory("Kabel-Uebergabegestell", QgsMarkerSymbol.createSimple({"name": "pentagon", "color": ci.ORANGE, "outline_color": "#1A1A1A", "size": "3.2"}), "Kabel-Uebergabegestell"),
                    QgsRendererCategory("Rohrende (Bestandsrohr)", QgsMarkerSymbol.createSimple({"name": "circle", "color": GRUEN, "outline_color": GRUEN, "size": "1.4"}), "Rohrende (Bestandsrohr)"),
                    QgsRendererCategory("NVt Bestand", ci.nvt_symbol("#1A1A1A", 4.5), "NVt Bestand"),
                    QgsRendererCategory("Muffe", QgsMarkerSymbol.createSimple({"name": "diamond", "color": ROT_DUNKEL, "outline_color": ROT_DUNKEL, "size": "2.6"}), "Muffe"),
                    QgsRendererCategory("Hausuebergabepunkt", QgsMarkerSymbol.createSimple({"name": "triangle", "color": "#FFFFFF", "outline_color": ci.GRAU, "size": "1.8"}), "Hausuebergabepunkt"),
                    QgsRendererCategory("Betriebsstelle", QgsMarkerSymbol.createSimple({"name": "star", "color": ci.ORANGE, "outline_color": "#1A1A1A", "size": "5"}), "Betriebsstelle"),
                    QgsRendererCategory("Kabelschacht (begehbar)", QgsMarkerSymbol.createSimple({"name": "square", "color": "#1A1A1A", "outline_color": "#1A1A1A", "size": "3.0"}), "Kabelschacht (begehbar)"),
                    QgsRendererCategory("Mast (Freileitung)", QgsMarkerSymbol.createSimple({"name": "circle", "color": "#FFFFFF", "outline_color": ROT_DUNKEL, "outline_width": "0.5", "size": "2.4"}), "Mast (Freileitung)"),
                    QgsRendererCategory("KVz / NVt Bestand", ci.nvt_symbol("#1A1A1A", 4.5), "KVz / NVt Bestand"),
                    QgsRendererCategory("HVt / Betriebsstelle", QgsMarkerSymbol.createSimple({"name": "star", "color": ci.ORANGE, "outline_color": "#1A1A1A", "size": "5"}), "HVt / Betriebsstelle"),
                    QgsRendererCategory("", QgsMarkerSymbol.createSimple({"name": "triangle", "color": ci.GRAU, "outline_color": ci.GRAU, "size": "2.4"}), "sonstige")]
            lyr.setRenderer(QgsCategorizedSymbolRenderer("typ", kats))
            ci.label_kasten(lyr, "coalesce(\"bezeichnung\", \"typ\")", groesse=6.5, rahmen="#1A1A1A", min_massstab=1000, abstand_mm=1.5)
        elif lname == "bestand_apl":
            lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({"name": "circle", "color": "#9E9E9E", "outline_color": "#6B6B6B", "size": "1.6"}))
            ci.label_kasten(lyr, "concat(coalesce(\"hnr\", ''), coalesce(\"hnr_zs\", ''), if(\"we\" is null, '', ' | ' || \"we\" || ' WE'))",
                            groesse=6.0, rahmen="#9E9E9E", min_massstab=1000, abstand_mm=1.2)
        elif lname == "bestand_muffen":
            lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({"name": "diamond", "color": ROT_DUNKEL, "outline_color": ROT_DUNKEL, "size": "2.2"}))
        elif lname == "hvt":
            lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({"name": "star", "color": ci.ORANGE, "outline_color": "#1A1A1A", "size": "6"}))
            ci.label_kasten(lyr, "concat('HVt ', coalesce(\"strasse\", ''), ' ', coalesce(\"hnr\", ''))", groesse=7.5, rahmen=ci.ORANGE, abstand_mm=2.0)
