# -*- coding: utf-8 -*-
"""Bestand aus Schritt 1 als Wegefuehrung fuer Schritt 5 (Vzk) und Schritt 6 (Hk) - ohne Qt.

Markus 22.09.2026: "Die Wegefuehrung ist die Trasse. Den Ausbau entscheidet der Planer mit diesem Tool. Wo Rohre vorhanden sind und
potenziell freie Rohre fuer das Hk, nimm den Weg entlang dieser Trasse - das gilt primaer fuer das Hk. Vzk baut neue Infrastruktur.
Die Werkzeuge sind Unterstuetzung und Visualisierung: der Planer soll schneller entscheiden, nicht selbst recherchieren."

Verfahren: Die Bestandsstuecke (bestand_trassen aus dem MegaPlan-Export, sonst bestand_rohre aus Rohrliste/Extern-Export/Plan[Goo])
werden als eigene Kanten ueber den Basisgraphen gelegt (Seitenraum in Schritt 5, OSM-Netz aus Schritt 3 in Schritt 6) und an ihm
angekoppelt (naechste Netzkante, die Kante wird dort geteilt). Der Steinerbaum mischt dann selbst: wo Bestand liegt, ist die Kante
guenstig und gewinnt; wo keiner liegt, gilt der bisherige Preis, und Luecken schliessen sich wie gewohnt ueber den Basisgraphen.

Harte Regel (Markus 22.09.2026, Option 1: "wenn MegaPlan vorhanden ist, soll immer die Trasse genutzt werden, wenn moeglich, auch bei
Neubau"): Netzkanten, die parallel zu einer Telekom-Trasse laufen (>= 80 % ihrer Laenge naeher als SPERR_ABSTAND_M), werden gesperrt
(Kosten x SPERR_FAKTOR, bleiben als Rueckfall im Graphen). Der Baum muss dort auf die Trasse; Neubau gibt es nur, wo keine Trasse fuehrt.
Die Ankopplung an die Trasse ist billig (ANTEIL_ANKOPPLUNG), damit auch kurze Trassenstuecke genommen werden.

Preise (ANNAHMEN, in Grossbuchstaben unten):
  Hk, Rohrtrasse mit potenziell freiem Hk-tauglichem Rohr .. Einzug 5,83 EUR/m (Kabel in vorhandenes Rohr), Ein-/Ausstieg ein Kopfloch
  Hk, Rohrtrasse ohne Rohr in der Rohrliste ............... wie oben, Hinweis 'Rohr unbestaetigt' (Rohrliste ist erfahrungsgemaess gefiltert)
  Hk, Trasse ohne nutzbares Rohr (erdverlegt, Rohr voll) .. Neubau entlang der Telekom-Trasse, Preis x ANTEIL_TRASSE (Vorzug im Weg)
  Vzk, jede Telekom-Trasse ................................ Neubau entlang der Trasse, Preis x ANTEIL_TRASSE - Vzk baut neu, kein Einzug
Hauseinfuehrungen und 'vom Kunden verlegt' bleiben aussen vor.
"""
import math

import geopandas as gpd
import numpy as np
import pandas as pd
from shapely.geometry import LineString, Point, box
from shapely.ops import unary_union
from shapely.strtree import STRtree

CRS = 25832
RAND_M = 300.0              # Bestand nur im Umkreis der Adressen/NVT (+ Rand) einblenden - Barntrup: 22.619 MegaPlan-Stuecke
ANKOPPLUNG_M = 15.0         # Bestandsknoten koppelt an die naechste Netzkante, wenn sie naeher liegt (Telekom liegt im Gehweg, Seitenlinie auch)
ANKOPPLUNG_ENDE_M = 40.0    # freie Enden des Bestands (Grad 1) duerfen weiter springen (Rohrende am KVz, Strasse gegenueber)
EINZUG_EUR_M = 5.83         # LV Einzug (cluster.config eur_m_lv Einzug) - Hk in ein freies Rohr
KOPFLOCH_EUR = 508.75       # Kopfloch fuer Ein-/Ausstieg in ein Bestandsrohr (wie cluster.graph Anzapfung)
ANTEIL_TRASSE = 0.7         # ANNAHME: Neubau entlang einer Telekom-Trasse bekommt im Weg den Vorzug (Faktor auf den Neubaupreis), im LV bleibt es Neubau
ANTEIL_ANKOPPLUNG = 0.1     # Hk: Ankopplung Bestand <-> Netz kostet nur diesen Anteil des Neubaupreises (sonst lohnen kurze Trassenstuecke nie)
ANTEIL_ANKOPPLUNG_VZK = 1.0     # Vzk: die Ankopplung ist echter Tiefbau - voller Preis
WECHSEL_AUFSCHLAG_VZK_EUR = 500.0   # ANNAHME: jeder Wechsel zwischen Seitenraum und Telekom-Trasse kostet Aufwand (Kopfloch, Verkehrssicherung) -
                                    # ohne diesen Aufschlag springt der Baum alle paar Meter hin und her (Alverdissen 22.09.2026: 337 Ankopplungen)
SPERR_ABSTAND_M = 10.0      # Netzkante gilt als parallel zur Telekom-Trasse, wenn >= 80 % ihrer Laenge naeher liegen (Achsnetz 10 m; Seitenraum 6 m, siehe Aufrufer)
NAH_ABSTAND_M = 8.0         # Vzk (steuern): so weit darf eine Netzkante von der Telekom-Trasse entfernt liegen und gilt noch als "auf der Trasse"
SPERR_FAKTOR = 50.0         # gesperrte Kante: Kosten x 50 - der Baum nimmt sie nur, wenn es gar nicht anders geht (Rueckfall statt Loch im Netz)
HK_MIN_INNEN_MM = 20.0      # ANNAHME: Hk (bis 96E, ~9 mm) braucht ein Rohr mit Innen-Ø >= 20 mm oder ein Kabelkanalrohr; Mikrorohr 10 mm und Speednet 8 mm nicht
VERNODEN_TOL_M = 0.5
KLASSE_ROHR = "Bestandsrohr"
KLASSE_TRASSE = "Telekom-Trasse"
AUSSEN_VOR = ("Hauseinfuehrung", "vom Kunden verlegt (Lage unbekannt)")


from ... import gemeinsam
_s = gemeinsam.s


def _layer(gpkg):
    try:
        import pyogrio
        return set(pyogrio.list_layers(str(gpkg))[:, 0])
    except Exception:
        return set()


def _lesen(gpkg, layer, bbox):
    g = gpd.read_file(str(gpkg), layer=layer, bbox=tuple(bbox) if bbox is not None else None)
    if not len(g):
        return g
    if g.crs is None:
        g = g.set_crs(CRS, allow_override=True)
    elif g.crs.to_epsg() != CRS:
        g = g.to_crs(CRS)
    g = g[g.geometry.notna()].explode(index_parts=False, ignore_index=True)
    g = g[(g.geometry.geom_type == "LineString") & (g.geometry.length > 0.05)].reset_index(drop=True)
    return g


def hat_bestand(gpkg):
    return bool(_layer(gpkg) & {"bestand_trassen", "bestand_rohre"})


def hk_tauglich(rohrklasse, innen_mm, einziehbar):
    """Passt ein Hk (12E-96E) in dieses Rohr? Kabelkanalrohre (KKR/KKF) ja, Speednet nein, Mikrorohr ab HK_MIN_INNEN_MM, unbekannt = potenziell."""
    k = _s(rohrklasse).lower()
    if einziehbar is not None and not pd.isna(einziehbar) and not bool(einziehbar):
        return False
    if "speednet" in k or "einblasen" in k:
        return False
    if k.startswith("kkr") or k.startswith("kabelkanal") or k.startswith("kkf"):
        return True
    if innen_mm is not None and not pd.isna(innen_mm) and float(innen_mm) > 0:
        return float(innen_mm) >= HK_MIN_INNEN_MM
    if k.startswith("mikrorohr"):
        return False        # Mikrorohr ohne Mass: die kleinen (10 mm) ueberwiegen
    return True             # 'Rohr (allgemein)', unbekannt: potenziell frei


def _rohre_verdichten(rohre, zweck):
    """Rohrliste (mehrere Rohre je Geometrie, Barntrup bis 26) -> ein Stueck je Geometrie mit dem besten Hk-tauglichen freien Rohr."""
    if not len(rohre):
        return rohre.iloc[0:0]
    r = rohre.copy()
    r["_wkb"] = r.geometry.map(lambda g: g.wkb)
    frei = pd.to_numeric(r.get("freie_rohre"), errors="coerce") if "freie_rohre" in r else pd.Series([np.nan] * len(r), index=r.index)
    r["_frei"] = frei.isna() | (frei > 0)                      # NULL = unbekannt = potenziell frei
    r["_hk"] = [hk_tauglich(k, m, e) for k, m, e in zip(r.get("rohrklasse", pd.Series([None] * len(r))),
                                                        r.get("innen_mm", pd.Series([np.nan] * len(r))),
                                                        r.get("rohr_einziehbar", pd.Series([None] * len(r))))]
    r["_gut"] = r["_frei"] & r["_hk"]
    r["_innen"] = pd.to_numeric(r.get("innen_mm"), errors="coerce").fillna(0.0) if "innen_mm" in r else 0.0
    r = r.sort_values(["_gut", "_innen"], ascending=[False, False])
    erste = r.drop_duplicates("_wkb", keep="first").copy()
    n_rohre = r.groupby("_wkb").size()
    n_gut = r.groupby("_wkb")["_gut"].sum()
    erste["rohre_gesamt"] = erste["_wkb"].map(n_rohre).astype(int)
    erste["rohre_hk_frei"] = erste["_wkb"].map(n_gut).astype(int)
    out = gpd.GeoDataFrame({
        "quelle_id": erste["quelle_id"].map(_s) if "quelle_id" in erste else ["rohr:{}".format(i) for i in erste.index],
        "mp_id": erste["mp_id"].map(_s) if "mp_id" in erste else "",
        "bestandsart": ["Rohr in Rohrliste ({} Rohre, {} frei und Hk-tauglich)".format(a, b) for a, b in zip(erste["rohre_gesamt"], erste["rohre_hk_frei"])],
        "rohrklasse": erste["rohrklasse"].map(_s) if "rohrklasse" in erste else "",
        "freie_rohre": pd.to_numeric(erste.get("freie_rohre"), errors="coerce") if "freie_rohre" in erste else np.nan,
        "rohr_frei_hk": erste["rohre_hk_frei"] > 0,
        "hinweis": ["" if b else ("kein freies Hk-taugliches Rohr" if a else "") for a, b in zip(erste["rohre_gesamt"], erste["rohre_hk_frei"])],
        "geometry": erste.geometry,
    }, crs=CRS).reset_index(drop=True)
    return out


def stuecke(gpkg, zweck="hk", bbox=None, log=print):
    """Bestandsstuecke als GeoDataFrame: quelle_id, mp_id, bestandsart, rohrklasse, freie_rohre, rohr_frei_hk, klasse, hinweis, geometry.
    klasse = 'Bestandsrohr' (Hk faehrt in ein vorhandenes Rohr) oder 'Telekom-Trasse' (Neubau entlang der Trasse)."""
    layer = _layer(gpkg)
    rohre = _lesen(gpkg, "bestand_rohre", bbox) if "bestand_rohre" in layer else None
    trassen = _lesen(gpkg, "bestand_trassen", bbox) if "bestand_trassen" in layer else None
    if (trassen is None or not len(trassen)) and (rohre is None or not len(rohre)):
        return gpd.GeoDataFrame(geometry=[], crs=CRS)
    if trassen is not None and len(trassen):
        t = trassen[~trassen["bestandsart"].map(_s).isin(AUSSEN_VOR)].copy() if "bestandsart" in trassen else trassen.copy()
        rohr_da = t["rohr_vorhanden"].fillna(False).astype(bool) if "rohr_vorhanden" in t else pd.Series([False] * len(t), index=t.index)
        in_liste = t["rohr_in_liste"] if "rohr_in_liste" in t else None
        st = gpd.GeoDataFrame({
            "quelle_id": t["quelle_id"].map(_s) if "quelle_id" in t else ["mp:{}".format(i) for i in t.index],
            "mp_id": t["mp_id"].map(_s) if "mp_id" in t else "",
            "bestandsart": t["bestandsart"].map(_s) if "bestandsart" in t else "",
            "rohrklasse": "",
            "freie_rohre": np.nan,
            "rohr_frei_hk": rohr_da.values,
            "hinweis": "",
            "geometry": t.geometry,
        }, crs=CRS).reset_index(drop=True)
        if rohre is not None and len(rohre):
            # Rohre der Rohrliste auf die Rohrtrassen legen: bestes Hk-taugliches freies Rohr je Trassenstueck
            rv = _rohre_verdichten(rohre, zweck)
            rv_tree = STRtree(list(rv.geometry))
            kl, fr, ok, hw = [], [], [], []
            for g, ist_rohr in zip(st.geometry, st["rohr_frei_hk"]):
                if not ist_rohr:
                    kl.append(""); fr.append(np.nan); ok.append(False); hw.append("")
                    continue
                treffer = [j for j in rv_tree.query(g.buffer(2.0)) if rv.geometry.iloc[j].intersection(g.buffer(2.0)).length > 0.5 * min(g.length, rv.geometry.iloc[j].length)]
                if not treffer:
                    kl.append(""); fr.append(np.nan); ok.append(True); hw.append("Rohr unbestaetigt (nicht in der Rohrliste)")
                    continue
                best = max(treffer, key=lambda j: (bool(rv["rohr_frei_hk"].iloc[j]), float(rv["freie_rohre"].iloc[j] or 0)))
                kl.append(rv["rohrklasse"].iloc[best]); fr.append(rv["freie_rohre"].iloc[best])
                ok.append(bool(rv["rohr_frei_hk"].iloc[best])); hw.append("" if rv["rohr_frei_hk"].iloc[best] else "kein freies Hk-taugliches Rohr")
            st["rohrklasse"], st["freie_rohre"], st["rohr_frei_hk"], st["hinweis"] = kl, fr, ok, hw
        elif in_liste is not None:
            st.loc[st["rohr_frei_hk"] & ~in_liste.fillna(False).astype(bool).values, "hinweis"] = "Rohr unbestaetigt (nicht in der Rohrliste)"
        else:
            st.loc[st["rohr_frei_hk"], "hinweis"] = "Rohr unbestaetigt (keine Rohrliste geladen)"
    else:
        st = _rohre_verdichten(rohre, zweck)
    st["klasse"] = np.where(st["rohr_frei_hk"].astype(bool) & (zweck == "hk"), KLASSE_ROHR, KLASSE_TRASSE)
    if zweck != "hk":
        st.loc[st["rohr_frei_hk"].astype(bool), "hinweis"] = "Telekom-Rohrtrasse - Vzk baut neu"
    st["laenge_m"] = st.geometry.length.round(1)
    log("Bestand als Weg ({}): {} Stuecke, {:.1f} km; davon {} Bestandsrohr {:.1f} km, {} Telekom-Trasse {:.1f} km".format(
        "Hk" if zweck == "hk" else "Vzk", len(st), st["laenge_m"].sum() / 1000,
        int((st["klasse"] == KLASSE_ROHR).sum()), st.loc[st["klasse"] == KLASSE_ROHR, "laenge_m"].sum() / 1000,
        int((st["klasse"] == KLASSE_TRASSE).sum()), st.loc[st["klasse"] == KLASSE_TRASSE, "laenge_m"].sum() / 1000))
    return st


def _key(x, y):
    return "B_{:.2f}_{:.2f}".format(x, y)


def _neubau_eur_m(G, cfg):
    if cfg is not None:
        try:
            from ..cluster import costs
            return float(costs.eur_m(cfg["kosten"]["bauverfahren_default"], 1, cfg))
        except Exception:
            pass
    preise = [float(d["eur_m"]) for _, _, d in G.edges(data=True) if d.get("eur_m") and not d.get("bestand") and not d.get("telekom_trasse")]
    return float(np.median(preise)) if preise else 148.0


def steuern(G, gpkg, cfg=None, bbox=None, rand_m=RAND_M, abstand_m=NAH_ABSTAND_M, anteil=ANTEIL_TRASSE, log=print):
    """Vzk-Weise (Markus 22.09.2026: "auch im Vzk sollen die Trassen der Telekom genutzt werden - hilft bei Wegesicherung und KMU"):
    Die Telekom-Trassen kommen NICHT als zweites Netz dazu (dann pendelt der Baum zwischen Gehweglinie und Trasse und das Ergebnis
    zerfaellt in Kurzstuecke), sondern sie verbilligen die vorhandenen Netzkanten, die neben ihnen liegen. Der Baum bleibt im
    Seitenraum - dort haengen die Adressen -, waehlt aber die Seite und den Zug, auf dem die Telekom schon liegt.
    -> dict Kennzahlen (oder None ohne Bestand)"""
    if bbox is not None:
        minx, miny, maxx, maxy = [float(v) for v in bbox]
        bbox = (minx - rand_m, miny - rand_m, maxx + rand_m, maxy + rand_m)
    st = stuecke(gpkg, "vzk", bbox, log)
    if not len(st):
        log("Telekom-Trassen als Wegefuehrung: keine Stuecke im Umkreis - Weg nur auf dem Netz")
        return None
    puffer = [g.buffer(abstand_m) for g in st.geometry]
    ptree = STRtree(puffer)
    n, laenge = 0, 0.0
    for u, v, d in G.edges(data=True):
        if str(u).startswith("A_") or str(v).startswith("A_") or d.get("virtuell"):
            continue
        geom = d.get("geometry")
        if geom is None or getattr(geom, "length", 0) <= 0.05:
            continue
        treffer = ptree.query(geom)
        if len(treffer) == 0:
            continue
        drin = unary_union([puffer[i] for i in treffer]).intersection(geom).length
        if drin / geom.length >= 0.8:
            d["telekom_nah"] = True
            if d.get("cost") is not None:
                d["cost"] = float(d["cost"]) * anteil
            n += 1
            laenge += geom.length
    erg = {"zweck": "vzk", "modus": "steuern", "stuecke": int(len(st)), "km_trasse": round(st["laenge_m"].sum() / 1000, 2),
           "kanten_nah": n, "km_nah": round(laenge / 1000, 2), "abstand_m": float(abstand_m), "anteil": float(anteil), "quelle": str(gpkg)}
    G.graph["bestand_weg"] = erg
    log("Telekom-Trassen als Wegefuehrung: {} Stuecke / {:.1f} km im Umkreis; {} Netzkanten ({:.1f} km) liegen naeher als {:.0f} m daneben "
        "und kosten im Weg nur {:.0f} % - der Baum bleibt im Seitenraum, waehlt aber den Zug der Telekom".format(
            len(st), st["laenge_m"].sum() / 1000, n, laenge / 1000, abstand_m, anteil * 100))
    return erg


def einblenden(G, gpkg, zweck="hk", cfg=None, bbox=None, rand_m=RAND_M, sperr_abstand_m=SPERR_ABSTAND_M, log=print):
    """Bestandsstuecke als Kanten in G einhaengen, an den Basisgraphen koppeln und parallele Netzkanten sperren (Hauptkabel). In place.
    sperr_abstand_m: 10 m fuer das Achsnetz (Schritt 3/6), 6 m fuer den Seitenraum-Graphen (Schritt 5), 0 = keine Sperre.
    Fuer den Vzk siehe steuern(). -> dict Kennzahlen (oder None ohne Bestand)."""
    from ..trassen.kern import vernoden
    from ..cluster.graph import _split_edge
    if bbox is not None:
        minx, miny, maxx, maxy = [float(v) for v in bbox]
        bbox = (minx - rand_m, miny - rand_m, maxx + rand_m, maxy + rand_m)
    st = stuecke(gpkg, zweck, bbox, log)
    if not len(st):
        log("Bestand als Weg: keine nutzbaren Stuecke im Umkreis - Weg nur auf dem Basisnetz")
        return None
    neubau = _neubau_eur_m(G, cfg)
    bv = (cfg or {}).get("kosten", {}).get("bauverfahren_default", "Offene Bauweise")

    # 1. knotenrein machen (MegaPlan liefert keine Topologie)
    rows = [dict(geometry=g) for g in st.geometry]
    bewegt, knoten = vernoden(rows, tol=VERNODEN_TOL_M)
    st = st.copy()
    st["geometry"] = [r["geometry"] for r in rows]

    # 2. Basisnetz fuer die Ankopplung (vor dem Einhaengen, damit Bestand nicht an Bestand koppelt)
    basis_kanten = [(u, v) for u, v, d in G.edges(data=True) if "x" in G.nodes[u] and "x" in G.nodes[v] and not str(u).startswith("A_") and not str(v).startswith("A_")
                    and not d.get("virtuell") and d.get("seite") not in ("Q", "E", "T", "D")]
    basis_geoms = [G[u][v].get("geometry") or LineString([(G.nodes[u]["x"], G.nodes[u]["y"]), (G.nodes[v]["x"], G.nodes[v]["y"])]) for u, v in basis_kanten]
    for (u, v), g in zip(basis_kanten, basis_geoms):
        d = G[u][v]
        d.setdefault("geometry", g)
        d.setdefault("querung_eur", 0.0)
        d.setdefault("eur_m", float(d.get("cost", d.get("length", 1.0)) or 0.0) / max(float(d.get("length", 1.0) or 1.0), 0.01))
    basis_tree = STRtree(basis_geoms)
    basis_knoten = [n for n in G.nodes if "x" in G.nodes[n] and not str(n).startswith("A_")]
    basis_xy = np.array([[G.nodes[n]["x"], G.nodes[n]["y"]] for n in basis_knoten]) if basis_knoten else np.zeros((0, 2))
    basis_ktree = STRtree([Point(x, y) for x, y in basis_xy]) if len(basis_xy) else None

    # 3. Bestandskanten einhaengen
    n_kanten, km_rohr, km_trasse = 0, 0.0, 0.0
    grad = {}
    for r in st.itertuples(index=False):
        c = list(r.geometry.coords)
        ist_rohr = r.klasse == KLASSE_ROHR
        eur_m = EINZUG_EUR_M if ist_rohr else neubau * ANTEIL_TRASSE
        for (x1, y1), (x2, y2) in zip(c[:-1], c[1:]):
            L = math.hypot(x2 - x1, y2 - y1)
            if L <= 0.01:
                continue
            u, v = _key(x1, y1), _key(x2, y2)
            if u == v:
                continue
            G.add_node(u, x=x1, y=y1)
            G.add_node(v, x=x2, y=y2)
            if G.has_edge(u, v) and G[u][v].get("length", 1e9) <= L:
                continue
            # Oberflaechenklasse wie eine normale Strassentrasse, damit die Stuecke in Schritt 5 gefuellte Plan[Goo]-Felder bekommen
            G.add_edge(u, v, length=L, klasse="Bestandsrohr" if ist_rohr else "geb_Oberbau", okl=0 if ist_rohr else 1,
                       bauverfahren="Einzug" if ist_rohr else bv, eur_m=eur_m, highway=None,
                       name="{}{}".format(r.klasse, " " + _s(r.rohrklasse) if _s(r.rohrklasse) else ""), quelle_id=_s(r.quelle_id), hauptstr=False, is_b=False,
                       querung=None, querung_eur=0.0, virtuell=False, geometry=LineString([(x1, y1), (x2, y2)]), seite="B",
                       bestand=bool(ist_rohr), telekom_trasse=True, bestandsart=_s(r.bestandsart), rohrklasse=_s(r.rohrklasse), mp_id=_s(r.mp_id),
                       freie_rohre=None if pd.isna(r.freie_rohre) else float(r.freie_rohre), bestand_hinweis=_s(r.hinweis), cost=L * eur_m)
            grad[u] = grad.get(u, 0) + 1
            grad[v] = grad.get(v, 0) + 1
            n_kanten += 1
            if ist_rohr:
                km_rohr += L
            else:
                km_trasse += L

    # 4. Ankopplung in zwei Durchgaengen: (a) je Bestandsknoten die naechste Basiskante und den Fusspunkt bestimmen, (b) jede getroffene
    #    Basiskante EINMAL an allen Fusspunkten teilen, dann die Verbindungskanten ziehen. Ein-/Ausstieg in ein Rohr kostet ein Kopfloch.
    wunsch = {}                      # Bestandsknoten -> (Zielknoten | None, Kante j | None, frac, qx, qy, dist)
    teilungen = {}                   # Kante j -> Liste (frac, qx, qy)
    ohne = 0
    for n, g_ in grad.items():
        x, y = G.nodes[n]["x"], G.nodes[n]["y"]
        p = Point(x, y)
        reich = ANKOPPLUNG_ENDE_M if g_ == 1 else ANKOPPLUNG_M
        if basis_ktree is not None:
            j = basis_ktree.nearest(p)
            if j is not None:
                dk = math.hypot(basis_xy[j][0] - x, basis_xy[j][1] - y)
                if dk <= 1.0:
                    wunsch[n] = (basis_knoten[j], None, None, None, None, dk)
                    continue
        treffer = basis_tree.query(p.buffer(reich))
        if len(treffer) == 0:
            ohne += 1
            continue
        j = int(min(treffer, key=lambda k: basis_geoms[k].distance(p)))
        line = basis_geoms[j]
        frac = float(line.project(p, normalized=True))
        q = line.interpolate(frac, normalized=True)
        dist = q.distance(p)
        if dist > reich:
            ohne += 1
            continue
        u, v = basis_kanten[j]
        if frac <= 0.02 or math.hypot(G.nodes[u]["x"] - q.x, G.nodes[u]["y"] - q.y) <= 1.0:
            wunsch[n] = (u, None, None, None, None, dist)
        elif frac >= 0.98 or math.hypot(G.nodes[v]["x"] - q.x, G.nodes[v]["y"] - q.y) <= 1.0:
            wunsch[n] = (v, None, None, None, None, dist)
        else:
            wunsch[n] = (None, j, frac, q.x, q.y, dist)
            teilungen.setdefault(j, []).append((frac, q.x, q.y))
    # (b) teilen
    n_teil, neu_id = 0, 0
    fusspunkt = {}                   # (j, frac gerundet) -> neuer Knoten
    for j, liste in teilungen.items():
        u, v = basis_kanten[j]
        if not G.has_edge(u, v):
            continue
        d = G[u][v]
        d.setdefault("geometry", basis_geoms[j])
        d.setdefault("querung_eur", 0.0)
        splits = []
        for frac, qx, qy in sorted(liste):
            if splits and (frac - splits[-1][0]) * float(d.get("length", 1.0)) < 0.5:
                fusspunkt[(j, round(frac, 4))] = splits[-1][1]        # zwei Fusspunkte naeher als 0,5 m teilen sich den Knoten
                continue
            neu_id += 1
            name = "BK_{}".format(neu_id)
            splits.append((frac, name, qx, qy))
            fusspunkt[(j, round(frac, 4))] = name
        _split_edge(G, u, v, splits)
        for _, name, _, _ in splits:
            G.nodes[name].pop("addr", None)
        n_teil += 1
    # (c) Verbindungskanten
    n_kopp = 0
    for n, (ziel, j, frac, qx, qy, dist) in wunsch.items():
        if ziel is None:
            ziel = fusspunkt.get((j, round(frac, 4)))
            if ziel is None or ziel not in G:
                ohne += 1
                continue
        if ziel == n or G.has_edge(n, ziel):
            continue
        x, y = G.nodes[n]["x"], G.nodes[n]["y"]
        kopfloch = KOPFLOCH_EUR if any(G[n][m].get("bestand") for m in G.neighbors(n)) else 0.0
        L = max(float(dist), 0.01)
        eur_a = neubau * (ANTEIL_ANKOPPLUNG if zweck == "hk" else ANTEIL_ANKOPPLUNG_VZK)
        aufschlag = 0.0 if zweck == "hk" else WECHSEL_AUFSCHLAG_VZK_EUR
        G.add_edge(n, ziel, length=L, klasse="geb_Oberbau", okl=1, bauverfahren=bv, eur_m=eur_a, highway=None, name="Ankopplung Bestand",
                   quelle_id="bestand_ankopplung", hauptstr=False, is_b=False, querung="Kopfloch Bestand" if kopfloch else None,
                   querung_eur=kopfloch + aufschlag, virtuell=False, seite="A", bestand=False, ankopplung=True,
                   geometry=LineString([(x, y), (G.nodes[ziel]["x"], G.nodes[ziel]["y"])]), cost=L * eur_a + kopfloch + aufschlag)
        n_kopp += 1

    # 5. Harte Regel: Netzkanten parallel zur Telekom-Trasse sperren - der Baum muss auf die Trasse, wo eine liegt
    n_sperr, km_sperr = 0, 0.0
    if sperr_abstand_m and sperr_abstand_m > 0:
        puffer = [g.buffer(sperr_abstand_m) for g in st.geometry]
        ptree = STRtree(puffer)
        for u, v, d in G.edges(data=True):
            if d.get("telekom_trasse") or d.get("ankopplung") or d.get("virtuell") or str(u).startswith("A_") or str(v).startswith("A_"):
                continue
            if d.get("seite") in ("Q", "E", "T", "D") or d.get("querung") or d.get("quelle_id") in ("hausquerung", "querung"):
                continue
            geom = d.get("geometry")
            if geom is None or geom.length <= 0.05:
                continue
            treffer = ptree.query(geom)
            if len(treffer) == 0:
                continue
            drin = unary_union([puffer[i] for i in treffer]).intersection(geom).length
            if drin / geom.length >= 0.8:
                d["gesperrt_trasse"] = True
                d["cost"] = float(d.get("cost", d.get("length", 0.0) or 0.0) or 0.0) * SPERR_FAKTOR
                d["bestand_hinweis"] = "parallel zur Telekom-Trasse (gesperrt, Rueckfall)"
                n_sperr += 1
                km_sperr += geom.length

    G.graph["bestand_weg"] = {"zweck": zweck, "kanten": n_kanten, "km_rohr": round(km_rohr / 1000, 2), "km_trasse": round(km_trasse / 1000, 2),
                              "ankopplungen": n_kopp, "geteilt": n_teil, "ohne_anschluss": ohne, "stuecke": int(len(st)), "quelle": str(gpkg),
                              "gesperrt": n_sperr, "km_gesperrt": round(km_sperr / 1000, 2), "sperr_abstand_m": float(sperr_abstand_m or 0)}
    log("Bestand als Weg: {} Kanten eingehaengt ({:.1f} km Bestandsrohr zu {:.2f} EUR/m Einzug, {:.1f} km Telekom-Trasse zu {:.0f} EUR/m = {:.0f} % Neubau), "
        "{} Ankopplungen ({} Netzkanten geteilt, {:.0f} % Neubaupreis{}), {} Bestandsknoten ohne Netz in Reichweite; vernodet: {} Enden gezogen, {} Kreuzungen".format(
            n_kanten, km_rohr / 1000, EINZUG_EUR_M, km_trasse / 1000, neubau * ANTEIL_TRASSE, ANTEIL_TRASSE * 100, n_kopp, n_teil,
            (ANTEIL_ANKOPPLUNG if zweck == "hk" else ANTEIL_ANKOPPLUNG_VZK) * 100,
            "" if zweck == "hk" else " + {:.0f} EUR je Wechsel".format(WECHSEL_AUFSCHLAG_VZK_EUR), ohne, bewegt, knoten))
    log("Harte Regel: {} Netzkanten ({:.1f} km) parallel zur Telekom-Trasse (< {:.0f} m) gesperrt (Kosten x {:.0f}) - dort muss der Weg auf die Trasse, Neubau nur ohne Trasse".format(
        n_sperr, km_sperr / 1000, sperr_abstand_m or 0, SPERR_FAKTOR))
    return G.graph["bestand_weg"]


def lage_von(d):
    """Kurztext fuer eine Kante in der Weg-Vorlage: Bestandsrohr, Telekom-Trasse, Ankopplung oder leer."""
    if d.get("bestand"):
        return "Bestandsrohr"
    if d.get("telekom_trasse"):
        return "Telekom-Trasse"
    if d.get("ankopplung"):
        return "Ankopplung"
    return ""
