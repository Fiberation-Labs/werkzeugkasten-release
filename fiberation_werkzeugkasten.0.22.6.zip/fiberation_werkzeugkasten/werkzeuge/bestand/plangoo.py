# -*- coding: utf-8 -*-
"""Werkzeug 1 - zweite Quelle: Bestand aus einem Plan[Goo]-V2-Projekt (GeoPackage + .db daneben). Markus 18.09.2026 mit dem Barntrup-Paket
PlGoV2_05766012_0001_11-09-26_11-40: "hier ist aber Bestand".

So kennzeichnet Plan[Goo] Bestand (Befund Barntrup, v2.25.9):
  TRANCH.IS_EXTERNAL_OBJECT = 1      Bestandstrasse (273 Stuecke, 5,7 km in EPSG:25832); Geometrie im GeoPackage-Layer GEOMETRY_LINE - dessen UID steht in
                                     TRANCH.GEOMETRY (nicht TRANCH.UID! Falle 18.09.2026: 0 Treffer beim Join ueber UID),
                                     dort auch EXISTING_HIGHEST_PIPE = True und das Label "... (Bestand)". TRANCH_META ist fuer Bestand leer.
  CONDUIT.IS_EXTERNAL_OBJECT = 1     Bestandsrohr als Rohrzug ueber viele Trassen (39 Stueck: RO_AA = KKR 110, RO_SNR_UBK = Speednet-Rohr
                                     unbekannter Belegung, RO_AI); CONDUIT_PATH verbindet Rohr und Trassen, PARENT_CONDUIT = Rohr im Rohr.
                                     CONDUIT_META EXTERNAL_OBJECT_ID = Megaplan-ID ("19-12508422"), EXTERNAL_SYSTEM_NAME = MEGAPLAN.
  POINT.IS_EXTERNAL_OBJECT = 1       Bestandspunkt: ksch (Kabelschacht, Name "KSch MP 19-..."), kueg (Kabel-Uebergabegestell), ra (Rohrende
                                     des Bestandsrohrs, virtuelles Material VI_AA), ggf. nvt/bst. Geometrie in GEOMETRY_POINT (UID = POINT.GEOMETRY).
  genutzt                            ein neues Rohr (IS_EXTERNAL_OBJECT = 0) liegt IM Bestandsrohr (PARENT_CONDUIT) oder auf der
                                     Bestandstrasse; ein Bestandspunkt ist ueber CONNECTION/CONNECTION_LINK mit einem neuen Rohr verbunden.
Materialnamen kommen aus dem Materialkatalog des Plan[Goo]-Plugins (core/templates/materiallisten/materials.json: name, type,
meta.diameter_inside, meta.allow_material_children); ohne Katalog bleibt der Schluessel stehen.
Plan[Goo] V2 fuehrt keine Kabel als Objekte - Bestandskabel gibt es aus dieser Quelle nicht.

Zweiter Modus alles=True (Markus 18.09.2026 zu Mannheim-Rheinau "aber es ist ja viel mehr Bestand drinnen"): das ganze Projekt gilt als
Bestand - ein bereits gebautes Netz, das als Plan[Goo]-Projekt vorliegt (Telekom-Export, alle Objekte tragen im Label "(Neu)", die
APL den Ausbauzustand "passed+"). Dann: alle Trassen mit den Rohren darauf, Rohrzuege aller Hauptrohre (ohne Innenrohre), Punkte NVT,
Kabelschacht, KUEG, Muffe, Betriebsstelle, Hausuebergabepunkt, dazu die versorgten APL als eigener Layer. Das Bestandskennzeichen
bleibt als Spalte trasse_markiert / punkt_markiert erhalten.
"""
import glob
import json
import os
import re
import sqlite3

import geopandas as gpd
import pandas as pd

CRS = 25832
NUTZBAR_ROHR = "Rohr einziehbar"
NUTZBAR_KABEL = "nur Kabel einblasen"
NUTZBAR_UNBEKANNT = "Kapazitaet unbekannt"
PUNKTTYP = {"ksch": "Kabelschacht", "kueg": "Kabel-Uebergabegestell", "ra": "Rohrende (Bestandsrohr)", "ru": "Rohrpunkt ru (Plan[Goo]-Typ)",
            "re": "Rohrende re (Plan[Goo]-Typ)", "nvt": "NVt Bestand", "bst": "Betriebsstelle", "apl": "APL Bestand", "hpp": "Hausuebergabepunkt",
            "muffe": "Muffe"}
PUNKTE_ALLES = ("nvt", "ksch", "kueg", "muffe", "bst", "hpp")   # Bauwerke im Modus 'ganzes Projekt'; ra/re/ru sind Hilfspunkte


def ist_plangoo_projekt(gpkg):
    """True, wenn das GeoPackage die Plan[Goo]-Layer traegt und die .db daneben liegt."""
    try:
        import pyogrio
        layer = set(pyogrio.list_layers(gpkg)[:, 0])
    except Exception:
        return False
    return "GEOMETRY_LINE" in layer and os.path.exists(db_pfad(gpkg))


def db_pfad(gpkg):
    return os.path.splitext(str(gpkg))[0] + ".db"


def stamm(gpkg):
    """Kurzer Stamm: aus 'PlGoV2_08222000_0018_04-11-25_15-22' wird '08222000_0018' (Workspace und Vorhaben) - haelt Dateinamen unter der
    Windows-Pfadgrenze; andere Namen bleiben ganz."""
    s = os.path.splitext(os.path.basename(str(gpkg)))[0]
    m = re.match(r"^PlGoV2_(\d+_\d+)", s)
    return m.group(1) if m else s


def materialkatalog(log=print):
    """Schluessel -> {name, type, innen_mm, kinder} aus dem Plan[Goo]-Plugin; leer, wenn nicht gefunden."""
    kandidaten = []
    try:
        from qgis.utils import plugins
        for name, pl in plugins.items():
            if name.startswith("technik_plangoo"):
                kandidaten.append(os.path.join(os.path.dirname(os.path.abspath(__import__(name).__file__)), "core", "templates", "materiallisten", "materials.json"))
    except Exception:
        pass
    appdata = os.environ.get("APPDATA", "")
    kandidaten += glob.glob(os.path.join(appdata, "QGIS", "QGIS3", "profiles", "*", "python", "plugins", "technik_plangoo*", "core", "templates",
                                         "materiallisten", "materials.json"))
    for p in kandidaten:
        if os.path.exists(p):
            try:
                with open(p, encoding="utf-8") as fh:
                    roh = json.load(fh)
                out = {}
                for k, v in roh.items():
                    if not isinstance(v, dict):
                        continue
                    meta = v.get("meta") or {}
                    out[k] = {"name": v.get("name") or k, "type": v.get("type") or "", "innen_mm": meta.get("diameter_inside"),
                              "kinder": bool(meta.get("allow_material_children")), "fuellung": meta.get("fill_methods") or []}
                log("Materialkatalog: {} Eintraege aus {}".format(len(out), p))
                return out
            except Exception as e:
                log("Materialkatalog nicht lesbar: {!r}".format(e))
    log("Materialkatalog des Plan[Goo]-Plugins nicht gefunden - Materialschluessel bleiben stehen.")
    return {}


def _nutzbarkeit(schluessel, mat):
    m = mat.get(schluessel) or {}
    if m.get("kinder"):
        return NUTZBAR_ROHR                      # KKR & Co.: Innenrohre erlaubt
    name = (m.get("name") or schluessel or "").lower()
    if "ubk" in name or "unbekannt" in name or schluessel.endswith("_UBK"):
        return NUTZBAR_UNBEKANNT
    if m.get("fuellung"):
        return NUTZBAR_KABEL                      # Mikrorohr: nur Kabel einblasen
    return NUTZBAR_UNBEKANNT


def _lesen_layer(gpkg, layer):
    g = gpd.read_file(gpkg, layer=layer)
    if g.crs is None:
        g = g.set_crs(3857, allow_override=True)
    if g.crs.to_epsg() != CRS:
        g = g.to_crs(CRS)
    return g


def laden(gpkg, log=print, fortschritt=None, alles=False):
    """-> dict mit GeoDataFrames rohre (je Bestandstrasse), rohrzuege (je Bestandsrohr), punkte, apl (nur alles=True), Zahlen fuers Protokoll.
    alles=False: Bestand = Kennzeichen extern (Megaplan-Import). alles=True: das ganze Projekt ist Bestand (gebautes Netz)."""
    f = fortschritt or (lambda p, t: None)
    gpkg = str(gpkg)
    db = db_pfad(gpkg)
    if not os.path.exists(db):
        raise FileNotFoundError("Plan[Goo]-Datenbank fehlt neben dem GeoPackage: {}".format(os.path.basename(db)))
    mat = materialkatalog(log)
    con = sqlite3.connect(db)
    q = lambda s: pd.read_sql_query(s, con)
    try:
        f(10, "Plan[Goo] lesen")
        tr = q("select UID, GEOMETRY, TYPE, IS_EXTERNAL_OBJECT from TRANCH")
        ext_tr = set(tr.loc[tr["IS_EXTERNAL_OBJECT"] == 1, "UID"])
        geom_zu_tr = dict(zip(tr["GEOMETRY"], tr["UID"]))          # GeoPackage-UID -> TRANCH.UID
        co = q("select UID, MATERIAL, IS_EXTERNAL_OBJECT from CONDUIT")
        pfad = q("select CONDUIT, PARENT_CONDUIT, TRANCH, PATH_ORDER from CONDUIT_PATH")
        markiert_co = set(co.loc[co["IS_EXTERNAL_OBJECT"] == 1, "UID"])
        if alles:
            # ganzes Projekt = Bestand: jedes Rohr zaehlt dort, wo es OBEN liegt (PARENT_CONDUIT leer) - ein Hauszufuehrungsrohr laeuft im
            # Verband als Innenrohr und liegt vor dem Haus allein; nur der alleinliegende Teil bildet den Rohrzug. Alle Trassen sind Bestand.
            pfad = pfad[pfad["PARENT_CONDUIT"].isna()]
            ext_co = co[co["UID"].isin(set(pfad["CONDUIT"]))].set_index("UID")
            ext_tr = set(tr["UID"])
        else:
            ext_co = co[co["IS_EXTERNAL_OBJECT"] == 1].set_index("UID")
        meta_co = q("select CONDUIT, KEY, VALUE from CONDUIT_META")
        mp_co = meta_co[meta_co["KEY"] == "EXTERNAL_OBJECT_ID"].set_index("CONDUIT")["VALUE"].to_dict()
        sys_co = meta_co[meta_co["KEY"] == "EXTERNAL_SYSTEM_NAME"].set_index("CONDUIT")["VALUE"].to_dict()
        log("Plan[Goo]: {} Trassen ({} Bestand), {} Rohre ({} Bestand)".format(len(tr), len(ext_tr), len(co), len(ext_co)))

        # Trassen -> Rohre darauf. Bestandstrasse = als extern markierte Trasse ODER Trasse, auf der ein Bestandsrohr liegt
        # (Mannheim-Rheinau 18.09.2026: 214 Bestandsrohre, aber nur 7 markierte Trassen - die Rohre laufen auf normalen Trassen).
        pfad_ext = pfad[pfad["CONDUIT"].isin(ext_co.index)]
        rohre_je_trasse = pfad_ext.groupby("TRANCH")["CONDUIT"].apply(list).to_dict()
        markiert_tr = set(tr.loc[tr["IS_EXTERNAL_OBJECT"] == 1, "UID"])
        ext_tr = ext_tr | set(rohre_je_trasse)
        neue = set() if alles else set(co.loc[co["IS_EXTERNAL_OBJECT"] == 0, "UID"])
        # genutzt: neues Rohr im Bestandsrohr (PARENT) oder direkt auf der Bestandstrasse
        neu_in_best = pfad[pfad["CONDUIT"].isin(neue) & pfad["PARENT_CONDUIT"].isin(ext_co.index)]
        best_mit_innen = neu_in_best.groupby("PARENT_CONDUIT")["CONDUIT"].nunique().to_dict()
        tr_mit_neu = set(pfad.loc[pfad["CONDUIT"].isin(neue), "TRANCH"]) & ext_tr
        innen_je_trasse = neu_in_best.groupby("TRANCH")["CONDUIT"].nunique().to_dict()

        f(35, "Bestandstrassen")
        lin = _lesen_layer(gpkg, "GEOMETRY_LINE")
        lin["GEOM_UID"] = lin["UID"]
        lin["UID"] = lin["UID"].map(geom_zu_tr).fillna(lin["UID"])   # auf TRANCH.UID umschluesseln
        alle = lin[lin.geometry.notna()]
        geom_alle = dict(zip(alle["UID"], alle.geometry))          # fuer die Rohrzuege, auch ueber nicht markierte Trassen
        lin = lin[lin["UID"].isin(ext_tr)].copy()
        lin = lin.explode(index_parts=False, ignore_index=True)
        lin = lin[lin.geometry.notna() & (lin.geometry.length > 0.005)].reset_index(drop=True)

        def name_von(k):
            return (mat.get(k) or {}).get("name") or k

        def klassen(uid):
            ks = rohre_je_trasse.get(uid, [])
            namen = sorted(set(name_von(ext_co.loc[c, "MATERIAL"]) for c in ks))
            if not namen:
                return "leere Trasse (ohne Rohr)" if alles else "Bestandstrasse ohne Rohr"
            if len(namen) > 2:
                return "; ".join(namen[:2]) + " + {} weitere".format(len(namen) - 2)
            return "; ".join(namen)

        def nutz(uid):
            ks = rohre_je_trasse.get(uid, [])
            werte = [_nutzbarkeit(ext_co.loc[c, "MATERIAL"], mat) for c in ks]
            if NUTZBAR_ROHR in werte:
                return NUTZBAR_ROHR
            if NUTZBAR_KABEL in werte:
                return NUTZBAR_KABEL
            return NUTZBAR_UNBEKANNT

        def mp(uid):
            return "; ".join(sorted(set(str(mp_co.get(c)) for c in rohre_je_trasse.get(uid, []) if mp_co.get(c)))) or None

        def innen(uid):
            ks = rohre_je_trasse.get(uid, [])
            w = [(mat.get(ext_co.loc[c, "MATERIAL"]) or {}).get("innen_mm") for c in ks]
            w = [x for x in w if isinstance(x, (int, float)) and x > 0]
            return max(w) if w else None

        rohre = gpd.GeoDataFrame({
            "quelle_id": "plangoo:" + lin["UID"].astype(str),
            "fpf_id": None,
            "gistool_id": None,
            "mp_id": lin["UID"].map(mp),
            "rohrklasse": lin["UID"].map(klassen),
            "rohrklasse_code": lin["UID"].map(lambda u: "; ".join(sorted(set(ext_co.loc[c, "MATERIAL"] for c in rohre_je_trasse.get(u, []))))),
            "subtyp": lin["TYPE"].astype(str) if "TYPE" in lin else None,
            "freie_rohre": None,
            "rohr_einziehbar": lin["UID"].map(lambda u: nutz(u) == NUTZBAR_ROHR),
            "innen_mm": lin["UID"].map(innen),
            "max_kabel": None,
            "strassentyp": lin["LOCATION_HINT"] if "LOCATION_HINT" in lin else None,
            "baumkrone": False, "naturschutz": False, "wasserschutz": False,
            "source_id": None, "target_id": None,
            "nutzbarkeit": lin["UID"].map(nutz),
            "genutzt": lin["UID"].map(lambda u: u in tr_mit_neu),
            "rohre_bestand": lin["UID"].map(lambda u: len(rohre_je_trasse.get(u, []))),
            "trasse_markiert": lin["UID"].map(lambda u: u in markiert_tr),
            "rohre_neu_innen": lin["UID"].map(lambda u: int(innen_je_trasse.get(u, 0))),
            "label_plangoo": lin["STIL_LAB_COMPLEX_BESCHR"] if "STIL_LAB_COMPLEX_BESCHR" in lin else None,
        }, geometry=lin.geometry, crs=lin.crs)
        rohre["laenge_m"] = rohre.geometry.length.round(1)
        log("Bestandstrassen: {} Stuecke ({} als Bestand markiert, {} tragen ein Bestandsrohr), {:.1f} km, davon mit neuem Rohr {:.1f} km".format(
            len(rohre), int(rohre["trasse_markiert"].sum()), int((rohre["rohre_bestand"] > 0).sum()), rohre["laenge_m"].sum() / 1000,
            rohre.loc[rohre["genutzt"], "laenge_m"].sum() / 1000))

        # Rohrzuege (je Bestandsrohr eine Linie aus seinen Trassen)
        f(55, "Bestandsrohre als Rohrzuege")
        geom_je_trasse = geom_alle
        zeilen = []
        for uid, row in ext_co.iterrows():
            teile = pfad_ext[pfad_ext["CONDUIT"] == uid].sort_values("PATH_ORDER")["TRANCH"].tolist()
            geoms = [geom_je_trasse[t] for t in teile if t in geom_je_trasse]
            if not geoms:
                continue
            from shapely.ops import linemerge, unary_union
            g = linemerge(unary_union(geoms)) if len(geoms) > 1 else geoms[0]
            m = mat.get(row["MATERIAL"]) or {}
            zeilen.append({"quelle_id": "plangoo:rohr:" + uid, "material": row["MATERIAL"], "rohrklasse": m.get("name") or row["MATERIAL"],
                           "rohr_markiert": uid in markiert_co,
                           "innen_mm": m.get("innen_mm") if isinstance(m.get("innen_mm"), (int, float)) and m.get("innen_mm") > 0 else None,
                           "nutzbarkeit": _nutzbarkeit(row["MATERIAL"], mat), "mp_id": mp_co.get(uid), "system": sys_co.get(uid),
                           "trassen": len(teile), "rohre_neu_innen": int(best_mit_innen.get(uid, 0)), "genutzt": uid in best_mit_innen,
                           "laenge_m": round(sum(x.length for x in geoms), 1), "geometry": g})
        rohrzuege = gpd.GeoDataFrame(zeilen, geometry="geometry", crs=lin.crs) if zeilen else gpd.GeoDataFrame(geometry=[], crs=lin.crs)
        log("Bestandsrohre (Rohrzuege): {}, davon {} mit neuem Innenrohr".format(len(rohrzuege), int(rohrzuege["genutzt"].sum()) if len(rohrzuege) else 0))

        # Punkte
        f(70, "Bestandspunkte")
        if alles:
            po = q("select UID, GEOMETRY, TYPE, IS_EXTERNAL_OBJECT from POINT where IS_EXTERNAL_OBJECT=1 or TYPE in ({})".format(
                ",".join("'{}'".format(x) for x in PUNKTE_ALLES)))
        else:
            po = q("select UID, GEOMETRY, TYPE, IS_EXTERNAL_OBJECT from POINT where IS_EXTERNAL_OBJECT=1")
        markiert_po = set(po.loc[po["IS_EXTERNAL_OBJECT"] == 1, "UID"])
        geom_zu_po = dict(zip(po["GEOMETRY"], po["UID"]))
        meta_po = q("select POINT, KEY, VALUE from POINT_META where KEY in ('EXTERNAL_OBJECT_ID','NAME')")
        mp_po = meta_po[meta_po["KEY"] == "EXTERNAL_OBJECT_ID"].set_index("POINT")["VALUE"].to_dict()
        pm = q("select pm.POINT, pm.MATERIAL from POINT_MATERIAL pm where pm.PARENT_MATERIAL is null")
        mat_po = pm.groupby("POINT")["MATERIAL"].first().to_dict()
        verb = q("select distinct pm.POINT from POINT_MATERIAL pm join CONNECTION cn on cn.POINT_MATERIAL=pm.UID "
                 "join CONNECTION_LINK cl on cl.CONNECTION=cn.UID join CONDUIT c on c.UID=cl.CONDUIT where c.IS_EXTERNAL_OBJECT=0")
        verbunden = set(verb["POINT"])
        pt = _lesen_layer(gpkg, "GEOMETRY_POINT")
        pt["UID"] = pt["UID"].map(geom_zu_po).fillna(pt["UID"])
        pt = pt[pt["UID"].isin(set(po["UID"]))].copy()
        typ_po = po.set_index("UID")["TYPE"].to_dict()
        punkte = gpd.GeoDataFrame({
            "quelle_id": "plangoo:" + pt["UID"].astype(str),
            "typ": pt["UID"].map(lambda u: PUNKTTYP.get(typ_po.get(u), typ_po.get(u) or "unbekannt")),
            "typ_code": pt["UID"].map(lambda u: typ_po.get(u)),
            "bezeichnung": pt["UID"].map(lambda u: (mat.get(mat_po.get(u)) or {}).get("name") or mat_po.get(u)),
            "label": pt["NAME"] if "NAME" in pt else None,
            "comsof_nutzung": pt["UID"].map(lambda u: "neues Rohr angeschlossen" if u in verbunden else "nicht genutzt"),
            "genutzt": pt["UID"].map(lambda u: u in verbunden),
            "mp_id": pt["UID"].map(lambda u: mp_po.get(u)),
            "gistool_id": None,
            "rohrstuecke": None,
            "strasse": pt["STRASSE"] if "STRASSE" in pt else None,
            "hnr": pt["HS_NR"].map(lambda v: None if pd.isna(v) else str(int(v)) if isinstance(v, float) else str(v)) if "HS_NR" in pt else None,
            "kls_id": pt["KLS_ID"] if "KLS_ID" in pt else None,
            "punkt_markiert": pt["UID"].map(lambda u: u in markiert_po),
            "nvt": pt["PARENT_NAME"] if "PARENT_NAME" in pt else None,
        }, geometry=pt.geometry, crs=pt.crs)
        punkte = punkte[punkte.geometry.notna()].reset_index(drop=True)
        # versorgte Adressen (APL mit Ausbauzustand) nur im Modus 'ganzes Projekt'
        apl = gpd.GeoDataFrame(geometry=[], crs=pt.crs)
        if alles:
            pa = _lesen_layer(gpkg, "GEOMETRY_POINT")
            pa = pa[pa["TYPE"].astype(str) == "apl"].copy()
            apl = gpd.GeoDataFrame({
                "quelle_id": "plangoo:" + pa["UID"].astype(str),
                "ausbauzustand": pa["APL_AUSBAUZUSTAND"] if "APL_AUSBAUZUSTAND" in pa else None,
                "we": pd.to_numeric(pa["APL_HH"], errors="coerce") if "APL_HH" in pa else None,
                "nvt": pa["PARENT_NAME"] if "PARENT_NAME" in pa else None,
                "strasse": pa["STRASSE"] if "STRASSE" in pa else None,
                "hnr": pa["HS_NR"].map(lambda v: None if pd.isna(v) else str(int(v)) if isinstance(v, float) else str(v)) if "HS_NR" in pa else None,
                "hnr_zs": pa["HS_NR_ZS"] if "HS_NR_ZS" in pa else None,
                "kls_id": pa["KLS_ID"] if "KLS_ID" in pa else None,
            }, geometry=pa.geometry, crs=pa.crs)
            apl = apl[apl.geometry.notna()].reset_index(drop=True)
            log("Versorgte Adressen (APL): {} ({})".format(len(apl), ", ".join("{} {}".format(v, k) for k, v in apl["ausbauzustand"].fillna("ohne Zustand").value_counts().items())))
        log("Bestandspunkte: {} ({})".format(len(punkte), ", ".join("{} {}".format(v, k) for k, v in punkte["typ"].value_counts().items())))
        einstellungen = {r[0]: r[1] for r in con.execute("select TYPE, VALUE from SETTINGS")}
    finally:
        con.close()
    return {"rohre": rohre, "rohrzuege": rohrzuege, "punkte": punkte, "apl": apl, "trassen_gesamt": len(tr), "rohre_gesamt": len(co),
            "materialkatalog": bool(mat), "alles": alles}
