# -*- coding: utf-8 -*-
"""Werkzeug 1 - zwei weitere Telekom-Lieferformen fuer den Bestand (Markus 21.09.2026, Barntrup: "das kann Telekom liefern").

(3) MegaPlan-Export "Rohranlage" (GeoPackage, EPSG:4258, ein Layer mit beliebigem Namen, Felder UNDERGROUND_ROUTE_TYPE / INSTALLATION_TYPE
    / MP_ID ...): das ist das TRASSENNETZ der Telekom (UNDERGROUND_ROUTE = Graben), nicht die Rohre. Barntrup: 22.619 Stuecke, 305 km, davon
    Rohrverlegt 86 km, Erdverlegt (Kabel direkt im Boden, kein Rohr) 208 km, Im Haus 10 km. Keine Rohrklasse, keine Kapazitaet, keine Punkte,
    keine Topologie. Wert: vollstaendiges Bild, wo Telekom im Boden liegt, und die Verlegeart.
(4) Comsof-Eingabe "IN_ExistingPipes" (Shapefile, auch als Zip; EPSG:25832; Felder MP_DB_ID, MP_ID, CAPACITY, MAX_DIAM, SUBTYPE, DUCT_CLASS,
    STRUCT_IDS, MAX_DUCTS): die ROHRE mit Rohrklasse und freien Rohren, wie sie der FPF-Importer fuer Comsof schreibt - dieselben Felder wie
    EXISTINGPIPE im Extern-Export, aber ohne TYPE, ohne Knoten-IDs, ohne Comsof-Nutzung und ohne Punkte (STRUCT_IDS nennt nur die IDs der
    Strukturpunkte). Barntrup: 1.058 Rohre, 231 km auf 531 Geometrien (bis 26 Rohre uebereinander), alle auf MegaPlan-Trassen 'Rohrverlegt'.

Vergleich Barntrup 21.09.2026: alle FPF-Rohre liegen auf MegaPlan-Trassen (100 %), aber nur 52 von 305 km MegaPlan-Trassen tragen ein
FPF-Rohr; 39 km 'Rohrverlegt' haben kein Rohr in der Comsof-Liste (Exportfilter oder Luecke - im Layer als eigene Klasse sichtbar, wenn
beide Dateien zusammen aufbereitet werden: rohre_pfad).
"""
import os
import re
import time
from datetime import datetime

import geopandas as gpd
import pandas as pd

from . import kern

FELDER_MEGAPLAN = ("UNDERGROUND_ROUTE_TYPE", "INSTALLATION_TYPE")
FELDER_COMSOF_IN = ("DUCT_CLASS", "MAX_DUCTS", "MP_ID")
ABSTAND_ROHR_M = 2.0     # Rohr gilt als 'auf der Trasse', wenn es naeher als 2 m an ihr liegt (Lagegenauigkeit MegaPlan vs. Comsof-Eingabe)

VERLEGEART = {"Rohrverlegt": "Rohrtrasse (Rohr vorhanden)", "Erdverlegt": "erdverlegtes Kabel (kein Rohr)", "Im Haus": "Hauseinfuehrung"}
BESTANDSART_MIT_ROHR = "Rohrtrasse, Rohr in Rohrliste"
BESTANDSART_OHNE_ROHR = "Rohrtrasse, KEIN Rohr in Rohrliste"
STOPPWOERTER = ("megaplan", "export", "rohranlage", "in_existingpipes", "existingpipes", "fpf", "bestands", "bestand", "rohre", "comsof")


# --- Erkennen -------------------------------------------------------------------------------------------------------------------------------
def gdal_pfad(pfad):
    """Zip -> /vsizip/-Pfad, sonst unveraendert."""
    p = str(pfad)
    if p.lower().endswith(".zip"):
        return "/vsizip/" + p.replace("\\", "/")
    return p


def _layer_mit_feldern(pfad, felder):
    """Name des ersten Layers, der alle Felder traegt, sonst None."""
    try:
        import pyogrio
        gp = gdal_pfad(pfad)
        for name in pyogrio.list_layers(gp)[:, 0]:
            try:
                info = pyogrio.read_info(gp, layer=name)
            except Exception:
                continue
            vorhanden = set(str(f).upper() for f in info.get("fields", []))
            if all(f in vorhanden for f in felder):
                return name
    except Exception:
        return None
    return None


def ist_megaplan_rohranlage(pfad):
    p = str(pfad).lower()
    if not p.endswith((".gpkg", ".shp", ".zip")):
        return None
    return _layer_mit_feldern(pfad, FELDER_MEGAPLAN)


def ist_comsof_eingabe_rohre(pfad):
    p = str(pfad).lower()
    if not p.endswith((".shp", ".zip", ".gpkg")):
        return None
    if p.endswith(".gpkg") and kern.ist_fpf_export(pfad):
        return None
    return _layer_mit_feldern(pfad, FELDER_COMSOF_IN)


def stamm(pfad, fallback):
    s = os.path.splitext(os.path.basename(str(pfad)))[0]
    woerter = [w for w in re.split(r"[\s_\-]+", s) if w and w.lower() not in STOPPWOERTER]
    return "_".join(woerter) or fallback


def _schreiben(gpkg, paare):
    geschrieben = []
    for name, g in paare:
        if g is None or not len(g):
            continue
        g = g.copy()
        for col in g.columns:
            if col == "geometry":
                continue
            if str(g[col].dtype) == "bool":
                g[col] = g[col].astype(int)
            elif g[col].dtype == object:
                g[col] = g[col].map(kern._s)
        g.to_file(gpkg, layer=name, driver="GPKG")
        geschrieben.append(name)
    return geschrieben


# --- (4) Comsof-Eingabe IN_ExistingPipes --------------------------------------------------------------------------------------------------
def rohre_lesen(pfad, log=print):
    """IN_ExistingPipes -> GeoDataFrame im Schema von bestand_rohre (wie der Extern-Export, ohne Comsof-Nutzung)."""
    layer = ist_comsof_eingabe_rohre(pfad)
    if not layer:
        raise ValueError("Keine Comsof-Rohrliste (Felder {}) in {}".format(", ".join(FELDER_COMSOF_IN), os.path.basename(str(pfad))))
    r = kern._lesen(gdal_pfad(pfad), layer, log)
    if not len(r):
        return gpd.GeoDataFrame(geometry=[], crs="EPSG:{}".format(kern.CRS))

    def sp(name, default=None):
        return r[name] if name in r else pd.Series([default] * len(r), index=r.index)

    innen = pd.to_numeric(sp("MAX_DIAM"), errors="coerce")
    kap = pd.to_numeric(sp("CAPACITY"), errors="coerce")
    innen = innen.where(innen > 0, kap.where(kap > 0))
    code = sp("DUCT_CLASS").map(kern._s)
    rohre = gpd.GeoDataFrame({
        "quelle_id": ["comsof:{}".format(kern._s(m) or i) for i, m in zip(r.index, sp("MP_ID"))],
        "fpf_id": pd.Series([None] * len(r), index=r.index, dtype=object),
        "gistool_id": None,
        "mp_id": sp("MP_ID").map(kern._s),
        "mp_db_id": sp("MP_DB_ID").map(kern._s),
        "rohrklasse": [kern.rohrklasse(c, d) for c, d in zip(code, innen)],
        "rohrklasse_code": code,
        "subtyp": sp("SUBTYPE").map(kern._s),
        "freie_rohre": pd.to_numeric(sp("MAX_DUCTS"), errors="coerce"),
        "rohr_einziehbar": [not (c or "").startswith("snr") for c in code],      # ANNAHME: Speednet-Rohr 8 mm = nur Kabel einblasen
        "innen_mm": innen,
        "strukturpunkte": sp("STRUCT_IDS").map(kern._s),
    }, geometry=r.geometry, crs=r.crs)
    rohre["nutzbarkeit"] = [kern._nutzbarkeit(a, b) for a, b in zip(rohre["freie_rohre"], rohre["rohr_einziehbar"])]
    rohre["genutzt"] = False
    # Buendel: wie viele Rohre der Liste liegen auf genau dieser Geometrie (Barntrup: bis 26)
    schl = rohre.geometry.map(lambda g: g.wkb if g is not None else None)
    rohre["rohre_auf_trasse"] = schl.map(schl.value_counts()).astype("Int64")
    rohre = kern._linien(rohre)
    rohre["laenge_m"] = rohre.geometry.length.round(1)
    rohre["freie_rohre"] = rohre["freie_rohre"].where(rohre["freie_rohre"] >= 0)
    log("Comsof-Rohrliste {}: {} Rohre, {:.1f} km, {} Geometrien, {} Strukturpunkte genannt".format(
        os.path.basename(str(pfad)), len(rohre), rohre["laenge_m"].sum() / 1000, schl.nunique(),
        rohre["strukturpunkte"].dropna().str.split(",").explode().str.strip().nunique()))
    return rohre


def aus_comsof_eingabe(pfad, out_dir=None, log=print, fortschritt=None):
    """IN_ExistingPipes (Shape/Zip) -> bestand_rohre + Bericht + Liste, ohne Punkte und ohne Nutzung im Plan."""
    t0 = time.time()
    f = fortschritt or (lambda p, t: None)
    pfad = str(pfad)
    out_dir = out_dir or os.path.dirname(pfad)
    os.makedirs(out_dir, exist_ok=True)
    st = stamm(pfad, "comsof")
    gpkg = kern.ausgabe_pfad(out_dir, "bestand_{}_{}.gpkg".format(st, datetime.now().strftime("%Y%m%d_%H%M")), log)
    out_dir = os.path.dirname(gpkg)
    f(10, "Rohrliste lesen")
    rohre = rohre_lesen(pfad, log)
    leer = gpd.GeoDataFrame(geometry=[], crs="EPSG:{}".format(kern.CRS))
    f(60, "Rohrnetz pruefen")
    netz = kern._komponenten_geom(rohre, log)
    f(80, "GeoPackage schreiben")
    geschrieben = _schreiben(gpkg, (("bestand_rohre", rohre),))
    f(92, "Kennzahlen")
    liste = kern.kennzahlen(rohre, leer, leer, leer, leer, netz)
    if len(rohre):
        b = rohre.groupby(rohre["rohre_auf_trasse"].fillna(1).astype(int).clip(upper=6).map(lambda n: "1 Rohr" if n == 1 else ("{} Rohre".format(n) if n < 6 else "6 und mehr Rohre")))
        for k, g in b:
            liste["zeilen"].append({"gruppe": "Buendel", "art": "Trasse mit {}".format(k), "anzahl": int(len(g)), "laenge_km": round(g["laenge_m"].sum() / 1000, 2),
                                    "genutzt_km": None, "frei": kern._frei_text(g["freie_rohre"]), "layer": "bestand_rohre", "feld": None})
    liste["summe"]["quelle_art"] = "comsof_in"
    liste_pfad = os.path.splitext(gpkg)[0] + "_liste.json"
    _liste_schreiben(liste_pfad, pfad, st, geschrieben, "comsof_in", liste)
    hinweise = [
        "- Quelle ist die Comsof-EINGABE 'IN_ExistingPipes' (Rohrliste des FPF-Importers, Telekom-Lieferung), nicht der Extern-Export: dieselben "
        "Rohrfelder (Rohrklasse, freie Rohre = MAX_DUCTS, Innendurchmesser, Megaplan-ID), aber ohne Comsof-Nutzung ('genutzt' ist immer 0), ohne "
        "Schaechte/Masten (STRUCT_IDS nennt nur ihre IDs, Spalte strukturpunkte) und ohne Bestandskabel.",
        "- **rohre_auf_trasse** = so viele Rohre der Liste liegen auf genau dieser Linie (Buendel; Barntrup bis 26 Speednet-Rohre uebereinander) - "
        "im Kartenfenster sieht man nur eine Linie.",
        "- **nur Kabel einblasen** = Speednet-Rohr (snr_*): ANNAHME aus der Rohrklasse, die Eingabe hat kein PLACE_DUCT-Feld.",
        "- Zusammenhang ueber Linienenden (keine Knoten-IDs in der Eingabe): Inseln sind meist Exportgrenzen.",
        "- Fehlt eine Trasse hier, heisst das nicht 'kein Telekom-Bestand': der MegaPlan-Export 'Rohranlage' zeigt zusaetzlich erdverlegte Kabel "
        "und Rohrtrassen ohne Rohr in dieser Liste - beide Dateien zusammen aufbereiten (Quelle MegaPlan + 'Rohrliste dazu').",
    ]
    bericht = kern._bericht(gpkg, pfad, liste, netz, time.time() - t0, quelle_text="Comsof-Eingabe IN_ExistingPipes (Rohrliste des FPF-Importers)",
                            hinweise=hinweise)
    f(100, "Fertig")
    return {"gpkg": gpkg, "bericht": bericht, "liste": liste_pfad, "stamm": st, "out_dir": out_dir, "layer": geschrieben, "quelle_art": "comsof_in",
            "rohre": len(rohre), "rohre_km": round(rohre["laenge_m"].sum() / 1000, 1) if len(rohre) else 0.0,
            "kabel": 0, "kabel_km": 0.0, "punkte": 0, "muffen": 0, "hauptkabel": 0, "netz": netz, "kennzahlen": liste}


# --- (3) MegaPlan-Export Rohranlage -----------------------------------------------------------------------------------------------------------
def trassen_lesen(pfad, log=print):
    layer = ist_megaplan_rohranlage(pfad)
    if not layer:
        raise ValueError("Kein MegaPlan-Export Rohranlage (Felder {}) in {}".format(", ".join(FELDER_MEGAPLAN), os.path.basename(str(pfad))))
    t = kern._lesen(gdal_pfad(pfad), layer, log)
    if not len(t):
        return gpd.GeoDataFrame(geometry=[], crs="EPSG:{}".format(kern.CRS))

    def sp(name, default=None):
        return t[name] if name in t else pd.Series([default] * len(t), index=t.index)

    verl = sp("INSTALLATION_TYPE").map(kern._s)
    art = sp("UNDERGROUND_ROUTE_TYPE").map(kern._s)
    tiefe = pd.to_numeric(sp("PLACE_DEPTH_HEIGHT"), errors="coerce")
    tr = gpd.GeoDataFrame({
        "quelle_id": "mp:" + sp("MP_ID").astype(str),
        "mp_id": sp("MP_ID").map(kern._s),
        "mp_db_id": sp("MP_DB_ID").map(kern._s),
        "mp_objekt": sp("id").map(kern._s),
        "verlegeart": verl,
        "trassenart": art,
        "bestandsart": [_bestandsart(v, a) for v, a in zip(verl, art)],
        "rohr_vorhanden": verl.map(lambda v: v == "Rohrverlegt"),
        "verlegetiefe_cm": (-tiefe).where((tiefe < 0) & (tiefe > -500)),       # ANNAHME: PLACE_DEPTH_HEIGHT -60 = 60 cm unter Oberflaeche
        "mp_durchmesser": pd.to_numeric(sp("DIAMETER"), errors="coerce"),
        "mp_breite": pd.to_numeric(sp("WIDTH"), errors="coerce"),
        "mp_tiefe": pd.to_numeric(sp("CENTRE_POINT_DEPTH"), errors="coerce"),
        "mp_schicht_oben": pd.to_numeric(sp("UPPER_MATERIAL_DEPTH"), errors="coerce"),
        "mp_schicht_kern": pd.to_numeric(sp("CORE_MATERIAL_DEPTH"), errors="coerce"),
        "mp_schicht_unten": pd.to_numeric(sp("BASE_MATERIAL_DEPTH"), errors="coerce"),
        "oberflaeche": sp("SURFACE_MATERIAL").map(kern._s),
        "gps_gemessen": sp("GPS_MEASURED").map(lambda v: kern._s(v) in ("Ja", "true", "True", "1")),
        "mitverlegung": sp("COLLOCATED_COMMENT").map(kern._s),
        "mbfd_vertrag": sp("MBFD_CONTRACT_NUMBER").map(kern._s),
    }, geometry=t.geometry, crs=t.crs)
    tr = kern._linien(tr)
    tr["laenge_m"] = tr.geometry.length.round(1)
    tr["genutzt"] = False
    log("MegaPlan Rohranlage {}: {} Trassenstuecke, {:.1f} km ({})".format(
        os.path.basename(str(pfad)), len(tr), tr["laenge_m"].sum() / 1000,
        ", ".join("{} {:.1f} km".format(k, g["laenge_m"].sum() / 1000) for k, g in tr.groupby(tr["verlegeart"].fillna("ohne Verlegeart")))))
    return tr


def _bestandsart(verlegeart, trassenart):
    if trassenart in ("Spülbohrung", "Spuelbohrung", "Bodenverdrängung", "Bodenverdraengung"):
        return "Sonderbau ({})".format(trassenart.replace("ü", "ue").replace("ä", "ae"))
    if trassenart and trassenart.lower().startswith("vom kunden"):
        return "vom Kunden verlegt (Lage unbekannt)"
    return VERLEGEART.get(verlegeart, verlegeart or "unbekannt")


def rohre_zuordnen(trassen, rohre, log=print):
    """Rohrtrassen bekommen 'Rohr in Rohrliste' ja/nein (Rohr naeher als ABSTAND_ROHR_M); Rohre bekommen die MegaPlan-Trasse (mp_trasse)."""
    if not len(trassen) or not len(rohre):
        return trassen, rohre
    from shapely.ops import unary_union
    rohr_u = unary_union(rohre.buffer(ABSTAND_ROHR_M).geometry.values)
    anteil = trassen.geometry.intersection(rohr_u).length / trassen.geometry.length.where(trassen.geometry.length > 0, 1.0)
    trassen["rohr_in_liste"] = anteil > 0.5
    ist_rohr = trassen["rohr_vorhanden"].astype(bool)
    normal = trassen["bestandsart"] == VERLEGEART["Rohrverlegt"]        # Sonderbau (Spuelbohrung) behaelt seine Klasse
    trassen.loc[ist_rohr & normal & trassen["rohr_in_liste"], "bestandsart"] = BESTANDSART_MIT_ROHR
    trassen.loc[ist_rohr & normal & ~trassen["rohr_in_liste"], "bestandsart"] = BESTANDSART_OHNE_ROHR
    # Rohr -> naechste Rohrtrasse (Megaplan-ID der Trasse)
    rt = trassen[ist_rohr][["mp_id", "geometry"]].rename(columns={"mp_id": "mp_trasse"})
    if len(rt):
        j = gpd.sjoin_nearest(rohre[["geometry"]], rt, how="left", max_distance=ABSTAND_ROHR_M, distance_col="abst")
        j = j[~j.index.duplicated(keep="first")]
        rohre["mp_trasse"] = j["mp_trasse"].reindex(rohre.index)
        rohre["abstand_trasse_m"] = j["abst"].reindex(rohre.index).round(2)
    km_mit = trassen.loc[ist_rohr & trassen["rohr_in_liste"], "laenge_m"].sum() / 1000
    km_ohne = trassen.loc[ist_rohr & ~trassen["rohr_in_liste"], "laenge_m"].sum() / 1000
    km_erd = trassen.loc[~ist_rohr & trassen["rohr_in_liste"], "laenge_m"].sum() / 1000
    log("Abgleich Trassen/Rohrliste: Rohrtrassen mit Rohr in der Liste {:.1f} km, OHNE Rohr in der Liste {:.1f} km; Rohre auf nicht-Rohrtrassen {:.1f} km".format(
        km_mit, km_ohne, km_erd))
    return trassen, rohre


def aus_megaplan(pfad, out_dir=None, log=print, fortschritt=None, rohre_pfad=None):
    """MegaPlan-Export Rohranlage -> bestand_trassen (+ bestand_rohre aus einer Comsof-Rohrliste, wenn rohre_pfad gesetzt) + Bericht + Liste."""
    t0 = time.time()
    f = fortschritt or (lambda p, t: None)
    pfad = str(pfad)
    out_dir = out_dir or os.path.dirname(pfad)
    os.makedirs(out_dir, exist_ok=True)
    st = stamm(pfad, "megaplan")
    gpkg = kern.ausgabe_pfad(out_dir, "bestand_{}_{}.gpkg".format(st, datetime.now().strftime("%Y%m%d_%H%M")), log)
    out_dir = os.path.dirname(gpkg)
    f(10, "MegaPlan-Trassen lesen")
    trassen = trassen_lesen(pfad, log)
    leer = gpd.GeoDataFrame(geometry=[], crs="EPSG:{}".format(kern.CRS))
    rohre = leer
    if rohre_pfad:
        f(35, "Rohrliste lesen")
        rohre = rohre_lesen(rohre_pfad, log)
        f(50, "Rohre den Trassen zuordnen")
        trassen, rohre = rohre_zuordnen(trassen, rohre, log)
    f(65, "Trassennetz pruefen")
    netz = kern._komponenten_geom(trassen[trassen["rohr_vorhanden"].astype(bool)] if len(trassen) else trassen, log)
    f(80, "GeoPackage schreiben")
    geschrieben = _schreiben(gpkg, (("bestand_trassen", trassen), ("bestand_rohre", rohre)))
    f(92, "Kennzahlen")
    liste = kern.kennzahlen(rohre, leer, leer, leer, leer, netz)
    if len(trassen):
        for k, g in trassen.groupby("bestandsart"):
            liste["zeilen"].append({"gruppe": "Trassen", "art": k, "anzahl": int(len(g)), "laenge_km": round(g["laenge_m"].sum() / 1000, 2),
                                    "genutzt_km": None, "frei": _tiefe_text(g["verlegetiefe_cm"]), "layer": "bestand_trassen", "feld": "bestandsart"})
        for k, g in trassen.groupby(trassen["trassenart"].fillna("ohne Angabe")):
            liste["zeilen"].append({"gruppe": "Trassenart", "art": k, "anzahl": int(len(g)), "laenge_km": round(g["laenge_m"].sum() / 1000, 2),
                                    "genutzt_km": None, "frei": "", "layer": "bestand_trassen", "feld": "trassenart"})
    su = liste["summe"]
    su["quelle_art"] = "megaplan"
    su["trassen"] = int(len(trassen))
    su["trassen_km"] = round(trassen["laenge_m"].sum() / 1000, 1) if len(trassen) else 0.0
    rv = trassen[trassen["rohr_vorhanden"].astype(bool)] if len(trassen) else trassen
    su["rohrtrassen_km"] = round(rv["laenge_m"].sum() / 1000, 1) if len(rv) else 0.0
    su["erdverlegt_km"] = round(trassen.loc[trassen["verlegeart"] == "Erdverlegt", "laenge_m"].sum() / 1000, 1) if len(trassen) else 0.0
    if "rohr_in_liste" in trassen:
        su["rohrtrassen_ohne_rohr_km"] = round(trassen.loc[trassen["rohr_vorhanden"].astype(bool) & ~trassen["rohr_in_liste"], "laenge_m"].sum() / 1000, 1)
    liste_pfad = os.path.splitext(gpkg)[0] + "_liste.json"
    _liste_schreiben(liste_pfad, pfad, st, geschrieben, "megaplan", liste, rohre_pfad=rohre_pfad)
    hinweise = [
        "- Quelle ist der MegaPlan-Export 'Rohranlage' (UNDERGROUND_ROUTE): das TRASSENNETZ der Telekom mit Verlegeart, nicht die Rohre. "
        "**Rohrtrasse** = INSTALLATION_TYPE Rohrverlegt (da liegt mindestens ein Rohr), **erdverlegtes Kabel** = Erdverlegt (Kabel direkt im Boden, "
        "kein Rohr, nichts einziehbar), **Hauseinfuehrung** = Im Haus.",
        "- Rohrklasse, freie Rohre, Kabel, Schaechte und Masten kennt dieser Export nicht. Dafuer braucht es die Comsof-Rohrliste IN_ExistingPipes "
        "oder den Extern-Export ('Rohrliste dazu' im Dialog).",
        "- **Verlegetiefe** aus PLACE_DEPTH_HEIGHT (-60 = 60 cm unter Oberflaeche, ANNAHME); die MegaPlan-Rohwerte DIAMETER/WIDTH/CENTRE_POINT_DEPTH "
        "und die Schichtdicken stehen unveraendert in mp_durchmesser, mp_breite, mp_tiefe, mp_schicht_* (Einheit im Export nicht benannt).",
        "- Zusammenhang wurde nur fuer Rohrtrassen ueber die Linienenden gerechnet.",
    ]
    if rohre_pfad:
        hinweise.insert(2, "- **Rohrtrasse, KEIN Rohr in Rohrliste**: MegaPlan sagt 'Rohrverlegt', aber in der Comsof-Rohrliste liegt kein Rohr naeher als "
                           "{:.0f} m - Exportfilter des PTI oder echte Luecke; vor Ort bzw. beim PTI klaeren, bevor man dort Bestand einplant. "
                           "Rohre tragen die Trassen-ID in mp_trasse.".format(ABSTAND_ROHR_M))
    bericht = kern._bericht(gpkg, pfad, liste, netz, time.time() - t0,
                            quelle_text="MegaPlan-Export Rohranlage (Trassennetz mit Verlegeart){}".format(
                                " + Comsof-Rohrliste {}".format(os.path.basename(str(rohre_pfad))) if rohre_pfad else ""), hinweise=hinweise)
    f(100, "Fertig")
    return {"gpkg": gpkg, "bericht": bericht, "liste": liste_pfad, "stamm": st, "out_dir": out_dir, "layer": geschrieben, "quelle_art": "megaplan",
            "trassen": len(trassen), "trassen_km": su["trassen_km"], "rohrtrassen_km": su["rohrtrassen_km"], "erdverlegt_km": su["erdverlegt_km"],
            "rohrtrassen_ohne_rohr_km": su.get("rohrtrassen_ohne_rohr_km"),
            "rohre": len(rohre), "rohre_km": round(rohre["laenge_m"].sum() / 1000, 1) if len(rohre) else 0.0,
            "kabel": 0, "kabel_km": 0.0, "punkte": 0, "muffen": 0, "hauptkabel": 0, "netz": netz, "kennzahlen": liste}


def _tiefe_text(s):
    s = pd.to_numeric(s, errors="coerce").dropna()
    if not len(s):
        return "Tiefe unbekannt"
    lo, hi = int(s.min()), int(s.max())
    return "Tiefe {} cm".format(lo if lo == hi else "{}-{}".format(lo, hi))


def _liste_schreiben(pfad, quelle, st, layer, art, liste, rohre_pfad=None):
    import json
    with open(pfad, "w", encoding="utf-8") as fh:
        json.dump({"quelle": str(quelle), "rohre_quelle": str(rohre_pfad) if rohre_pfad else None, "stamm": st, "layer": layer, "quelle_art": art, **liste},
                  fh, indent=1, ensure_ascii=False)
