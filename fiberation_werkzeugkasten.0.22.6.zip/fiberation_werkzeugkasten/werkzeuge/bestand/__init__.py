# -*- coding: utf-8 -*-
"""Werkzeug 1 - Bestand aus Telekom-Lieferung: Bestandsrohre, -kabel, -punkte aus dem Comsof-Extern-GeoPackage zeigen und aufbereiten."""
