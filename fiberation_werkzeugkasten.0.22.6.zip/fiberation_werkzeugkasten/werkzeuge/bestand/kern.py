# -*- coding: utf-8 -*-
"""Werkzeug 1 - Kern ohne Qt: Bestand aus dem FPF-Extern-Export (Markus 18.09.2026: "soll alles aus dem FPF-Telekom-Export, was Bestand
ist, zeigen und aufbereiten").

Vier Quellen: (1) das GeoPackage "Nur Export Extern" des Plan[Goo]-FPF-Importers (unten), (2) ein Plan[Goo]-Projekt mit Bestand aus
dem Megaplan-As-built-Import (siehe plangoo.py; Markus 18.09.2026 Barntrup "hier ist aber Bestand"), (3) der MegaPlan-Export "Rohranlage"
(Trassennetz mit Verlegeart) und (4) die Comsof-Eingabe IN_ExistingPipes (Rohrliste, Shape/Zip) - beide in telekom.py (Markus 21.09.2026
Barntrup "das kann Telekom liefern"). quelle_art() unterscheidet.
Quelle (1) ist das GeoPackage "Nur Export Extern" des Plan[Goo]-FPF-Importers (z. B. 05954036_0004_extern.gpkg, Comsof-Layer, EPSG:25832).
Bestand steckt dort in mehreren Layern, jeweils mit eigenem Kennzeichen (Befund Witten Heven 18.09.2026):
  "Verwendbare Trassen"  TYPE EXISTINGPIPE  = Bestandsrohr (22.375 Stuecke, 143 km). DUCT_CLASS = Rohrklasse (kkr110_*, snr_*, mr_*, kkf, common),
                         MAX_DUCTS = frei einziehbare Rohre laut Comsof (1/2/3, -1 unbekannt), PLACE_DUCT F = kein Rohr einziehbar (nur Kabel
                         einblasen, Speednet-Rohr 8 mm), MAX_DIAM = Innendurchmesser mm, SUBTYPE ("KKR 110"), MP_ID = Megaplan-ID,
                         STREETTYPE, TREE_CROWN/NATURE_RES/WATER_PROT als Hinweise. KABELLINIE ist an Rohren leer.
                         TYPE EXISTINGCABLE = Bestandskabel (4.872, 33 km): KABELLINIE, SPEC_NAME (Kabeltyp), MAX_FIBERS = freie Fasern.
                         TYPE TRANSITION    = Anschlussstueck Schacht -> Rohr (0-30 m), traegt die Topologie (SOURCE_ID/TARGET_ID).
  "Verwendete Trassen"   Comsof-Ergebnis; dieselben IDs -> welche Bestandsrohre/-kabel der Comsof-Plan wirklich nutzt (genutzt).
  "Strukturpunkte/Ausrüstungen"  EXISTING True = Bestandspunkt: HandHole (Zugschacht), ManHole (begehbarer Schacht), Pole (Mast),
                         Cabinet (KVz/NVt Bestand, IDENTIFIER "NVt 17gr (Bestand)"), CentralOffice (HVt). LAYER = Comsof-Nutzung
                         (Feeder/Distribution/Drop/Not Used), MP_ID, GISTOOL_ID, DCT_PIECES (angeschlossene Rohrstuecke).
  "Muffen"               EXISTING True = Bestandsmuffe.       "Hauptkabel" TYPE EXISTING = vorhandenes Hauptkabel, das der Plan nutzt.
  "HVt"                  Betriebsstelle mit Adresse und KLS_ID.
Aufbereiten heisst: Linien zerlegen, Klartext statt Codes, Nutzbarkeit je Rohr, Laengen, Nutzung im Comsof-Plan, Zusammenhang des
Rohrnetzes (Komponenten ueber SOURCE_ID/TARGET_ID), Kennzahlen je Rohrklasse/Kabellinie/Punkttyp; Ausgabe GeoPackage bestand_<Stamm>_<Datum>.gpkg
+ Bericht (Markdown) + Liste (JSON fuer die Tabelle im Dialog). Nichts wird nach Plan[Goo] geschrieben (das ist Schritt 10).
"""
import json
import os
import re
import time
from datetime import datetime

import geopandas as gpd
import pandas as pd

CRS = 25832
LAYER_TRASSEN = "Verwendbare Trassen"
LAYER_VERWENDET = "Verwendete Trassen"
LAYER_PUNKTE = "Strukturpunkte/Ausrüstungen"
LAYER_MUFFEN = "Muffen"
LAYER_HK = "Hauptkabel"
LAYER_HVT = "HVt"

# Comsof-Rohrklasse -> Klartext (Zuordnung aus Durchmesser und Namen abgeleitet, Witten 18.09.2026 - ANNAHME, im Bericht gekennzeichnet)
ROHRKLASSE = {
    "kkr110_duct_type": "Kabelkanalrohr KKR 110",
    "kkr110_duct_type_40": "KKR 110 mit Innenrohr 40",
    "kkr110_duct_type_20": "KKR 110 mit Innenrohr 20",
    "snr_duct_type": "Speednet-Rohr 8 mm (nur Kabel einblasen)",
    "mr_duct_type_35": "Mikrorohr 35 mm",
    "mr_duct_type_25": "Mikrorohr 25 mm",
    "kkf_duct_type": "Kabelkanalformstein KKF",
    "common_duct_type": "Rohr (allgemein)",
}
PUNKTTYP = {"HandHole": "Kabelschacht (Zugschacht)", "ManHole": "Kabelschacht (begehbar)", "Pole": "Mast (Freileitung)",
            "Cabinet": "KVz / NVt Bestand", "CentralOffice": "HVt / Betriebsstelle", "AccessStructure": "Zugangsstruktur"}
NUTZUNG_COMSOF = {"Feeder": "Hauptkabel", "Distribution": "Verteilkabel (Vzk)", "Drop": "Hauszufuehrung", "Not Used": "nicht genutzt",
                  "Demand": "Bedarfspunkt"}
NUTZBAR_ROHR = "Rohr einziehbar"
NUTZBAR_KABEL = "nur Kabel einblasen"
NUTZBAR_UNBEKANNT = "Kapazitaet unbekannt"
NUTZBAR_VOLL = "kein freies Rohr"


def rohrklasse(code, innen_mm=None):
    """Comsof-DUCT_CLASS -> Klartext. Muster: <familie>_duct_type[_<innenrohr mm>]; Familien kkr110 (Kabelkanalrohr 110), kkr50, kkf
    (Kabelkanalformstein), snr (Speednet-Rohr 8 mm, nur Kabel einblasen), mr (Mikrorohr <mm>), common (Rohr allgemein). ANNAHME."""
    c = _s(code)
    if not c:
        return "unbekannt"
    if c in ROHRKLASSE:
        return ROHRKLASSE[c]
    m = re.match(r"^(kkr\d+|kkf|snr|mr|common)_duct_type(?:_(\d+))?$", c)
    if not m:
        return c
    fam, mm = m.group(1), m.group(2)
    if fam.startswith("kkr"):
        basis = "Kabelkanalrohr KKR {}".format(fam[3:])
        return "KKR {} mit Innenrohr {}".format(fam[3:], mm) if mm else basis
    if fam == "kkf":
        return "KKF mit Innenrohr {}".format(mm) if mm else "Kabelkanalformstein KKF"
    if fam == "snr":
        return "Speednet-Rohr 8 mm (nur Kabel einblasen)"
    if fam == "mr":
        return "Mikrorohr {} mm".format(mm or (int(innen_mm) if innen_mm and not pd.isna(innen_mm) else "?"))
    return "Rohr (allgemein)"


def ist_fpf_export(pfad):
    """True, wenn die Datei den Comsof-Trassenlayer enthaelt."""
    try:
        import pyogrio
        return LAYER_TRASSEN in set(pyogrio.list_layers(pfad)[:, 0])
    except Exception:
        return False


def stamm(pfad):
    s = os.path.splitext(os.path.basename(str(pfad)))[0]
    for w in ("_extern", "-extern", "extern_"):
        s = s.replace(w, "")
    return s.strip("_") or "fpf"


def _lesen(pfad, layer, log):
    try:
        g = gpd.read_file(pfad, layer=layer)
    except Exception as e:
        log("  Layer {!r} nicht gelesen: {!r}".format(layer, e))
        return gpd.GeoDataFrame(geometry=[], crs="EPSG:{}".format(CRS))
    if g.crs is None:
        g = g.set_crs("EPSG:{}".format(CRS), allow_override=True)
    elif g.crs.to_epsg() != CRS:
        g = g.to_crs(CRS)
    return g


def _linien(g):
    if not len(g):
        return g
    g = g.explode(index_parts=False, ignore_index=True)
    g = g[g.geometry.notna() & (g.geometry.length > 0.005)].reset_index(drop=True)
    return g


from ... import gemeinsam
_s = gemeinsam.s_oder_none


def _flag(v):
    return str(v).strip().lower() in ("true", "t", "1", "ja")


def _nutzbarkeit(max_ducts, place_duct):
    if not place_duct:
        return NUTZBAR_KABEL
    if max_ducts is None or pd.isna(max_ducts) or int(max_ducts) < 0:
        return NUTZBAR_UNBEKANNT
    if int(max_ducts) == 0:
        return NUTZBAR_VOLL
    return NUTZBAR_ROHR


PFAD_GRENZE = 240
AUSWEICH_ORDNER = os.path.join(os.path.expanduser("~"), "PlanGoo", "Werkzeugkasten")


def ausgabe_pfad(out_dir, dateiname, log=print):
    """Wie dateiwahl.ausgabe_pfad, ohne Qt: zu lange Pfade (Windows 259) wandern in den kurzen lokalen Ordner."""
    voll = os.path.join(out_dir, dateiname)
    if len(voll) <= PFAD_GRENZE:
        return voll
    os.makedirs(AUSWEICH_ORDNER, exist_ok=True)
    kurz = os.path.join(AUSWEICH_ORDNER, dateiname)
    log("ACHTUNG: Ausgabepfad zu lang ({} Zeichen, Windows-Grenze 259) - Ausgabe stattdessen unter {}".format(len(voll), kurz))
    return kurz


QUELLE_TEXT = {"fpf": "FPF-Extern-Export (Comsof)", "plangoo": "Plan[Goo]-Projekt", "megaplan": "MegaPlan-Export Rohranlage (Trassennetz)",
               "comsof_in": "Comsof-Rohrliste IN_ExistingPipes"}


def quelle_art(pfad):
    """'fpf' (Comsof-Extern-Export), 'plangoo' (Plan[Goo]-Projekt mit .db daneben), 'megaplan' (MegaPlan-Export Rohranlage),
    'comsof_in' (Comsof-Eingabe IN_ExistingPipes als Shape oder Zip) oder None."""
    pfad = str(pfad)
    if not os.path.exists(pfad):
        return None
    if pfad.lower().endswith(".gpkg") and ist_fpf_export(pfad):
        return "fpf"
    from . import plangoo as pg
    if pfad.lower().endswith(".gpkg") and pg.ist_plangoo_projekt(pfad):
        return "plangoo"
    from . import telekom
    if telekom.ist_megaplan_rohranlage(pfad):
        return "megaplan"
    if telekom.ist_comsof_eingabe_rohre(pfad):
        return "comsof_in"
    return None


def aufbereiten(pfad, out_dir=None, log=print, fortschritt=None, mit_kabeln=True, mit_punkten=True, mit_anschluss=False, alles=False, rohre_pfad=None):
    """Bestand aus einem FPF-Extern-Export, einem Plan[Goo]-Projekt, einem MegaPlan-Export Rohranlage (dazu optional rohre_pfad = Comsof-Rohrliste)
    oder einer Comsof-Rohrliste IN_ExistingPipes herausziehen und aufbereitet als GeoPackage + Bericht + Liste schreiben.
    -> dict (gpkg, bericht, liste, stamm, quelle_art, Zahlen, kennzahlen)"""
    pfad = str(pfad)
    if not os.path.exists(pfad):
        raise FileNotFoundError(pfad)
    art = quelle_art(pfad)
    if art == "fpf":
        return _aus_fpf(pfad, out_dir, log, fortschritt, mit_kabeln, mit_punkten, mit_anschluss)
    if art == "plangoo":
        return _aus_plangoo(pfad, out_dir, log, fortschritt, mit_punkten, alles)
    from . import telekom
    if art == "megaplan":
        return telekom.aus_megaplan(pfad, out_dir, log, fortschritt, rohre_pfad=rohre_pfad)
    if art == "comsof_in":
        return telekom.aus_comsof_eingabe(pfad, out_dir, log, fortschritt)
    from . import plangoo as pg
    if os.path.basename(pfad).lower().startswith("plgov2") and not os.path.exists(pg.db_pfad(pfad)):
        raise ValueError("Plan[Goo]-Projekt ohne Datenbank: neben {} fehlt die Datei {}".format(os.path.basename(pfad), os.path.basename(pg.db_pfad(pfad))))
    raise ValueError("Keine bekannte Bestandsquelle in {}: weder Comsof-Layer '{}' (FPF-Extern-Export), noch Plan[Goo]-Layer GEOMETRY_LINE mit .db daneben, "
                     "noch MegaPlan-Rohranlage (UNDERGROUND_ROUTE_TYPE), noch Comsof-Rohrliste (DUCT_CLASS/MAX_DUCTS)".format(os.path.basename(pfad), LAYER_TRASSEN))


def _aus_fpf(pfad, out_dir, log, fortschritt, mit_kabeln, mit_punkten, mit_anschluss):
    """FPF-Extern-Export (Comsof) -> Bestand."""
    t0 = time.time()
    f = fortschritt or (lambda p, t: None)
    out_dir = out_dir or os.path.dirname(pfad)
    os.makedirs(out_dir, exist_ok=True)
    st = stamm(pfad)
    gpkg = ausgabe_pfad(out_dir, "bestand_{}_{}.gpkg".format(st, datetime.now().strftime("%Y%m%d_%H%M")), log)
    out_dir = os.path.dirname(gpkg)

    # --- Trassen -------------------------------------------------------------------------------------------------------------------
    f(5, "Trassen lesen")
    tr = _lesen(pfad, LAYER_TRASSEN, log)
    typ = tr["TYPE"].astype(str) if "TYPE" in tr else pd.Series([""] * len(tr))
    log("Verwendbare Trassen: {} Stuecke, davon Bestandsrohre {}, Bestandskabel {}, Anschlussstuecke {}".format(
        len(tr), int((typ == "EXISTINGPIPE").sum()), int((typ == "EXISTINGCABLE").sum()), int((typ == "TRANSITION").sum())))
    f(20, "Comsof-Nutzung")
    vw = _lesen(pfad, LAYER_VERWENDET, log)
    genutzt_ids = set(vw["ID"].dropna().astype(int).tolist()) if len(vw) and "ID" in vw else set()

    def spalte(g, name, default=None):
        return g[name] if name in g else pd.Series([default] * len(g), index=g.index)

    # Rohre
    f(30, "Bestandsrohre aufbereiten")
    r = tr[typ == "EXISTINGPIPE"].copy()
    rohre = gpd.GeoDataFrame({
        "quelle_id": "fpf:" + spalte(r, "ID").astype(str),
        "fpf_id": pd.to_numeric(spalte(r, "ID"), errors="coerce"),
        "gistool_id": spalte(r, "GISTOOL_ID").map(_s),
        "mp_id": spalte(r, "MP_ID").map(_s),
        "rohrklasse": [rohrklasse(c, d) for c, d in zip(spalte(r, "DUCT_CLASS"), pd.to_numeric(spalte(r, "MAX_DIAM"), errors="coerce"))],
        "rohrklasse_code": spalte(r, "DUCT_CLASS").map(_s),
        "subtyp": spalte(r, "SUBTYPE").map(_s),
        "freie_rohre": pd.to_numeric(spalte(r, "MAX_DUCTS"), errors="coerce"),
        "rohr_einziehbar": spalte(r, "PLACE_DUCT").map(_flag),
        "innen_mm": pd.to_numeric(spalte(r, "MAX_DIAM"), errors="coerce"),
        "max_kabel": spalte(r, "MAX_CABLES").map(_s),
        "strassentyp": spalte(r, "STREETTYPE").map(_s),
        "baumkrone": spalte(r, "TREE_CROWN").map(_flag),
        "naturschutz": spalte(r, "NATURE_RES").map(_flag),
        "wasserschutz": spalte(r, "WATER_PROT").map(_flag),
        "source_id": pd.to_numeric(spalte(r, "SOURCE_ID"), errors="coerce"),
        "target_id": pd.to_numeric(spalte(r, "TARGET_ID"), errors="coerce"),
    }, geometry=r.geometry, crs=r.crs)
    rohre["nutzbarkeit"] = [_nutzbarkeit(a, b) for a, b in zip(rohre["freie_rohre"], rohre["rohr_einziehbar"])]
    rohre["genutzt"] = rohre["fpf_id"].isin(genutzt_ids)
    rohre = _linien(rohre)
    rohre["laenge_m"] = rohre.geometry.length.round(1)
    rohre["freie_rohre"] = rohre["freie_rohre"].where(rohre["freie_rohre"] >= 0)   # -1 -> NULL = unbekannt
    log("Bestandsrohre: {} Stuecke, {:.1f} km, davon im Comsof-Plan genutzt {:.1f} km".format(
        len(rohre), rohre["laenge_m"].sum() / 1000, rohre.loc[rohre["genutzt"], "laenge_m"].sum() / 1000))

    # Kabel
    kabel = gpd.GeoDataFrame(geometry=[], crs=r.crs)
    if mit_kabeln:
        f(45, "Bestandskabel aufbereiten")
        k = tr[typ == "EXISTINGCABLE"].copy()
        kabel = gpd.GeoDataFrame({
            "quelle_id": "fpf:" + spalte(k, "ID").astype(str),
            "fpf_id": pd.to_numeric(spalte(k, "ID"), errors="coerce"),
            "gistool_id": spalte(k, "GISTOOL_ID").map(_s),
            "mp_id": spalte(k, "MP_ID").map(_s),
            "kabellinie": spalte(k, "KABELLINIE").map(_s),
            "kabeltyp": spalte(k, "SPEC_NAME").map(_s),
            "freie_fasern": pd.to_numeric(spalte(k, "MAX_FIBERS"), errors="coerce"),
            "strassentyp": spalte(k, "STREETTYPE").map(_s),
            "source_id": pd.to_numeric(spalte(k, "SOURCE_ID"), errors="coerce"),
            "target_id": pd.to_numeric(spalte(k, "TARGET_ID"), errors="coerce"),
        }, geometry=k.geometry, crs=k.crs)
        kabel["genutzt"] = kabel["fpf_id"].isin(genutzt_ids)
        kabel = _linien(kabel)
        kabel["laenge_m"] = kabel.geometry.length.round(1)
        kabel["freie_fasern"] = kabel["freie_fasern"].where(kabel["freie_fasern"] >= 0)
        log("Bestandskabel: {} Stuecke, {:.1f} km, {} Kabellinien".format(len(kabel), kabel["laenge_m"].sum() / 1000, kabel["kabellinie"].nunique()))

    # Anschlussstuecke (Topologie Schacht -> Rohr)
    a = tr[typ == "TRANSITION"].copy()
    anschluss = gpd.GeoDataFrame({
        "quelle_id": "fpf:" + spalte(a, "ID").astype(str),
        "fpf_id": pd.to_numeric(spalte(a, "ID"), errors="coerce"),
        "source_id": pd.to_numeric(spalte(a, "SOURCE_ID"), errors="coerce"),
        "target_id": pd.to_numeric(spalte(a, "TARGET_ID"), errors="coerce"),
    }, geometry=a.geometry, crs=a.crs)
    anschluss["genutzt"] = anschluss["fpf_id"].isin(genutzt_ids)
    anschluss_linien = _linien(anschluss)
    if len(anschluss_linien):
        anschluss_linien["laenge_m"] = anschluss_linien.geometry.length.round(1)

    # --- Zusammenhang des Rohrnetzes -------------------------------------------------------------------------------------------------
    f(55, "Rohrnetz pruefen")
    netz = _komponenten(rohre, anschluss, log)

    # --- Punkte -----------------------------------------------------------------------------------------------------------------------
    punkte = gpd.GeoDataFrame(geometry=[], crs=r.crs)
    muffen = gpd.GeoDataFrame(geometry=[], crs=r.crs)
    if mit_punkten:
        f(65, "Bestandspunkte")
        sp = _lesen(pfad, LAYER_PUNKTE, log)
        if len(sp) and "EXISTING" in sp:
            e = sp[sp["EXISTING"].map(_flag)].copy()
            punkte = gpd.GeoDataFrame({
                "quelle_id": "fpf:" + spalte(e, "ID").astype(str),
                "typ": spalte(e, "TYPE").map(lambda v: PUNKTTYP.get(_s(v), _s(v) or "unbekannt")),
                "typ_code": spalte(e, "TYPE").map(_s),
                "bezeichnung": spalte(e, "IDENTIFIER").map(_s),
                "label": spalte(e, "LABEL").map(_s),
                "comsof_nutzung": spalte(e, "LAYER").map(lambda v: NUTZUNG_COMSOF.get(_s(v), _s(v))),
                "genutzt": spalte(e, "LAYER").map(lambda v: _s(v) not in (None, "Not Used")),
                "mp_id": spalte(e, "MP_ID").map(_s),
                "gistool_id": spalte(e, "GISTOOL_ID").map(_s),
                "rohrstuecke": spalte(e, "DCT_PIECES").map(_s),
                "strasse": spalte(e, "STRASSE").map(_s),
                "hnr": spalte(e, "HNR").map(_s),
                "kls_id": spalte(e, "KLS_ID").map(_s),
            }, geometry=e.geometry, crs=e.crs)
            punkte = punkte[punkte.geometry.notna()].reset_index(drop=True)
            log("Bestandspunkte: {} ({})".format(len(punkte), ", ".join("{} {}".format(v, k) for k, v in punkte["typ"].value_counts().items())))
        mu = _lesen(pfad, LAYER_MUFFEN, log)
        if len(mu) and "EXISTING" in mu:
            m = mu[mu["EXISTING"].map(_flag)].copy()
            muffen = gpd.GeoDataFrame({
                "quelle_id": "fpf:" + spalte(m, "ID").astype(str),
                "comsof_nutzung": spalte(m, "LAYER").map(lambda v: NUTZUNG_COMSOF.get(_s(v), _s(v))),
                "genutzt": spalte(m, "LAYER").map(lambda v: _s(v) not in (None, "Not Used")),
                "mp_id": spalte(m, "MP_ID").map(_s) if "MP_ID" in m else None,
                "gistool_id": spalte(m, "GISTOOL_ID").map(_s),
                "label": spalte(m, "LABEL").map(_s),
            }, geometry=m.geometry, crs=m.crs)
            muffen = muffen[muffen.geometry.notna()].reset_index(drop=True)
            log("Bestandsmuffen: {}".format(len(muffen)))

    # --- Hauptkabel Bestand, HVt ----------------------------------------------------------------------------------------------------
    f(75, "Hauptkabel und HVt")
    hk = _lesen(pfad, LAYER_HK, log)
    hk_best = gpd.GeoDataFrame(geometry=[], crs=r.crs)
    if len(hk) and "TYPE" in hk:
        h = hk[hk["TYPE"].astype(str) == "EXISTING"].copy()
        hk_best = gpd.GeoDataFrame({
            "quelle_id": "fpf:hk:" + spalte(h, "CABLE_ID").astype(str),
            "fasern": pd.to_numeric(spalte(h, "CABLEGRAN"), errors="coerce"),
            "kabeltyp": spalte(h, "IDENTIFIER").map(_s),
            "label": spalte(h, "LABEL").map(_s),
        }, geometry=h.geometry, crs=h.crs)
        hk_best = _linien(hk_best)
        if len(hk_best):
            hk_best["laenge_m"] = hk_best.geometry.length.round(1)
            hk_best["fasern"] = hk_best["fasern"].where(hk_best["fasern"] >= 0)
        log("Vorhandene Hauptkabel im Plan: {} Stuecke, {:.1f} km".format(len(hk_best), hk_best["laenge_m"].sum() / 1000 if len(hk_best) else 0))
    hvt = _lesen(pfad, LAYER_HVT, log)
    hvt_out = gpd.GeoDataFrame(geometry=[], crs=r.crs)
    if len(hvt):
        hvt_out = gpd.GeoDataFrame({
            "label": spalte(hvt, "LABEL").map(_s),
            "kls_id": spalte(hvt, "KLS_ID").map(_s),
            "strasse": spalte(hvt, "STRASSE").map(_s),
            "hnr": spalte(hvt, "HNR").map(_s),
            "gemeinde": spalte(hvt, "GEMEINDE").map(_s),
            "mp_id": spalte(hvt, "MP_ID").map(_s),
            "fasern_aus": pd.to_numeric(spalte(hvt, "FIBER_OUT"), errors="coerce"),
            "haushalte": pd.to_numeric(spalte(hvt, "HOMECOUNT"), errors="coerce"),
        }, geometry=hvt.geometry, crs=hvt.crs)

    # --- Schreiben --------------------------------------------------------------------------------------------------------------------
    f(85, "GeoPackage schreiben")
    geschrieben = []
    for name, g in (("bestand_rohre", rohre), ("bestand_kabel", kabel), ("bestand_anschluss", anschluss_linien if mit_anschluss else anschluss_linien.iloc[0:0]),
                    ("bestand_punkte", punkte), ("bestand_muffen", muffen), ("bestand_hauptkabel", hk_best), ("hvt", hvt_out)):
        if not len(g):
            continue
        g = g.copy()
        for col in g.columns:
            if col != "geometry" and g[col].dtype == object:
                g[col] = g[col].map(_s)
            elif col != "geometry" and str(g[col].dtype) == "bool":
                g[col] = g[col].astype(int)
        g.to_file(gpkg, layer=name, driver="GPKG")
        geschrieben.append(name)

    # --- Kennzahlen -----------------------------------------------------------------------------------------------------------------
    f(92, "Kennzahlen")
    liste = kennzahlen(rohre, kabel, punkte, muffen, hk_best, netz)
    liste_pfad = os.path.splitext(gpkg)[0] + "_liste.json"
    with open(liste_pfad, "w", encoding="utf-8") as fh:
        json.dump({"quelle": pfad, "stamm": st, "layer": geschrieben, **liste}, fh, indent=1, ensure_ascii=False)
    bericht = _bericht(gpkg, pfad, liste, netz, time.time() - t0)
    f(100, "Fertig")
    return {"gpkg": gpkg, "bericht": bericht, "liste": liste_pfad, "stamm": st, "out_dir": out_dir, "layer": geschrieben, "quelle_art": "fpf",
            "rohre": len(rohre), "rohre_km": round(rohre["laenge_m"].sum() / 1000, 1) if len(rohre) else 0.0,
            "kabel": len(kabel), "kabel_km": round(kabel["laenge_m"].sum() / 1000, 1) if len(kabel) else 0.0,
            "punkte": len(punkte), "muffen": len(muffen), "hauptkabel": len(hk_best), "netz": netz, "kennzahlen": liste}


def _aus_plangoo(pfad, out_dir, log, fortschritt, mit_punkten, alles=False):
    """Plan[Goo]-Projekt (GeoPackage + .db) -> Bestand: Bestandstrassen mit ihren Rohren, Rohrzuege je Bestandsrohr, Bestandspunkte.
    alles=True: das ganze Projekt gilt als Bestand (gebautes Netz), zusaetzlich Layer bestand_apl (versorgte Adressen)."""
    from . import plangoo as pg
    t0 = time.time()
    f = fortschritt or (lambda p, t: None)
    out_dir = out_dir or os.path.dirname(pfad)
    os.makedirs(out_dir, exist_ok=True)
    st = pg.stamm(pfad)
    gpkg = ausgabe_pfad(out_dir, "bestand_{}_{}.gpkg".format(st, datetime.now().strftime("%Y%m%d_%H%M")), log)
    out_dir = os.path.dirname(gpkg)
    log("Bestand = {}".format("das ganze Projekt (gebautes Netz)" if alles else "Objekte mit Bestandskennzeichen (Megaplan-Import)"))
    d = pg.laden(pfad, log=log, fortschritt=f, alles=alles)
    rohre, rohrzuege = d["rohre"], d["rohrzuege"]
    apl = d.get("apl")
    leer = gpd.GeoDataFrame(geometry=[], crs="EPSG:{}".format(CRS))
    punkte = d["punkte"] if mit_punkten else leer
    f(80, "Rohrnetz pruefen")
    netz = _komponenten_geom(rohre, log)
    f(88, "GeoPackage schreiben")
    geschrieben = []
    for name, g in (("bestand_rohre", rohre), ("bestand_rohrzuege", rohrzuege), ("bestand_punkte", punkte), ("bestand_apl", apl)):
        if g is None or not len(g):
            continue
        g = g.copy()
        for col in g.columns:
            if col == "geometry":
                continue
            if str(g[col].dtype) == "bool":
                g[col] = g[col].astype(int)
            elif g[col].dtype == object:
                g[col] = g[col].map(_s)
        g.to_file(gpkg, layer=name, driver="GPKG")
        geschrieben.append(name)
    f(94, "Kennzahlen")
    liste = kennzahlen(rohre, leer, punkte, leer, leer, netz)
    if len(rohrzuege):
        for kl, g in rohrzuege.groupby("rohrklasse"):
            liste["zeilen"].append({"gruppe": "Rohrzuege", "art": kl, "anzahl": int(len(g)), "laenge_km": round(g["laenge_m"].sum() / 1000, 2),
                                    "genutzt_km": round(g.loc[g["genutzt"], "laenge_m"].sum() / 1000, 2),
                                    "frei": "{} mit neuem Innenrohr".format(int(g["genutzt"].sum())), "layer": "bestand_rohrzuege", "feld": "rohrklasse"})
    liste["summe"]["rohrzuege"] = int(len(rohrzuege))
    liste["summe"]["rohrzuege_genutzt"] = int(rohrzuege["genutzt"].sum()) if len(rohrzuege) else 0
    liste["summe"]["alles"] = bool(alles)
    if apl is not None and len(apl):
        liste["summe"]["apl"] = int(len(apl))
        for z, g in apl.groupby(apl["ausbauzustand"].fillna("ohne Zustand")):
            liste["zeilen"].append({"gruppe": "Adressen", "art": "APL {}".format(z), "anzahl": int(len(g)), "laenge_km": None, "genutzt_km": None,
                                    "frei": "{} WE".format(int(pd.to_numeric(g["we"], errors="coerce").fillna(0).sum())), "layer": "bestand_apl", "feld": "ausbauzustand"})
    liste_pfad = os.path.splitext(gpkg)[0] + "_liste.json"
    with open(liste_pfad, "w", encoding="utf-8") as fh:
        json.dump({"quelle": pfad, "stamm": st, "layer": geschrieben, "quelle_art": "plangoo", **liste}, fh, indent=1, ensure_ascii=False)
    hinweise = [
        ("- Quelle ist ein Plan[Goo]-Projekt, Modus GANZES PROJEKT: alle Trassen, Hauptrohre, Bauwerke und versorgten APL gelten als Bestand "
         "(gebautes Netz); das Bestandskennzeichen aus dem Megaplan-Import steht in trasse_markiert / rohr_markiert / punkt_markiert." if alles else
         "- Quelle ist ein Plan[Goo]-Projekt: Bestand = Objekte mit IS_EXTERNAL_OBJECT (aus dem Megaplan-As-built-Import), Megaplan-ID in mp_id."),
        "- **Bestandstrassen** (Layer Bestandsrohre) tragen die Bestandsrohre, die darueber laufen; **Rohrzuege** ist dasselbe je Bestandsrohr als eine Linie.",
        "- **genutzt** = auf der Trasse liegt ein neues Rohr bzw. im Bestandsrohr steckt ein neues Innenrohr; bei Punkten: neues Rohr angeschlossen.",
        "- **Nutzbarkeit** aus dem Materialkatalog: Rohr einziehbar = Material erlaubt Innenrohre (KKR), nur Kabel einblasen = Mikrorohr, "
        "Speednet unbekannt (ubk.) = Kapazitaet unbekannt. Freie Rohre kennt Plan[Goo] nicht.",
        "- Plan[Goo] V2 fuehrt keine Kabel als Objekte; Bestandskabel gibt es nur aus dem FPF-Extern-Export (Comsof).",
        "- Rohrenden (Typ ra) sind Hilfspunkte des Bestandsrohrs, keine Bauwerke.",
        "- Materialkatalog des Plan[Goo]-Plugins {}gefunden.".format("" if d.get("materialkatalog") else "NICHT "),
    ]
    bericht = _bericht(gpkg, pfad, liste, netz, time.time() - t0, quelle_text="Plan[Goo]-Projekt (IS_EXTERNAL_OBJECT an Trassen, Rohren und Punkten)",
                       hinweise=hinweise)
    f(100, "Fertig")
    return {"gpkg": gpkg, "bericht": bericht, "liste": liste_pfad, "stamm": st, "out_dir": out_dir, "layer": geschrieben, "quelle_art": "plangoo",
            "rohre": len(rohre), "rohre_km": round(rohre["laenge_m"].sum() / 1000, 1) if len(rohre) else 0.0,
            "kabel": 0, "kabel_km": 0.0, "punkte": len(punkte), "muffen": 0, "hauptkabel": 0, "rohrzuege": len(rohrzuege),
            "apl": int(len(apl)) if apl is not None else 0, "alles": alles, "netz": netz, "kennzahlen": liste}


def _komponenten_geom(linien, log, toleranz=0.05):
    """Zusammenhang ueber die Linienenden (fuer Quellen ohne Knoten-IDs): Enden im Abstand < toleranz gelten als ein Knoten."""
    out = {"komponenten": 0, "groesste_anteil": 0.0, "inseln": 0, "ohne_knoten": 0}
    if not len(linien):
        return out
    try:
        import networkx as nx
    except Exception:
        log("networkx fehlt - Zusammenhang nicht geprueft")
        return out
    G = nx.Graph()
    k = 1.0 / toleranz
    for geom in linien.geometry:
        c = list(geom.coords)
        a = (round(c[0][0] * k), round(c[0][1] * k))
        b = (round(c[-1][0] * k), round(c[-1][1] * k))
        if G.has_edge(a, b):
            G[a][b]["l"] += geom.length
        else:
            G.add_edge(a, b, l=geom.length)
    komp = list(nx.connected_components(G))
    laengen = [sum(d["l"] for _, _, d in G.subgraph(c).edges(data=True)) for c in komp]
    gesamt = sum(laengen) or 1.0
    out = {"komponenten": len(komp), "groesste_anteil": round(max(laengen) / gesamt * 100, 1), "inseln": sum(1 for l in laengen if l < 50),
           "ohne_knoten": 0, "gesamt_m": round(gesamt)}
    log("Rohrnetz: {} zusammenhaengende Teile, groesstes {} % der Laenge, {} Inseln unter 50 m".format(out["komponenten"], out["groesste_anteil"], out["inseln"]))
    return out


def _komponenten(rohre, anschluss, log):
    """Zusammenhang des Bestandsrohrnetzes ueber die Comsof-Knoten (SOURCE_ID/TARGET_ID) - Inseln deuten auf Luecken im Export."""
    out = {"komponenten": 0, "groesste_anteil": 0.0, "inseln": 0, "ohne_knoten": 0}
    try:
        import networkx as nx
    except Exception:
        log("networkx fehlt - Zusammenhang nicht geprueft")
        return out
    G = nx.Graph()
    ohne = 0
    for g in (rohre, anschluss):
        if not len(g):
            continue
        for s, t, l in zip(g["source_id"], g["target_id"], g.geometry.length if "laenge_m" not in g else g["laenge_m"]):
            if pd.isna(s) or pd.isna(t):
                ohne += 1
                continue
            G.add_edge(int(s), int(t), l=float(l))
    if not G.number_of_edges():
        return out
    komp = list(nx.connected_components(G))
    laengen = []
    for c in komp:
        sub = G.subgraph(c)
        laengen.append(sum(d["l"] for _, _, d in sub.edges(data=True)))
    gesamt = sum(laengen) or 1.0
    out = {"komponenten": len(komp), "groesste_anteil": round(max(laengen) / gesamt * 100, 1), "inseln": sum(1 for l in laengen if l < 50),
           "ohne_knoten": ohne, "gesamt_m": round(gesamt)}
    log("Rohrnetz: {} zusammenhaengende Teile, groesstes {} % der Laenge, {} Inseln unter 50 m".format(out["komponenten"], out["groesste_anteil"], out["inseln"]))
    return out


def kennzahlen(rohre, kabel, punkte, muffen, hk_best, netz):
    """Tabellen fuer Dialog und Bericht: je Rohrklasse, je Nutzbarkeit, je Kabellinie, je Punkttyp."""
    zeilen = []
    if len(rohre):
        for kl, g in rohre.groupby("rohrklasse"):
            zeilen.append({"gruppe": "Rohre", "art": kl, "anzahl": int(len(g)), "laenge_km": round(g["laenge_m"].sum() / 1000, 2),
                           "genutzt_km": round(g.loc[g["genutzt"], "laenge_m"].sum() / 1000, 2),
                           "frei": _frei_text(g["freie_rohre"]), "layer": "bestand_rohre", "feld": "rohrklasse"})
        for nb, g in rohre.groupby("nutzbarkeit"):
            zeilen.append({"gruppe": "Nutzbarkeit", "art": nb, "anzahl": int(len(g)), "laenge_km": round(g["laenge_m"].sum() / 1000, 2),
                           "genutzt_km": round(g.loc[g["genutzt"], "laenge_m"].sum() / 1000, 2), "frei": _frei_text(g["freie_rohre"]),
                           "layer": "bestand_rohre", "feld": "nutzbarkeit"})
    if len(kabel):
        for kl, g in kabel.groupby(kabel["kabellinie"].fillna("ohne Kabellinie")):
            zeilen.append({"gruppe": "Kabel", "art": kl, "anzahl": int(len(g)), "laenge_km": round(g["laenge_m"].sum() / 1000, 2),
                           "genutzt_km": round(g.loc[g["genutzt"], "laenge_m"].sum() / 1000, 2),
                           "frei": _frei_text(g["freie_fasern"], "Fasern"), "layer": "bestand_kabel", "feld": "kabellinie"})
    if len(punkte):
        for tp, g in punkte.groupby("typ"):
            zeilen.append({"gruppe": "Punkte", "art": tp, "anzahl": int(len(g)), "laenge_km": None, "genutzt_km": None,
                           "frei": "{} im Plan genutzt".format(int(g["genutzt"].sum())), "layer": "bestand_punkte", "feld": "typ"})
    if len(muffen):
        zeilen.append({"gruppe": "Punkte", "art": "Muffe (Bestand)", "anzahl": int(len(muffen)), "laenge_km": None, "genutzt_km": None,
                       "frei": "{} im Plan genutzt".format(int(muffen["genutzt"].sum())), "layer": "bestand_muffen", "feld": None})
    if len(hk_best):
        zeilen.append({"gruppe": "Hauptkabel", "art": "vorhandenes Hauptkabel im Plan", "anzahl": int(len(hk_best)),
                       "laenge_km": round(hk_best["laenge_m"].sum() / 1000, 2), "genutzt_km": round(hk_best["laenge_m"].sum() / 1000, 2),
                       "frei": "", "layer": "bestand_hauptkabel", "feld": None})
    return {"zeilen": zeilen, "netz": netz,
            "summe": {"rohre": int(len(rohre)), "rohre_km": round(rohre["laenge_m"].sum() / 1000, 1) if len(rohre) else 0.0,
                      "rohre_genutzt_km": round(rohre.loc[rohre["genutzt"], "laenge_m"].sum() / 1000, 1) if len(rohre) else 0.0,
                      "kabel": int(len(kabel)), "kabel_km": round(kabel["laenge_m"].sum() / 1000, 1) if len(kabel) else 0.0,
                      "kabel_genutzt_km": round(kabel.loc[kabel["genutzt"], "laenge_m"].sum() / 1000, 1) if len(kabel) else 0.0,
                      "punkte": int(len(punkte)), "punkte_genutzt": int(punkte["genutzt"].sum()) if len(punkte) else 0,
                      "muffen": int(len(muffen)), "hauptkabel": int(len(hk_best))}}


def _frei_text(s, einheit="Rohre"):
    s = pd.to_numeric(s, errors="coerce").dropna()
    if not len(s):
        return "unbekannt"
    lo, hi = int(s.min()), int(s.max())
    return "{} {}".format(lo if lo == hi else "{}-{}".format(lo, hi), einheit)


def _bericht(gpkg, quelle, liste, netz, dauer, quelle_text=None, hinweise=None):
    p = os.path.splitext(gpkg)[0] + "_bericht.md"
    su = liste["summe"]
    z = ["# Bestand - {}".format(os.path.basename(quelle)), "",
         "Stand {}, {:.0f} s. Quelle: {}.".format(datetime.now().strftime("%d.%m.%Y %H:%M"), dauer,
                                                  quelle_text or "FPF-Extern-Export (Comsof); Bestand = EXISTINGPIPE, EXISTINGCABLE, EXISTING an Punkten, Muffen, Hauptkabeln"), "",
         "## Summe",
         "- Bestandsrohre: {} Stuecke, {} km, davon im Plan genutzt {} km".format(su["rohre"], su["rohre_km"], su["rohre_genutzt_km"]),
         "- Bestandskabel: {} Stuecke, {} km, davon genutzt {} km".format(su["kabel"], su["kabel_km"], su["kabel_genutzt_km"]),
         "- Bestandspunkte: {} (davon {} im Plan genutzt), Bestandsmuffen: {}, vorhandene Hauptkabel im Plan: {}".format(
             su["punkte"], su["punkte_genutzt"], su["muffen"], su["hauptkabel"]),
         "- Rohrnetz: {} zusammenhaengende Teile, groesstes {} % der Laenge, {} Inseln unter 50 m, {} Stuecke ohne Knoten".format(
             netz.get("komponenten", 0), netz.get("groesste_anteil", 0), netz.get("inseln", 0), netz.get("ohne_knoten", 0)), ""]
    if "rohrzuege" in su:
        z.insert(len(z) - 1, "- Bestandsrohre als Rohrzuege: {}, davon {} mit neuem Innenrohr".format(su["rohrzuege"], su.get("rohrzuege_genutzt", 0)))
    if "apl" in su:
        z.insert(len(z) - 1, "- Versorgte Adressen (APL): {}".format(su["apl"]))
    if "trassen" in su:
        z.insert(len(z) - 1, "- Telekom-Trassen (MegaPlan): {} Stuecke, {} km, davon Rohrtrassen {} km, erdverlegte Kabel {} km{}".format(
            su["trassen"], su["trassen_km"], su["rohrtrassen_km"], su["erdverlegt_km"],
            "; Rohrtrassen OHNE Rohr in der Rohrliste {} km".format(su["rohrtrassen_ohne_rohr_km"]) if "rohrtrassen_ohne_rohr_km" in su else ""))
    for gruppe, titel in (("Trassen", "## Telekom-Trassen je Bestandsart"), ("Trassenart", "## Telekom-Trassen je Bauweise"),
                          ("Rohre", "## Bestandsrohre je Rohrklasse"), ("Rohrzuege", "## Bestandsrohre als Rohrzuege je Material"),
                          ("Nutzbarkeit", "## Bestandsrohre je Nutzbarkeit"), ("Buendel", "## Rohre je Trasse (Buendel)"),
                          ("Kabel", "## Bestandskabel je Kabellinie"), ("Punkte", "## Bestandspunkte"), ("Adressen", "## Versorgte Adressen"),
                          ("Hauptkabel", "## Hauptkabel")):
        zeilen = [r for r in liste["zeilen"] if r["gruppe"] == gruppe]
        if not zeilen:
            continue
        z += [titel, "", "| Art | Anzahl | Laenge km | genutzt km | frei |", "|---|---|---|---|---|"]
        for r in sorted(zeilen, key=lambda x: -(x["laenge_km"] or 0)):
            z.append("| {} | {} | {} | {} | {} |".format(r["art"], r["anzahl"], r["laenge_km"] if r["laenge_km"] is not None else "",
                                                      r["genutzt_km"] if r["genutzt_km"] is not None else "", r["frei"]))
        z.append("")
    z += ["## Lesehilfe und Fallstricke"]
    z += hinweise if hinweise else [
          "- **freie Rohre** = MAX_DUCTS aus Comsof: so viele Rohre lassen sich laut Telekom-Bestand noch einziehen; leer = unbekannt (-1).",
          "- **nur Kabel einblasen** = PLACE_DUCT F (Speednet-Rohr 8 mm): kein weiteres Rohr, aber ein Kabel einblasbar.",
          "- **genutzt** = das Stueck liegt auch in den 'Verwendeten Trassen', der Comsof-Plan nutzt es also schon.",
          "- Rohrklassen-Klartext (KKR 110, Mikrorohr 35/25, KKF) ist aus Code und Durchmesser abgeleitet - ANNAHME, Code steht in rohrklasse_code.",
          "- Kabellinien stehen nur an Bestandskabeln; Rohre tragen die Megaplan-ID (mp_id) fuer den Abgleich mit der Netzdokumentation.",
          "- Der Export enthaelt nur Bestand im Comsof-Arbeitsbereich; was der PTI nicht exportiert hat, fehlt hier auch.",
          "- Inseln im Rohrnetz sind meist Exportgrenzen oder fehlende Anschlussstuecke, keine echten Luecken."]
    z += ["", "GeoPackage: `{}`".format(os.path.basename(gpkg))]
    with open(p, "w", encoding="utf-8") as fh:
        fh.write("\n".join(z))
    return p
