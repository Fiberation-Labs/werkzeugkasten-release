# -*- coding: utf-8 -*-
"""Werkzeug 1 - Uebernahme der geprueften Adressen in das aktive Plan[Goo]-Projekt.

Zwei Faelle je Adresse (Schluessel KLS-ID, sonst Strasse + Hausnummer + Zusatz):
  * APL vorhanden: HH (= WE laut Liste), USTO (= Gewerbeeinheiten), P2P und Gebaeudenutzung (Plan[Goo]-BuildingType) setzen;
    Bauluecken bekommen die Begruendung "Bauluecke", rote Adressen "Pruefen".
  * APL fehlt: neuen APL mit Adresse anlegen (nur wenn gewaehlt), Lage = geprueft Koordinate der Liste.
Adressen mit status 'ignorieren' werden uebersprungen. Vorher Backup-Zip ueber die Plan[Goo]-Backup-Klasse.
Alles ueber die Plan[Goo]-API (GooPoint, GooAddress, GooAsb) wie in Plan[Goo]s eigener Adress-Massenbearbeitung.
"""
import importlib
import os
from datetime import datetime

from . import regeln

from ... import plangoo_api


M = "technik_plangoo_v2_vds_main"
BUILDING_ERLAUBT = {regeln.WOHNHAUS, regeln.GEWERBE, regeln.SCHULE, regeln.KRANKENHAUS, regeln.OEFFENTLICH}


def _m(name):
    return plangoo_api.modul(name)


def instanz():
    inst = _m("core.project.instance").GooInstances.get_active_instance()
    if inst is None:
        raise RuntimeError("Kein Plan[Goo]-Projekt geoeffnet.")
    return inst


def backup(inst, log=print):
    """Backup-Zip neben die Projektdatenbank. -> Pfad"""
    db, gp = inst.db_path, inst.gpkg_path
    Backup = _m("core.project.backup").Backup
    ziel = os.path.join(os.path.dirname(db), "{}_adressen_{}.zip".format(os.path.splitext(os.path.basename(gp))[0],
                                                                        datetime.now().strftime("%Y-%m-%d_%H-%M")))
    Backup.create_zip_backup(db, gp, ziel)
    log("Backup: " + ziel)
    return ziel


def _schluessel(kls, strasse, hnr, hnr_zs):
    k = str(kls or "").strip()
    if k.endswith(".0"):
        k = k[:-2]
    if k and k not in ("0", "None", "nan"):
        return "kls:" + k
    return "adr:{}|{}|{}".format(str(strasse or "").strip().lower(), str(hnr or "").strip(), str(hnr_zs or "").strip().lower())


def vorhandene_apl(inst, GooPoint):
    """-> dict Schluessel -> (feature, GooPoint oder None), Liste der GooPoints (fuer ASB)"""
    layer = inst.get_point_layer()
    apl = {}
    for f in layer.getFeatures():
        if str(f["TYPE"] or "") not in ("apl", "nap"):
            continue
        s = _schluessel(f["KLS_ID"], f["STRASSE"], f["HS_NR"], f["HS_NR_ZS"])
        apl.setdefault(s, f)
    return apl, layer


def uebernehmen(adr, attribute=True, neue_anlegen=False, nur_gruen_gelb=False, mit_backup=True, log=print, fortschritt=None):
    """-> dict(geaendert, angelegt, uebersprungen, fehler, backup). fortschritt(prozent, text) alle 20 Adressen."""
    f_ = fortschritt or (lambda p, t: None)
    f_(1, "Backup")
    from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY, QgsProject
    inst = instanz()
    comps = _m("core.components")
    GooPoint, GooAddress, GooAsb = comps.GooPoint, comps.GooAddress, comps.GooAsb
    C = _m("core.utilities.constants")
    T, DbT, MetaApl = C.GooPointTypes, C.DbMetaDataTypes, C.MetaApl
    erg = {"geaendert": 0, "angelegt": 0, "uebersprungen": 0, "fehler": 0, "backup": None, "meldungen": []}
    if mit_backup:
        try:
            erg["backup"] = backup(inst, log)
        except Exception as e:
            raise RuntimeError("Backup fehlgeschlagen: {!r}".format(e)[:300])
    apl, layer = vorhandene_apl(inst, GooPoint)
    log("Plan[Goo]: {} APL im Projekt, {} Adressen in der Pruefung".format(len(apl), len(adr)))
    ct = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:25832"), layer.crs(), QgsProject.instance())
    goo_asb = None
    conn = inst.get_connection()
    try:
        conn.auto_commit_insert = False
    except Exception:
        pass
    n_ges = max(len(adr), 1)
    for i_, (_, r) in enumerate(adr.iterrows()):
        if i_ % 20 == 0:
            f_(5 + 93 * i_ / n_ges, "Uebernahme {}/{}".format(i_, n_ges))
        status = str(r.get("status", "offen") or "offen")
        if status == "ignorieren" or (nur_gruen_gelb and r.get("ampel") == "rot") or bool(r.get("koord_fehlt", False)):
            erg["uebersprungen"] += 1
            continue
        s = _schluessel(r["kls_id"], r["strasse"], r["hnr"], r["hnr_zs"])
        f = apl.get(s)
        try:
            if f is not None:
                if not attribute:
                    erg["uebersprungen"] += 1
                    continue
                pt = GooPoint.from_feature(f)
                _attribute_setzen(pt, r, MetaApl, DbT)
                erg["geaendert"] += 1
            elif neue_anlegen:
                if goo_asb is None:
                    goo_asb = _asb(apl, GooPoint, GooAsb, r)
                p = r.geometry
                q = ct.transform(QgsPointXY(p.x, p.y))
                address = GooAddress.from_raw_address_dict({
                    "PLZ": str(r["plz"] or ""), "ORT": str(r["ort"] or ""), "ORTSTEIL": str(r["ortsteil"] or ""),
                    "STRASSE": str(r["strasse"] or ""), "HS_NR": regeln._int(r["hnr"]) or 0, "HS_NR_ZS": str(r["hnr_zs"] or ""),
                    "KLS": regeln._int(r["kls_id"]) or None, "KLS_SUF": None})
                name = "{} {}{}".format(r["strasse"], r["hnr"], r["hnr_zs"] or "").strip()
                pt = GooPoint.create_from_point(q, asb=goo_asb, name=name, type_=T.APL, address=address)
                _attribute_setzen(pt, r, MetaApl, DbT)
                erg["angelegt"] += 1
            else:
                erg["uebersprungen"] += 1
        except Exception as e:
            erg["fehler"] += 1
            if len(erg["meldungen"]) < 30:
                erg["meldungen"].append("{} {}{}: {!r}".format(r["strasse"], r["hnr"], r["hnr_zs"] or "", e)[:200])
    try:
        conn.auto_commit_insert = True
    except Exception:
        pass
    try:
        conn.commit()
    except Exception:
        pass
    try:
        layer.reload()
        inst.get_point_layer().triggerRepaint()
    except Exception:
        pass
    f_(100, "Fertig")
    log("Uebernahme: {} APL geaendert, {} angelegt, {} uebersprungen, {} Fehler".format(
        erg["geaendert"], erg["angelegt"], erg["uebersprungen"], erg["fehler"]))
    for m_ in erg["meldungen"]:
        log("  " + m_)
    return erg


def _asb(apl, GooPoint, GooAsb, r):
    for f in apl.values():
        try:
            return GooPoint.from_feature(f).get_asb()
        except Exception:
            continue
    onkz, asb = regeln._int(r.get("onkz")), regeln._int(r.get("asb"))
    if onkz and asb:
        return GooAsb.from_onb_asb(onkz, asb)
    raise RuntimeError("ASB nicht bestimmbar: kein APL im Projekt und keine ONKZ/ASB in der Liste")


def _attribute_setzen(pt, r, MetaApl, DbT):
    we, ge, p2p = regeln._int(r["we"]), regeln._int(r["ge"]), regeln._int(r["p2p"])
    pt.set_hh(we or None)
    pt.set_usto(ge or None)
    pt.set_p2p(p2p or None)
    typ = str(r.get("gebaeudetyp") or "")
    meta = pt.get_meta()
    if typ in BUILDING_ERLAUBT:
        meta.create_meta_value(MetaApl.BUILDING.value[0], typ, DbT.STR)
    grund = None
    quelle = str(r.get("quelle") or "")
    if bool(r.get("bauluecke", False)) or quelle == "bauluecke":
        grund = "Baulücke"
    elif quelle == "alkis":                       # fehlender Bedarf, aus der Pruefliste aufgenommen (Markus 17.09.)
        grund = "vorhandenes Gebäude im Ausbaugebiet"
    elif str(r.get("dublette") or ""):
        grund = "Doppelte Adresse"
    elif r.get("ampel") == "rot":
        grund = "Prüfen"
    if grund:
        meta.create_meta_value(MetaApl.REASON.value[0], grund, DbT.STR)
