# -*- coding: utf-8 -*-
"""ALKIS-Gebaeude (vereinfachtes Schema, ave:GebaeudeBauwerk) per WFS der Landesvermessungen laden.

Die Dienste kommen aus dem Katalog des QGIS-Plugins GeoBasis_Loader (Anton May, Mike Elstermann), wenn es installiert ist,
sonst aus der eingebauten Tabelle (Stand 14.09.2026). Abruf ueber WFS 2.0 GetFeature in Kacheln, Ergebnis als GeoDataFrame
in EPSG:25832. Ohne Netz oder ohne Dienst (Bayern, Bremen, Thueringen) liefert `laden` None und der Pruefer arbeitet ohne Gebaeude.
"""
import glob
import json
import os
import re
import tempfile
import time

# Land -> (WFS-URL, Typname). Fallback, falls der GeoBasis-Loader-Katalog nicht lesbar ist.
DIENSTE = {
    "NW": ("https://www.wfs.nrw.de/geobasis/wfs_nw_alkis_vereinfacht", "ave:GebaeudeBauwerk"),
    "NI": ("https://opendata.lgln.niedersachsen.de/doorman/noauth/alkis_wfs_einfach", "ave:GebaeudeBauwerk"),
    "HE": ("https://www.gds.hessen.de/wfs2/aaa-suite/cgi-bin/alkis/vereinf/wfs", "ave:GebaeudeBauwerk"),
    "RP": ("https://www.geoportal.rlp.de/registry/wfs/519", "ave:GebaeudeBauwerk"),
    "BW": ("https://owsproxy.lgl-bw.de/owsproxy/wfs/WFS_LGL-BW_ALKIS", "nora:v_al_gebaeude"),
    "BB": ("https://isk.geobasis-bb.de/ows/alkis_vereinf_wfs", "ave:GebaeudeBauwerk"),
    "SN": ("https://geodienste.sachsen.de/aaa/public_alkis/vereinf/wfs", "ave:GebaeudeBauwerk"),
    "ST": ("https://www.geodatenportal.sachsen-anhalt.de/wss/service/ST_LVermGeo_ALKIS_WFS_OpenData/guest", "ave:GebaeudeBauwerk"),
    "SH": ("https://dienste.gdi-sh.de/WFS_SH_ALKIS_VWG_OpenGBD", "ave:GebaeudeBauwerk"),
    "MV": ("https://www.geodaten-mv.de/dienste/alkis_wfs_einfach", "ave:GebaeudeBauwerk"),
    "SL": ("https://geoportal.saarland.de/registry/wfs/414", "ALKIS_ALKIS_WFS_ohne_Eig:GebaeudeBauwerk"),
    "HH": ("https://geodienste.hamburg.de/WFS_HH_ALKIS_vereinfacht", "ave:GebaeudeBauwerk"),
    "BE": ("https://gdi.berlin.de/services/wfs/alkis_gebaeude", "alkis_gebaeude:gebaeude"),
}
OHNE_DIENST = {"BY": "Bayern", "HB": "Bremen", "TH": "Thueringen"}
LAENDER = {"NW": "Nordrhein-Westfalen", "NI": "Niedersachsen", "HE": "Hessen", "RP": "Rheinland-Pfalz", "BW": "Baden-Wuerttemberg",
           "BB": "Brandenburg", "SN": "Sachsen", "ST": "Sachsen-Anhalt", "SH": "Schleswig-Holstein", "MV": "Mecklenburg-Vorpommern",
           "SL": "Saarland", "HH": "Hamburg", "BE": "Berlin", "BY": "Bayern", "HB": "Bremen", "TH": "Thueringen"}

# grobe Umgriffe in EPSG:25832 (minx, miny, maxx, maxy) nur zur Vorauswahl; der Planer kann das Land im Dialog aendern
UMGRIFF = {
    "NW": (280000, 5570000, 545000, 5835000), "NI": (340000, 5700000, 705000, 5965000), "HE": (405000, 5480000, 595000, 5725000),
    "RP": (300000, 5430000, 465000, 5645000), "BW": (380000, 5260000, 625000, 5525000), "SL": (325000, 5440000, 405000, 5515000),
    "SH": (455000, 5925000, 645000, 6115000), "HH": (545000, 5915000, 595000, 5965000), "HB": (465000, 5865000, 505000, 5915000),
    "TH": (555000, 5575000, 765000, 5725000), "BY": (560000, 5225000, 835000, 5605000), "ST": (635000, 5675000, 805000, 5905000),
    "BB": (695000, 5675000, 965000, 5955000), "BE": (775000, 5795000, 825000, 5845000), "MV": (645000, 5895000, 955000, 6065000),
    "SN": (695000, 5575000, 905000, 5725000),
}

# Nebengebaeude, die fuer den Adressabgleich nicht zaehlen (funktion aus ALKIS)
NEBEN = re.compile(r"carport|überdachung|ueberdachung|garage|parken|parkdeck|silo|auskragend|schuppen|gartenhaus|scheune|stall|"
                   r"schutzhütte|schutzhuette|treibhaus|gewächshaus|gewaechshaus|wasserbehälter|behälter|behaelter|trafo|umformer|"
                   r"toilette|kiosk|wartehalle|bahnsteig|brücke|bruecke|mauer|turm|denkmal|zelt|tank|hütte|huette|unterstand|"
                   r"bootshaus|jagdhaus|wochenendhaus|ferienhaus|gebäude zur freizeit|freizeit|sport|umkleide|"
                   r"land- und forst|landwirtschaft|forstwirtschaft|durchfahrt|entsorgung|versorgung", re.I)
NEBEN_GRUPPE = re.compile(r"sonstiges bauwerk|vorratsbeh|land- und forst|zum parken|freizeit|sport|verkehr", re.I)


def laender_fuer_bbox(minx, miny, maxx, maxy):
    """Laenderkuerzel, deren Umgriff die Box schneidet, groesste Ueberdeckung zuerst."""
    treffer = []
    for land, (a, b, c, d) in UMGRIFF.items():
        ix = min(maxx, c) - max(minx, a)
        iy = min(maxy, d) - max(miny, b)
        if ix > 0 and iy > 0:
            treffer.append((ix * iy, land))
    return [l for _, l in sorted(treffer, reverse=True)]


def dienst(land):
    """(url, typname) fuer ein Land: zuerst GeoBasis-Loader-Katalog, sonst Tabelle. None, wenn kein Dienst."""
    if land in OHNE_DIENST:
        return None
    aus_katalog = _aus_geobasis_katalog(land)
    return aus_katalog or DIENSTE.get(land)


def _aus_geobasis_katalog(land):
    try:
        wurzeln = []
        try:
            from qgis.core import QgsApplication
            wurzeln.append(os.path.join(QgsApplication.qgisSettingsDirPath(), "python", "plugins", "GeoBasis_Loader", "catalogs"))
        except Exception:
            pass
        wurzeln.append(os.path.join(os.environ.get("APPDATA", ""), "QGIS", "QGIS3", "profiles", "default", "python", "plugins",
                                    "GeoBasis_Loader", "catalogs"))
        muster = re.compile(r"^{}: ALKIS Geb.*\(WFS\)$".format(land))
        for w in wurzeln:
            for p in glob.glob(os.path.join(w, "katalog_*.json")):
                with open(p, encoding="utf-8") as f:
                    text = f.read()
                for m in _eintraege(json.loads(text)):
                    if muster.match(m.get("name", "")) and m.get("type") == "ogc_wfs":
                        uri = m.get("uri", "")
                        url = re.search(r"url='([^']+)'", uri)
                        typ = re.search(r"typename='([^']+)'", uri)
                        if url and typ:
                            return url.group(1).split("?")[0], typ.group(1)
    except Exception:
        return None
    return None


def _eintraege(obj):
    if isinstance(obj, dict):
        if "uri" in obj and "name" in obj:
            yield obj
        for v in obj.values():
            yield from _eintraege(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _eintraege(v)


def laden(minx, miny, maxx, maxy, land, log=print, kachel_m=2000.0, rand_m=60.0, zeitlimit_s=60, fortschritt=None):
    """Gebaeude im Umgriff (EPSG:25832) laden. -> GeoDataFrame (EPSG:25832, Spalten oid, funktion, gebnutzbez, lagebeztxt, relevant) oder None"""
    d = dienst(land)
    if d is None:
        log("ALKIS: fuer {} gibt es keinen offenen Gebaeude-WFS.".format(LAENDER.get(land, land)))
        return None
    url, typ = d
    g = _abrufen(url, typ, minx, miny, maxx, maxy, log, kachel_m, rand_m, zeitlimit_s, fortschritt, was="Gebaeude")
    if g is None:
        return None
    for sp in ("funktion", "gebnutzbez", "lagebeztxt", "oid"):
        if sp not in g.columns:
            g[sp] = None
    g["relevant"] = [_relevant(f, n) for f, n in zip(g["funktion"], g["gebnutzbez"])]
    g = g[["oid", "funktion", "gebnutzbez", "lagebeztxt", "relevant", "geometry"]].reset_index(drop=True)
    log("ALKIS {}: {} Gebaeude ({} relevant)".format(land, len(g), int(g["relevant"].sum())))
    return g


NUTZUNG_BAU = re.compile(r"wohnbau|gemischter nutzung|gemischte baufl", re.I)   # nicht: besonderer funktionaler Praegung (Kirche, Schule, Friedhof)


def _nutzung(tntxt):
    """tntxt 'Wohnbaufläche;719' oder mehrere Anteile -> (Nutzung mit groesstem Anteil, Anteil Bauflaeche 0..1)."""
    paare = re.findall(r"([^;|,]+?)\s*;\s*(\d+(?:\.\d+)?)", str(tntxt or ""))
    if not paare:
        t = str(tntxt or "").strip()
        return t, (1.0 if NUTZUNG_BAU.search(t) else 0.0)
    ges = sum(float(a) for _, a in paare) or 1.0
    bau = sum(float(a) for n, a in paare if NUTZUNG_BAU.search(n)) / ges
    return max(paare, key=lambda t: float(t[1]))[0].strip(), round(bau, 2)


def laden_flurstuecke(minx, miny, maxx, maxy, land, log=print, kachel_m=1000.0, rand_m=60.0, zeitlimit_s=90, fortschritt=None):
    """Flurstuecke (ave:Flurstueck, vereinfachtes Schema) im Umgriff laden - fuer moegliche Bauluecken (Markus 17.09.2026).
    -> GeoDataFrame (EPSG:25832, Spalten oid, flstkennz, gemarkung, flur, flurstnr, flaeche, lagebeztxt, tntxt, nutzung, bau_anteil) oder None"""
    d = dienst(land)
    if d is None or "GebaeudeBauwerk" not in d[1]:
        log("ALKIS: fuer {} kein Flurstuecks-WFS im vereinfachten Schema - Bauluecken-Suche entfaellt.".format(LAENDER.get(land, land)))
        return None
    url, typ = d[0], d[1].replace("GebaeudeBauwerk", "Flurstueck")
    g = _abrufen(url, typ, minx, miny, maxx, maxy, log, kachel_m, rand_m, zeitlimit_s, fortschritt, was="Flurstuecke")
    if g is None:
        return None
    for sp in ("oid", "flstkennz", "gemarkung", "flur", "flstnrzae", "flstnrnen", "flaeche", "lagebeztxt", "tntxt"):
        if sp not in g.columns:
            g[sp] = None
    g["flurstnr"] = [("{}/{}".format(z, n) if str(n or "").strip() not in ("", "None", "nan") else str(z or "")).strip()
                     for z, n in zip(g["flstnrzae"], g["flstnrnen"])]
    nz = [_nutzung(t) for t in g["tntxt"]]
    g["nutzung"] = [n for n, _ in nz]
    g["bau_anteil"] = [a for _, a in nz]
    g = g[["oid", "flstkennz", "gemarkung", "flur", "flurstnr", "flaeche", "lagebeztxt", "tntxt", "nutzung", "bau_anteil", "geometry"]].reset_index(drop=True)
    log("ALKIS {}: {} Flurstuecke ({} mit Bauflaechen-Nutzung)".format(land, len(g), int((g["bau_anteil"] > 0).sum())))
    return g


def _abrufen(url, typ, minx, miny, maxx, maxy, log, kachel_m, rand_m, zeitlimit_s, fortschritt, was="Gebaeude"):
    """WFS-GetFeature gekachelt (Teilen bei > 5000 Treffern), Antwort als GeoDataFrame in 25832, Dubletten ueber oid entfernt. -> GeoDataFrame oder None"""
    import geopandas as gpd
    import pandas as pd
    import requests
    minx, miny, maxx, maxy = minx - rand_m, miny - rand_m, maxx + rand_m, maxy + rand_m
    kacheln = [(minx, miny, maxx, maxy)]
    teile, n_req, t0 = [], 0, time.time()
    tmp = tempfile.mkdtemp(prefix="fib_alkis_")
    while kacheln:
        a, b, c, e = kacheln.pop()
        if c - a > kachel_m or e - b > kachel_m:
            mx, my = (a + c) / 2, (b + e) / 2
            kacheln += [(a, b, mx, my), (mx, b, c, my), (a, my, mx, e), (mx, my, c, e)]
            continue
        n_req += 1
        if fortschritt:
            fortschritt(n_req, n_req + len(kacheln))
        try:
            r = requests.get(url, params={"SERVICE": "WFS", "VERSION": "2.0.0", "REQUEST": "GetFeature", "TYPENAMES": typ,
                                          "BBOX": "{:.0f},{:.0f},{:.0f},{:.0f},urn:ogc:def:crs:EPSG::25832".format(a, b, c, e),
                                          "COUNT": 5000, "SRSNAME": "urn:ogc:def:crs:EPSG::25832"}, timeout=zeitlimit_s)
        except Exception as ex:
            log("ALKIS: Abruf {} fehlgeschlagen ({}), Pruefung laeuft ohne {}.".format(was, str(ex)[:80], was))
            return None
        if r.status_code != 200 or b"ExceptionReport" in r.content[:2000]:
            log("ALKIS: Dienst antwortet bei {} mit Fehler (HTTP {}), Pruefung laeuft ohne {}.".format(was, r.status_code, was))
            return None
        n_ret = re.search(rb'numberReturned="(\d+)"', r.content[:3000])
        n_ret = int(n_ret.group(1)) if n_ret else -1
        if n_ret >= 5000:
            mx, my = (a + c) / 2, (b + e) / 2
            kacheln += [(a, b, mx, my), (mx, b, c, my), (a, my, mx, e), (mx, my, c, e)]
            continue
        if n_ret == 0:
            continue
        p = os.path.join(tmp, "k{}.gml".format(n_req))
        with open(p, "wb") as f:
            f.write(r.content)
        try:
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                g = gpd.read_file(p)
        except Exception as ex:
            log("ALKIS: Antwort nicht lesbar ({}).".format(str(ex)[:80]))
            continue
        if len(g):
            teile.append(g)
    if not teile:
        log("ALKIS: keine {} im Umgriff ({} Abrufe).".format(was, n_req))
        return None
    g = pd.concat(teile, ignore_index=True)
    g = gpd.GeoDataFrame(g, geometry="geometry")
    if g.crs is None:
        g = g.set_crs(25832)
    elif g.crs.to_epsg() != 25832:
        g = g.to_crs(25832)
    key = "oid" if "oid" in g.columns else ("gml_id" if "gml_id" in g.columns else None)
    if key:
        g = g.drop_duplicates(subset=[key])
    log("ALKIS: {} {} in {} Abrufen, {:.0f} s".format(len(g), was, n_req, time.time() - t0))
    return g.reset_index(drop=True)


def _relevant(funktion, gruppe):
    f, gr = str(funktion or ""), str(gruppe or "")
    if NEBEN.search(f) or NEBEN_GRUPPE.search(gr):
        return False
    return True
