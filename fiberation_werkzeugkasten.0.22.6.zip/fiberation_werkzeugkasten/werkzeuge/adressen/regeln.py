# -*- coding: utf-8 -*-
"""Werkzeug 1 - Regeln: Telekom-Qualitaetskenner, Gebaeudetypen, Bedarf je Adresse nach ZTV TK-Netz 21 (Version November 2025).

Quellen (Kapitel ZTV 21):
  8.5.1.1  je Stromzaehler ein FTTH-Bedarf; kleine Gewerbe in Wohnobjekten: je Geschaeftskunde eine WE zusaetzlich
  8.5.1.2  pauschaler Zusatzbedarf im Haus: 1-3 WE keiner, 4-8 WE +1, ab 9 WE +2
  8.5.1.3  Schulen (Schueler/Klassen), Krankenhaeuser (Betten): individuell; oeffentliche Gebaeude: min. 12 Fs, 9 FTTH + 4 Direktfasern,
           Hauptverwaltungen > 10.000 EW: min. 24 Fs
  8.5.1.7  technische Einrichtungen (Trafo, Pumpstation, Klaerwerk ...): je Bedarfspunkt 1 SNR, Anschluss nur bei Bedarf
  8.8      Industrie-/Gewerbegebiete: je Produkt ausserhalb FTTH 2 Direktfasern
  8.8.2    Gewerbegebiet, Bedarf unbekannt: min. 12 Fs je Objekt, min. 4 FTTH + 4 Direktfasern; grosse Objekte min. 24 Fs
  Hauszufuehrung: Gebaeude > 8 WE bekommen ein 12-faseriges Kabel (Koppler im Haus), sonst 1 Faser.
MBfD / Bundesfoerderung (Kap. 13, Extrakt Memory-Database-Fiberation/docs/06_ztv_tknetz21_planungsregeln.md, Markus 30.09.2026):
  4 Fs je WE + 2 Fs je Gebaeude, Gf-AP HUEP statt OneBox (zentraler 1:32 im NVT bis 68 WE), 100 % Anschaltung - kein pauschaler
  Zusatzbedarf; 1-8 WE Mikrokabel in SNR 12 (EFH 6 Fs, 4 WE -> 18 Fs -> 24er), 9-68 WE Minikabel (bis 12 WE 48, bis 17 WE 72,
  18-23 WE 96, 24-35 WE 96+48, 36-46 WE 2x96, 47-68 WE 3x96), > 68 WE wie Eigenausbau (OneBox) + 3 Kollo-SNR ins Haus;
  Bauluecken/0 WE zaehlen mit der mittleren WE-Zahl der Umgebung (nie 0); Gewerbeobjekt min. 12-Fs-Kabel + HUEP 2WE;
  Schulen (BF) 9/14/20 As nach Schuelern, Krankenhaeuser (BF) 13/23/46/68 As nach Betten, oeffentliche Gebaeude min. 9 As
  (Hauptverwaltung > 10.000 EW: 14); ab Materialkonzept 4.1 Vzk zu Schulen/Krankenhaeusern +1x SNRV 12x12 bis Grundstuecksgrenze.
Kenner (Spalte adress_qualitaet_kenner, aus den Barntrup-Daten abgeleitet - Telekom-Dokumentation liegt nicht vor):
  K = Koordinate vorhanden, A = amtliche Adresse mit Gebaeude (nur mit A ist die Gebaeudefunktion gefuellt und die Bewertung gut),
  X/B/N nicht sicher gedeutet.
"""
import math
import re

from ... import regelwerk

# --- Plan[Goo]-Gebaeudetypen (core.utilities.constants.BuildingType) -------------------------------------------------------------------
WOHNHAUS, GEWERBE, SCHULE, KRANKENHAUS, OEFFENTLICH = "Wohnhaus", "Gewerbe", "Schule", "Krankenhaus", "öff. Gebäude"
TECHNISCH, UNBEKANNT = "technische Einrichtung", ""

_MUSTER = [
    (KRANKENHAUS, r"krankenhaus|klinik|hospital"),
    (SCHULE, r"schule|schulgeb|bildung|hochschule|universit|akademie"),
    (OEFFENTLICH, r"öffentlich|oeffentlich|verwaltung|rathaus|gericht|polizei|feuerwehr|amt\b|behörde|behoerde|bibliothek|museum|kirche|kapelle|friedhof"),
    (TECHNISCH, r"trafo|umspann|umformer|pumpstation|pumpwerk|kläranlage|klaeranlage|klärwerk|klaerwerk|wasserwerk|windkraft|windrad|"
                r"funkmast|sendeanlage|versorgungsanlage|heizwerk|gasregler|schaltanlage|technische anlage"),
    (GEWERBE, r"gewerbe|industrie|handel|dienstleistung|wirtschaft|büro|buero|betrieb|lager|werkstatt|fabrik|hotel|gast|laden|"
              r"verkauf|geschäft|geschaeft|praxis|bank|versicherung|logistik|einkaufs"),
    (WOHNHAUS, r"wohn"),
]
_NUR_WOHNEN = re.compile(r"wohn", re.I)


def gebaeudetyp(funktion, ge=0):
    """Telekom-Gebaeudefunktion (Bedarfsliste) -> (Plan[Goo]-Gebaeudetyp, gemischt: bool).
    Gemischt genutzte Gebaeude mit Wohnen bleiben Wohnhaus (Gewerbe zaehlt ueber die Einheiten, Kap. 8.5.1.1)."""
    f = (funktion or "").strip()
    if not f:
        return (GEWERBE if _int(ge) > 0 else UNBEKANNT), False
    fl = f.lower()
    mit_wohnen = bool(_NUR_WOHNEN.search(fl))
    for typ, muster in _MUSTER:
        if re.search(muster, fl, re.I):
            if typ == GEWERBE and mit_wohnen:
                return WOHNHAUS, True
            return typ, (typ != WOHNHAUS and mit_wohnen)
    return UNBEKANNT, mit_wohnen


def kenner_ampel(kenner):
    """-> (ampel, hinweis). gruen: K und A; gelb: K ohne A; rot: kein K (keine Koordinate)."""
    k = (kenner or "").upper()
    if "K" not in k:
        return "rot", "Kenner ohne K (keine Koordinate)"
    if "A" not in k:
        return "gelb", "Kenner {} ohne A (Adresse nicht amtlich bestaetigt)".format(k)
    return "gruen", ""


def zusatzbedarf(we_gesamt):
    """Kap. 8.5.1.2, pauschaler Ansatz."""
    if we_gesamt >= 9:
        return 2
    if we_gesamt >= 4:
        return 1
    return 0


def _int(v):
    try:
        if v is None or (isinstance(v, float) and math.isnan(v)):
            return 0
        return int(float(str(v).replace(",", ".")))
    except Exception:
        return 0


def bedarf(we, ge, p2p, gebietstyp, funktion, treiber="", mbfd=None, we_umfeld=None):
    """Bedarf je Adresse. -> dict(we_gesamt, zusatz, anschluesse, snr, fasern_haus, fasern_direkt, gebaeudetyp, gemischt, sonderfall, regel,
    gewerbegebiet, fasern_bedarf, kabel_haus, snr_kollo, we_quelle)
    anschluesse = FTTH-Anschluesse, die am Gf-AP bereitzustellen sind (WE + Gewerbe-WE + Zusatzbedarf).
    fasern_haus = Fasern im Hauszufuehrungskabel (1 oder 12, oeffentlich 12/24), fasern_direkt = P2P-/Direktfasern bis zum NVT.
    snr = SNR-Einfuehrungen am NVT fuer diese Adresse (Fiberation-Regelsatz: 1 + Sonderbau).
    mbfd: None = am Ausbautreiber erkennen (regelwerk); True -> bedarf_mbfd (Kap. 13), we_umfeld = mittlere WE der Umgebung fuer 0-WE-Adressen."""
    if mbfd is None:
        mbfd = regelwerk.ist_mbfd_text(treiber)
    if mbfd:
        return bedarf_mbfd(we, ge, p2p, gebietstyp, funktion, treiber, we_umfeld)
    we, ge, p2p = _int(we), _int(ge), _int(p2p)
    igg = "gewerbe" in (gebietstyp or "").lower() or "industrie" in (gebietstyp or "").lower()
    typ, gemischt = gebaeudetyp(funktion, ge)
    regel, sonder = [], ""
    we_gesamt = we + ge
    if ge:
        regel.append("8.5.1.1: {} Gewerbe-Einheit(en) je +1 WE".format(ge))
    zusatz = zusatzbedarf(we_gesamt) if typ not in (TECHNISCH,) else 0
    if zusatz:
        regel.append("8.5.1.2: Zusatzbedarf +{}".format(zusatz))
    anschluesse = we_gesamt + zusatz
    fasern_direkt = 2 * p2p
    if p2p:
        regel.append("8.8.1: {} P2P-Produkt(e) je 2 Direktfasern".format(p2p))
    snr = 1
    fasern_haus = 1 if anschluesse <= 8 else 12
    if anschluesse > 8:
        regel.append("> 8 Anschluesse: 12-Fs-Hauszufuehrung, Koppler im Haus")

    if typ == TECHNISCH:
        anschluesse, fasern_haus = 0, 0
        sonder = "technische Einrichtung: 1 SNR vorhalten, Anschluss nur bei Bedarf (8.5.1.7)"
    elif typ == KRANKENHAUS:
        snr += 1
        fasern_haus, fasern_direkt = max(fasern_haus, 12), max(fasern_direkt, 4)
        sonder = "Krankenhaus: Bedarf nach Betten, Planer fragt nach (8.5.1.3); +1 SNR 7 mm Reserve in der Laengstrasse"
    elif typ == SCHULE:
        snr += 1
        fasern_haus = max(fasern_haus, 12)
        sonder = "Schule: Bedarf nach Schuelern/Klassen, Planer fragt nach (8.5.1.3)"
    elif typ == OEFFENTLICH:
        snr += 1
        anschluesse = max(anschluesse, 9)
        fasern_haus, fasern_direkt = max(fasern_haus, 12), max(fasern_direkt, 4)
        sonder = "oeffentliches Gebaeude: min. 12 Fs, 9 FTTH + 4 Direktfasern; Hauptverwaltung > 10.000 EW: 24 Fs (8.5.1.3)"
    elif typ == GEWERBE:
        snr += 1
        regel.append("Sonderbau Gewerbe: +1 SNR")
    if igg and typ not in (TECHNISCH,):
        anschluesse = max(anschluesse, 4)
        fasern_haus, fasern_direkt = max(fasern_haus, 12), max(fasern_direkt, 4)
        regel.append("8.8.2 Gewerbegebiet: min. 12 Fs, 4 FTTH + 4 Direktfasern")
        if not sonder:
            sonder = "Gewerbegebiet: Bedarf bestaetigen, grosse Objekte min. 24 Fs und 4 SNR (8.8.2)"
    if we_gesamt > 512:
        snr += 1
        regel.append("> 512 WE: +1 SNR")
    if we_gesamt == 0 and typ not in (TECHNISCH,):
        regel.append("0 WE und 0 GE: mindestens 1 Anschluss angenommen")
        anschluesse = max(anschluesse, 1)
    return {"we_gesamt": we_gesamt, "zusatz": zusatz, "anschluesse": anschluesse, "snr": snr, "fasern_haus": fasern_haus,
            "fasern_direkt": fasern_direkt, "gebaeudetyp": typ, "gemischt": gemischt, "sonderfall": sonder, "regel": "; ".join(regel),
            "gewerbegebiet": igg, "fasern_bedarf": fasern_haus, "kabel_haus": "", "snr_kollo": 0, "we_quelle": "liste",
            "treiber": treiber or ""}


# --- MBfD / Bundesfoerderung (ZTV 21 Kap. 13) ------------------------------------------------------------------------------------------
MBFD_FS_JE_WE, MBFD_FS_JE_GEBAEUDE = 4, 2
MBFD_ONEBOX_AB_WE = 69                    # > 68 WE: wie Eigenausbau (OneBox, Koppler im Haus) + 3 Kollo-SNR ins Haus
MBFD_KOLLO_SNR_HAUS = 3
MBFD_MIKROKABEL = (6, 12, 24, 36)         # 1-8 WE: Mikrokabel in SNR 12 (EFH = 6 Fs; 4 WE -> 18 Fs -> 24er)
MBFD_MINIKABEL = [(12, (48,)), (17, (72,)), (23, (96,)), (35, (96, 48)), (46, (96, 96)), (68, (96, 96, 96))]   # bis WE -> Kabel je SNR
MBFD_SCHULE = ((1850, 9, (48,)), (3000, 14, (72,)), (4500, 20, (96,)))                    # bis Schueler -> Anschluesse, Kabel
MBFD_KRANKENHAUS = ((500, 13, (72,)), (1000, 23, (96,)), (2000, 46, (96, 96)), (3000, 68, (96, 96, 96)))   # bis Betten
MBFD_OEFFENTLICH_MIN_AS = 9               # Hauptverwaltung > 10.000 EW: 14
MBFD_GEWERBE_MIN_FS, MBFD_GEWERBE_MIN_AS = 12, 2


def kabel_mbfd(we_gesamt):
    """Hauszufuehrung nach Kap. 13 -> (Faserbedarf 4 je WE + 2, Kabel je SNR als Tupel, Text)."""
    w = max(0, _int(we_gesamt))
    fs = MBFD_FS_JE_WE * w + MBFD_FS_JE_GEBAEUDE
    if w <= 8:
        k = next((k for k in MBFD_MIKROKABEL if k >= fs), MBFD_MIKROKABEL[-1])
        return fs, (k,), "{} Fs -> {}er Mikrokabel".format(fs, k)
    for grenze, kabel in MBFD_MINIKABEL:
        if w <= grenze:
            return fs, kabel, "{} Fs -> {} Minikabel {}".format(fs, len(kabel), "+".join(str(k) for k in kabel))
    return fs, (12,), "{} Fs -> > 68 WE: OneBox wie Eigenausbau (12-Fs-Kabel, Koppler im Haus)".format(fs)


def bedarf_mbfd(we, ge, p2p, gebietstyp, funktion, treiber="", we_umfeld=None):
    """Bedarf je Adresse nach ZTV 21 Kap. 13 (Bundesfoerderung). Gleiche Schluessel wie bedarf(); zusaetzlich zaehlt:
    fasern_bedarf = 4 Fs je WE + 2 je Gebaeude, kabel_haus = Kabel je SNR (Text), snr = Zahl der SNR 12 in die Bodenplatte,
    snr_kollo = Kollo-SNR ins Haus (> 68 WE), we_quelle = angebot | umgebung | annahme (0 WE mit Umgebungs-WE, Markus 30.09.2026)."""
    we, ge, p2p = _int(we), _int(ge), _int(p2p)
    igg = "gewerbe" in (gebietstyp or "").lower() or "industrie" in (gebietstyp or "").lower()
    typ, gemischt = gebaeudetyp(funktion, ge)
    regel, sonder = ["Kap. 13 MBfD: 4 Fs je WE + 2 je Gebaeude, HUEP, 1:32 im NVT"], ""
    we_quelle = "angebot"
    we_gesamt = we + ge
    if ge:
        regel.append("8.5.1.1: {} Gewerbeeinheit(en) je +1 WE".format(ge))
    if we_gesamt == 0 and typ in (WOHNHAUS, UNBEKANNT):      # Bauluecke/Wohnhaus ohne WE; Schule, KH, oeffentlich, Gewerbe haben eigene Mindestwerte
        if we_umfeld:
            we_gesamt, we_quelle = max(1, int(round(float(we_umfeld)))), "umgebung"
            regel.append("Kap. 13: 0 WE (Bauluecke) mit mittlerer WE der Umgebung {} angesetzt".format(we_gesamt))
        else:
            we_gesamt, we_quelle = 1, "annahme"
            regel.append("0 WE: 1 WE angenommen (Umgebung unbekannt)")
    zusatz = 0                                    # 100 % Anschaltung, Reserve steckt in den 4 Fs je WE - kein pauschaler Zusatzbedarf
    anschluesse = we_gesamt
    fasern_direkt = 2 * p2p
    if p2p:
        regel.append("8.8.1: {} P2P-Produkt(e) je 2 Direktfasern".format(p2p))
    fasern_bedarf, kabel, kabel_text = kabel_mbfd(we_gesamt)
    snr_kollo = 0

    if typ == TECHNISCH:
        anschluesse, fasern_bedarf, kabel, kabel_text = 0, 0, (), ""
        sonder = "technische Einrichtung: 1 SNR vorhalten, Anschluss nur bei Bedarf (8.5.1.7)"
    elif typ == KRANKENHAUS:
        _, as_, kabel = MBFD_KRANKENHAUS[0]
        anschluesse = max(anschluesse, as_)
        fasern_bedarf, kabel_text = sum(kabel), "Krankenhaus (BF) <= 500 Betten: {} Fs".format(sum(kabel))
        sonder = ("Krankenhaus (BF): <= 500 Betten 13 As/72 Fs, <= 1000 23 As/96 Fs, <= 2000 46 As/2x96, <= 3000 68 As/3x96 - "
                  "Planer fragt nach Betten; ab Materialkonzept 4.1 +1x SNRV 12x12 bis zur Grundstuecksgrenze")
    elif typ == SCHULE:
        _, as_, kabel = MBFD_SCHULE[0]
        anschluesse = max(anschluesse, as_)
        fasern_bedarf, kabel_text = sum(kabel), "Schule (BF) <= 1850 Schueler: {} Fs".format(sum(kabel))
        sonder = ("Schule (BF): <= 1850 Schueler 9 As/48 Fs, <= 3000 14 As/72 Fs, <= 4500 20 As/96 Fs - "
                  "Planer fragt nach Schuelern/Klassen; ab Materialkonzept 4.1 +1x SNRV 12x12 bis zur Grundstuecksgrenze")
    elif typ == OEFFENTLICH:
        anschluesse = max(anschluesse, MBFD_OEFFENTLICH_MIN_AS)
        fasern_bedarf, kabel, kabel_text = kabel_mbfd(anschluesse)
        sonder = "oeffentliches Gebaeude (BF): min. 9 Anschluesse, Hauptverwaltung > 10.000 EW: 14 (Kap. 13)"
    elif typ == GEWERBE:
        anschluesse = max(anschluesse, MBFD_GEWERBE_MIN_AS)
        fasern_bedarf, kabel, kabel_text = kabel_mbfd(anschluesse)
        if sum(kabel) < MBFD_GEWERBE_MIN_FS:
            kabel, kabel_text = (MBFD_GEWERBE_MIN_FS,), "{} Fs -> min. 12-Fs-Kabel (Gewerbeobjekt)".format(fasern_bedarf)
        regel.append("Kap. 13: Gewerbeobjekt min. 12-Fs-Kabel + HUEP 2WE")
    if igg and typ != TECHNISCH:
        regel.append("Kap. 13 GWG mit BF: nur NVT 22 L (BF), PON planerisch max. 16 As, Redundanz-Forderung Vzk")
        if not sonder:
            sonder = "Gewerbegebiet (BF): Redundanz Vzk (Ring/Zweitweg zu zweitem NVT) nach Entscheidungsbaum - Planer entscheidet"
    if we_gesamt >= MBFD_ONEBOX_AB_WE and typ != TECHNISCH:
        snr_kollo = MBFD_KOLLO_SNR_HAUS
        regel.append("Kap. 13: > 68 WE wie Eigenausbau (OneBox, Koppler im Haus) + {} Kollo-SNR ins Haus (Kollokation im Haus)".format(snr_kollo))
    fasern_haus = int(sum(kabel))
    snr = max(1, len(kabel))
    if len(kabel) > 1:
        regel.append("{} SNR 12 fuer {} Minikabel".format(len(kabel), len(kabel)))
    return {"we_gesamt": we_gesamt, "zusatz": zusatz, "anschluesse": anschluesse, "snr": snr, "fasern_haus": fasern_haus,
            "fasern_direkt": fasern_direkt, "gebaeudetyp": typ, "gemischt": gemischt, "sonderfall": sonder, "regel": "; ".join(regel),
            "gewerbegebiet": igg, "fasern_bedarf": int(fasern_bedarf), "kabel_haus": kabel_text, "snr_kollo": snr_kollo,
            "we_quelle": we_quelle, "treiber": treiber or ""}


def hnr_platzhalter(hnr):
    z = re.search(r"\d+", str(hnr or ""))
    return z is None or z.group(0) in ("0", "999", "9999")
