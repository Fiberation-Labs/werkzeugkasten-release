# -*- coding: utf-8 -*-
"""Werkzeug 4 - Kern ohne Qt: NVT-Standort im oeffentlichen Raum vorschlagen, Korridor zeigen, Standortsicherung fuehren.

Platzierung (Markus 18.09.2026, "Standorte meistens nicht verwendbar - am besten neben bereits gebauten NVT oder auf Buergersteigen"):
  * ALKIS-Nutzung "Strassenverkehr" = oeffentlicher Strassenraum (Fahrbahn + Bankett/Gehweg auf dem Strassenflurstueck). Wo die Fahrbahn
    liegt, sagt ALKIS nicht - geschaetzt aus OSM-Achse + Regelbreite je highway-Typ. Vorher stand der NVT mitten im Strassenraum.
  * Jede ALKIS-Verkehrsflaeche wird einzeln eingestuft (Kontext.teile, Spalte einstufung im Layer verkehrsflaechen): Fahrbahn = Strassenverkehr,
    Fahrweg/Wirtschaftsweg, Parkplatz und jeder "Weg", der befahrbar ist (OSM-Fahrachse darin, Strassenname, breiter als 3,5 m);
    Gehweg = "Begleitflaeche Strassenverkehr", Fussweg/Gehweg/Radweg/Platz und namenlose schmale Wege am Strassenraum; Weg = ohne Anschluss.
    Anlass 18.09.2026 (Barntrup, Obere Trift): die Stichstrasse "Im Rueschern" ist in ALKIS ein "Weg" und galt als Buergersteig, der echte
    Buergersteig gegenueber ist "Begleitflaeche Strassenverkehr" und galt als Fahrbahn. Die Fahrbahnschaetzung nimmt nur Achsen, die in
    derselben Flaeche verlaufen; ohne Achse wird die Fahrbahn aus der Flaechenbreite geschaetzt (NVT nur, wenn >= 4 m daneben frei bleiben).
  * Kandidaten: (1) Gehweg = Gehweg-Flaeche, die an eine Fahrbahn-Flaeche grenzt (Buergersteig), Restbreite >= 1,50 m zur Fahrbahn;
    (2) Bankett = in der Fahrbahn-Flaeche 0,6-1,8 m vor der Grenze, Abstand zur Achse >= Regelbreite/2 + halbe NVT-Tiefe + 0,5 m;
    (3) Bankett schmal = wie (2), aber nur Mindestfahrbahn 3,5 m gesichert (Fahrbahnbreite vor Ort pruefen, Abzug im Score);
    (4) Privatgrund direkt an der Strassengrenze (0,6-1,0 m) als Notloesung mit Gestattungsvertrag (Abzug im Score);
    (5) neben Bestand-NVT (OSM man_made=street_cabinet, Plan[Goo]-NVT) mit Bonus. Nie auf der Fahrbahn.
  * Naehe zum Sitzvorschlag zaehlt (0,05 je m): lieber Bankett schmal am Netzschwerpunkt als Gehweg 60 m weiter.
Regeln (ZTV TK-Netz 21 Kap. 8.6.5 Standortwahl, Standortsicherungs-Checkliste Markus 18.09.2026):
  * Gehwegrestbreite >= 1,50 m; Abstand zur Grenze des oeffentlichen Grundes >= 0,6 m, Wunsch 0,8 m (auf dem Gehweg 0,3 m / 0,4 m: der NVT
    steht mit der Rueckwand an der Grundstuecksgrenze, sonst passt kein 2,0 m breiter Buergersteig); nicht im/am Gebaeude (>= 1,0 m);
    Abstand Kreuzung >= 8 m; moeglichst im eigenen Gebiet
Standortsicherung (Datenmodell im Layer nvt_standorte, je NVT Haupt- und optional Alternativstandort):
  * Pruef-Checkliste p1..p8 mit Status OK / Nicht OK / Nicht relevant und Bemerkung
  * Rechtliche Sicherung: oeffentlicher Grund (Zustimmung Wegebaulasttraeger § 127 TKG: beantragt/erteilt/abgelehnt) oder Privatgrund
    (Gestattungsvertrag: in Verhandlung/unterschrieben/abgelehnt, Eigentuemer-Kontakt)
  * Gesamtstatus je NVT: Gesichert (alle Punkte OK/nicht relevant und Sicherung erteilt bzw. unterschrieben), Abgelehnt (ein Punkt
    Nicht OK oder Sicherung abgelehnt), sonst Offen; offene Punkte als Text
Ausgabe: GeoPackage (nvt_standorte, korridore, sitz_vorher, bestand_nvt, flurstuecke, verkehrsflaechen), Excel "Netzverteiler-Standorte
[<Projekt>].xlsx" im Fiberation-Format plus Checkliste, Pruefblatt als Markdown. Lageplaene (PNG 1:1000) erzeugt der Dialog in QGIS.
"""
import math
import os
import re
from datetime import datetime

os.environ.setdefault("OPENPYXL_LXML", "False")   # siehe fiberation_werkzeugkasten/__init__.py: GDAL + lxml = Absturz beim zweiten Excel

CRS = 25832
REGELBREITE = {"motorway": 11.0, "trunk": 9.0, "primary": 8.0, "secondary": 7.5, "tertiary": 6.5, "unclassified": 5.5,
               "residential": 5.5, "living_street": 4.5, "service": 3.5, "road": 5.5, "motorway_link": 7.0, "trunk_link": 7.0,
               "primary_link": 7.0, "secondary_link": 6.5, "tertiary_link": 6.0}
REGELN = {"restgehweg_m": 1.5, "nvt_tiefe_m": 0.4, "fahrbahn_min_m": 0.5, "fahrbahn_min_halb_m": 1.75, "rand_min_m": 0.6, "rand_wunsch_m": 0.8,
          "gebaeude_min_m": 1.0, "kreuzung_min_m": 8.0, "suchradius_m": 60.0, "schritt_m": 2.0, "bestand_nah_m": 3.0, "privat_max_m": 1.2,
          "offsets_bankett_m": (0.6, 0.9, 1.3, 1.8), "offsets_gehweg_m": (0.3, 0.45, 0.6, 0.8, 1.2), "offsets_privat_m": (0.6, 1.0),
          "offsets_m": (1.5, 2.0, 2.5, 3.0, 4.0, 5.5, 8.0),
          # auf dem Buergersteig steht der NVT mit der Rueckseite an der Grundstuecksgrenze (Mitte 0,3 m = Rueckwand 0,1 m); nur so passt
          # ein 2,0 m breiter Gehweg noch (0,1 + 0,4 Tiefe + 1,5 Rest). Bankett/Strassenraum behalten rand_min_m (Regler im Dialog).
          "rand_min_gehweg_m": 0.3, "rand_wunsch_gehweg_m": 0.4,
          "gehweg_max_breite_m": 3.5, "achse_in_min_m": 8.0}
ACHSEN = dict(REGELBREITE, track=3.0)   # Achsen fuer die Fahrbahnschaetzung; Wirtschaftswege mit 3 m
FAHRBAHN = re.compile(r"stra(?:ß|ss)enverkehr|fahrbahn", re.I)
GEHWEG = re.compile(r"^weg$|platz|gehweg|fu(?:ß|ss)weg|radweg|fahrweg|verkehrsbegleit", re.I)   # Flurstuecks-Nutzung (tntxt) = oeffentlicher Grund
# Einstufung je Verkehrsflaeche (nutzart + bez): eindeutig Gehweg/Seitenraum bzw. eindeutig befahrbar; "Weg" ohne Zusatz ist mehrdeutig
FUSSWEG = re.compile(r"gehweg|fu(?:ß|ss)weg|fu(?:ß|ss)g|^gang$|(?<!park|rast)platz|begleitfl|verkehrsbegleit", re.I)
FAHRWEG = re.compile(r"fahrweg|wirtschaftsweg|parkplatz|rastplatz", re.I)

# --- Standortsicherung: Checkliste, Rechtliche Sicherung, Gesamtstatus (Markus 18.09.2026) --------------------------------------------
CHECKLISTE = [("p1", "Stellflaeche und Arbeitsraum (Montage, Wartung)"),
              ("p2", "Gehwegrestbreite mindestens 1,50 m"),
              ("p3", "Sichtdreiecke an Kreuzungen und Einfahrten frei"),
              ("p4", "Abstaende Baeume, Einbauten, Hydranten, Hausanschluesse"),
              ("p5", "Untergrund fuer Sockel/Fundament geeignet"),
              ("p6", "Leitungsauskunft eingeholt, keine Fremdleitungen"),
              ("p7", "Denkmalschutz und Gestaltungssatzung geprueft"),
              ("p8", "Kabelzufuehrung/Trassenanbindung plausibel")]
CHECKLISTE_LANG = {"p1": "Stellflaeche und Arbeitsraum fuer Montage und Wartung ausreichend (Tuer oeffnet, Monteur steht sicher, kein Parkstreifen)",
                   "p2": "Gehwegrestbreite mindestens 1,50 m eingehalten (Rollstuhl, Kinderwagen; Massgabe Wegebaulasttraeger beachten)",
                   "p3": "Keine Sichtdreiecke an Kreuzungen oder Einfahrten verletzt",
                   "p4": "Abstaende zu Baeumen (Wurzelbereich), Einbauten, Hydranten und Hausanschluessen ausreichend",
                   "p5": "Untergrund fuer Sockel/Fundament geeignet (kein Fels, keine Aufschuettung, kein Graben)",
                   "p6": "Leitungsauskunft eingeholt, keine Fremdleitungen unter der Stellflaeche",
                   "p7": "Denkmalschutz und Gestaltungssatzung geprueft (Ortskern, Ensemble, Farbe/Verkleidung)",
                   "p8": "Kabelzufuehrung/Trassenanbindung plausibel (Hk-Zufuehrung, Verteilkabel, Bohrung/Graben moeglich)"}
PRUEF_STATUS = ("", "OK", "Nicht OK", "Nicht relevant")
GRUND = ("", "oeffentlich", "privat")
ZUSTIMMUNG = ("", "beantragt", "erteilt", "abgelehnt")            # oeffentlicher Grund: Wegebaulasttraeger nach § 127 TKG
GESTATTUNG = ("", "in Verhandlung", "unterschrieben", "abgelehnt")  # Privatgrund: Gestattungsvertrag
VARIANTEN = ("Haupt", "Alternativ")
STOSI_SPALTEN = ["variante"] + ["{}_status".format(k) for k, _ in CHECKLISTE] + ["{}_bem".format(k) for k, _ in CHECKLISTE] + \
                ["grund", "zustimmung", "gestattung", "eigentuemer", "gesamt", "offene_punkte"]


def gesamtstatus(row):
    """-> (Gesichert | Offen | Abgelehnt, Liste offener Punkte als Text)."""
    g = lambda k: _s(row.get(k) if hasattr(row, "get") else row[k])   # noqa: E731
    offen, abgelehnt = [], False
    for k, text in CHECKLISTE:
        st = g(k + "_status")
        if st == "Nicht OK":
            abgelehnt = True
            offen.append("{} NICHT OK".format(k.upper()))
        elif st not in ("OK", "Nicht relevant"):
            offen.append("{} ungeprueft".format(k.upper()))
    grund, zu, ge = g("grund"), g("zustimmung"), g("gestattung")
    if grund == "oeffentlich":
        if zu == "abgelehnt":
            abgelehnt = True
            offen.append("Zustimmung § 127 TKG abgelehnt")
        elif zu != "erteilt":
            offen.append("Zustimmung § 127 TKG {}".format(zu or "nicht beantragt"))
    elif grund == "privat":
        if ge == "abgelehnt":
            abgelehnt = True
            offen.append("Gestattung abgelehnt")
        elif ge != "unterschrieben":
            offen.append("Gestattungsvertrag {}".format(ge or "offen"))
    else:
        offen.append("Grund (oeffentlich/privat) nicht festgelegt")
    if abgelehnt:
        return "Abgelehnt", offen
    return ("Gesichert" if not offen else "Offen"), offen


def stosi_vorbelegen(info):
    """Checkliste aus der automatischen Pruefung vorbelegen - nur, was das Werkzeug sicher weiss."""
    d = {"variante": "Haupt"}
    for k, _ in CHECKLISTE:
        d[k + "_status"], d[k + "_bem"] = "", ""
    lage, rest = _s(info.get("lage")), info.get("restgehweg_m")
    if lage.startswith("Bankett"):
        d["p2_status"], d["p2_bem"] = "Nicht relevant", "kein Gehweg (Bankett)"
        if lage == "Bankett schmal":
            d["p1_bem"] = "Strassenraum schmal: Fahrbahnbreite und Bankett vor Ort messen (Achse {} m, Regelbreite {} m)".format(
                info.get("achse_m"), info.get("regelbreite_m"))
    elif lage == "Gehweg" and rest is not None:
        if rest >= REGELN["restgehweg_m"]:
            d["p2_status"], d["p2_bem"] = "OK", "Restbreite {:.2f} m (ALKIS Gehwegflaeche bis Strassenverkehr)".format(rest)
        else:
            d["p2_bem"] = "Restbreite rechnerisch {:.2f} m - vor Ort messen".format(rest)
    elif lage == "privat":
        d["p2_status"], d["p2_bem"] = "Nicht relevant", "Privatgrund an der Strassengrenze"
    elif lage == "Weg":
        d["p2_status"], d["p2_bem"] = "Nicht relevant", "Wirtschaftsweg/Weg ohne Strassenanschluss"
    kr = info.get("kreuzung_m")
    if kr is not None and kr >= 25:
        d["p3_status"], d["p3_bem"] = "OK", "naechste Kreuzung {:.0f} m".format(kr)
    d["grund"] = "oeffentlich" if info.get("oeffentlich") else ("privat" if info.get("oeffentlich") is False else "")
    d["zustimmung"], d["gestattung"], d["eigentuemer"] = "", "", ""
    d["gesamt"], offen = gesamtstatus(d)
    d["offene_punkte"] = "; ".join(offen)
    return d


# --- Eingang ---------------------------------------------------------------------------------------------------------------------------
def nvt_laden(quelle, log=print):
    """quelle: nvt_gebiete_*.gpkg (Werkzeug 3), 'plangoo' (NVT des offenen Projekts) oder Punkt-GeoPackage/Shape.
    -> (sitze GeoDataFrame [name, geometry], gebiete GeoDataFrame|None, adressen GeoDataFrame|None, trassen GeoDataFrame|None)"""
    import geopandas as gpd
    q = str(quelle)
    gebiete = adressen = trassen = None
    if q.lower() == "plangoo":
        sitze = _nvt_aus_plangoo(log)
    else:
        import pyogrio
        layer = [n for n, _ in pyogrio.list_layers(q)]
        if "nvt_sitz" in layer:
            sitze = gpd.read_file(q, layer="nvt_sitz")
            gebiete = gpd.read_file(q, layer="nvt_gebiete") if "nvt_gebiete" in layer else None
            adressen = gpd.read_file(q, layer="adressen") if "adressen" in layer else None
            trassen = gpd.read_file(q, layer="netz") if "netz" in layer else None
        else:
            sitze = gpd.read_file(q, layer=layer[0])
            if "name" not in sitze.columns:
                for c in ("NAME", "bezeichner", "Bezeichner", "nvt", "NVT", "id"):
                    if c in sitze.columns:
                        sitze["name"] = sitze[c].astype(str)
                        break
                else:
                    sitze["name"] = ["NVT{:02d}".format(i + 1) for i in range(len(sitze))]
    for g in (sitze, gebiete, adressen, trassen):
        if g is not None and (g.crs is None or g.crs.to_epsg() != CRS):
            g.to_crs(CRS, inplace=True) if g.crs is not None else g.set_crs(CRS, inplace=True, allow_override=True)
    sitze = sitze[sitze.geometry.notna()].reset_index(drop=True)
    sitze["name"] = sitze["name"].astype(str)
    log("NVT: {} Sitze{}{}".format(len(sitze), ", Gebiete" if gebiete is not None else "", ", Adressen" if adressen is not None else ""))
    return sitze, gebiete, adressen, trassen


def _nvt_aus_plangoo(log):
    import importlib
    import geopandas as gpd
    from shapely.geometry import Point
    from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject
    inst = plangoo_api.instanz()
    if inst is None:
        raise RuntimeError("Kein Plan[Goo]-Projekt geoeffnet.")
    layer = inst.get_point_layer()
    ct = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:{}".format(CRS)), QgsProject.instance())
    rows, geoms = [], []
    for f in layer.getFeatures():
        if str(f["TYPE"] or "") != "nvt" or f.geometry() is None or f.geometry().isEmpty():
            continue
        p = ct.transform(f.geometry().asPoint())
        rows.append({"name": str(f["NAME"] or f["UID"]), "uid": str(f["UID"])})
        geoms.append(Point(p.x(), p.y()))
    if not rows:
        raise RuntimeError("Das Projekt enthaelt keine NVT.")
    return gpd.GeoDataFrame(rows, geometry=geoms, crs=CRS)


def bestand_plangoo(log=print):
    """NVT-Punkte des offenen Plan[Goo]-Projekts als Bestand-Anker (leer, wenn kein Projekt offen oder kein QGIS)."""
    try:
        g = _nvt_aus_plangoo(lambda s: None)
        g["quelle"] = "Plan[Goo]"
        log("Bestand: {} NVT aus dem offenen Plan[Goo]-Projekt".format(len(g)))
        return g[["name", "quelle", "geometry"]]
    except Exception:
        return None


def trassen_laden(pfad, log=print):
    """Plan[Goo]-GeoPackage (GEOMETRY_LINE) -> GeoDataFrame Linien EPSG:25832 ohne Gebaeude-Stuecke."""
    import geopandas as gpd
    g = gpd.read_file(pfad, layer="GEOMETRY_LINE")
    g = g.set_crs(3857, allow_override=True) if g.crs is None else g
    g = g.to_crs(CRS)
    if "TYPE" in g:
        g = g[g["TYPE"].fillna("underground").astype(str) != "in_house"]
    g = g.explode(index_parts=False, ignore_index=True)
    log("Trassen: {} Linien aus {}".format(len(g), os.path.basename(pfad)))
    return g[["geometry"]].reset_index(drop=True)


def _bbox4326(minx, miny, maxx, maxy, rand_m):
    import geopandas as gpd
    from shapely.geometry import Point
    box = gpd.GeoSeries([Point(minx - rand_m, miny - rand_m), Point(maxx + rand_m, maxy + rand_m)], crs="EPSG:25832").to_crs(4326).total_bounds
    return (box[1], box[0], box[3], box[2])


def osm_strassen(minx, miny, maxx, maxy, out_dir, log=print):
    """OSM-Strassenachsen mit highway-Typ (Regelbreite als Ersatz fuer die Fahrbahnkante, Trassenersatz). -> GeoDataFrame oder None"""
    try:
        from ..cluster import osm
        js = osm.fetch(_bbox4326(minx, miny, maxx, maxy, 200), os.path.join(out_dir, "osm_cache.json") if out_dir else None)
        strassen, _ = osm.to_frames(js, CRS)
        strassen = strassen[strassen.highway.isin(list(ACHSEN.keys()))]
        log("OSM: {} Strassenachsen".format(len(strassen)))
        return strassen if len(strassen) else None
    except osm.Abgebrochen:
        raise
    except Exception as e:
        log("OSM nicht geladen ({}) - Restgehweg ohne ALKIS bleibt ungeprueft".format(str(e)[:80]))
        return None


def osm_bestand(minx, miny, maxx, maxy, out_dir, log=print):
    """Vorhandene Netzverteiler/Schaltschraenke aus OSM (man_made=street_cabinet, telecom). -> GeoDataFrame [name, quelle] oder None"""
    try:
        import geopandas as gpd
        from shapely.geometry import Point
        from ..cluster import osm
        s, w, n, e = _bbox4326(minx, miny, maxx, maxy, 300)
        q = ('[out:json][timeout:60];(node["man_made"="street_cabinet"]({s},{w},{n},{e});way["man_made"="street_cabinet"]({s},{w},{n},{e});'
             'node["telecom"]({s},{w},{n},{e}););out center tags;').format(s=s, w=w, n=n, e=e)
        js = osm.fetch((s, w, n, e), os.path.join(out_dir, "osm_cache_bestand.json") if out_dir else None, query=q)
        rows, geoms = [], []
        for el in js.get("elements", []):
            t = el.get("tags", {}) or {}
            lat, lon = (el.get("lat"), el.get("lon")) if el.get("type") == "node" else ((el.get("center") or {}).get("lat"), (el.get("center") or {}).get("lon"))
            if lat is None or lon is None:
                continue
            art = t.get("street_cabinet") or t.get("telecom") or "Schaltschrank"
            op = t.get("operator") or ""
            rows.append({"name": "{}{}".format(art, " (" + op + ")" if op else ""), "quelle": "OSM", "telekom": int("telekom" in op.lower() or art == "telecom")})
            geoms.append(Point(lon, lat))
        if not rows:
            log("Bestand: keine Schaltschraenke in OSM im Umgriff")
            return None
        g = gpd.GeoDataFrame(rows, geometry=geoms, crs=4326).to_crs(CRS)
        log("Bestand: {} Schaltschraenke aus OSM ({} Telekom/Telecom)".format(len(g), int(g["telekom"].sum())))
        return g
    except osm.Abgebrochen:
        raise
    except Exception as e:
        log("Bestand aus OSM nicht geladen ({})".format(str(e)[:80]))
        return None


def _breite(poly, max_m=12.0):
    """Breite einer Verkehrsflaeche = Durchmesser des groessten Innenkreises (Bisektion ueber negative Puffer). Buergersteig 1,5-3 m,
    Stichstrasse ab 3,5 m, Strassenraum mit Fahrbahn ab 5 m."""
    try:
        lo, hi = 0.0, max_m / 2.0
        if poly.buffer(-hi).is_empty is False:
            return max_m
        for _ in range(12):
            m = (lo + hi) / 2.0
            if poly.buffer(-m).is_empty:
                hi = m
            else:
                lo = m
        return round(2.0 * lo, 2)
    except Exception:
        return None


# --- Kontext ---------------------------------------------------------------------------------------------------------------------------
class Kontext(object):
    def __init__(self, flaechen, strassen, trassen, regeln, bestand=None):
        from shapely.ops import unary_union
        from shapely.prepared import prep
        from shapely.strtree import STRtree
        self.r = dict(REGELN)
        self.r.update(regeln or {})
        self.flur = flaechen.get("flurstuecke")
        self.verkehr = flaechen.get("verkehr")
        self.geb = flaechen.get("gebaeude")
        if self.geb is not None and "relevant" in self.geb:
            self.geb = self.geb[self.geb["relevant"]].reset_index(drop=True)
        self.strassen = strassen
        self.trassen = trassen
        self.bestand = bestand if bestand is not None and len(bestand) else None
        # OSM-Achsen mit Typ (gleiche Reihenfolge wie der Baum self.t["strassen"])
        s_geoms, self.strassen_typ = [], []
        if strassen is not None and len(strassen):
            hw = strassen["highway"] if "highway" in strassen else [""] * len(strassen)
            for g, h in zip(strassen.geometry, hw):
                if g is not None and not g.is_empty:
                    s_geoms.append(g)
                    self.strassen_typ.append(str(h))
        stree = STRtree(s_geoms) if s_geoms else None
        # Verkehrsflaechen einzeln einstufen (Markus 18.09.2026: NVT stand mitten auf einer Stichstrasse, weil ALKIS sie als "Weg" fuehrt,
        # waehrend der Gehweg gegenueber als "Begleitflaeche Strassenverkehr" wie Fahrbahn behandelt wurde):
        #   Fahrbahn = Strassenverkehr ohne Zusatz, Fahrweg/Wirtschaftsweg, Parkplatz; dazu "Weg", der befahrbar ist: OSM-Fahrachse laeuft
        #              darin (>= 8 m und >= 30 % der Laenge), breiter als 3,5 m, oder mit Strassennamen (Stichstrasse/Anliegerweg)
        #   Gehweg   = Begleitflaeche Strassenverkehr, Fussweg/Gehweg/Radweg/Platz, oder namenloser schmaler "Weg" am Strassenraum
        #   Weg      = Gehweg-Einstufung ohne Anschluss (> 1 m) an eine Fahrbahn-Flaeche (Fuss-/Wirtschaftsweg im Gelaende)
        self.teile = []
        if self.verkehr is not None and len(self.verkehr):
            def col(c):
                if c not in self.verkehr:
                    return [""] * len(self.verkehr)
                return [("" if v is None or str(v) in ("None", "nan") else str(v)) for v in self.verkehr[c]]
            einst = []
            for g, n, bz, nm in zip(self.verkehr.geometry, col("nutzart"), col("bez"), col("name")):
                if g is None or g.is_empty:
                    einst.append("")
                    continue
                txt = "{} {}".format(n, bz).strip()
                achsen = [j for j in (stree.query(g) if stree is not None else []) if s_geoms[j].intersection(g).length > 0.5]
                l_in = sum(s_geoms[j].intersection(g).length for j in achsen)
                breite = _breite(g)
                if FUSSWEG.search(txt):
                    klasse = "Gehweg"
                elif FAHRBAHN.search(n) or FAHRWEG.search(txt):
                    klasse = "Fahrbahn"
                elif l_in >= self.r["achse_in_min_m"] and l_in >= 0.3 * g.length / 2.0:
                    klasse = "Fahrbahn"
                elif breite > self.r["gehweg_max_breite_m"] or nm.strip():
                    klasse = "Fahrbahn"
                else:
                    klasse = "Gehweg"
                self.teile.append({"geom": g, "klasse": klasse, "achsen": achsen, "breite": breite, "name": nm.strip(), "nutzart": txt})
                einst.append(klasse)
        fahr = [t["geom"] for t in self.teile if t["klasse"] == "Fahrbahn"]
        self.fahrbahn = unary_union(fahr) if fahr else None
        self.fahrbahn_prep = prep(self.fahrbahn) if self.fahrbahn is not None else None
        geh, sonst = [], []
        for t in self.teile:
            if t["klasse"] != "Gehweg":
                continue
            if self.fahrbahn is not None and t["geom"].distance(self.fahrbahn) <= 1.0:
                geh.append(t["geom"])
            else:
                t["klasse"] = "Weg"
                sonst.append(t["geom"])
        if self.teile:
            k, ein2 = iter(t["klasse"] for t in self.teile), []
            for e in einst:
                ein2.append(next(k) if e else "")
            self.verkehr["einstufung"] = ein2
        self.t = {"teile": (STRtree([t["geom"] for t in self.teile]) if self.teile else None, None)}
        self.gehweg = unary_union(geh) if geh else None
        self.gehweg_prep = prep(self.gehweg) if self.gehweg is not None else None
        self.weg = unary_union(sonst) if sonst else None
        self.weg_prep = prep(self.weg) if self.weg is not None else None
        fahr_teile = list(self.fahrbahn.geoms) if self.fahrbahn is not None and hasattr(self.fahrbahn, "geoms") else ([self.fahrbahn] if self.fahrbahn is not None else [])
        # Strassenflurstuecke = oeffentlicher Grund: Nutzung Verkehr (tntxt), Anteil Fahrbahn >= 30 % oder >= 15 m Netz
        sf = []
        if self.flur is not None and len(self.flur):
            tt, tg = None, []
            if trassen is not None and len(trassen):
                tg = [g for g in trassen.geometry if g is not None and not g.is_empty]
                tt = STRtree(tg) if tg else None
            ftree = STRtree(fahr_teile) if fahr_teile else None
            tn = self.flur["tntxt"] if "tntxt" in self.flur else [""] * len(self.flur)
            for poly, t in zip(self.flur.geometry, tn):
                if poly is None or poly.is_empty:
                    continue
                if FAHRBAHN.search(str(t)) or GEHWEG.search(str(t).split(";")[0]):
                    sf.append(poly)
                    continue
                if ftree is not None and sum(fahr_teile[j].intersection(poly).area for j in ftree.query(poly)) >= 0.3 * poly.area:
                    sf.append(poly)
                    continue
                if tt is not None and sum(tg[j].intersection(poly).length for j in tt.query(poly)) >= 15.0:
                    sf.append(poly)
        self.strassen_flur = sf
        self.strassen_flur_union = unary_union(sf) if sf else None
        self.strassen_flur_prep = prep(self.strassen_flur_union) if sf else None
        for name, gdf in (("geb", self.geb), ("flur", self.flur), ("trassen", trassen)):
            geoms = [g for g in gdf.geometry if g is not None and not g.is_empty] if gdf is not None and len(gdf) else []
            self.t[name] = (STRtree(geoms) if geoms else None, geoms)
        self.t["strassen"] = (stree, s_geoms)
        self.t["fahrbahn"] = (STRtree(fahr_teile) if fahr_teile else None, fahr_teile)
        bpts = [g for g in self.bestand.geometry if g is not None] if self.bestand is not None else []
        self.t["bestand"] = (STRtree(bpts) if bpts else None, bpts)
        from shapely.geometry import Point as _P
        self.kreuzungen = _kreuzungen(trassen if trassen is not None else strassen)
        kp = [_P(x, y) for x, y in self.kreuzungen]
        self.t["kreuz"] = (STRtree(kp) if kp else None, kp)

    # -- Lage -----------------------------------------------------------------------------------------------------------------------
    def teil(self, p):
        """Verkehrsflaeche (Eintrag aus self.teile), in der p liegt, sonst None."""
        tree, _ = self.t.get("teile", (None, None))
        if tree is None:
            return None
        for j in tree.query(p):
            if self.teile[j]["geom"].contains(p):
                return self.teile[j]
        return None

    def lage(self, p):
        """-> (oeffentlich True/False/None, Abstand zur Grenze der eigenen Flaeche, Grob-Lage: Strassenraum | Gehweg | Weg | privat | unbekannt,
        Verkehrsflaeche oder None). Der Randabstand geht auf die vereinigte Flaeche gleicher Klasse, damit Naehte zwischen zwei
        ALKIS-Polygonen nicht als Grenze zaehlen."""
        t = self.teil(p)
        if t is not None:
            if t["klasse"] == "Gehweg" and self.gehweg is not None:
                return True, self.gehweg.boundary.distance(p), "Gehweg", t
            if t["klasse"] == "Fahrbahn" and self.fahrbahn is not None:
                return True, self.fahrbahn.boundary.distance(p), "Strassenraum", t
            if t["klasse"] == "Weg" and self.weg is not None:
                return True, self.weg.boundary.distance(p), "Weg", t
        if self.gehweg_prep is not None and self.gehweg_prep.contains(p):
            return True, self.gehweg.boundary.distance(p), "Gehweg", None
        if self.fahrbahn_prep is not None and self.fahrbahn_prep.contains(p):
            return True, self.fahrbahn.boundary.distance(p), "Strassenraum", None
        if self.weg_prep is not None and self.weg_prep.contains(p):
            return True, self.weg.boundary.distance(p), "Weg", None
        if self.strassen_flur_prep is not None and self.strassen_flur_prep.contains(p):
            return True, self.strassen_flur_union.boundary.distance(p), "Strassenraum", None
        if self.verkehr is None and self.flur is None:
            return None, None, "unbekannt", None
        return False, (self.fahrbahn.distance(p) if self.fahrbahn is not None else None), "privat", None

    def fahrbahn_abstand(self, p):
        tree, geoms = self.t["fahrbahn"]
        if tree is None:
            return None
        kand = tree.query(p.buffer(40.0))
        return min((geoms[j].distance(p) for j in kand), default=99.0)

    def gebaeude_abstand(self, p):
        tree, geoms = self.t["geb"]
        if tree is None:
            return None
        kand = tree.query(p.buffer(6.0))
        return min((geoms[j].distance(p) for j in kand), default=99.0)

    def strassentyp(self, p):
        tree, geoms = self.t["strassen"]
        if tree is None:
            return None, None
        best = None
        for j in tree.query(p.buffer(30.0)):
            d = geoms[j].distance(p)
            if best is None or d < best[0]:
                best = (d, j)
        if best is None:
            return None, None
        return self.strassen_typ[best[1]], best[0]

    def achse(self, p, teil=None):
        """Massgebliche OSM-Achse fuer p: liegt p in einer Verkehrsflaeche, zaehlen nur Achsen, die in ihr verlaufen oder hoechstens 1,5 m
        daneben - sonst bekam eine Stichstrasse die Achse der Hauptstrasse und galt als breites Bankett. Ohne Flaeche wie bisher die
        naechste Achse bis 25 m. -> (Abstand, highway-Typ, Regelbreite) oder (None, None, None)"""
        if teil is not None:
            tree, geoms = self.t["strassen"]
            best = None
            for j in teil["achsen"]:
                d = geoms[j].distance(p)
                if best is None or d < best[0]:
                    best = (d, j)
            if best is None and tree is not None:
                saum = teil["geom"].buffer(1.5)
                for j in tree.query(saum):
                    if geoms[j].intersection(saum).length >= self.r["achse_in_min_m"]:
                        d = geoms[j].distance(p)
                        if best is None or d < best[0]:
                            best = (d, j)
            if best is None:
                return None, None, None
            typ = self.strassen_typ[best[1]]
            return best[0], typ, ACHSEN.get(typ, 5.5)
        typ, d = self.strassentyp(p)
        if typ is None or d is None or d > 25.0:
            return None, None, None
        return d, typ, ACHSEN.get(typ, 5.5)

    def kreuzung_abstand(self, p):
        tree, pts = self.t.get("kreuz", (None, []))
        if tree is None:
            return None
        kand = tree.query(p.buffer(60.0))
        return min((pts[j].distance(p) for j in kand), default=99.0)

    def bestand_abstand(self, p):
        tree, pts = self.t.get("bestand", (None, []))
        if tree is None:
            return None, ""
        kand = list(tree.query(p.buffer(60.0)))
        if not kand:
            return None, ""
        j = min(kand, key=lambda k: pts[k].distance(p))
        return pts[j].distance(p), _s(self.bestand["name"].iloc[j]) if self.bestand is not None else ""

    def flurstueck(self, p):
        tree, geoms = self.t["flur"]
        if tree is None:
            return None
        for j in tree.query(p):
            if geoms[j].contains(p):
                return self.flur.iloc[j]
        return None


def _kreuzungen(linien):
    """Knoten, an denen >= 3 Linienenden zusammenlaufen (Kreuzung/Einmuendung). -> Liste (x, y)"""
    from collections import Counter
    if linien is None or not len(linien):
        return []
    z = Counter()
    for g in linien.geometry:
        if g is None or g.is_empty:
            continue
        for part in (g.geoms if hasattr(g, "geoms") else [g]):
            c = list(part.coords)
            z[(round(c[0][0], 1), round(c[0][1], 1))] += 1
            z[(round(c[-1][0], 1), round(c[-1][1], 1))] += 1
    return [k for k, n in z.items() if n >= 3]


# --- Bewertung -------------------------------------------------------------------------------------------------------------------------
def bewerten(ctx, p, sitz, gebiet=None):
    """-> (zulaessig, score, info). info["lage"]: Gehweg | Bankett | Bankett schmal | Fahrbahn | Weg | privat | unbekannt"""
    r = ctx.r
    info = {}
    oeff, rand, grob, teil = ctx.lage(p)
    gd = ctx.gebaeude_abstand(p)
    d_achse, typ, breite = ctx.achse(p, teil)
    fk = ctx.fahrbahn_abstand(p) if grob in ("Gehweg", "privat", "Weg") else None
    kr = ctx.kreuzung_abstand(p)
    bd, bname = ctx.bestand_abstand(p)
    im_gebiet = True if gebiet is None else gebiet.contains(p)
    info.update({"oeffentlich": oeff, "rand_m": (round(rand, 2) if rand is not None else None), "gebaeude_m": (None if gd is None else round(gd, 2)),
                 "achse_m": (None if d_achse is None else round(d_achse, 2)), "strasse_typ": typ, "regelbreite_m": breite,
                 "kreuzung_m": (None if kr is None else round(kr, 1)), "bestand_m": (None if bd is None else round(bd, 1)),
                 "bestand_name": bname, "im_gebiet": im_gebiet, "restgehweg_m": None, "fahrbahn_m": None})
    gruende, strafe = [], 0.0
    lage = grob
    halb = r["nvt_tiefe_m"] / 2.0                                       # Kandidat = NVT-Mitte; Vorderkante liegt halbe Tiefe weiter
    fb = None if teil is None else teil.get("breite")                   # Breite der Verkehrsflaeche (groesster Innenkreis)
    if grob == "Strassenraum":
        if d_achse is None:
            # keine Achse in der Flaeche: Fahrbahn aus der Flaechenbreite schaetzen - was neben dem NVT bleibt, muss die Fahrbahn tragen
            frei = None if fb is None or rand is None else fb - rand - halb
            info["fahrbahn_m"] = None if frei is None else round(max(frei, 0.0), 2)
            if frei is None:
                lage, strafe = "Bankett", strafe + 1.0
                info["hinweis_lage"] = "Fahrbahnlage ohne OSM-Achse nicht schaetzbar"
            elif frei < 2.0 * r["fahrbahn_min_halb_m"] + r["fahrbahn_min_m"]:
                lage = "Fahrbahn"
                gruende.append("auf der Fahrbahn (Flaeche {:.1f} m breit, keine OSM-Achse)".format(fb))
            elif frei < REGELBREITE["residential"] + r["fahrbahn_min_m"]:
                lage, strafe = "Bankett schmal", strafe + 1.5
                info["hinweis_lage"] = "keine OSM-Achse: Fahrbahn aus Flaechenbreite {:.1f} m geschaetzt".format(fb)
            else:
                lage, strafe = "Bankett", strafe + 0.5
                info["hinweis_lage"] = "keine OSM-Achse: Fahrbahn aus Flaechenbreite {:.1f} m geschaetzt".format(fb)
        else:
            frei_regel = d_achse - breite / 2.0 - halb                  # Luft zwischen NVT-Vorderkante und Regel-Fahrbahnkante
            frei_min = d_achse - r["fahrbahn_min_halb_m"] - halb        # dito bei Mindestfahrbahn 3,5 m
            info["fahrbahn_m"] = round(max(d_achse - breite / 2.0, 0.0), 2)
            if frei_min < r["fahrbahn_min_m"]:
                lage = "Fahrbahn"
                gruende.append("auf der Fahrbahn (Achse {:.1f} m)".format(d_achse))
            elif frei_regel < r["fahrbahn_min_m"]:
                lage, strafe = "Bankett schmal", strafe + 1.5
            else:
                lage, strafe = "Bankett", strafe - 0.5 - 0.25 * min(2.0, frei_regel)   # breiter Seitenraum ist besser
    elif grob == "Gehweg":
        rest = None if fk is None else fk - halb
        info["restgehweg_m"], info["fahrbahn_m"] = (None if rest is None else round(rest, 2)), (None if fk is None else round(fk, 2))
        if rest is not None and rest < r["restgehweg_m"]:
            gruende.append("Gehwegrestbreite {:.1f} m".format(rest))
        else:
            strafe -= 1.5                                               # Buergersteig ist der Wunschplatz (Markus 18.09.2026)
            if rest is not None:
                strafe += 0.5 * max(0.0, 2.0 - rest)                    # knapp ueber 1,5 m ist schlechter als 2 m
    elif grob == "Weg":
        strafe += 0.5
        if d_achse is not None and d_achse - breite / 2.0 - halb < r["fahrbahn_min_m"]:
            gruende.append("auf dem Weg (Achse {:.1f} m)".format(d_achse))
        elif d_achse is None and fb is not None and rand is not None and fb - rand - halb < r["restgehweg_m"]:
            gruende.append("Weg zu schmal ({:.1f} m)".format(fb))
    elif grob == "privat":
        info["fahrbahn_m"] = None if fk is None else round(fk, 2)
        if fk is None or fk > r["privat_max_m"]:
            gruende.append("nicht oeffentlich")
        else:
            strafe += 2.5                                               # Gestattungsvertrag noetig - nur wenn nichts Oeffentliches passt
            lage = "privat"
    else:
        strafe += 1.0
    if gd is not None and gd < r["gebaeude_min_m"]:
        gruende.append("im/am Gebaeude ({:.1f} m)".format(gd))
    auf_gehweg = grob in ("Gehweg", "Weg")
    rmin = min(r["rand_min_m"], r["rand_min_gehweg_m"]) if auf_gehweg else r["rand_min_m"]
    rwunsch = min(r["rand_wunsch_m"], r["rand_wunsch_gehweg_m"]) if auf_gehweg else r["rand_wunsch_m"]
    if rand is not None and grob in ("Strassenraum", "Gehweg", "Weg") and rand < rmin:
        gruende.append("zu nah an der Grenze ({:.1f} m)".format(rand))
    if kr is not None and kr < r["kreuzung_min_m"]:
        gruende.append("Kreuzung {:.0f} m".format(kr))
    if bd is not None and bd < 0.8:
        gruende.append("ueberlappt Bestand-NVT")
    if not im_gebiet:
        gruende.append("ausserhalb des Gebiets")
    zul = not gruende
    score = 0.05 * p.distance(sitz) + strafe
    if rand is not None and grob in ("Strassenraum", "Gehweg", "Weg"):
        score += 0.5 * abs(rand - rwunsch)
    if bd is not None and 0.8 <= bd <= r["bestand_nah_m"]:
        score -= 4.0                                  # neben einem vorhandenen NVT: der Platz ist erprobt und genehmigt
    if kr is not None and kr < 15:
        score += 0.1 * (15 - kr)
    score += 10.0 * len(gruende)
    info["lage"] = lage
    info["gruende"] = "; ".join(gruende)
    return zul, score, info


def _normale(a, b):
    dx, dy = b.x - a.x, b.y - a.y
    n = math.hypot(dx, dy) or 1.0
    return -dy / n, dx / n


def _entlang(geom, kreis, schritt):
    """Punkte (a, b) alle schritt Meter entlang der Linien von geom innerhalb kreis."""
    seg = geom.intersection(kreis)
    if seg.is_empty:
        return
    for part in (seg.geoms if hasattr(seg, "geoms") else [seg]):
        if part.geom_type != "LineString" or part.length < 0.5:
            continue
        L = part.length
        d = 0.0
        while d <= L:
            yield part.interpolate(d), part.interpolate(min(L, d + 0.5))
            d += schritt


def kandidaten(ctx, sitz):
    """Kandidaten im Suchradius: neben der Fahrbahnkante (Bankett), auf Gehweg-/Weg-/Platzflaechen, neben Bestand-NVT; ohne ALKIS-
    Flaechen wie frueher senkrecht zu den Trassen. -> Liste (Point, offset, art)"""
    from shapely.geometry import Point
    r = ctx.r
    out = []
    kreis = sitz.buffer(r["suchradius_m"])
    if ctx.fahrbahn is not None:
        for a, b in _entlang(ctx.fahrbahn.boundary, kreis, r["schritt_m"]):
            nx_, ny_ = _normale(a, b)
            probe = Point(a.x + nx_ * 0.3, a.y + ny_ * 0.3)
            if not ctx.fahrbahn_prep.contains(probe):
                nx_, ny_ = -nx_, -ny_                                    # nx zeigt in den Strassenraum
            for off in r["offsets_bankett_m"]:
                out.append((Point(a.x + nx_ * off, a.y + ny_ * off), off, "Strassenrand"))
            for off in r["offsets_privat_m"]:
                out.append((Point(a.x - nx_ * off, a.y - ny_ * off), off, "Privatgrund"))
    if ctx.gehweg is not None:
        for a, b in _entlang(ctx.gehweg.boundary, kreis, r["schritt_m"]):
            nx_, ny_ = _normale(a, b)
            probe = Point(a.x + nx_ * 0.3, a.y + ny_ * 0.3)
            if not ctx.gehweg_prep.contains(probe):
                nx_, ny_ = -nx_, -ny_
            for off in r["offsets_gehweg_m"]:
                out.append((Point(a.x + nx_ * off, a.y + ny_ * off), off, "Gehwegrand"))
    tree, bpts = ctx.t.get("bestand", (None, []))
    if tree is not None:
        for j in tree.query(sitz.buffer(r["suchradius_m"] * 1.5)):
            q = bpts[j]
            for dist in (1.2, 1.8):
                for w in range(8):
                    ang = w * math.pi / 4.0
                    out.append((Point(q.x + math.cos(ang) * dist, q.y + math.sin(ang) * dist), dist, "neben Bestand"))
    if not out:
        tree, geoms = ctx.t["trassen"] if ctx.t["trassen"][0] is not None else ctx.t["strassen"]
        if tree is None:
            return []
        for j in tree.query(kreis):
            for a, b in _entlang(geoms[j], kreis, r["schritt_m"]):
                nx_, ny_ = _normale(a, b)
                for seite in (1.0, -1.0):
                    for off in r["offsets_m"]:
                        out.append((Point(a.x + seite * nx_ * off, a.y + seite * ny_ * off), off, "Trasse"))
    return out


def standort_waehlen(ctx, sitz, gebiet=None):
    """-> (bester Punkt, info, Korridor-Polygon|None, Anzahl zulaessig)"""
    from shapely.ops import unary_union
    kand = kandidaten(ctx, sitz)
    if not kand:
        return sitz, {"zulaessig": False, "gruende": "keine Strassenflaeche/Trasse im Suchradius", "hinweis": "Sitz unveraendert", "lage": "unbekannt"}, None, 0
    bewertet = []
    for p, off, art in kand:
        zul, score, info = bewerten(ctx, p, sitz, gebiet)
        info["offset_m"], info["kandidat"] = off, art
        bewertet.append((0 if zul else 1, score, p, zul, info))
    bewertet.sort(key=lambda k: (k[0], k[1]))
    zulaessige = [b[2] for b in bewertet if b[3]]
    if not zulaessige and ctx.r["suchradius_m"] < 250:
        alt = ctx.r["suchradius_m"]
        ctx.r["suchradius_m"] = alt * 2
        try:
            for p2, off, art in kandidaten(ctx, sitz):
                zul2, score2, info2 = bewerten(ctx, p2, sitz, gebiet)
                info2["offset_m"], info2["kandidat"] = off, art
                bewertet.append((0 if zul2 else 1, score2, p2, zul2, info2))
        finally:
            ctx.r["suchradius_m"] = alt
        bewertet.sort(key=lambda k: (k[0], k[1]))
        zulaessige = [b[2] for b in bewertet if b[3]]
    _, score, p, zul, info = bewertet[0]
    korridor = unary_union([q.buffer(1.0) for q in zulaessige]).buffer(0.3).buffer(-0.3) if zulaessige else None
    info["zulaessig"] = zul
    info["hinweis"] = "" if zul else ("kein zulaessiger Kandidat im Umkreis; bester Ersatz: " + info["gruende"])
    if zul:
        offen = []
        if info.get("oeffentlich") is None:
            offen.append("oeffentlicher Raum nicht geprueft (keine ALKIS-Flaechen)")
        if info.get("lage") == "Bankett schmal":
            offen.append("Strassenraum schmal - Fahrbahnbreite vor Ort pruefen")
        if info.get("lage") == "privat":
            offen.append("Privatgrund an der Strassengrenze - Gestattungsvertrag noetig")
        if info.get("hinweis_lage"):
            offen.append(info["hinweis_lage"])
        if info.get("bestand_m") is not None and info["bestand_m"] <= ctx.r["bestand_nah_m"]:
            offen.append("neben Bestand-NVT {} ({} m)".format(info.get("bestand_name") or "", info["bestand_m"]))
        info["hinweis"] = "; ".join(offen)
    return p, info, korridor, len(zulaessige)


# --- Standortsicherung: Flurstueck, Adresse -------------------------------------------------------------------------------------------
def stosi_daten(ctx, p, adressen=None):
    """Gemeinde, Gemarkung, Flur, Flurstueck (Zaehler/Nenner), Strasse, Hausnummer, PLZ fuer den Standort."""
    d = {"gemeinde": "", "gemarkung": "", "gemaschl": "", "flur": "", "flurstueck": "", "flurstueck_nenner": "", "strasse": "", "hausnummer": "",
         "plz": "", "ort": ""}
    fl = ctx.flurstueck(p)
    if fl is not None:
        d["gemeinde"] = _s(fl.get("gemeinde"))
        d["gemarkung"] = _s(fl.get("gemarkung"))
        d["gemaschl"] = _s(fl.get("gemaschl"))
        d["flur"] = _s(fl.get("flur"))
        d["flurstueck"] = _s(fl.get("flstnrzae"))
        d["flurstueck_nenner"] = _s(fl.get("flstnrnen"))
        lage = re.sub(r"^\(.*?\)\s*", "", _s(fl.get("lagebeztxt")))
        d["strasse"] = re.sub(r"\s+\d.*$", "", lage).strip(" ,")
    tree, geoms = ctx.t["geb"]
    if tree is not None and ctx.geb is not None and "lagebeztxt" in ctx.geb:
        kand = sorted(((geoms[j].distance(p), j) for j in tree.query(p.buffer(40.0))), key=lambda k: k[0])
        for _, j in kand[:12]:
            lb = re.sub(r"^\(.*?\)\s*", "", _s(ctx.geb["lagebeztxt"].iloc[j]))
            if not lb:
                continue
            if not d["strasse"] or lb.startswith(d["strasse"]):
                nums = list(dict.fromkeys(re.findall(r"\d+\s?[a-zA-Z]?", lb)))
                nums = [n.replace(" ", "") for n in nums]
                if nums:
                    d["hausnummer"] = nums[0] if len(nums) == 1 else "{} - {}".format(nums[0], nums[-1])
                    if not d["strasse"]:
                        d["strasse"] = re.sub(r"\s*\d.*$", "", lb)
                    break
    if adressen is not None and len(adressen):
        try:
            dist = adressen.geometry.distance(p)
            a = adressen.iloc[int(dist.idxmin())]
            d["plz"], d["ort"] = _s(a.get("plz")), _s(a.get("ort"))
            if not d["strasse"]:
                d["strasse"] = _s(a.get("strasse"))
        except Exception:
            pass
    return d


from ... import gemeinsam, plangoo_api
_s = gemeinsam.s_ganz


# --- Standortsicherung: lesen, speichern, Alternative ------------------------------------------------------------------------------------
def standorte_lesen(gpkg):
    """Layer nvt_standorte als GeoDataFrame, fehlende Spalten der Standortsicherung ergaenzt (aeltere Ergebnisse)."""
    import geopandas as gpd
    g = gpd.read_file(gpkg, layer="nvt_standorte")
    if g.crs is None or g.crs.to_epsg() != CRS:
        g = g.set_crs(CRS, allow_override=True)
    for c in STOSI_SPALTEN + ["lage", "fahrbahn_m", "achse_m", "bestand_m", "bestand_name"]:
        if c not in g:
            g[c] = "Haupt" if c == "variante" else ("" if c not in ("fahrbahn_m", "achse_m", "bestand_m") else None)
    g["variante"] = g["variante"].astype(str).replace({"": "Haupt", "nan": "Haupt", "None": "Haupt"})
    return g


def _standorte_schreiben(gpkg, g):
    s = g.copy()
    for c in s.columns:
        if c == "geometry":
            continue
        if c == "zulaessig":
            s[c] = s[c].map(lambda v: 1 if str(v).lower() in ("1", "true", "ja") else 0)
        elif c == "oeffentlich":
            s[c] = s[c].map(lambda v: "" if v is None or str(v) in ("", "nan", "None") else ("ja" if str(v).lower() in ("1", "true", "ja") else ("nein" if str(v).lower() in ("0", "false", "nein") else str(v))))
        elif s[c].dtype == object:
            s[c] = s[c].map(_s)
    s.to_file(gpkg, layer="nvt_standorte", driver="GPKG")
    try:
        from ...gemeinsam import wal_schliessen
        wal_schliessen(gpkg)
    except Exception:
        pass


def standort_speichern(gpkg, name, variante, werte, log=print):
    """Checkliste/Rechtliche Sicherung/Kommentar eines Standorts schreiben und den Gesamtstatus neu ableiten. -> (gesamt, offene Punkte)"""
    g = standorte_lesen(gpkg)
    maske = (g["name"].astype(str) == str(name)) & (g["variante"].astype(str) == str(variante or "Haupt"))
    if not maske.any():
        raise RuntimeError("Standort {} ({}) nicht in der Datei.".format(name, variante))
    erlaubt = set(STOSI_SPALTEN) | {"kommentar", "status", "station", "information", "gehaeusetyp", "strasse", "hausnummer"}
    for k, v in (werte or {}).items():
        if k in erlaubt and k not in ("gesamt", "offene_punkte"):
            g.loc[maske, k] = _s(v)
    zeile = g[maske].iloc[0]
    gesamt, offen = gesamtstatus(zeile)
    g.loc[maske, "gesamt"] = gesamt
    g.loc[maske, "offene_punkte"] = "; ".join(offen)
    g.loc[maske, "status"] = {"Gesichert": "gesichert", "Abgelehnt": "abgelehnt"}.get(gesamt, "offen")
    _standorte_schreiben(gpkg, g)
    log("Standort {} ({}): {}{}".format(name, variante or "Haupt", gesamt, " - " + "; ".join(offen) if offen else ""))
    return gesamt, offen


def alternative_anlegen(gpkg, name, log=print):
    """Zweiten Standort (Variante Alternativ) fuer einen NVT anlegen: Kopie des Hauptstandorts, 3 m nach Osten versetzt, Checkliste leer.
    Der Planer schiebt den Punkt im Layer an die richtige Stelle. -> True, wenn neu angelegt"""
    import geopandas as gpd
    import pandas as pd
    from shapely.geometry import Point
    g = standorte_lesen(gpkg)
    haupt = g[(g["name"].astype(str) == str(name)) & (g["variante"] == "Haupt")]
    if not len(haupt):
        raise RuntimeError("Kein Hauptstandort fuer {}.".format(name))
    if ((g["name"].astype(str) == str(name)) & (g["variante"] == "Alternativ")).any():
        log("Alternativstandort fuer {} gibt es schon.".format(name))
        return False
    z = haupt.iloc[0].to_dict()
    p = z["geometry"]
    z["geometry"] = Point(p.x + 3.0, p.y)
    z["variante"] = "Alternativ"
    for k, _ in CHECKLISTE:
        z[k + "_status"], z[k + "_bem"] = "", ""
    z["zustimmung"], z["gestattung"], z["eigentuemer"] = "", "", ""
    z["kommentar"] = "Alternativstandort - Punkt im Layer an die richtige Stelle schieben, dann pruefen"
    z["gesamt"], offen = gesamtstatus(z)
    z["offene_punkte"] = "; ".join(offen)
    z["status"] = "offen"
    g2 = gpd.GeoDataFrame(pd.concat([g, gpd.GeoDataFrame([z], geometry="geometry", crs=CRS)], ignore_index=True), crs=CRS)
    _standorte_schreiben(gpkg, g2)
    log("Alternativstandort fuer {} angelegt (3 m oestlich, Checkliste leer).".format(name))
    return True


def standorte_fuer_netz(pfad, log=print):
    """Fuer Werkzeug 5 und 9: name -> (x, y) je NVT. Genommen wird der Hauptstandort; ist er abgelehnt und es gibt einen nicht abgelehnten
    Alternativstandort, der Alternativstandort. Nur zulaessige Punkte; nicht zulaessige bleiben beim Sitzvorschlag."""
    g = standorte_lesen(pfad)
    out, wahl = {}, {}
    for _, r in g.iterrows():
        if r.geometry is None or str(r.get("zulaessig")).lower() not in ("1", "true", "ja"):
            continue
        name, var, gesamt = str(r["name"]), _s(r.get("variante")) or "Haupt", _s(r.get("gesamt")) or "Offen"
        rang = (0 if gesamt == "Gesichert" else 1 if gesamt == "Offen" else 2, 0 if var == "Haupt" else 1)
        if name not in wahl or rang < wahl[name]:
            wahl[name] = rang
            out[name] = (r.geometry.x, r.geometry.y)
    log("Standorte aus Werkzeug 4: {} NVT mit zulaessigem Standort von {} Zeilen ({})".format(len(out), len(g), os.path.basename(pfad)))
    return out


def stamm_von(gpkg):
    n = os.path.splitext(os.path.basename(str(gpkg)))[0]
    n = re.sub(r"^nvt_standorte_", "", n)
    return re.sub(r"_\d{8}_\d{4}$", "", n) or "NVT"


def excel_aus_gpkg(gpkg, log=print):
    """Excel der Standortsicherung aus dem (vom Planer bearbeiteten) Layer neu schreiben."""
    g = standorte_lesen(gpkg)
    for c in ("zulaessig",):
        g[c] = g[c].map(lambda v: str(v).lower() in ("1", "true", "ja"))
    return excel_schreiben(g, os.path.dirname(os.path.abspath(gpkg)), stamm_von(gpkg), log)


# --- Gesamtablauf ----------------------------------------------------------------------------------------------------------------------
def pruefen(quelle, netz_pfad=None, out_dir=None, land=None, regeln=None, gehaeusetyp="Gf-NVt 22 L", log=print, fortschritt=None):
    """-> dict(gpkg, excel, bericht, standorte GeoDataFrame, korridore, kontext)"""
    import geopandas as gpd
    import pandas as pd
    from ..adressen import alkis as a_alkis
    from . import alkis_flaechen
    import time as _time
    t0 = _time.time()
    _log = log
    log = lambda s: _log("{:5.0f} s  {}".format(_time.time() - t0, s))   # noqa: E731 - Laufzeit je Phase sichtbar
    f = fortschritt or (lambda p, t: None)
    f(2, "NVT laden")
    sitze, gebiete, adressen, trassen = nvt_laden(quelle, log)
    out_dir = out_dir or (os.path.dirname(os.path.abspath(str(quelle))) if os.path.exists(str(quelle)) else os.path.expanduser("~"))
    os.makedirs(out_dir, exist_ok=True)
    if netz_pfad and os.path.exists(str(netz_pfad)):
        trassen = trassen_laden(netz_pfad, log)
    minx, miny, maxx, maxy = sitze.total_bounds
    if not land:
        kand = a_alkis.laender_fuer_bbox(minx, miny, maxx, maxy)
        land = kand[0] if kand else "NW"
    f(10, "ALKIS-Flaechen abrufen")
    flaechen = alkis_flaechen.laden(minx, miny, maxx, maxy, land, log=log)
    f(40, "OSM-Strassen und Bestand abrufen")
    strassen = osm_strassen(minx, miny, maxx, maxy, out_dir, log)
    bestand = osm_bestand(minx, miny, maxx, maxy, out_dir, log)
    pg = bestand_plangoo(log)
    if pg is not None and len(pg):
        bestand = pg if bestand is None else gpd.GeoDataFrame(pd.concat([bestand[["name", "quelle", "geometry"]], pg], ignore_index=True), crs=CRS)
    if trassen is None:
        trassen = strassen[["geometry"]].copy() if strassen is not None else None
        log("Keine Trassen uebergeben - Strassenachsen dienen als Ersatz")
    ctx = Kontext(flaechen, strassen, trassen, regeln, bestand=bestand)
    kl = {k: sum(1 for t in ctx.teile if t["klasse"] == k) for k in ("Fahrbahn", "Gehweg", "Weg")}
    umg = sum(1 for t in ctx.teile if t["klasse"] == "Fahrbahn" and not FAHRBAHN.search(t["nutzart"]))
    log("Verkehrsflaechen: {} Fahrbahn (davon {} ALKIS-'Weg' als befahrbar erkannt), {} Gehweg, {} Weg ohne Strassenanschluss; Strassenflurstuecke {}, "
        "Bestand-NVT {}".format(kl["Fahrbahn"], umg, kl["Gehweg"], kl["Weg"], len(ctx.strassen_flur), 0 if ctx.bestand is None else len(ctx.bestand)))
    f(55, "Standorte bewerten")
    rows, korr = [], []
    n = len(sitze)
    for i, r in sitze.iterrows():
        if i % 3 == 0:
            f(55 + 35 * i / max(n, 1), "Standort {}/{}".format(i + 1, n))
        sitz = r.geometry
        geb_poly = None
        if gebiete is not None:
            sel = gebiete[gebiete["name"].astype(str) == str(r["name"])]
            if len(sel):
                geb_poly = sel.geometry.iloc[0]
        p, info, korridor, n_zul = standort_waehlen(ctx, sitz, geb_poly)
        sd = stosi_daten(ctx, p, adressen)
        st = stosi_vorbelegen(info)
        rows.append({"name": str(r["name"]), "gehaeusetyp": gehaeusetyp, "zulaessig": bool(info.get("zulaessig")),
                     "oeffentlich": info.get("oeffentlich"), "lage": info.get("lage", ""), "fahrbahn_m": info.get("fahrbahn_m"), "achse_m": info.get("achse_m"),
                     "restgehweg_m": info.get("restgehweg_m"), "rand_m": info.get("rand_m"),
                     "gebaeude_m": info.get("gebaeude_m"), "kreuzung_m": info.get("kreuzung_m"), "bestand_m": info.get("bestand_m"),
                     "bestand_name": info.get("bestand_name", ""), "strasse_typ": info.get("strasse_typ"),
                     "versatz_m": round(p.distance(sitz), 1), "kandidaten_ok": n_zul, "hinweis": info.get("hinweis", ""),
                     "gruende": info.get("gruende", ""), **sd, "station": "", "information": "", "status": "offen", "kommentar": "",
                     "herkunft": "Vorschlag", **st, "geometry": p})
        if korridor is not None and not korridor.is_empty:
            korr.append({"name": str(r["name"]), "flaeche_m2": round(korridor.area), "geometry": korridor})
    standorte = gpd.GeoDataFrame(rows, crs=CRS)
    korridore = gpd.GeoDataFrame(korr, crs=CRS) if korr else None
    f(92, "Schreiben")
    stamm = re.sub(r"[^A-Za-z0-9_\-]+", "_", re.sub(r"^nvt_gebiete_", "", os.path.splitext(os.path.basename(str(quelle)))[0])).strip("_")[:40] or "NVT"
    gpkg = os.path.join(out_dir, "nvt_standorte_{}_{}.gpkg".format(stamm, datetime.now().strftime("%Y%m%d_%H%M")))
    _standorte_schreiben(gpkg, standorte)
    if korridore is not None:
        korridore.to_file(gpkg, layer="korridore", driver="GPKG")
    sitze[["name", "geometry"]].to_file(gpkg, layer="sitz_vorher", driver="GPKG")
    if bestand is not None and len(bestand):
        b = bestand.copy()
        for c in b.columns:
            if c != "geometry" and b[c].dtype == object:
                b[c] = b[c].astype(str)
        b.to_file(gpkg, layer="bestand_nvt", driver="GPKG")
    for lname, gdf in (("flurstuecke", flaechen.get("flurstuecke")), ("verkehrsflaechen", flaechen.get("verkehr"))):
        if gdf is not None and len(gdf):
            g2 = gdf.copy()
            for c in g2.columns:
                if c != "geometry" and g2[c].dtype == object:
                    g2[c] = g2[c].astype(str)
            g2.to_file(gpkg, layer=lname, driver="GPKG")
    excel = excel_schreiben(standorte, out_dir, stamm, log)
    md = bericht(standorte, korridore, out_dir, stamm, quelle, land, ctx, log)
    f(100, "Fertig")
    z = int(standorte["zulaessig"].sum())
    lagen = standorte["lage"].value_counts().to_dict()
    log("Standorte: {} von {} zulaessig ({}), {} Korridore; {}".format(z, len(standorte), ", ".join("{} {}".format(v, k) for k, v in lagen.items()),
                                                                    0 if korridore is None else len(korridore), gpkg))
    return {"gpkg": gpkg, "excel": excel, "bericht": md, "standorte": standorte, "korridore": korridore, "kontext": ctx, "land": land,
            "out_dir": out_dir, "stamm": stamm}


def excel_schreiben(standorte, out_dir, stamm, log=print):
    """Fiberation-Format der Standortsicherung (Dortmund-Skripte) + Flur, Lage, Pruef-Checkliste, Rechtliche Sicherung, Gesamtstatus."""
    import pandas as pd
    p = os.path.join(out_dir, "Netzverteiler-Standorte [{}].xlsx".format(stamm))
    s = standorte
    def sp(c, vor=""):
        return s[c] if c in s else pd.Series([vor] * len(s), index=s.index)
    daten = {
        "Bezeichner": s["name"], "Variante": sp("variante", "Haupt"), "Gehäusetyp": s["gehaeusetyp"], "Gemeinde": s["gemeinde"], "PLZ": s["plz"],
        "Straße": s["strasse"], "Hausnummer": s["hausnummer"], "Flurstück": s["flurstueck"], "Flurstück-Nenner": s["flurstueck_nenner"],
        "Gemarkung": s["gemarkung"], "Flur": s["flur"], "Station": s["station"], "Information": s["information"],
        "Rechtswert": s.geometry.x.round(2), "Hochwert": s.geometry.y.round(2),
        "zulässig": s["zulaessig"].map(lambda v: "ja" if str(v).lower() in ("1", "true", "ja") else "nein"),
        "Lage": sp("lage"), "Abstand Fahrbahnkante m": sp("fahrbahn_m"), "Abstand Strassenachse m": sp("achse_m"), "Gehwegrestbreite m": s["restgehweg_m"],
        "Abstand Grenze m": s["rand_m"], "Abstand Gebäude m": s["gebaeude_m"], "Abstand Kreuzung m": s["kreuzung_m"],
        "Bestand-NVT m": sp("bestand_m"), "Bestand-NVT": sp("bestand_name"),
    }
    for k, text in CHECKLISTE:
        daten["{} {}".format(k.upper(), text)] = sp(k + "_status")
        daten["{} Bemerkung".format(k.upper())] = sp(k + "_bem")
    daten["Grund"] = sp("grund")
    daten["Zustimmung § 127 TKG"] = sp("zustimmung")
    daten["Gestattungsvertrag"] = sp("gestattung")
    daten["Eigentümer-Kontakt"] = sp("eigentuemer")
    daten["Gesamtstatus"] = sp("gesamt", "Offen")
    daten["Offene Punkte"] = sp("offene_punkte")
    daten["Hinweis"] = s["hinweis"].map(_s) + s["gruende"].map(lambda g: (" | " + _s(g)) if _s(g) else "")
    daten["Kommentar"] = sp("kommentar")
    df = pd.DataFrame(daten)
    try:
        with pd.ExcelWriter(p, engine="openpyxl") as w:
            df.to_excel(w, index=False, sheet_name="Netzverteiler-Standorte")
            ws = w.sheets["Netzverteiler-Standorte"]
            for col in ws.columns:
                ws.column_dimensions[col[0].column_letter].width = max(10, min(40, max(len(str(c.value or "")) for c in col) + 2))
            # Uebersicht mit Statusfilter
            ue = df[["Bezeichner", "Variante", "Lage", "zulässig", "Gesamtstatus", "Offene Punkte", "Straße", "Hausnummer", "Flurstück", "Gemarkung"]]
            ue.to_excel(w, index=False, sheet_name="Uebersicht")
            ws2 = w.sheets["Uebersicht"]
            ws2.auto_filter.ref = ws2.dimensions
            for col in ws2.columns:
                ws2.column_dimensions[col[0].column_letter].width = max(10, min(60, max(len(str(c.value or "")) for c in col) + 2))
        log("Excel: " + p)
    except Exception as e:
        log("Excel nicht geschrieben ({})".format(str(e)[:80]))
        p = None
    return p


class _OhneKontext(object):
    """Platzhalter, wenn ALKIS/OSM nicht abgerufen wurden (Zeichnen/Uebernahme ohne Lagepruefung)."""
    def __init__(self, regeln=None):
        self.r = dict(REGELN)
        self.r.update(regeln or {})
        self.flur = self.verkehr = self.geb = self.strassen = self.bestand = None


def bericht(standorte, korridore, out_dir, stamm, quelle, land, ctx, log=print):
    p = os.path.join(out_dir, "nvt_standorte_{}_pruefblatt.md".format(stamm))
    ctx = ctx or _OhneKontext()
    r = ctx.r
    z = int(standorte["zulaessig"].sum())
    zeilen = ["# NVT-Standorte {}".format(stamm), "",
              "Stand {}, Fiberation Werkzeugkasten, Werkzeug 4. Quelle: `{}`. ALKIS {}: {} Flurstuecke, {} Verkehrsflaechen, {} Gebaeude; "
              "OSM-Strassen: {}; Bestand-NVT: {}.".format(datetime.now().strftime("%d.%m.%Y %H:%M"), quelle, land,
                                                            0 if ctx.flur is None else len(ctx.flur), 0 if ctx.verkehr is None else len(ctx.verkehr),
                                                            0 if ctx.geb is None else len(ctx.geb), 0 if ctx.strassen is None else len(ctx.strassen),
                                                            0 if ctx.bestand is None else len(ctx.bestand)),
              "", "Regeln: Verkehrsflaechen einzeln eingestuft (Fahrbahn = Strassenverkehr und befahrbare Wege mit OSM-Achse, Strassenname oder > {} m Breite; "
              "Gehweg = Begleitflaeche, Fuss-/Radweg, Platz, schmale namenlose Wege am Strassenraum); nie auf der Fahrbahn (OSM-Achse in der Flaeche + Regelbreite "
              "je Strassentyp, mindestens 3,5 m, ohne Achse aus der Flaechenbreite); Bankett >= {} m Luft zur Fahrbahnkante; Gehweg Restbreite >= {} m "
              "(halbe NVT-Tiefe {} m); Abstand Grenze >= {} m, auf dem Gehweg >= {} m (Rueckwand an der Grundstuecksgrenze); Gebaeude >= {} m; Kreuzung >= {} m; "
              "Suchradius {} m; Bonus neben Bestand-NVT bis {} m; Privatgrund an der Strassengrenze nur als Notloesung (Gestattungsvertrag).".format(
                  r["gehweg_max_breite_m"], r["fahrbahn_min_m"], r["restgehweg_m"], r["nvt_tiefe_m"] / 2.0, r["rand_min_m"], r["rand_min_gehweg_m"],
                  r["gebaeude_min_m"], r["kreuzung_min_m"], r["suchradius_m"], r["bestand_nah_m"]),
              "", "**{} von {} Standorten zulaessig.** Excel fuer die Standortsicherung: `Netzverteiler-Standorte [{}].xlsx` "
              "(Blatt Netzverteiler-Standorte mit Checkliste, Blatt Uebersicht mit Statusfilter).".format(z, len(standorte), stamm),
              "", "| NVT | Var. | zul. | Lage | Fahrbahn m | Restbreite m | Grenze m | Gebaeude m | Kreuzung m | Bestand m | Strasse | Hnr | Flurstueck | Gesamt | Hinweis |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    q = lambda v: "?" if v is None or (isinstance(v, float) and v != v) else v   # noqa: E731
    for _, s in standorte.sort_values(["name", "variante"] if "variante" in standorte else ["name"]).iterrows():
        fs = _s(s["flurstueck"]) + ("/" + _s(s["flurstueck_nenner"]) if _s(s["flurstueck_nenner"]) else "")
        zeilen.append("| {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} (Flur {}) | {} | {} |".format(
            s["name"], _s(s.get("variante", "Haupt")) or "Haupt", "ja" if str(s["zulaessig"]).lower() in ("1", "true", "ja") else "nein",
            _s(s.get("lage")), q(s.get("fahrbahn_m")), q(s["restgehweg_m"]), q(s["rand_m"]), q(s["gebaeude_m"]), q(s["kreuzung_m"]),
            q(s.get("bestand_m")), s["strasse"], s["hausnummer"], fs, s["flur"], _s(s.get("gesamt")) or "Offen",
            (_s(s["hinweis"]) + (" | " + _s(s["gruende"]) if _s(s["gruende"]) else "")).strip(" |")))
    offen = standorte[standorte["gesamt"].astype(str) != "Gesichert"] if "gesamt" in standorte else standorte
    zeilen += ["", "## OFFEN - Standortsicherung", ""]
    if len(offen):
        for _, s in offen.iterrows():
            zeilen.append("- **{} ({})**: {}".format(s["name"], _s(s.get("variante", "Haupt")) or "Haupt", _s(s.get("offene_punkte")) or "offen"))
    else:
        zeilen.append("alle Standorte gesichert")
    zeilen += ["", "Korridor = Flaeche aller zulaessigen Kandidaten im Suchradius; dort kann der NVT stehen. Der Planer setzt den endgueltigen Punkt "
               "und fuehrt die Checkliste im Werkzeug (Status je Punkt, Rechtliche Sicherung, Alternativstandort). Standortsicherung: Zustimmung "
               "des Wegebaulasttraegers nach § 127 TKG bzw. Gestattungsvertrag; Fotos vor Ort ergaenzen.", ""]
    with open(p, "w", encoding="utf-8") as f:
        f.write("\n".join(zeilen))
    log("Pruefblatt: " + p)
    return p


# --- Standorte vom Planer: gezeichnet oder aus einem Layer uebernommen (Markus 12.10.2026) ----------------------------------------------
def _kontext_laden(minx, miny, maxx, maxy, out_dir, land, regeln, trassen, log, f):
    """ALKIS-Flaechen, OSM-Strassen und Bestand-NVT fuer die Lagepruefung - wie in pruefen()."""
    import geopandas as gpd
    import pandas as pd
    from . import alkis_flaechen
    f(10, "ALKIS-Flaechen abrufen")
    flaechen = alkis_flaechen.laden(minx, miny, maxx, maxy, land, log=log)
    f(40, "OSM-Strassen und Bestand abrufen")
    strassen = osm_strassen(minx, miny, maxx, maxy, out_dir, log)
    bestand = osm_bestand(minx, miny, maxx, maxy, out_dir, log)
    pg = bestand_plangoo(log)
    if pg is not None and len(pg):
        bestand = pg if bestand is None else gpd.GeoDataFrame(pd.concat([bestand[["name", "quelle", "geometry"]], pg], ignore_index=True), crs=CRS)
    if trassen is None:
        trassen = strassen[["geometry"]].copy() if strassen is not None else None
    return Kontext(flaechen, strassen, trassen, regeln, bestand=bestand), flaechen, bestand


def uebernehmen(quelle, punkte, out_dir=None, land=None, regeln=None, gehaeusetyp="Gf-NVt 22 L", herkunft="gezeichnet", lage_pruefen=True,
                log=print, fortschritt=None):
    """Standorte, die der Planer selbst gesetzt hat (gezeichnet oder aus einem vorhandenen Layer), in dieselbe Standortdatei bringen wie
    pruefen(): gleiche Spalten, gleiche Checkliste, gleiche Excel/Pruefblatt - damit Standortsicherung, Schritt 5 und Schritt 10 nicht merken,
    woher der Punkt kommt. punkte: Liste dict(name, x, y[, gehaeusetyp]) in EPSG:25832. quelle: nvt_gebiete-Datei aus Schritt 3 (Sitz vorher,
    Gebiete, Adressen fuer PLZ/Ort) oder None. lage_pruefen: ALKIS/OSM abrufen und den Punkt bewerten (Lage, Flurstueck, Strasse, Abstaende);
    der Punkt des Planers bleibt in jedem Fall stehen und gilt als zulaessig - Beanstandungen stehen im Hinweis. -> dict wie pruefen()"""
    import geopandas as gpd
    from shapely.geometry import Point
    from ..adressen import alkis as a_alkis
    import time as _time
    t0 = _time.time()
    _log = log
    log = lambda s: _log("{:5.0f} s  {}".format(_time.time() - t0, s))   # noqa: E731
    f = fortschritt or (lambda p, t: None)
    punkte = [dict(p) for p in (punkte or []) if p.get("x") is not None and p.get("y") is not None]
    if not punkte:
        raise RuntimeError("Keine Standorte uebergeben.")
    f(2, "NVT laden")
    sitze = gebiete = adressen = trassen = None
    if quelle and os.path.exists(str(quelle)):
        try:
            sitze, gebiete, adressen, trassen = nvt_laden(quelle, log)
        except Exception as e:
            log("NVT-Datei nicht lesbar ({!r}) - Standorte ohne Sitz vorher/Gebiete".format(e))
    out_dir = out_dir or (os.path.dirname(os.path.abspath(str(quelle))) if quelle and os.path.exists(str(quelle)) else os.path.expanduser("~"))
    os.makedirs(out_dir, exist_ok=True)
    xs, ys = [float(p["x"]) for p in punkte], [float(p["y"]) for p in punkte]
    minx, miny, maxx, maxy = min(xs), min(ys), max(xs), max(ys)
    if not land:
        kand = a_alkis.laender_fuer_bbox(minx, miny, maxx, maxy)
        land = kand[0] if kand else "NW"
    ctx = flaechen = bestand = None
    if lage_pruefen:
        try:
            ctx, flaechen, bestand = _kontext_laden(minx, miny, maxx, maxy, out_dir, land, regeln, trassen, log, f)
        except Exception as e:
            log("Lagepruefung nicht moeglich ({!r}) - Standorte werden ohne Lage/Flurstueck geschrieben".format(str(e)[:160]))
            ctx = None
    sitz_von = {}
    if sitze is not None:
        for _, r in sitze.iterrows():
            sitz_von[str(r["name"])] = r.geometry
    f(55, "Standorte bewerten")
    rows = []
    gesehen = {}
    for i, pk in enumerate(punkte):
        if i % 3 == 0:
            f(55 + 35 * i / max(len(punkte), 1), "Standort {}/{}".format(i + 1, len(punkte)))
        name = _s(pk.get("name")) or "NVT{:02d}".format(i + 1)
        variante = "Haupt"
        if name in gesehen:
            gesehen[name] += 1
            variante = "Alternativ" if gesehen[name] == 1 else "Alternativ {}".format(gesehen[name])
        else:
            gesehen[name] = 0
        p = Point(float(pk["x"]), float(pk["y"]))
        sitz = sitz_von.get(name, p)
        geb_poly = None
        if gebiete is not None:
            sel = gebiete[gebiete["name"].astype(str) == name]
            if len(sel):
                geb_poly = sel.geometry.iloc[0]
        info = {"lage": "", "hinweis": "Lage nicht geprueft (ohne ALKIS/OSM)", "gruende": ""}
        sd = {"gemeinde": "", "gemarkung": "", "gemaschl": "", "flur": "", "flurstueck": "", "flurstueck_nenner": "", "strasse": "", "hausnummer": "",
              "plz": "", "ort": ""}
        if ctx is not None:
            try:
                zul, _, info = bewerten(ctx, p, sitz, geb_poly)
                info["hinweis"] = "" if zul else "Pruefung: " + info.get("gruende", "")
                if info.get("lage") == "privat":
                    info["hinweis"] = (info["hinweis"] + "; " if info["hinweis"] else "") + "Privatgrund - Gestattungsvertrag noetig"
                sd = stosi_daten(ctx, p, adressen)
            except Exception as e:
                info = {"lage": "", "hinweis": "Lagepruefung fehlgeschlagen: {!r}".format(e)[:160], "gruende": ""}
        elif adressen is not None and len(adressen):
            try:
                dist = adressen.geometry.distance(p)
                a = adressen.iloc[int(dist.idxmin())]
                sd["plz"], sd["ort"], sd["strasse"] = _s(a.get("plz")), _s(a.get("ort")), _s(a.get("strasse"))
            except Exception:
                pass
        st = stosi_vorbelegen(info)
        st["variante"] = variante
        rows.append({"name": name, "gehaeusetyp": _s(pk.get("gehaeusetyp")) or gehaeusetyp, "zulaessig": True,
                     "oeffentlich": info.get("oeffentlich"), "lage": info.get("lage", ""), "fahrbahn_m": info.get("fahrbahn_m"), "achse_m": info.get("achse_m"),
                     "restgehweg_m": info.get("restgehweg_m"), "rand_m": info.get("rand_m"), "gebaeude_m": info.get("gebaeude_m"),
                     "kreuzung_m": info.get("kreuzung_m"), "bestand_m": info.get("bestand_m"), "bestand_name": info.get("bestand_name", ""),
                     "strasse_typ": info.get("strasse_typ"), "versatz_m": round(p.distance(sitz), 1), "kandidaten_ok": None,
                     "hinweis": info.get("hinweis", ""), "gruende": info.get("gruende", ""), **sd, "station": "", "information": "",
                     "status": "offen", "kommentar": "", "herkunft": herkunft, **st, "geometry": p})
    standorte = gpd.GeoDataFrame(rows, crs=CRS)
    f(92, "Schreiben")
    stamm = re.sub(r"[^A-Za-z0-9_\-]+", "_", re.sub(r"^nvt_gebiete_", "", os.path.splitext(os.path.basename(str(quelle or "NVT")))[0])).strip("_")[:40] or "NVT"
    gpkg = os.path.join(out_dir, "nvt_standorte_{}_{}.gpkg".format(stamm, datetime.now().strftime("%Y%m%d_%H%M")))
    _standorte_schreiben(gpkg, standorte)
    if sitze is not None and len(sitze):
        sitze[["name", "geometry"]].to_file(gpkg, layer="sitz_vorher", driver="GPKG")
    if bestand is not None and len(bestand):
        b = bestand.copy()
        for c in b.columns:
            if c != "geometry" and b[c].dtype == object:
                b[c] = b[c].astype(str)
        b.to_file(gpkg, layer="bestand_nvt", driver="GPKG")
    if flaechen:
        for lname, gdf in (("flurstuecke", flaechen.get("flurstuecke")), ("verkehrsflaechen", flaechen.get("verkehr"))):
            if gdf is not None and len(gdf):
                g2 = gdf.copy()
                for c in g2.columns:
                    if c != "geometry" and g2[c].dtype == object:
                        g2[c] = g2[c].astype(str)
                g2.to_file(gpkg, layer=lname, driver="GPKG")
    excel = excel_schreiben(standorte, out_dir, stamm, log)
    md = bericht(standorte, None, out_dir, stamm, quelle or herkunft, land, ctx, log)
    f(100, "Fertig")
    lagen = standorte["lage"].map(lambda v: _s(v) or "ungeprueft").value_counts().to_dict()
    log("Standorte ({}): {} uebernommen ({}); {}".format(herkunft, len(standorte), ", ".join("{} {}".format(v, k) for k, v in lagen.items()), gpkg))
    return {"gpkg": gpkg, "excel": excel, "bericht": md, "standorte": standorte, "korridore": None, "kontext": ctx, "land": land,
            "out_dir": out_dir, "stamm": stamm}


# --- StoSi-Shape wie Plan[Goo] "Export StoSi-Shape fuer GDI" (Markus 12.10.2026) -------------------------------------------------------
# Plan[Goo] (technik_plangoo_v2_vds_main/modules/tab_common/export_stosi_shape.py) exportiert seinen Punktlayer GEOMETRY_POINT, gefiltert auf
# TYPE in (nvt, fiber_pop) und NOT IS_EXTERNAL_OBJECT, als ESRI Shapefile UTF-8 in EPSG:25832 und zippt die Dateien. Die Attribute sind die
# Spalten des Punktlayers (Schema aus einem Plan[Goo]-V2-Projekt 2026, Feldnamen kuerzt der Shape-Treiber wie bei Plan[Goo] auf 10 Zeichen).
PLANGOO_PUNKTFELDER = [("fid", "int"), ("UID", "str"), ("TYPE", "str"), ("SUB_TYPE", "str"), ("NAME", "str"), ("SECOND_NAME", "str"),
                       ("PARENT_NAME", "str"), ("PLZ", "str"), ("ORT", "str"), ("ORTSTEIL", "str"), ("STRASSE", "str"), ("HS_NR", "int"),
                       ("HS_NR_ZS", "str"), ("KLS_ID", "str"), ("IS_EXTERNAL_OBJECT", "bool"), ("MAIN_MATERIAL", "str"), ("MAIN_PROJECT", "str"),
                       ("NVT_HK_FASERN", "str"), ("APL_AUSBAUZUSTAND", "str"), ("APL_HH", "int"), ("APL_USTO", "int"), ("APL_P2P", "int"),
                       ("PLGO_V2_VERSION", "str"), ("APL_SNR_RESERVIERUNG", "str"), ("SHOW_LABEL", "bool"), ("APL_BUILDING", "bool"),
                       ("NVT_HK_NAMEN", "str"), ("NVT_APL_COUNT", "int"), ("auxiliary_storage_labeling_positionx", "float"),
                       ("auxiliary_storage_labeling_positiony", "float"), ("auxiliary_storage_labeling_labelrotation", "float"),
                       ("IS_CASCADED", "bool"), ("KLS_ID_BEDARFSPUNKT_ID", "str"), ("APL_SL", "int"), ("APL_BUILDING_CONNECTION_TYPE", "str")]


def _hausnummer_teilen(hnr):
    """'36' -> (36, ''), '12a' -> (12, 'a'), '12 - 16' -> (12, ''), '' -> (None, '')"""
    m = re.match(r"\s*(\d+)\s*([A-Za-z]?)", _s(hnr))
    if not m:
        return None, ""
    return int(m.group(1)), m.group(2)


def stosi_zeilen(gpkg):
    """Je NVT eine Zeile im Plan[Goo]-Punktschema: der Hauptstandort, bei abgelehntem Hauptstandort der beste Alternativstandort."""
    import uuid
    g = standorte_lesen(gpkg)
    wahl = {}
    for _, r in g.iterrows():
        if r.geometry is None:
            continue
        name, var, gesamt = str(r["name"]), _s(r.get("variante")) or "Haupt", _s(r.get("gesamt")) or "Offen"
        rang = (0 if var == "Haupt" and gesamt != "Abgelehnt" else 1 if gesamt != "Abgelehnt" else 2, 0 if var == "Haupt" else 1)
        if name not in wahl or rang < wahl[name][0]:
            wahl[name] = (rang, r)
    zeilen = []
    for i, name in enumerate(sorted(wahl)):
        r = wahl[name][1]
        hs, zs = _hausnummer_teilen(r.get("hausnummer"))
        zeilen.append({"fid": i + 1, "UID": uuid.uuid4().hex, "TYPE": "nvt", "SUB_TYPE": None, "NAME": name, "SECOND_NAME": None, "PARENT_NAME": None,
                       "PLZ": _s(r.get("plz")) or None, "ORT": _s(r.get("ort")) or _s(r.get("gemeinde")) or None, "ORTSTEIL": None,
                       "STRASSE": _s(r.get("strasse")) or None, "HS_NR": hs, "HS_NR_ZS": zs or None, "KLS_ID": None, "IS_EXTERNAL_OBJECT": False,
                       "MAIN_MATERIAL": _s(r.get("gehaeusetyp")) or None, "MAIN_PROJECT": name, "NVT_HK_FASERN": None, "APL_AUSBAUZUSTAND": None,
                       "APL_HH": None, "APL_USTO": None, "APL_P2P": None, "PLGO_V2_VERSION": "2", "APL_SNR_RESERVIERUNG": None, "SHOW_LABEL": True,
                       "APL_BUILDING": None, "NVT_HK_NAMEN": None, "NVT_APL_COUNT": None, "auxiliary_storage_labeling_positionx": None,
                       "auxiliary_storage_labeling_positiony": None, "auxiliary_storage_labeling_labelrotation": None, "IS_CASCADED": False,
                       "KLS_ID_BEDARFSPUNKT_ID": None, "APL_SL": None, "APL_BUILDING_CONNECTION_TYPE": None,
                       "x": float(r.geometry.x), "y": float(r.geometry.y)})
    return zeilen


def stosi_shape(gpkg, out_dir=None, log=print):
    """StoSi-Shape wie Plan[Goo]: ESRI Shapefile (UTF-8, EPSG:25832) in einer Zip-Datei 'StoSi_GDI_shp_<Projekt>_<Datum>.zip' neben der
    Standortdatei (oder in out_dir). Schreibt mit demselben QGIS-Schreiber wie Plan[Goo] (QgsVectorFileWriter), damit Feldkuerzung und
    Typen gleich ausfallen. -> Pfad der Zip-Datei"""
    import tempfile
    import zipfile
    from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransformContext, QgsFeature, QgsField, QgsFields, QgsGeometry,
                           QgsPointXY, QgsVectorFileWriter, QgsVectorLayer)
    from qgis.PyQt.QtCore import QVariant
    zeilen = stosi_zeilen(gpkg)
    if not zeilen:
        raise RuntimeError("Export ist leer. Keine Standorte in der Datei.")
    typ = {"int": QVariant.Int, "str": QVariant.String, "bool": QVariant.Bool, "float": QVariant.Double}
    lyr = QgsVectorLayer("Point?crs=EPSG:25832", "StoSi", "memory")
    felder = QgsFields()
    for name, t in PLANGOO_PUNKTFELDER:
        felder.append(QgsField(name, typ[t]))
    lyr.dataProvider().addAttributes(list(felder))
    lyr.updateFields()
    feats = []
    for z in zeilen:
        f = QgsFeature(lyr.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(z["x"], z["y"])))
        for name, t in PLANGOO_PUNKTFELDER:
            v = z.get(name)
            if v is not None:
                f[name] = v
        feats.append(f)
    lyr.dataProvider().addFeatures(feats)
    out_dir = out_dir or os.path.dirname(os.path.abspath(gpkg))
    os.makedirs(out_dir, exist_ok=True)
    stem = "StoSi_GDI_shp_{}_{}".format(stamm_von(gpkg), datetime.now().strftime("%Y-%m-%d_%H-%M"))
    zip_pfad = os.path.join(out_dir, stem + ".zip")
    opt = QgsVectorFileWriter.SaveVectorOptions()
    opt.layerName = stem
    opt.driverName = "ESRI Shapefile"
    opt.fileEncoding = "UTF-8"
    with tempfile.TemporaryDirectory() as tmp:
        shp = os.path.join(tmp, stem + ".shp")
        erg = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, shp, QgsCoordinateTransformContext(), opt)
        if erg[0] != QgsVectorFileWriter.NoError or not os.path.exists(shp):
            raise RuntimeError("Shape nicht geschrieben: {}".format(erg[1] if len(erg) > 1 else erg))
        with zipfile.ZipFile(zip_pfad, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for n in sorted(os.listdir(tmp)):
                q = os.path.join(tmp, n)
                if os.path.isfile(q):
                    zf.write(q, n)
    log("StoSi-Shape: {} NVT -> {}".format(len(zeilen), zip_pfad))
    return zip_pfad


def lauf_zusammenfassung(r):
    """Ergebnis von pruefen()/uebernehmen() fuer den Dialog (JSON-faehig, hintergrund_lauf.py): Pfade und Zahlen statt GeoDataFrames."""
    s = r.get("standorte")
    lagen = {}
    n = zul = 0
    if s is not None and len(s):
        n = int(len(s))
        zul = int(s["zulaessig"].map(lambda v: str(v).lower() in ("1", "true", "ja")).sum())
        lagen = {str(k) or "ungeprueft": int(v) for k, v in s["lage"].map(lambda v: _s(v) or "ungeprueft").value_counts().items()}
    return {"gpkg": r.get("gpkg"), "excel": r.get("excel"), "bericht": r.get("bericht"), "out_dir": r.get("out_dir"), "stamm": r.get("stamm"),
            "land": r.get("land"), "n": n, "zulaessig": zul, "lagen": lagen}
