# -*- coding: utf-8 -*-
"""ALKIS-Flaechen fuer die Standortpruefung: Flurstuecke, tatsaechliche Nutzung (Verkehrsflaechen) und Gebaeude per WFS.

Vereinfachtes AdV-Schema (NW, NI, HE, RP, BB, SN, ST, SH, MV, HH): ave:Flurstueck (gemeinde, gemarkung, gemaschl, flur, flstnrzae,
flstnrnen, lagebeztxt), ave:Nutzung (nutzart), ave:GebaeudeBauwerk (funktion, lagebeztxt). BW: nora:v_al_*. Dienste aus
werkzeuge.adressen.alkis (GeoBasis-Loader-Katalog, Fallback-Tabelle). Alles EPSG:25832.
"""
import os
import re
import tempfile
import time
import warnings

from ..adressen import alkis as a_alkis

TYPEN = {  # Land -> (Flurstueck, Nutzung) Typnamen; Gebaeude kommt aus adressen.alkis
    "NW": ("ave:Flurstueck", "ave:Nutzung"), "NI": ("ave:Flurstueck", "ave:Nutzung"), "HE": ("ave:Flurstueck", "ave:Nutzung"),
    "RP": ("ave:Flurstueck", "ave:Nutzung"), "BB": ("ave:Flurstueck", "ave:Nutzung"), "SN": ("ave:Flurstueck", "ave:Nutzung"),
    "ST": ("ave:Flurstueck", "ave:Nutzung"), "SH": ("ave:Flurstueck", "ave:Nutzung"), "MV": ("ave:Flurstueck", "ave:Nutzung"),
    "HH": ("ave:Flurstueck", "ave:Nutzung"), "BW": ("nora:v_al_flurstueck", "nora:v_al_tatsaechliche_nutzung"),
}
VERKEHR = re.compile(r"stra(?:ß|ss)enverkehr|^weg$|^platz$|fahrbahn|gehweg|fu(?:ß|ss)weg|radweg|fahrweg|verkehrsbegleit", re.I)


def _abruf(url, typ, bbox, log, zeitlimit_s=60):
    import geopandas as gpd
    import pandas as pd
    import requests
    minx, miny, maxx, maxy = bbox
    kachel = 1500.0
    teile, tmp = [], tempfile.mkdtemp(prefix="fib_alkis_")
    n = 0
    x = minx
    while x < maxx:
        y = miny
        while y < maxy:
            n += 1
            bb = "{:.0f},{:.0f},{:.0f},{:.0f},urn:ogc:def:crs:EPSG::25832".format(x, y, min(x + kachel, maxx), min(y + kachel, maxy))
            r = requests.get(url, params={"SERVICE": "WFS", "VERSION": "2.0.0", "REQUEST": "GetFeature", "TYPENAMES": typ, "BBOX": bb,
                                          "COUNT": 5000, "SRSNAME": "urn:ogc:def:crs:EPSG::25832"}, timeout=zeitlimit_s)
            if r.status_code == 200 and b"ExceptionReport" not in r.content[:2000] and b"numberReturned=\"0\"" not in r.content[:3000]:
                p = os.path.join(tmp, "k{}.gml".format(n))
                with open(p, "wb") as f:
                    f.write(r.content)
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        g = gpd.read_file(p)
                    if len(g):
                        teile.append(g)
                except Exception:
                    pass
            y += kachel
        x += kachel
    if not teile:
        return None
    g = gpd.GeoDataFrame(pd.concat(teile, ignore_index=True), geometry="geometry")
    g = g.set_crs(25832, allow_override=True) if g.crs is None else (g.to_crs(25832) if g.crs.to_epsg() != 25832 else g)
    key = "oid" if "oid" in g.columns else ("gml_id" if "gml_id" in g.columns else None)
    if key:
        g = g.drop_duplicates(subset=[key])
    return g.reset_index(drop=True)


def laden(minx, miny, maxx, maxy, land, log=print, rand_m=120.0):
    """-> dict(flurstuecke, verkehr, gebaeude) GeoDataFrames (oder None je Eintrag)."""
    t0 = time.time()
    bbox = (minx - rand_m, miny - rand_m, maxx + rand_m, maxy + rand_m)
    out = {"flurstuecke": None, "verkehr": None, "gebaeude": None}
    d = a_alkis.dienst(land)
    if d is None:
        log("ALKIS: kein offener Dienst fuer {}.".format(a_alkis.LAENDER.get(land, land)))
        return out
    url = d[0]
    typen = TYPEN.get(land)
    try:
        if typen:
            fl = _abruf(url, typen[0], bbox, log)
            if fl is not None:
                for sp in ("gemeinde", "gemarkung", "gemaschl", "flur", "flstnrzae", "flstnrnen", "lagebeztxt"):
                    if sp not in fl.columns:
                        alt = {"gemeinde": "gemeinde_name", "gemarkung": "gemarkung_name", "flstnrzae": "zaehler", "flstnrnen": "nenner",
                               "lagebeztxt": "lagebezeichnung"}.get(sp)
                        fl[sp] = fl[alt] if alt in fl.columns else None
                out["flurstuecke"] = fl
            nu = _abruf(url, typen[1], bbox, log)
            if nu is not None:
                feld = next((c for c in ("nutzart", "objektname", "unterart_name", "nutzung", "art") if c in nu.columns), None)
                if feld:
                    nu["nutzart"] = nu[feld].astype(str)
                    out["verkehr"] = nu[nu["nutzart"].str.contains(VERKEHR)].reset_index(drop=True)
        geb = a_alkis.laden(minx, miny, maxx, maxy, land, log=lambda s: None, rand_m=rand_m)
        out["gebaeude"] = geb
    except Exception as e:
        log("ALKIS-Flaechen: Abruf teilweise fehlgeschlagen ({}).".format(str(e)[:100]))
    log("ALKIS {}: {} Flurstuecke, {} Verkehrsflaechen, {} Gebaeude, {:.0f} s".format(
        land, 0 if out["flurstuecke"] is None else len(out["flurstuecke"]), 0 if out["verkehr"] is None else len(out["verkehr"]),
        0 if out["gebaeude"] is None else len(out["gebaeude"]), time.time() - t0))
    return out
