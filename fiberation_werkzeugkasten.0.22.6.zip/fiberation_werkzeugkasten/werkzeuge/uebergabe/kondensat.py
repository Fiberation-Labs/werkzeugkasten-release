# -*- coding: utf-8 -*-
"""Schritt 10 - Kondensat aus Hk-Trasse (Schritt 7) und NVT-Trassen (Schritt 5) vor der Uebergabe nach Plan[Goo] (Markus 12.10.2026).

Voraussetzung: beide Planungen final und geprueft (Schritt 5: alle NVT geprueft oder uebertragen; Schritt 7: alle Straenge geprueft).
Sonst wird die Uebergabe mit der Liste der offenen Stellen blockiert.

Dissolve: alle Linien beider Planungen auf das RASTER_M-Raster gesetzt (shapely set_precision = dieselbe Snap-Toleranz wie die
NVT-Anbindung), dann unary_union. Das nodet jede Kreuzung und Beruehrung, fasst deckungsgleiche und ueberlappende Abschnitte zu einem
Stueck zusammen und trennt an jedem Knoten (Abzweige bleiben Knoten, nichts wird zu einer Gesamtlinie verschmolzen).

Attribute: ein einheitliches Schema fuer beide Quellen, das ist der Satz, den Plan[Goo] je Trasse kennt (bauverfahren = CONST_METHOD,
surface, allowance, location_hint, wesi, sub_type Hauszufuehrung, bestand = BESTANDSTRASSE). Je Ergebnisstueck werden die Quellstuecke
ueber einen schmalen Puffer bestimmt: herkunft NVT, HK oder HK+NVT; Werte zuerst aus der NVT-Planung (genauer), sonst aus der Hk-Planung;
bestand, sobald eine Quelle Bestand ist. Leere Werte sind erlaubt (Markus: "sind attribute nicht befuellt ist es nicht schlimm").

Selbstpruefung: Stuecke und Meter vorher/nachher, paarweiser Ueberlappungstest (Laenge gemeinsamer Abschnitte = 0)."""
import os
from datetime import datetime

from ... import gemeinsam, schema
from .. import topologie
from ..trassen import kern as tkern

RASTER_M = tkern.NVT_SNAP_M           # 0,05 m - dieselbe Snap-Toleranz wie die NVT-Anbindung
EBENE = "uebergabe"
UEBERGABE_SPALTEN = schema.TRASSEN_UEBERGABE_SPALTEN
UEBERNAHME = schema.PLANGOO_TRASSE_FELDER


_s = gemeinsam.s


def vorbedingungen(trassen_gpkg, hk_gpkg):
    """-> dict(ok, fehlt [Texte], nvt_gesamt, nvt_fertig, hk_gesamt, hk_fertig)"""
    from ..hk import kern as hkern
    fehlt = []
    n = tkern.nvt_lesen(trassen_gpkg)
    st = n["status"].astype(str)
    fertig = st.isin(["geprueft", "uebertragen"])
    for name, s in zip(n["name"].astype(str), st):
        if s not in ("geprueft", "uebertragen"):
            fehlt.append("Schritt 5, NVT {}: {}".format(name, s or "offen"))
    import geopandas as gpd
    geb = gpd.read_file(hk_gpkg, layer="hk_gebiete")
    hst = geb["status"].astype(str) if "status" in geb else geb["name"].map(lambda _: "offen")
    for name, s in zip(geb["name"].astype(str), hst):
        if s not in ("geprueft", "uebertragen"):
            fehlt.append("Schritt 7, Strang {}: {}".format(name, s or "offen"))
    return {"ok": not fehlt, "fehlt": fehlt, "nvt_gesamt": int(len(n)), "nvt_fertig": int(fertig.sum()), "hk_gesamt": int(len(geb)),
            "hk_fertig": int(hst.isin(["geprueft", "uebertragen"]).sum())}


def _quellen(trassen_gpkg, hk_gpkg):
    """Beide Planungen als Liste dict(herkunft, geometry, attr, nvt, hk)."""
    from ..hk import kern as hkern
    quellen = []
    p = tkern.ebene_lesen(trassen_gpkg, "planung")
    for _, r in p.iterrows():
        g = r.geometry
        if g is None or g.is_empty:
            continue
        attr = {c: _s(r.get(c)) for c in UEBERNAHME}
        attr["bestand"] = 1 if str(r.get("bestand") or 0) in ("1", "1.0", "True", "true") else 0
        quellen.append({"herkunft": "NVT", "geometry": g, "attr": attr, "nvt": _s(r.get("nvt")), "hk": "", "uid": _s(r.get("uid")),
                        "typ": _s(r.get("typ"))})
    h = hkern.planung_lesen(hk_gpkg)
    for _, r in h.iterrows():
        g = r.geometry
        if g is None or g.is_empty:
            continue
        attr = {c: _s(r.get(c)) for c in UEBERNAHME}
        if attr.get("sub_type") == "Hauszufuehrung":
            attr["sub_type"] = ""        # Hk ist nie Hauszufuehrung
        attr["bestand"] = 1 if str(r.get("bestand") or 0) in ("1", "1.0", "True", "true") else 0
        quellen.append({"herkunft": "HK", "geometry": g, "attr": attr, "nvt": "", "hk": _s(r.get("hk")), "uid": _s(r.get("uid")),
                        "typ": _s(r.get("typ"))})
    return quellen


def _linien(geom):
    if geom is None or geom.is_empty:
        return []
    if geom.geom_type == "LineString":
        return [geom]
    if geom.geom_type in ("MultiLineString", "GeometryCollection"):
        out = []
        for g in geom.geoms:
            out.extend(_linien(g))
        return out
    return []


def dissolve(trassen_gpkg, hk_gpkg, raster=RASTER_M, log=print, schreiben=True):
    """Kondensat bilden, pruefen und (schreiben=True) als Ebene 'uebergabe' in das Trassen-GeoPackage schreiben.
    -> dict(gdf, stats, konflikte [Texte], ebene)"""
    import geopandas as gpd
    import shapely
    from shapely.geometry import LineString
    from shapely.ops import unary_union
    from shapely.strtree import STRtree
    quellen = _quellen(trassen_gpkg, hk_gpkg)
    if not quellen:
        raise RuntimeError("Beide Planungen sind leer.")
    roh = [q["geometry"] for q in quellen]
    fein = topologie.stuetzpunkte_einrasten(roh, raster)
    fein = [shapely.set_precision(g, raster) if g is not None else None for g in fein]
    fein = [g if (g is not None and not g.is_empty) else None for g in fein]
    stats = {"n_vorher": len(quellen), "n_vorher_nvt": sum(1 for q in quellen if q["herkunft"] == "NVT"), "n_vorher_hk": sum(1 for q in quellen if q["herkunft"] == "HK"),
             "m_vorher": round(sum(g.length for g in roh), 1), "m_vorher_nvt": round(sum(q["geometry"].length for q in quellen if q["herkunft"] == "NVT"), 1),
             "m_vorher_hk": round(sum(q["geometry"].length for q in quellen if q["herkunft"] == "HK"), 1)}
    vereinigt = unary_union([g for g in fein if g is not None])
    stuecke = [l for l in _linien(vereinigt) if l.length > raster]
    # Quellen je Stueck: Quellgeometrie (gerastert) muss das Stueck fast ganz abdecken
    tree = STRtree([g if g is not None else LineString() for g in fein])
    zeilen, konflikte = [], []
    for k, seg in enumerate(stuecke):
        mitte = seg.interpolate(0.5, normalized=True)
        kand = []
        for j in tree.query(seg.buffer(raster)):
            j = int(j)
            g = fein[j]
            if g is None or g.distance(mitte) > raster:
                continue
            gedeckt = g.buffer(raster, cap_style=2).intersection(seg).length
            if gedeckt >= 0.9 * seg.length:
                kand.append(j)
        herk = sorted({quellen[j]["herkunft"] for j in kand})
        herkunft = "+".join(herk) if herk else "?"
        attr = {c: "" for c in UEBERNAHME}
        for prio in ("NVT", "HK"):
            for j in kand:
                if quellen[j]["herkunft"] != prio:
                    continue
                for c in UEBERNAHME:
                    if not attr[c] and quellen[j]["attr"].get(c):
                        attr[c] = quellen[j]["attr"][c]
        # Konflikte nur zaehlen, wo beide Quellen einen Wert haben und er sich unterscheidet
        if len(herk) > 1:
            for c in ("bauverfahren", "surface"):
                werte = {quellen[j]["herkunft"]: quellen[j]["attr"].get(c) for j in kand if quellen[j]["attr"].get(c)}
                if len(set(werte.values())) > 1:
                    konflikte.append("Stueck {}: {} NVT '{}' / HK '{}' - NVT uebernommen".format(k + 1, c, werte.get("NVT", ""), werte.get("HK", "")))
        bestand = 1 if any(quellen[j]["attr"].get("bestand") for j in kand) else 0
        typ = next((quellen[j]["typ"] for j in kand if quellen[j]["herkunft"] == "NVT" and quellen[j]["typ"]), "") or \
            next((quellen[j]["typ"] for j in kand if quellen[j]["typ"]), "")
        nvts = sorted({quellen[j]["nvt"] for j in kand if quellen[j]["nvt"]})
        hks = sorted({quellen[j]["hk"] for j in kand if quellen[j]["hk"]})
        z = {c: "" for c in UEBERGABE_SPALTEN}
        z.update(attr)
        z.update({"uid": "U{:05d}".format(k + 1), "nvt": ", ".join(nvts), "hk": ", ".join(hks), "typ": typ, "bestand": bestand,
                  "laenge_m": round(seg.length, 1), "quelle": "Dissolve " + datetime.now().strftime("%Y-%m-%d %H:%M"), "kante": "",
                  "status": "geprueft", "hinweis": "Quellen: " + ", ".join(quellen[j]["uid"] for j in kand[:6]), "herkunft": herkunft,
                  "geometry": seg})
        zeilen.append(z)
    gdf = gpd.GeoDataFrame(zeilen, geometry="geometry", crs=tkern.CRS)
    # Selbstpruefung: keine Ueberlappungen mehr
    geoms = list(gdf.geometry)
    t2 = STRtree(geoms)
    ueberlappt = 0.0
    paare = 0
    for i, g in enumerate(geoms):
        for j in t2.query(g):
            j = int(j)
            if j <= i:
                continue
            x = g.intersection(geoms[j])
            l = sum(p.length for p in _linien(x))
            if l > 1e-6:
                ueberlappt += l
                paare += 1
    stats.update({"n_nachher": len(gdf), "m_nachher": round(float(gdf["laenge_m"].sum()), 1), "ueberlappung_m": round(ueberlappt, 2), "ueberlappung_paare": paare,
                  "herkunft": {k: int(v) for k, v in gdf["herkunft"].value_counts().items()} if len(gdf) else {},
                  "ohne_quelle": int((gdf["herkunft"] == "?").sum()) if len(gdf) else 0, "konflikte": len(konflikte)})
    log("Kondensat: {} Stuecke / {:.0f} m vorher (NVT {} / {:.0f} m, HK {} / {:.0f} m) -> {} Stuecke / {:.0f} m nachher; Ueberlappung {:.2f} m in {} Paaren; "
        "Herkunft {}; {} Attributkonflikte (NVT gewinnt)".format(stats["n_vorher"], stats["m_vorher"], stats["n_vorher_nvt"], stats["m_vorher_nvt"], stats["n_vorher_hk"],
                                                              stats["m_vorher_hk"], stats["n_nachher"], stats["m_nachher"], stats["ueberlappung_m"], paare,
                                                              stats["herkunft"], len(konflikte)))
    for k_ in konflikte[:20]:
        log("  " + k_)
    if schreiben:
        tkern.ebene_schreiben(trassen_gpkg, gdf, EBENE, extra=("herkunft", "hk"))
        log("Ebene '{}' in {} geschrieben ({} Stuecke).".format(EBENE, os.path.basename(trassen_gpkg), len(gdf)))
    return {"gdf": gdf, "stats": stats, "konflikte": konflikte, "ebene": EBENE}


def stats_text(st):
    return ("{} Stuecke / {:.0f} m aus Schritt 5 und {} Stuecke / {:.0f} m aus Schritt 7 -> {} Stuecke / {:.0f} m (Herkunft {}).\n"
            "Ueberlappung nach dem Dissolve: {:.2f} m in {} Paaren{}.{}").format(
        st["n_vorher_nvt"], st["m_vorher_nvt"], st["n_vorher_hk"], st["m_vorher_hk"], st["n_nachher"], st["m_nachher"],
        ", ".join("{} {}".format(v, k) for k, v in sorted(st["herkunft"].items())), st["ueberlappung_m"], st["ueberlappung_paare"],
        " - sauber" if st["ueberlappung_paare"] == 0 else " - BITTE PRUEFEN", " {} Attributkonflikte, NVT uebernommen.".format(st["konflikte"]) if st["konflikte"] else "")
