# -*- coding: utf-8 -*-
"""Werkzeug 10 - Nach Plan[Goo] uebernehmen: Gebiete, NVT und Adresszuordnung aus Werkzeug 3 in das offene Projekt schreiben."""
