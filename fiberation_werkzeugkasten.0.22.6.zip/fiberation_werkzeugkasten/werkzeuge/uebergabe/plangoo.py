# -*- coding: utf-8 -*-
"""Werkzeug 10 - Uebernahme des fertigen NVT-Schnitts (Werkzeug 3) in das aktive Plan[Goo]-Projekt (Planer: "final fertig").

Je Gebiet aus dem GeoPackage (Layer nvt_gebiete, nvt_sitz, adressen):
  1. Projekt (Netzebene Vzk, Gebiets-ID/ONB/ASB/Ausbautreiber wie das Projekt),
  2. NVT-Punkt am Sitz (oder am geprueften Standort aus Werkzeug 4, wenn gewaehlt und vorhanden) mit dem Material der vorhandenen
     NVT (sonst GH_OCL) und den Materialvorlagen des Plugins, Planungsaktivitaet,
  3. Versorgungsbereich als Polygon Typ nvt mit Bezug auf den NVT-Punkt, Gebietsfarbe,
  4. jede Adresse (KLS-ID, sonst Strasse+Hausnummer) haengt an ihrem NVT (PARENT) und bekommt eine Planungsaktivitaet im neuen Projekt;
     der NVT bekommt die Adresse seiner ersten Adresse (Abnahme: "Punktobjekt benoetigt Adressangabe").
Vorhandene NVT werden auf Wunsch mit Suffix _alt gekennzeichnet (samt Projekt), ihre Versorgungsbereiche geloescht. Vorher Backup-Zip.
Keine Trassen, Rohre oder Kabel: Zufuehrung und Vzk sind Werkzeug 5, Hk die Werkzeuge 6 bis 7.
Alles ueber die Plan[Goo]-Core-API (Muster: HLD Roboter plangoo_schnitt.py, 07.-09.09.2026).
"""
import importlib
import os
from datetime import datetime

from ..adressen import plangoo as aplangoo

from ... import plangoo_api


M = "technik_plangoo_v2_vds_main"
USER = "Fiberation Werkzeugkasten"
FARBEN = ["#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4", "#46f0f0", "#f032e6", "#bcf60c", "#fabebe", "#008080", "#e6beff",
          "#9a6324", "#fffac8", "#800000", "#aaffc3", "#808000", "#ffd8b1", "#000075", "#808080", "#ffe119"]
CRS = 25832


def _m(name):
    return plangoo_api.modul(name)


def _groesstes(geom):
    if geom is not None and geom.geom_type == "MultiPolygon":
        return max(geom.geoms, key=lambda g: g.area)
    return geom


def standorte_lesen(pfad, log=print):
    """Werkzeug-4-Ergebnis: name -> (x, y) fuer zulaessige Standorte (Hauptstandort; bei Ablehnung die Alternative)."""
    from ..standort.kern import standorte_fuer_netz
    return standorte_fuer_netz(pfad, log)


def vorschau(gpkg, inst=None):
    """Zahlen fuer die Rueckfrage vor dem Schreiben: Gebiete, Adressen, vorhandene NVT, APL im Projekt."""
    import geopandas as gpd
    inst = inst or aplangoo.instanz()
    geb = gpd.read_file(gpkg, layer="nvt_gebiete")
    adr = gpd.read_file(gpkg, layer="adressen")
    n_nvt = sum(1 for f in inst.get_point_layer().getFeatures() if str(f["TYPE"] or "") == "nvt")
    n_apl = sum(1 for f in inst.get_point_layer().getFeatures() if str(f["TYPE"] or "") in ("apl", "nap"))
    return {"gebiete": int(len(geb)), "adressen": int(len(adr)), "nvt_vorhanden": n_nvt, "apl_projekt": n_apl,
            "projekt": os.path.splitext(os.path.basename(inst.gpkg_path))[0]}


def uebernehmen(gpkg, alte_kennzeichnen=True, standorte_pfad=None, mit_backup=True, inst=None, log=print, fortschritt=None):
    """-> dict(nvt, bereiche, projekte, adressen, ohne_apl, alte, backup, meldungen). fortschritt(prozent, text)."""
    import geopandas as gpd
    from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry, QgsPointXY, QgsProject
    f_ = fortschritt or (lambda p, t: None)
    inst = inst or aplangoo.instanz()
    comps = _m("core.components")
    GooPoint, GooProject, GooPolygon = comps.GooPoint, comps.GooProject, comps.GooPolygon
    GooPointMaterial = _m("core.components.pointmaterial").GooPointMaterial
    C = _m("core.utilities.constants")
    T, PT = C.GooPointTypes, C.GooPolygonTypes
    erg = {"nvt": 0, "bereiche": 0, "projekte": 0, "adressen": 0, "ohne_apl": 0, "alte": 0, "backup": None, "meldungen": [], "offen": []}

    f_(1, "Lesen")
    geb = gpd.read_file(gpkg, layer="nvt_gebiete")
    sitz = gpd.read_file(gpkg, layer="nvt_sitz")
    adr = gpd.read_file(gpkg, layer="adressen")
    for df in (geb, sitz, adr):
        if df.crs is None or df.crs.to_epsg() != CRS:
            df.set_crs(CRS, allow_override=True, inplace=True)
    geb = geb[geb.geometry.notna() & ~geb.geometry.is_empty].copy()
    geb["name"] = geb["name"].astype(str).str.strip()
    sitz_xy = {str(r["name"]).strip(): (r.geometry.x, r.geometry.y) for _, r in sitz.iterrows() if r.geometry is not None}
    standorte = standorte_lesen(standorte_pfad, log) if standorte_pfad else {}
    namen = [n for n in geb["name"].tolist() if n]
    if not namen:
        raise RuntimeError("Keine Gebiete im GeoPackage.")
    adr["nvt"] = adr["nvt"].astype(str).str.strip()
    log("Schnitt: {} Gebiete, {} Adressen, {} Sitze{}".format(len(namen), len(adr), len(sitz_xy),
                                                             ", {} Standorte aus Werkzeug 4".format(len(standorte)) if standorte else ""))

    if mit_backup:
        f_(3, "Backup")
        try:
            db, gp = inst.db_path, inst.gpkg_path
            Backup = _m("core.project.backup").Backup
            ziel = os.path.join(os.path.dirname(db), "{}_nvt_{}.zip".format(os.path.splitext(os.path.basename(gp))[0],
                                                                           datetime.now().strftime("%Y-%m-%d_%H-%M")))
            Backup.create_zip_backup(db, gp, ziel)
            erg["backup"] = ziel
            log("Backup: " + ziel)
        except Exception as e:
            raise RuntimeError("Backup fehlgeschlagen: {!r}".format(e)[:300])

    # --- Kontext des Projekts -----------------------------------------------------------------------------------------------------------
    f_(6, "Projekt lesen")
    layer = inst.get_point_layer()
    ct = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:{}".format(CRS)), layer.crs(), QgsProject.instance())
    alte_nvt = GooPoint.from_type(T.NVT)
    gebiets_id, sponsor, root_material = None, None, None
    for n in alte_nvt:
        try:
            pr = n.get_planning_project()
        except Exception:
            pr = None
        if pr is not None:
            gebiets_id = gebiets_id or pr.get_gebiets_id()
            try:
                sponsor = sponsor or pr.get_sponsor()
            except Exception:
                pass
        if root_material is None:
            try:
                mats = n.get_materials()
                if mats:
                    root_material = mats[0].get_material()
            except Exception:
                pass
    if sponsor is None:
        # Ausbautreiber des Projekts (GooSettings AUSBAUTREIBER, im leeren Projekt aus Kachel 9 gesetzt)
        from . import projekt as _projekt
        sponsor = _projekt.ausbautreiber()
    # 30.09.2026: Gehaeuse nach Ausbautreiber (regelwerk): MBfD -> GF-NVt22 L (BF) GH_NCL wie im Telekom-Angebot (Dornberg: 16x GH_NCL),
    # XS-Regelsatz -> GH_NCLXS, Eigenausbau -> GH_OCL. Ein vorhandenes Gehaeuse, das nicht zum Ausbautreiber passt, wird nicht uebernommen.
    from ... import regelwerk
    rs = regelwerk.regelsatz_aus_gebieten(geb, vorgabe=regelwerk.regelsatz_fuer(str(getattr(sponsor, "value", sponsor) or "")))
    if root_material is not None and not regelwerk.nvt_material_passt(root_material.get_key(), rs):
        log("Vorhandenes NVT-Gehaeuse {} passt nicht zum Regelsatz {} - nehme {}".format(root_material.get_key(), rs, regelwerk.nvt_material_key(rs)))
        root_material = None
    if root_material is None:
        root_material = inst.get_materials().get_material_by_key(regelwerk.nvt_material_key(rs))
    apl_index, _ = aplangoo.vorhandene_apl(inst, GooPoint)
    if not apl_index:
        raise RuntimeError("Das Projekt enthaelt keine APL - erst Werkzeug 2 (Uebernahme) oder FPF-Import.")
    goo_asb = None
    for f in apl_index.values():
        try:
            goo_asb = GooPoint.from_feature(f).get_asb()
            if goo_asb is not None:
                break
        except Exception:
            continue
    if goo_asb is None:
        raise RuntimeError("ASB des Projekts nicht bestimmbar (kein APL mit ASB).")
    try:
        onb, asb = int(goo_asb.get_onb()), int(goo_asb.get_asb())
    except Exception:
        onb, asb = 0, 0
    templates = inst.get_material_templates()
    poly_layer = inst.get_polygon_layer()
    col_idx = poly_layer.dataProvider().fieldNameMap().get("COLOR_CODE") if poly_layer is not None else None
    log("Projekt: {} NVT vorhanden, {} APL, Gebiets-ID {}, ONB/ASB {}/{}, Ausbautreiber {}, NVT-Material {}".format(
        len(alte_nvt), len(apl_index), gebiets_id, onb, asb, getattr(sponsor, "value", sponsor),
        root_material.get_key() if root_material is not None else "-"))

    conn = inst.get_connection()
    try:
        conn.auto_commit_insert = False
    except Exception:
        pass
    try:
        # --- alte NVT kennzeichnen -------------------------------------------------------------------------------------------------------
        if alte_kennzeichnen and alte_nvt:
            f_(8, "Alte NVT kennzeichnen")
            for n in alte_nvt:
                try:
                    alt = n.get_name() or "NVT"
                    if not alt.endswith("_alt"):
                        n.set_name(alt + "_alt")
                    pr = n.get_planning_project()
                    if pr is not None and not (pr.get_name() or "").endswith("_alt"):
                        pr.set_name((pr.get_name() or "Projekt") + "_alt")
                    for poly in GooPolygon.from_point_reference(n):
                        poly.delete()
                    n.reload_properties(repaint=False)
                    erg["alte"] += 1
                except Exception as e:
                    erg["meldungen"].append("Alter NVT {}: {!r}".format(n.get_name(), e)[:200])
            log("Vorhandene NVT als _alt gekennzeichnet: {}".format(erg["alte"]))
        elif alte_nvt:
            # Namenskollisionen vermeiden
            vorhanden = {n.get_name() for n in alte_nvt}
            doppelt = [n for n in namen if n in vorhanden]
            if doppelt:
                raise RuntimeError("{} NVT-Namen gibt es schon im Projekt ({}...). Haken 'vorhandene NVT als _alt kennzeichnen' setzen "
                                   "oder Gebiete umbenennen.".format(len(doppelt), ", ".join(doppelt[:5])))

        # --- neue NVT, Projekte, Bereiche ------------------------------------------------------------------------------------------------
        neue = {}
        n_ges = max(len(namen), 1)
        for i, (_, r) in enumerate(geb.iterrows()):
            name = r["name"]
            if not name or name in neue:
                continue
            f_(10 + 55 * i / n_ges, "NVT {}/{}".format(i + 1, n_ges))
            try:
                pr = GooProject.create(name, network_level=C.NetworkLevel.VZK, gebiets_id=gebiets_id, onb=onb, asb=asb)
                if sponsor is not None:
                    try:
                        pr.set_sponsor(sponsor)
                    except Exception as e:
                        erg["meldungen"].append("Projekt {}: Ausbautreiber nicht gesetzt: {!r}".format(name, e)[:160])
                erg["projekte"] += 1
                xy = standorte.get(name) or sitz_xy.get(name)
                if xy is None:
                    c = r.geometry.representative_point()
                    xy = (c.x, c.y)
                    erg["offen"].append("{}: kein Sitz - NVT in die Gebietsmitte gesetzt".format(name))
                q = ct.transform(QgsPointXY(*xy))
                pt = GooPoint.create_from_point(q, asb=goo_asb, name=name, type_=T.NVT)
                if root_material is not None:
                    try:
                        pm = GooPointMaterial.create(pt, root_material)
                        tmpl = templates.set_material_template(pm)
                        if tmpl:
                            for mat in tmpl.values():
                                try:
                                    templates.set_material_template(mat["mat"])
                                except Exception:
                                    pass
                    except Exception as e:
                        erg["meldungen"].append("NVT {}: Material nicht gesetzt: {!r}".format(name, e)[:160])
                for m_ in pt.get_all_materials():
                    try:
                        m_.create_activity(activity=C.ActivityStatus.PLANUNG.value, datetime_=datetime.today(), project=pr, user=USER)
                    except Exception:
                        pass
                erg["nvt"] += 1
                try:
                    qg = QgsGeometry.fromWkt(_groesstes(r.geometry).wkt)
                    qg.transform(ct)
                    qg.convertToSingleType()
                    poly = GooPolygon.create_from_polygon(qg, PT.NVT, name=name, point_reference=pt)
                    if poly is not None:
                        if col_idx is not None:
                            try:
                                poly_layer.dataProvider().changeAttributeValues({poly.get_feature().id(): {col_idx: FARBEN[i % len(FARBEN)]}})
                                poly.reload_properties(repaint=False)
                            except Exception:
                                pass
                        erg["bereiche"] += 1
                except Exception as e:
                    erg["meldungen"].append("Bereich {}: {!r}".format(name, e)[:160])
                neue[name] = (pt, pr)
            except Exception as e:
                erg["meldungen"].append("NVT {} nicht angelegt: {!r}".format(name, e)[:200])
        log("Angelegt: {} NVT, {} Projekte, {} Versorgungsbereiche".format(erg["nvt"], erg["projekte"], erg["bereiche"]))

        # --- Adressen umhaengen ----------------------------------------------------------------------------------------------------------
        f_(66, "Adressen zuordnen")
        nvt_adresse = {}
        n_ges = max(len(adr), 1)
        for i, (_, r) in enumerate(adr.iterrows()):
            if i % 25 == 0:
                f_(66 + 30 * i / n_ges, "Adressen {}/{}".format(i, n_ges))
            ziel = neue.get(r["nvt"])
            if ziel is None:
                erg["ohne_apl"] += 1
                if len(erg["offen"]) < 200:
                    erg["offen"].append("Adresse ohne angelegten NVT '{}': {} {}{}".format(r["nvt"], r.get("strasse", ""), r.get("hnr", ""),
                                                                                           r.get("hnr_zs", "") or ""))
                continue
            s = aplangoo._schluessel(r.get("kls_id"), r.get("strasse"), r.get("hnr"), r.get("hnr_zs"))
            f = apl_index.get(s)
            if f is None:
                erg["ohne_apl"] += 1
                if len(erg["offen"]) < 200:
                    erg["offen"].append("APL nicht im Projekt: {} {}{} ({})".format(r.get("strasse", ""), r.get("hnr", ""),
                                                                                    r.get("hnr_zs", "") or "", s))
                continue
            try:
                apl = GooPoint.from_feature(f)
                pt, pr = ziel
                apl.set_parent(pt)
                for m_ in apl.get_all_materials():
                    try:
                        alte = [x for x in m_.get_activities() if x.get_activity() == C.ActivityStatus.PLANUNG.value]
                    except Exception:
                        alte = []
                    for x in alte:
                        try:
                            x.delete()
                        except Exception:
                            pass
                    try:
                        m_.create_activity(activity=C.ActivityStatus.PLANUNG.value, datetime_=datetime.today(), project=pr, user=USER)
                    except Exception:
                        pass
                apl.reload_properties(repaint=False)
                nvt_adresse.setdefault(r["nvt"], apl)
                erg["adressen"] += 1
            except Exception as e:
                erg["ohne_apl"] += 1
                if len(erg["meldungen"]) < 50:
                    erg["meldungen"].append("Adresse {} {}: {!r}".format(r.get("strasse", ""), r.get("hnr", ""), e)[:200])
        for name, apl in nvt_adresse.items():
            try:
                pt, _pr = neue[name]
                a = apl.get_address()
                if a is not None:
                    pt.set_address(a)
                    pt.reload_properties(repaint=False)
            except Exception as e:
                erg["meldungen"].append("NVT-Adresse {}: {!r}".format(name, e)[:160])
        log("Adressen zugeordnet: {}, ohne Zuordnung: {}".format(erg["adressen"], erg["ohne_apl"]))
    finally:
        try:
            conn.auto_commit_insert = True
        except Exception:
            pass
        try:
            conn.commit()
        except Exception:
            pass
        f_(98, "Layer aktualisieren")
        for lyr in (inst.get_point_layer(), inst.get_polygon_layer()):
            try:
                lyr.reload()
                lyr.triggerRepaint()
            except Exception:
                pass
    for m_ in erg["meldungen"]:
        log("  " + m_)
    f_(100, "Fertig")
    return erg
