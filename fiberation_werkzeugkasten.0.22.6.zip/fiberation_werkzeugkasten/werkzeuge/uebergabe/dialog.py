# -*- coding: utf-8 -*-
"""Werkzeug 10 - Dialog "Ab nach Plan[Goo]" (Markus 16.09.2026: die letzte Kachel).

Oben das Projekt: neues leeres Plan[Goo]-Projekt anlegen (kurzer Ordner, Name, Ausbautreiber ueber den Plan[Goo]-Dialog, dann Offline
"In Bearbeitung nehmen") oder das offene Projekt verwenden. Darunter die Importschritte Kachel fuer Kachel: 2 Adressen als APL,
3 Gebiete + NVT + Zuordnung (Standorte aus 4), 5 gepruefte Trassen, 6-7 Hk (folgt). Jeder Schritt zeigt vorher seine Zahlen und
schreibt ein Backup-Zip; der Projektstand (APL, NVT, Trassen) wird nach jedem Schritt neu gelesen.
"""
import os
import re
import traceback

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QApplication, QCheckBox, QDialog, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                                 QProgressBar, QPushButton, QRadioButton, QTextEdit, QVBoxLayout)

from ... import ablauf, ci, dateiwahl, layerbaum
from ...dialogbasis import WerkzeugDialog
from ...dateiwahl import DateiFeld
from . import projekt


def stamm_von(gpkg):
    """Stamm eines Werkzeug-3-Ergebnisses, wie Werkzeug 4 ihn fuer seine Dateinamen bildet."""
    return re.sub(r"[^A-Za-z0-9_\-]+", "_", re.sub(r"^nvt_gebiete_", "", os.path.splitext(os.path.basename(str(gpkg)))[0])).strip("_")[:40]


def passende_standorte(gpkg):
    """Juengstes Werkzeug-4-Ergebnis zum Schnitt (gleicher Stamm), sonst None."""
    if not gpkg:
        return None
    st = stamm_von(gpkg)
    for p in dateiwahl.kandidaten("nvt_standorte"):
        if os.path.basename(p).startswith("nvt_standorte_" + st):
            return p
    return None


class UebergabeDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel("uebergabe").replace("  ", " ", 1))
        self.setMinimumWidth(860)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel("uebergabe"), "Leeres Plan[Goo]-Projekt anlegen, dann Schritt fuer Schritt importieren: 2 Adressen, 3 Gebiete und NVT, 5 gepruefte Trassen.")
        lay.addWidget(self.kopf)

        # --- Projekt ------------------------------------------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Plan[Goo]-Projekt"))
        g = QGridLayout()
        g.setHorizontalSpacing(8)
        g.setVerticalSpacing(6)
        r = QHBoxLayout()
        self.r_neu = QRadioButton("Neues leeres Projekt anlegen")
        self.r_offen = QRadioButton("Offenes Plan[Goo]-Projekt verwenden")
        self.r_neu.setChecked(True)
        r.addWidget(self.r_neu)
        r.addWidget(self.r_offen)
        r.addStretch(1)
        g.addLayout(r, 0, 0, 1, 4)
        g.addWidget(QLabel("Ordner:"), 1, 0)
        self.e_ordner = QLineEdit()
        self.e_ordner.setPlaceholderText("kurzer, nicht synchronisierter Ordner, z. B. C:\\Users\\<Nutzer>\\PlanGoo\\<Stamm>")
        self.e_ordner.setToolTip("Plan[Goo] bricht bei Projektpfaden ueber 259 Zeichen ab - deshalb kurz und nicht in OneDrive.")
        g.addWidget(self.e_ordner, 1, 1, 1, 2)
        k_ord = QPushButton("Waehlen")
        k_ord.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        k_ord.clicked.connect(self._ordner_waehlen)
        g.addWidget(k_ord, 1, 3)
        g.addWidget(QLabel("Name:"), 2, 0)
        self.e_name = QLineEdit()
        self.e_name.setPlaceholderText("PlGoo_<Stamm> - es entstehen <Name>.gpkg und <Name>.db")
        g.addWidget(self.e_name, 2, 1)
        self.k_anlegen = QPushButton("Anlegen und in Bearbeitung nehmen")
        self.k_anlegen.setStyleSheet(ci.STIL_KNOPF)
        self.k_anlegen.setCursor(Qt.PointingHandCursor)
        self.k_anlegen.setToolTip("Legt <Name>.gpkg und .db aus der Plan[Goo]-Vorlage an, fragt den Ausbautreiber ab und nimmt das Projekt offline in Bearbeitung.")
        self.k_anlegen.clicked.connect(self._anlegen)
        g.addWidget(self.k_anlegen, 2, 2, 1, 2)
        self.r_neu.toggled.connect(lambda an: [w.setEnabled(an) for w in (self.e_ordner, self.e_name, k_ord, self.k_anlegen)])
        self.lab_projekt = QLabel(projekt.stand_text(None))
        self.lab_projekt.setWordWrap(True)
        self.lab_projekt.setStyleSheet("color:{}; padding:5px; border:1px solid {}; border-radius:4px; font-size:11px;".format(ci.SCHWARZ, ci.GRAU_HELL))
        g.addWidget(self.lab_projekt, 3, 0, 1, 3)
        k_st = QPushButton("Stand lesen")
        k_st.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        k_st.setToolTip("Zaehlt APL, NVT, Gebiete und Trassen im offenen Projekt")
        k_st.clicked.connect(self._stand)
        g.addWidget(k_st, 3, 3, Qt.AlignTop)
        g.setColumnStretch(1, 1)
        g.setColumnStretch(2, 1)
        lay.addLayout(g)

        # --- Schritte -----------------------------------------------------------------------------------------------------------------
        ks = QHBoxLayout()
        ks.addWidget(self._ueberschrift("Importschritte - Kachel fuer Kachel"))
        ks.addStretch(1)
        self.h_backup = QCheckBox("Backup-Zip vor jedem Schritt")
        self.h_backup.setChecked(True)
        ks.addWidget(self.h_backup)
        lay.addLayout(ks)
        s = QGridLayout()
        s.setHorizontalSpacing(8)
        s.setVerticalSpacing(5)
        s.setColumnStretch(1, 1)
        # Schritt 2 Adressen
        s.addWidget(self._schritt("2  Adressen als APL"), 0, 0)
        self.f_adr = DateiFeld("adresspruefung", "adresspruefung_....gpkg aus Kachel 2", "GeoPackage (*.gpkg)", "Adresspruefung waehlen", ci.STIL_KNOPF_ZWEIT)
        s.addWidget(self.f_adr, 0, 1)
        self.h_rot = QCheckBox("rote auslassen")
        self.h_rot.setChecked(True)
        self.h_rot.setToolTip("Adressen mit roter Ampel (Dublette, kein Gebaeude) nicht anlegen; 'ignorieren' wird immer ausgelassen.")
        s.addWidget(self.h_rot, 0, 2)
        self.k1 = self._knopf("Importieren", self._schritt1)
        s.addWidget(self.k1, 0, 3)
        self.lab1 = self._status()
        s.addWidget(self.lab1, 1, 1, 1, 3)
        # Schritt 3 Gebiete
        s.addWidget(self._schritt("3  Gebiete, NVT, Zuordnung"), 2, 0)
        self.f_geb = DateiFeld("nvt_gebiete", "nvt_gebiete_....gpkg aus Kachel 3", "GeoPackage (*.gpkg)", "NVT-Gebiete waehlen", ci.STIL_KNOPF_ZWEIT)
        s.addWidget(self.f_geb, 2, 1)
        self.h_alt = QCheckBox("vorhandene NVT als _alt")
        self.h_alt.setChecked(True)
        self.h_alt.setToolTip("Vorhandene NVT und Projekte als _alt kennzeichnen und ihre Versorgungsbereiche loeschen (im leeren Projekt ohne Wirkung).")
        s.addWidget(self.h_alt, 2, 2)
        self.k2 = self._knopf("Importieren", self._schritt2)
        s.addWidget(self.k2, 2, 3)
        st = QHBoxLayout()
        self.h_stosi = QCheckBox("Standorte aus Kachel 4:")
        self.h_stosi.setChecked(True)
        st.addWidget(self.h_stosi)
        self.f_st = DateiFeld("nvt_standorte", "nvt_standorte_....gpkg - leer = Sitzvorschlag aus dem Schnitt", "GeoPackage (*.gpkg)",
                              "NVT-Standorte waehlen", ci.STIL_KNOPF_ZWEIT, vorbelegen=False)
        st.addWidget(self.f_st, 1)
        self.h_stosi.toggled.connect(self.f_st.setEnabled)
        s.addLayout(st, 3, 1, 1, 3)
        self.lab2 = self._status()
        s.addWidget(self.lab2, 4, 1, 1, 3)
        # Schritt 4 Trassen: Kondensat aus Schritt 5 (NVT-Trassen) und Schritt 7 (Hk-Trasse) - Markus 12.10.2026
        s.addWidget(self._schritt("5  NVT-Trassen"), 5, 0)
        self.f_tr = DateiFeld("trassen", "trassen_....gpkg aus Kachel 5", "GeoPackage (*.gpkg)", "Trassen-Ergebnis waehlen", ci.STIL_KNOPF_ZWEIT)
        s.addWidget(self.f_tr, 5, 1, 1, 3)
        s.addWidget(self._schritt("7  Hk-Trasse"), 6, 0)
        self.f_hk = DateiFeld("hk", "hk_....gpkg aus Kachel 6/7 (Hk-Trasse in der Planung)", "GeoPackage (*.gpkg)", "Hk-Ergebnis waehlen", ci.STIL_KNOPF_ZWEIT)
        s.addWidget(self.f_hk, 6, 1)
        self.k3 = self._knopf("Kondensat importieren", self._schritt3)
        self.k3.setToolTip("Nur wenn alle NVT (Schritt 5) und alle Straenge (Schritt 7) geprueft sind: beide Planungen zusammenlegen (Dissolve, "
                           "keine doppelten oder ueberlappenden Stuecke, Knoten bleiben), Vorschau mit Zahlen, dann nach Plan[Goo].")
        s.addWidget(self.k3, 6, 3)
        self.lab3 = self._status()
        s.addWidget(self.lab3, 7, 1, 1, 3)
        lay.addLayout(s)

        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(150)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log, 1)

        k = QHBoxLayout()
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.setToolTip("Protokoll ein- und ausblenden; bei Fehlern klappt es von selbst auf")
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        k.addWidget(self.k_log)
        k.addStretch(1)
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, "w4"))
        k.addWidget(hilfe)
        schl = QPushButton("Schliessen")
        self.k_schliessen = schl
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.close)
        k.addWidget(schl)
        lay.addLayout(k)

        self.setAcceptDrops(True)
        self.f_geb.box.lineEdit().editingFinished.connect(self._quelle_geaendert)
        self.f_geb.box.activated.connect(lambda *_: self._quelle_geaendert())
        self._quelle_geaendert()
        # Markus 12.10.: Standdatei - eine Datei des Gebiets gewaehlt, die uebrigen Felder fuellen sich aus werkzeugkasten_stand.json
        for feld in (self.f_tr, self.f_adr, self.f_geb, self.f_hk, self.f_st):
            feld.box.lineEdit().editingFinished.connect(self._stand_uebernehmen)
            feld.box.activated.connect(lambda *_: self._stand_uebernehmen())
        from ... import fenster
        fenster.einrichten(self, "uebergabe", 860)

    # --- Hilfen ------------------------------------------------------------------------------------------------------------------------
    def _schritt(self, t):
        lab = QLabel(t)
        lab.setStyleSheet("font-weight:600;")
        lab.setMinimumWidth(190)
        return lab

    def _status(self):
        lab = QLabel("")
        lab.setWordWrap(True)
        lab.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        return lab

    def _knopf(self, text, slot):
        b = QPushButton(text)
        b.setStyleSheet(ci.STIL_KNOPF)
        b.setCursor(Qt.PointingHandCursor)
        b.clicked.connect(slot)
        return b

    def showEvent(self, ev):
        super().showEvent(ev)
        for f in (self.f_adr, self.f_geb, self.f_tr):
            f.vorbelegen()
        self._quelle_geaendert()
        self._stand_uebernehmen()          # Vorbelegung auf ein Gebiet ausrichten (Standdatei des Trassen-Ordners)
        self._stand(still=True)

    def setze_quelle(self, gpkg):
        """Von Kachel 3 aufgerufen ("Weiter mit 9"): aktuellen Schnitt vorbelegen."""
        if gpkg:
            self.f_geb.setText(gpkg)
            self._quelle_geaendert()

    def _quelle_geaendert(self):
        """Standorte zum Schnitt suchen, Ordner und Name fuer ein neues Projekt aus dem Stamm vorbelegen."""
        geb = self.f_geb.text()
        p = passende_standorte(geb)
        if p and (not self.f_st.text() or stamm_von(geb) not in os.path.basename(self.f_st.text())):
            self.f_st.setText(p)
        if geb:
            # Vorgaben folgen dem Schnitt, solange der Planer sie nicht selbst geaendert hat
            stamm = stamm_von(geb)
            auto = getattr(self, "_auto", ("", ""))
            if not self.e_ordner.text().strip() or self.e_ordner.text() == auto[0]:
                self.e_ordner.setText(projekt.kurzer_ordner(stamm))
            if not self.e_name.text().strip() or self.e_name.text() == auto[1]:
                self.e_name.setText(projekt.name_aus_stamm(stamm))
            self._auto = (projekt.kurzer_ordner(stamm), projekt.name_aus_stamm(stamm))

    def _ordner_waehlen(self):
        p = QFileDialog.getExistingDirectory(self, "Ordner fuer das neue Plan[Goo]-Projekt", self.e_ordner.text() or os.path.expanduser("~"))
        if p:
            self.e_ordner.setText(p)

    def _datei_fallen_gelassen(self, p):
        n = os.path.basename(p).lower()
        if not n.endswith(".gpkg"):
            return False
        if n.startswith("nvt_standorte_"):
            self.f_st.setText(p)
            self.h_stosi.setChecked(True)
        elif n.startswith("adresspruefung_"):
            self.f_adr.setText(p)
        elif n.startswith("trassen_"):
            self.f_tr.setText(p)
        elif n.startswith("hk_"):
            self.f_hk.setText(p)
        else:
            self.f_geb.setText(p)
            self._quelle_geaendert()
        self._stand_uebernehmen()
        return True

    def _stand_uebernehmen(self):
        """Standdatei neben den Ergebnissen (stand.py): sobald eine Datei des Gebiets gewaehlt ist, kommen die uebrigen Felder aus deren Ordner -
        auch gegen die Vorbelegung mit dem juengsten Ergebnis (Pruefer B4: sonst mischen sich Gebiete)."""
        from ... import stand
        quelle = None
        s = self.sender()
        for feld in (self.f_tr, self.f_hk, self.f_geb, self.f_adr, self.f_st):
            p = feld.text()
            if p and os.path.exists(p) and (s is None or s in (feld.box, feld.box.lineEdit(), feld)):
                quelle = feld
                break
        if quelle is None:
            for feld in (self.f_tr, self.f_hk, self.f_geb, self.f_adr, self.f_st):
                if feld.text() and os.path.exists(feld.text()):
                    quelle = feld
                    break
        if quelle is None:
            return
        ordner = os.path.dirname(os.path.abspath(quelle.text()))
        if not os.path.exists(stand.pfad(ordner)):
            return
        gefuellt = []
        for feld, art in ((self.f_adr, "adresspruefung"), (self.f_geb, "nvt_gebiete"), (self.f_st, "nvt_standorte"), (self.f_tr, "trassen"), (self.f_hk, "hk")):
            if feld is quelle:
                continue
            q = stand.ergebnis(ordner, art)
            if q and os.path.normcase(feld.text()) != os.path.normcase(q):
                feld.setText(q)
                gefuellt.append(art)
                if art == "nvt_standorte":
                    self.h_stosi.setChecked(True)
                if art == "nvt_gebiete":
                    self._quelle_geaendert()
        if gefuellt:
            self._log("Standdatei {}: {} uebernommen".format(os.path.join(ordner, stand.DATEI), ", ".join(gefuellt)))

    # --- Projekt -----------------------------------------------------------------------------------------------------------------------
    def _stand(self, still=False):
        try:
            st = projekt.projekt_stand()
        except Exception as e:
            st = None
            if not still:
                self._log("Projektstand nicht lesbar: {!r}".format(e))
        self.lab_projekt.setText(projekt.stand_text(st))
        if st and not still:
            self._log(projekt.stand_text(st))
        return st

    def _anlegen(self):
        ordner, name = self.e_ordner.text().strip(), self.e_name.text().strip()
        if not ordner or not name:
            QMessageBox.information(self, "Neues Projekt", "Ordner und Name angeben (Vorgabe erscheint, sobald ein Schnitt in Schritt 3 gewaehlt ist).")
            return
        if projekt.aktive_instanz() is not None:
            if QMessageBox.question(self, "Neues Projekt", "In Plan[Goo] ist schon ein Projekt in Bearbeitung. Trotzdem ein neues anlegen und "
                                    "wechseln? (Das offene Projekt wird von Plan[Goo] zurueckgesetzt.)",
                                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                return
        try:
            SponsorDialog = projekt._m("modules.other.dialog_sponsor").SponsorDialog
            sponsor = SponsorDialog.get_sponsor(self)
        except Exception as e:
            QMessageBox.critical(self, "Ausbautreiber", "Plan[Goo]-Dialog nicht verfuegbar: {!r}".format(e)[:400])
            return
        if sponsor is None:
            self._log("Abgebrochen: kein Ausbautreiber gewaehlt.")
            return
        self.k_anlegen.setEnabled(False)
        try:
            db, gp = projekt.neues_projekt(ordner, name, sponsor, log=self._log)
            try:
                pl = projekt.plangoo_plugin()
                off = pl.get_edit_offline() if pl is not None and hasattr(pl, "get_edit_offline") else None
                if off is not None and hasattr(off, "reset") and projekt.aktive_instanz() is not None:
                    off.reset()
            except Exception:
                pass
            projekt.in_bearbeitung_nehmen(db, gp, log=self._log)
            dateiwahl.merken("plangoo", gp)
            self._stand()
            QMessageBox.information(self, "Neues Projekt", "Leeres Projekt angelegt und in Bearbeitung genommen:\n{}\n\nAusbautreiber: {}\n\n"
                                    "Jetzt Schritt 2: Adressen importieren.".format(gp, getattr(sponsor, "value", sponsor)))
        except Exception as e:
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "Neues Projekt - Fehler", "{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])
        finally:
            self.k_anlegen.setEnabled(True)

    def _projekt_noetig(self):
        st = self._stand(still=True)
        if st is None:
            QMessageBox.warning(self, "Kein Projekt", "Kein Plan[Goo]-Projekt in Bearbeitung. Oben ein neues anlegen oder in Plan[Goo] eines "
                                "in Bearbeitung nehmen, dann 'Stand lesen'.")
        return st

    # --- Schritte ----------------------------------------------------------------------------------------------------------------------
    def _schritt1(self):
        gpkg = self.f_adr.text()
        if not gpkg or not os.path.exists(gpkg):
            QMessageBox.information(self, "Adressen", "Adresspruefung aus Kachel 2 waehlen.")
            return
        st = self._projekt_noetig()
        if st is None:
            return
        try:
            v = projekt.adressen_vorschau(gpkg)
        except Exception as e:
            QMessageBox.critical(self, "Adressen", "Datei nicht lesbar: {!r}".format(e)[:400])
            return
        if not st["apl"] and not v["onkz_asb"]:
            QMessageBox.warning(self, "Adressen", "Das Projekt hat noch keine APL und die Liste keine ONKZ/ASB - ASB der neuen APL nicht bestimmbar.")
            return
        text = ("Projekt: {}\n\n{} Adressen in der Pruefung, davon {} 'ignorieren', {} rot{}, {} ohne Koordinate.\n"
                "Vorhandene APL im Projekt: {} (bekommen WE, Gewerbe, P2P, Gebaeudenutzung), fehlende werden neu angelegt.\n{}\n\nImportieren?").format(
            os.path.basename(st["pfad"]), v["gesamt"], v["ignorieren"], v["rot"], " (werden ausgelassen)" if self.h_rot.isChecked() else "",
            v["ohne_koordinate"], st["apl"], "Backup-Zip wird vorher geschrieben." if self.h_backup.isChecked() else "KEIN Backup.")
        if QMessageBox.question(self, "2 Adressen als APL", text, QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self._lauf(self.k1, self.lab1, "Adressen", lambda: projekt.adressen_importieren(
            gpkg, rote_auslassen=self.h_rot.isChecked(), mit_backup=self.h_backup.isChecked(), log=self._log, fortschritt=self._fortschritt),
            lambda e: "{} APL geaendert, {} angelegt, {} uebersprungen, {} Fehler".format(e["geaendert"], e["angelegt"], e["uebersprungen"], e["fehler"]),
            "adresspruefung", gpkg)

    def _schritt2(self):
        from . import plangoo
        gpkg = self.f_geb.text()
        if not gpkg or not os.path.exists(gpkg):
            QMessageBox.information(self, "Gebiete", "NVT-Gebiete aus Kachel 3 waehlen.")
            return
        st = self._projekt_noetig()
        if st is None:
            return
        if not st["apl"]:
            QMessageBox.warning(self, "Gebiete", "Das Projekt hat noch keine APL - erst Schritt 2.")
            return
        try:
            v = plangoo.vorschau(gpkg)
        except Exception as e:
            QMessageBox.critical(self, "Gebiete", "Nicht lesbar: {!r}".format(e)[:400])
            return
        stp = self._standorte_pfad()
        text = ("Projekt: {}\n\nEs werden angelegt: {} NVT mit Projekt und Versorgungsbereich.\n{} Adressen werden an ihre NVT gehaengt "
                "({} APL im Projekt).\nVorhandene NVT im Projekt: {}{}\nNVT-Lage: {}\n{}\n\nImportieren?").format(
            v["projekt"], v["gebiete"], v["adressen"], v["apl_projekt"], v["nvt_vorhanden"],
            " - werden als _alt gekennzeichnet" if self.h_alt.isChecked() and v["nvt_vorhanden"] else "",
            "gepruefter Standort aus Kachel 4 ({})".format(os.path.basename(stp)) if stp else "Sitzvorschlag aus dem Schnitt",
            "Backup-Zip wird vorher geschrieben." if self.h_backup.isChecked() else "KEIN Backup.")
        if QMessageBox.question(self, "3 Gebiete, NVT, Zuordnung", text, QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        if stp:
            dateiwahl.merken("nvt_standorte", stp)

        def lauf():
            e = plangoo.uebernehmen(gpkg, alte_kennzeichnen=self.h_alt.isChecked(), standorte_pfad=stp, mit_backup=self.h_backup.isChecked(),
                                    log=self._log, fortschritt=self._fortschritt)
            for o in e["offen"][:60]:
                self._log("  offen: " + o)
            return e
        self._lauf(self.k2, self.lab2, "Gebiete", lauf,
                   lambda e: "{} NVT, {} Projekte, {} Bereiche, {} Adressen zugeordnet, {} ohne APL, {} alte gekennzeichnet".format(
                       e["nvt"], e["projekte"], e["bereiche"], e["adressen"], e["ohne_apl"], e["alte"]),
                   "nvt_gebiete", gpkg)

    def _schritt3(self):
        """Markus 12.10.: Kondensat aus Schritt 5 und 7 - nur wenn beide final und geprueft sind; Vorschau mit Zahlen, dann Import."""
        gpkg, hk = self.f_tr.text(), self.f_hk.text()
        if not gpkg or not os.path.exists(gpkg):
            QMessageBox.information(self, "Trassen", "Trassen-Ergebnis aus Kachel 5 waehlen.")
            return
        if not hk or not os.path.exists(hk):
            QMessageBox.information(self, "Trassen", "Hk-Ergebnis aus Kachel 7 waehlen - die Uebergabe braucht beide Planungen.")
            return
        st = self._projekt_noetig()
        if st is None:
            return
        if not st["nvt"]:
            QMessageBox.warning(self, "Trassen", "Das Projekt hat noch keine NVT - erst Schritt 3.")
            return
        self.k_log.setChecked(True) if hasattr(self, "k_log") else None
        try:
            v = projekt.kondensat_vorschau(gpkg, hk, log=self._log)
        except Exception as e:
            self._log(traceback.format_exc()[-1200:])
            QMessageBox.critical(self, "Trassen", "Kondensat nicht gebildet: {!r}".format(e)[:400])
            return
        if not v["ok"]:
            QMessageBox.warning(self, "Uebergabe blockiert", "{}\n\nEs fehlt:\n{}{}".format(v["text"], "\n".join("- " + x for x in v["fehlt"][:20]),
                                                                                       "\n- ... ({} weitere)".format(len(v["fehlt"]) - 20) if len(v["fehlt"]) > 20 else ""))
            self.lab3.setText("blockiert: " + v["text"])
            self.lab3.setStyleSheet("color:#C62828; font-size:11px;")
            return
        text = ("Projekt: {}\n\nKondensat aus Schritt 5 und 7:\n{}\n\nDie Ebene 'uebergabe' liegt im Trassen-GeoPackage. {}\n\nNach Plan[Goo] importieren?").format(
            os.path.basename(st["pfad"]), v["text"], "Backup-Zip wird vorher geschrieben." if self.h_backup.isChecked() else "KEIN Backup.")
        if QMessageBox.question(self, "5+7 Trassen", text, QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            self.lab3.setText("Kondensat gebildet (Ebene uebergabe), nicht importiert: " + v["text"].replace("\n", " "))
            return
        dateiwahl.merken("hk", hk)
        self._lauf(self.k3, self.lab3, "Trassen", lambda: projekt.kondensat_importieren(gpkg, hk, mit_backup=self.h_backup.isChecked(), log=self._log, fortschritt=self._fortschritt),
                   lambda e: "{} Trassen angelegt, {} uebersprungen, {} Fehler ({} Stuecke / {:.0f} m Kondensat)".format(e["angelegt"], e["uebersprungen"], e["fehler"],
                                                                                                                      e["stats"]["n_nachher"], e["stats"]["m_nachher"]),
                   "trassen", gpkg)

    def _standorte_pfad(self):
        if not self.h_stosi.isChecked():
            return None
        p = self.f_st.text()
        return p if p and os.path.exists(p) else None

    def _lauf(self, knopf, label, titel, fn, zusammenfassung, art, gpkg):
        knopf.setEnabled(False)
        try:
            dateiwahl.merken(art, gpkg)
            self._log("{}: Import startet ...".format(titel))
            e = fn()
            text = zusammenfassung(e)
            label.setText("erledigt: " + text + (" | Backup: " + os.path.basename(e["backup"]) if e.get("backup") else ""))
            label.setStyleSheet("color:#2E8B57; font-size:11px;")
            try:
                self.iface.mapCanvas().refresh()
            except Exception:
                pass
            self._stand()
            meld = e.get("meldungen") or []
            if e.get("fehler") or meld:
                QMessageBox.warning(self, titel, "Import mit Hinweisen:\n{}\n\nEinzelheiten im Protokoll.".format(text))
            else:
                QMessageBox.information(self, titel, "Import fertig:\n{}".format(text))
        except Exception as ex:
            self._fortschritt(0, "Fehler")
            self._log("{}: Fehler {!r}".format(titel, ex))
            self._log(traceback.format_exc()[-1500:])
            label.setText("Fehler: {!r}".format(ex)[:200])
            label.setStyleSheet("color:#C62828; font-size:11px;")
            QMessageBox.critical(self, titel + " - Fehler", "{!r}\n\nEinzelheiten im Protokoll.".format(ex)[:600])
        finally:
            knopf.setEnabled(True)
