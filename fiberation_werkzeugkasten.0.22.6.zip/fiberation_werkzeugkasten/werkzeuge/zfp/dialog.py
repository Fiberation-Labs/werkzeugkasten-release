# -*- coding: utf-8 -*-
"""Schritt 11 - Dialog "ZFP222 Ringauftraege": fertiges Plan[Goo]-Projekt (offen oder Datei) -> Kopf pruefen/ergaenzen (Auftragsart, Gebietsname,
BA-ID, Projekt-ID, ONKZ, AsB, KLS-ID BSt, Termin) -> Formblatt fuellen (.xlsm mit Makros) + Auftragsliste (.xlsx) + Bericht; Tabelle der
Zeilen und Pruefhinweise. Markus 22.09.2026: Block 4/5 leer, SMA fuellt die Telekom, Plan[Goo] ist die Quelle."""
import os
import traceback

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QComboBox, QDateEdit, QDialog, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                                 QMessageBox, QProgressBar, QPushButton, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout, QCheckBox)

from ... import ablauf, ci, dateiwahl, tabelle
from ...dialogbasis import WerkzeugDialog
from ...dateiwahl import DateiFeld
from . import kern

SCHL = "zfp"


class ZfpDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self.ergebnis = None
        self._projekt = None
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel(SCHL).replace("  ", " ", 1))
        self.setMinimumWidth(900)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel(SCHL), "Das Telekom-Formblatt ZFP222 'Ringauftraege erzeugen v3.4' aus dem fertigen Plan[Goo]-Projekt fuellen: "
                                                       "Kopf, Block 1 HK, Block 2 NVt, Block 3 NE4. Block 4 und 5 bleiben leer, SMA fuellt die Telekom.")
        lay.addWidget(self.kopf)

        lay.addWidget(self._ueberschrift("Quelle und Kopf"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(6)
        g.addWidget(QLabel("Plan[Goo]-Projekt:"), 0, 0)
        self.f_pg = DateiFeld("plangoo", "leer = das offene Plan[Goo]-Projekt; sonst PlGoV2_....gpkg (mit .db daneben)", "GeoPackage (*.gpkg)", "Plan[Goo]-Projekt waehlen", ci.STIL_KNOPF_ZWEIT, vorbelegen=False)
        self.f_pg.box.activated.connect(lambda *_: self._projekt_lesen())
        self.f_pg.box.lineEdit().editingFinished.connect(self._projekt_lesen)
        g.addWidget(self.f_pg, 0, 1, 1, 4)
        self.k_lesen = QPushButton("Projekt lesen")
        self.k_lesen.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_lesen.setToolTip("NVT, Hk-Bezeichnungen, BSt, ONKZ/AsB aus dem Projekt lesen und den Kopf vorbelegen")
        self.k_lesen.clicked.connect(self._projekt_lesen)
        g.addWidget(self.k_lesen, 0, 5)
        g.addWidget(QLabel("Auftragsart:"), 1, 0)
        self.art = QComboBox()
        for a in kern.AUFTRAGSARTEN:
            self.art.addItem(a)
        self.art.setMaximumWidth(220)
        z1 = QHBoxLayout()
        z1.setSpacing(8)
        z1.addWidget(self.art)
        z1.addWidget(QLabel("Gebietsname:"))
        self.gebiet = QLineEdit()
        self.gebiet.setPlaceholderText("z. B. Barntrup PushPK (G4)")
        z1.addWidget(self.gebiet, 1)
        z1.addWidget(QLabel("Termin:"))
        self.h_termin = QCheckBox()
        self.h_termin.setToolTip("Termin (Spalte H) in alle Zeilen schreiben; sonst leer")
        z1.addWidget(self.h_termin)
        self.termin = QDateEdit()
        self.termin.setCalendarPopup(True)
        self.termin.setDisplayFormat("dd.MM.yyyy")
        from qgis.PyQt.QtCore import QDate
        self.termin.setDate(QDate.currentDate().addMonths(3))
        self.termin.setEnabled(False)
        self.h_termin.toggled.connect(self.termin.setEnabled)
        z1.addWidget(self.termin)
        g.addLayout(z1, 1, 1, 1, 5)
        g.addWidget(QLabel("BA-ID / Projekt-ID:"), 2, 0)
        z2 = QHBoxLayout()
        z2.setSpacing(8)
        self.ba_id = QLineEdit()
        self.ba_id.setPlaceholderText("BA-ID (G5)")
        self.projekt_id = QLineEdit()
        self.projekt_id.setPlaceholderText("Projekt-ID (G6), leer = Vorhaben aus Plan[Goo]")
        z2.addWidget(self.ba_id)
        z2.addWidget(self.projekt_id)
        z2.addWidget(QLabel("ONKZ:"))
        self.onkz = QLineEdit()
        self.onkz.setMaximumWidth(70)
        self.onkz.setPlaceholderText("aus Projekt")
        z2.addWidget(self.onkz)
        z2.addWidget(QLabel("AsB:"))
        self.asb = QLineEdit()
        self.asb.setMaximumWidth(50)
        self.asb.setPlaceholderText("aus Pr.")
        z2.addWidget(self.asb)
        z2.addWidget(QLabel("KLS-ID BSt:"))
        self.kls = QLineEdit()
        self.kls.setMaximumWidth(120)
        self.kls.setPlaceholderText("L9.97R (G9)")
        z2.addWidget(self.kls)
        g.addLayout(z2, 2, 1, 1, 5)
        g.addWidget(QLabel("Vorlage / Ausgabe:"), 3, 0)
        z3 = QHBoxLayout()
        z3.setSpacing(8)
        self.vorlage = QLineEdit()
        self.vorlage.setPlaceholderText("leer = mitgelieferte Vorlage v3.4 ({})".format(os.path.basename(kern.VORLAGE)))
        self.vorlage.setToolTip("Eigene ZFP222-Vorlage (.xlsm), z. B. eine neuere Version der Telekom")
        z3.addWidget(self.vorlage, 1)
        v = QPushButton("Vorlage")
        v.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        v.clicked.connect(self._vorlage_waehlen)
        z3.addWidget(v)
        self.out = QLineEdit()
        self.out.setPlaceholderText("Ausgabeordner, leer = neben dem Projekt")
        z3.addWidget(self.out, 1)
        o = QPushButton("Ordner")
        o.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        o.clicked.connect(self._out_waehlen)
        z3.addWidget(o)
        g.addLayout(z3, 3, 1, 1, 5)
        g.setColumnStretch(1, 1)
        lay.addLayout(g)
        self.lab_projekt = QLabel("Projekt noch nicht gelesen.")
        self.lab_projekt.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        lay.addWidget(self.lab_projekt)

        k = QHBoxLayout()
        self.k_start = QPushButton("ZFP222 fuellen")
        self.k_start.setStyleSheet(ci.STIL_KNOPF)
        self.k_start.setCursor(Qt.PointingHandCursor)
        self.k_start.clicked.connect(self._start)
        self.k_excel = QPushButton("Formblatt oeffnen")
        self.k_excel.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_excel.setEnabled(False)
        self.k_excel.clicked.connect(lambda: self._oeffnen(self.ergebnis and self.ergebnis.get("xlsm")))
        self.k_liste = QPushButton("Auftragsliste oeffnen")
        self.k_liste.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_liste.setEnabled(False)
        self.k_liste.clicked.connect(lambda: self._oeffnen(self.ergebnis and self.ergebnis.get("xlsx")))
        self.k_bericht = QPushButton("Bericht oeffnen")
        self.k_bericht.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_bericht.setEnabled(False)
        self.k_bericht.clicked.connect(lambda: self._oeffnen(self.ergebnis and self.ergebnis.get("bericht")))
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        for x in (self.k_start, self.k_excel, self.k_liste, self.k_bericht, self.k_log):
            k.addWidget(x)
        k.addStretch(1)
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, SCHL))
        k.addWidget(hilfe)
        schl = QPushButton("Schliessen")
        self.k_schliessen = schl
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.close)
        k.addWidget(schl)
        lay.addLayout(k)
        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)

        self.tabelle = tabelle.Tabelle("zfp_auftraege", ["Block", "HK-Bez.", "NVt / Gebiets-ID", "Auftragsbezeichnung", "Montageort", "Hinweis"], self.iface, karte=False)
        self.tabelle.setMinimumHeight(220)
        lay.addWidget(self.tabelle, 1)
        self.lab_summe = QLabel("")
        self.lab_summe.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        lay.addWidget(self.lab_summe)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(120)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log)
        self.setAcceptDrops(True)
        from ... import fenster
        fenster.einrichten(self, SCHL, 900)

    # --- Hilfen ------------------------------------------------------------------------------------------------------------------------
    def _out_waehlen(self):
        p = dateiwahl.ordner_waehlen(self, "Ausgabeordner waehlen", "ausgabe", self.out.text())
        if p:
            self.out.setText(p)

    def _vorlage_waehlen(self):
        from qgis.PyQt.QtWidgets import QFileDialog
        p, _ = QFileDialog.getOpenFileName(self, "ZFP222-Vorlage waehlen", self.vorlage.text() or os.path.dirname(kern.VORLAGE), "Excel mit Makros (*.xlsm)")
        if p:
            self.vorlage.setText(p)

    def _datei_fallen_gelassen(self, p):
        n = os.path.basename(p).lower()
        if n.endswith(".gpkg"):
            self.f_pg.setText(p)
            self._projekt_lesen()
        elif n.endswith(".xlsm"):
            self.vorlage.setText(p)
        else:
            return False
        return True

    def _gpkg(self):
        p = self.f_pg.text().strip()
        if p:
            return p if os.path.exists(p) else None
        return dateiwahl.projekt_gpkg()

    # --- Projekt lesen -------------------------------------------------------------------------------------------------------------------
    def _projekt_lesen(self):
        gpkg = self._gpkg()
        if not gpkg:
            self.lab_projekt.setText("Kein Plan[Goo]-Projekt geoeffnet und keine Datei gewaehlt.")
            return None
        try:
            p = kern.projekt_lesen(gpkg, log=self._log)
        except Exception as e:
            self.lab_projekt.setText("Projekt nicht lesbar: {!r}".format(e)[:200])
            self._log(traceback.format_exc()[-800:])
            return None
        self._projekt = p
        if not self.onkz.text().strip():
            self.onkz.setPlaceholderText(p["onkz"] or "?")
        if not self.asb.text().strip():
            self.asb.setPlaceholderText(p["asb"] or "?")
        if not self.projekt_id.text().strip():
            self.projekt_id.setPlaceholderText("Projekt-ID (G6), leer = " + (p["gebiets_id"] or "?"))
        if len(p["bst"]) and kern._s(p["bst"]["KLS_ID"].iloc[0]) and not self.kls.text().strip():
            self.kls.setPlaceholderText(kern._s(p["bst"]["KLS_ID"].iloc[0]))
        if not self.gebiet.text().strip():
            ort = p["nvt"]["ORT"].map(kern._s).value_counts()
            if len(ort) and ort.index[0]:
                self.gebiet.setPlaceholderText("z. B. {} {}".format(ort.index[0], "PushPK" if self.art.currentText() == "PUSH PK" else "MBfD"))
        hks = sorted(set(p["nvt"]["NVT_HK_NAMEN"].map(kern._s)) - {""})
        blockiert = sum(1 for b in p["pruefung"] if b["blockiert"])
        self.lab_projekt.setText("{}: {} NVT in {} Hk ({}), {} APL, BSt {}; ONKZ {}, AsB {}; {} Pruefhinweise{}".format(
            os.path.basename(gpkg), len(p["nvt"]), len(hks), ", ".join(hks[:8]) + (" ..." if len(hks) > 8 else ""), len(p["apl"]),
            ", ".join(p["bst"]["NAME"].map(kern._s)) or "-", p["onkz"] or "?", p["asb"] or "?", len(p["pruefung"]), " ({} blockierend)".format(blockiert) if blockiert else ""))
        self._tabelle_pruefung(p["pruefung"])
        return p

    # --- Fuellen -----------------------------------------------------------------------------------------------------------------------
    def _start(self):
        self.log.clear()
        self.k_start.setEnabled(False)
        try:
            gpkg = self._gpkg()
            if not gpkg:
                QMessageBox.information(self, "ZFP222", "Kein Plan[Goo]-Projekt geoeffnet - Projekt oeffnen oder ein PlGoV2_....gpkg waehlen.")
                return
            kopf = {"auftragsart": self.art.currentText(), "gebietsname": self.gebiet.text().strip(), "ba_id": self.ba_id.text().strip(),
                    "projekt_id": self.projekt_id.text().strip(), "onkz": self.onkz.text().strip(), "asb": self.asb.text().strip(), "kls_id_bst": self.kls.text().strip(),
                    "termin": self.termin.date().toString("dd.MM.yyyy") if self.h_termin.isChecked() else None}
            r = kern.erzeugen(gpkg, kopf, vorlage=self.vorlage.text().strip() or None, out_dir=dateiwahl.ausgabeordner(self.out.text()), log=self._log, fortschritt=self._fortschritt)
            self.ergebnis = r
            dateiwahl.merken("zfp", r["xlsm"])
            for k_ in (self.k_excel, self.k_liste, self.k_bericht):
                k_.setEnabled(True)
            self._tabelle_zeilen(r)
            n1, n2, n3 = r["anzahl"]
            blockiert = [b for b in r["pruefung"] if b["blockiert"]]
            text = "Formblatt gefuellt: {} HK, {} NVt, {} NE4 (Auftragsart {}, ONKZ {}, AsB {}).\n\n{}".format(
                n1, n2, n3, r["kopf"]["auftragsart"], r["kopf"]["onkz"] or "?", r["kopf"]["asb"] or "?", os.path.basename(r["xlsm"]))
            if r["pruefung"]:
                text += "\n\n{} Pruefhinweise, {} blockierend:\n".format(len(r["pruefung"]), len(blockiert)) + "\n".join("- " + b["text"] for b in r["pruefung"][:8])
            QMessageBox.information(self, "ZFP222", text + "\n\nIn Excel oeffnen, Kopf pruefen, dann das Makro 'Auftraege erzeugen' starten.")
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "ZFP222 - Fehler", "{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])
        finally:
            self.k_start.setEnabled(True)

    # --- Tabelle -----------------------------------------------------------------------------------------------------------------------
    def _tabelle_pruefung(self, pruefung):
        self.tabelle.setRowCount(0)
        for b in pruefung:
            i = self.tabelle.rowCount()
            self.tabelle.insertRow(i)
            for j, w in enumerate(("Pruefung", "", b["objekt"], "", "", ("BLOCKIEREND: " if b["blockiert"] else "") + b["text"])):
                self.tabelle.setItem(i, j, QTableWidgetItem(str(w)))
        self.tabelle.resizeColumnsToContents()
        self.tabelle.fertig()
        self.lab_summe.setText("{} Pruefhinweise vor dem Fuellen".format(len(pruefung)) if pruefung else "Keine Pruefhinweise.")

    def _tabelle_zeilen(self, r):
        self.tabelle.setRowCount(0)
        z = r["zeilen"]
        onkz, asb = r["kopf"]["onkz"], r["kopf"]["asb"]

        def ort(x):
            return "{} {}{}, {} {} {}".format(x["strasse"], x["hnr"], x["hnr_zs"], x["plz"], x["ort"], x["ortsteil"]).strip(", ")

        reihen = [("1 HK", h["hk"], "", kern.SYNTAX["HK"].format(hk=h["hk"], anzahl_nvt=h["anzahl_nvt"], onkz=h["onkz"], asb=h["asb"], nvts=h["nvts"]), ort(h),
                   "AsB {} (Fremdansch.)".format(h["asb"]) if h["asb"] != asb else "") for h in z["hk"]]
        reihen += [("2 NVt", n["hk"], n["nvt"], kern.SYNTAX["NVT"].format(nvt=n["nvt"], onkz=n["onkz"], asb=n["asb"], hk=n["hk"]), ort(n), "" if n["hk"] else "ohne Hk") for n in z["nvt"]]
        reihen += [("3 NE4", n["hk"], n["gebiet"], kern.SYNTAX["NE4"].format(gebiet=n["gebiet"], onkz=n["onkz"], asb=n["asb"], hk=n["hk"]), ort(n), "") for n in z["ne4"]]
        for b in r["pruefung"]:
            reihen.append(("Pruefung", "", b["objekt"], "", "", ("BLOCKIEREND: " if b["blockiert"] else "") + b["text"]))
        for reihe in reihen:
            i = self.tabelle.rowCount()
            self.tabelle.insertRow(i)
            for j, w in enumerate(reihe):
                self.tabelle.setItem(i, j, QTableWidgetItem(str(w)))
        self.tabelle.resizeColumnsToContents()
        self.tabelle.fertig()
        n1, n2, n3 = r["anzahl"]
        self.lab_summe.setText("{} HK, {} NVt, {} NE4 | ONKZ {} AsB {} | {} Pruefhinweise | {}".format(n1, n2, n3, onkz or "?", asb or "?", len(r["pruefung"]), os.path.basename(r["xlsm"])))
