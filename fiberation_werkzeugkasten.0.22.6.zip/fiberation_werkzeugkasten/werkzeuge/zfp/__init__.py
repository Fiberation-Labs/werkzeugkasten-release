# -*- coding: utf-8 -*-
"""Schritt 11 - ZFP222 Ringauftraege: das Telekom-Formblatt "Ringauftraege erzeugen v3.4" (.xlsm) aus dem fertigen Plan[Goo]-Projekt fuellen
(Kopf, Block 1 HK, Block 2 NVt, Block 3 NE4), dazu eine einfache Auftragsliste (.xlsx) und ein Bericht."""
