# -*- coding: utf-8 -*-
"""Schritt 11 - ZFP222 Ringauftraege - Kern ohne Qt.

Markus 22.09.2026: "Zum Schluss, wenn Plan[Goo] fertig ist, muss diese ZFP-Liste automatisch befuellt werden koennen." Block 4 (NVt
Nachinstallation) und Block 5 (HVt) bleiben leer, SMA fuellt die Telekom, Plan[Goo] ist die einzige Quelle.

Quelle: das Plan[Goo]-Projekt (GeoPackage + .db daneben):
  GEOMETRY_POINT TYPE nvt: NAME (NVT = Gebiets-ID), NVT_HK_NAMEN (Hk-Bezeichnung, z. B. "6R/14"), PLZ/ORT/ORTSTEIL/STRASSE/HS_NR/HS_NR_ZS
  (Montageort = NVT-Standort), KLS_ID, NVT_APL_COUNT; TYPE bst: NAME, KLS_ID (oft leer -> Planer traegt ein); TYPE apl: PARENT_NAME = NVT.
  DB PROJECT: NAME (Hk-Projekt "3R/44" oder NVT-Projekt), ONB, ASB, GEBIETS_ID (Workspace/Vorhaben) - ONKZ = ONB. Ein Projekt kann Hk
  mehrerer AsB tragen (St. Johann: 3, 6, 81) -> Spalte A "AsB fuer Fremdansch." bei Hk mit anderem AsB als der Kopf.
Formblatt (Blatt Form, v3.4): Kopf E2 Auftragsart, G4 Gebietsname, G5 BA-ID, G6 Projekt-ID, G7 ONKZ, G8 AsB, G9 KLS-ID BSt, D4-D8 Anzahl je Block;
  Block 1 HK ab benanntem Bereich Block1 (+3): Nr/HK-Bez./SMA/Auftragsbezeichnung/Termin/Montageort; Block 2 NVt (Block2), Block 3 NE4 (Block3).
  Syntax der Auftragsbezeichnungen aus dem Blatt VORLAGEN: HK_{HK-Bez}_{AnzahlNVT}_{ONKZ}_{ASB}_FTTH_{NVTs mit _}, NVT_{NVT}_{ONKZ}_{ASB}_FTTH_{HK-Bez},
  NE4_{GebietsID}_{ONKZ}_{ASB}_FTTH_{HK-Bez}. GF-Codes und PGZ zieht das Makro des Formblatts selbst aus VORLAGEN.
Der Code der Schreibroutine stammt aus dem HLD Roboter (hld/zfp222.py, 08.09.2026). Makro-Vertraeglichkeit: openpyxl mit keep_vba, der Planer
prueft in Excel (Makro "Auftraege erzeugen").
"""
import copy
import math
import os
import re
import sqlite3
import time
from collections import Counter
from datetime import datetime

import geopandas as gpd
import pandas as pd

HIER = os.path.dirname(os.path.abspath(__file__))
VORLAGE = os.path.normpath(os.path.join(HIER, "..", "..", "resources", "ZFP222_Formblatt_Ringauftraege_erzeugen_v3_4.xlsm"))
AUFTRAGSARTEN = ("PUSH PK", "MBfD PASSED", "MBfD PREPARED")
SYNTAX = {"HK": "HK_{hk}_{anzahl_nvt}_{onkz}_{asb}_FTTH_{nvts}", "NVT": "NVT_{nvt}_{onkz}_{asb}_FTTH_{hk}", "NE4": "NE4_{gebiet}_{onkz}_{asb}_FTTH_{hk}"}
SPALTEN = {"A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "H": 8, "J": 10, "K": 11, "L": 12, "M": 13, "N": 14, "O": 15}


from ... import gemeinsam
_s = gemeinsam.s


def _hnr(v):
    h = _s(v)
    if h.endswith(".0"):
        h = h[:-2]
    return h


def db_pfad(gpkg):
    return os.path.splitext(str(gpkg))[0] + ".db"


def stamm(gpkg):
    n = os.path.splitext(os.path.basename(str(gpkg)))[0]
    m = re.match(r"^PlGoV2_(\d+_\d+)", n)
    return m.group(1) if m else n[:40]


# --- Lesen ----------------------------------------------------------------------------------------------------------------------------------
def projekt_lesen(gpkg, log=print):
    """-> dict(nvt (GeoDataFrame), bst (GeoDataFrame), projekte (DataFrame NAME/ONB/ASB/GEBIETS_ID), apl_je_nvt (dict), onkz, asb, gebiets_id, pruefung (Liste))"""
    gpkg = str(gpkg)
    pt = gpd.read_file(gpkg, layer="GEOMETRY_POINT")
    typ = pt["TYPE"].astype(str)
    nvt = pt[typ == "nvt"].copy()
    bst = pt[typ == "bst"].copy()
    apl = pt[typ.isin(["apl", "nap"])]
    apl_je_nvt = apl["PARENT_NAME"].map(_s).value_counts().to_dict() if len(apl) else {}
    projekte = pd.DataFrame(columns=["NAME", "ONB", "ASB", "GEBIETS_ID"])
    db = db_pfad(gpkg)
    if os.path.exists(db):
        try:
            con = sqlite3.connect(db)
            projekte = pd.read_sql_query("select NAME, ONB, ASB, GEBIETS_ID from PROJECT", con)
            con.close()
        except Exception as e:
            log("Plan[Goo]-Datenbank nicht lesbar ({}) - ONKZ/AsB aus den Punkten geschaetzt".format(str(e)[:100]))
    else:
        log("Plan[Goo]-Datenbank fehlt neben dem GeoPackage - ONKZ/AsB muss der Planer eintragen")
    gueltig = projekte[pd.to_numeric(projekte["ONB"], errors="coerce").fillna(0) > 0] if len(projekte) else projekte
    onkz = str(int(Counter(gueltig["ONB"].astype(int)).most_common(1)[0][0])) if len(gueltig) else ""
    asb = str(int(Counter(gueltig["ASB"].astype(int)).most_common(1)[0][0])) if len(gueltig) else ""
    gebiets_id = _s(gueltig["GEBIETS_ID"].dropna().iloc[0]) if len(gueltig) and gueltig["GEBIETS_ID"].notna().any() else ""
    pruefung = []
    ohne_hk = nvt[nvt["NVT_HK_NAMEN"].map(_s) == ""]
    for n in ohne_hk["NAME"].map(_s):
        pruefung.append({"art": "NVT ohne Hk", "objekt": n, "text": "NVT {} traegt keine Hk-Bezeichnung (NVT_HK_NAMEN leer) - Block 1 bis 3 ohne HK-Bez.".format(n), "blockiert": 1})
    ohne_adr = nvt[nvt["STRASSE"].map(_s) == ""]
    for n in ohne_adr["NAME"].map(_s):
        pruefung.append({"art": "NVT ohne Adresse", "objekt": n, "text": "NVT {} hat keinen Montageort (Strasse leer) - naechster APL wird genommen".format(n), "blockiert": 0})
    dopp = [n for n, c in Counter(nvt["NAME"].map(_s)).items() if c > 1]
    for n in dopp:
        pruefung.append({"art": "NVT doppelt", "objekt": n, "text": "NVT-Name {} kommt mehrfach vor".format(n), "blockiert": 1})
    if not len(bst):
        pruefung.append({"art": "BSt fehlt", "objekt": "", "text": "Kein Punkt vom Typ bst im Projekt - KLS-ID der BSt eintragen", "blockiert": 0})
    elif len(bst) > 1:
        pruefung.append({"art": "mehrere BSt", "objekt": ", ".join(bst["NAME"].map(_s)), "text": "{} Betriebsstellen im Projekt - KLS-ID der richtigen eintragen".format(len(bst)), "blockiert": 0})
    asbs = sorted(set(int(a) for a in gueltig["ASB"].dropna().astype(int))) if len(gueltig) else []
    if len(asbs) > 1:
        pruefung.append({"art": "mehrere AsB", "objekt": ", ".join(str(a) for a in asbs), "text": "Hk-Projekte mit AsB {} - Kopf AsB {}, andere in Spalte A 'AsB fuer Fremdansch.'".format(", ".join(str(a) for a in asbs), asb), "blockiert": 0})
    log("Plan[Goo]: {} NVT, {} APL, {} BSt, {} Projekte, ONKZ {}, AsB {} (weitere: {}), Vorhaben {}".format(
        len(nvt), len(apl), len(bst), len(projekte), onkz or "?", asb or "?", ", ".join(str(a) for a in asbs if str(a) != asb) or "-", gebiets_id or "?"))
    return {"nvt": nvt, "bst": bst, "apl": apl, "apl_je_nvt": apl_je_nvt, "projekte": projekte, "onkz": onkz, "asb": asb, "gebiets_id": gebiets_id, "pruefung": pruefung}


def zeilen_bilden(p, onkz, asb, log=print):
    """-> dict(hk=[...], nvt=[...], ne4=[...]) mit Zeilen-Dicts (Montageort = NVT-Standortadresse, sonst naechster APL)."""
    from shapely.strtree import STRtree
    nvt, apl = p["nvt"], p["apl"]
    tree = STRtree(list(apl.geometry)) if len(apl) else None
    proj_asb = {}
    for _, r in p["projekte"].iterrows():
        try:
            proj_asb[_s(r["NAME"])] = (str(int(r["ONB"])), str(int(r["ASB"])))
        except Exception:
            pass

    def ort_von(r):
        if _s(r.get("STRASSE")):
            q = r
        elif tree is not None:
            q = apl.iloc[tree.nearest(r.geometry)]
        else:
            q = {}
        return {"plz": _s(q.get("PLZ")), "ort": _s(q.get("ORT")), "ortsteil": _s(q.get("ORTSTEIL")), "strasse": _s(q.get("STRASSE")), "hnr": _hnr(q.get("HS_NR")), "hnr_zs": _s(q.get("HS_NR_ZS"))}

    def natkey(x):
        return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", str(x))]

    zeilen_nvt, zeilen_ne4, gruppen = [], [], {}
    for _, r in nvt.sort_values("NAME", key=lambda s: s.map(natkey)).iterrows():
        name = _s(r["NAME"])
        hk = _s(r.get("NVT_HK_NAMEN"))
        ort = ort_von(r)
        o, a = proj_asb.get(hk, (onkz, asb))
        z = dict(hk=hk, nvt=name, gebiet=name, apl=int(p["apl_je_nvt"].get(name, 0) or 0), kls_id=_s(r.get("KLS_ID")), onkz=o or onkz, asb=a or asb, **ort)
        zeilen_nvt.append(z)
        zeilen_ne4.append(dict(z))
        gruppen.setdefault(hk, []).append(z)
    zeilen_hk = []
    for i, hk in enumerate(sorted((h for h in gruppen if h), key=natkey), 1):     # NVT ohne Hk-Bezeichnung bilden keine HK-Zeile (Pruefhinweis)
        liste = gruppen[hk]
        o, a = proj_asb.get(hk, (onkz, asb))
        zeilen_hk.append(dict(nr=i, hk=hk, anzahl_nvt=len(liste), nvts="_".join(z["nvt"] for z in liste), onkz=o or onkz, asb=a or asb,
                              **{k: liste[0][k] for k in ("plz", "ort", "ortsteil", "strasse", "hnr", "hnr_zs")}))
    log("Zeilen: {} HK, {} NVt, {} NE4".format(len(zeilen_hk), len(zeilen_nvt), len(zeilen_ne4)))
    return {"hk": zeilen_hk, "nvt": zeilen_nvt, "ne4": zeilen_ne4}


# --- Schreiben ------------------------------------------------------------------------------------------------------------------------------
def _shift_names_and_merges(wb, ws, ab_zeile, n):
    """Nach ws.insert_rows(ab_zeile, n): verbundene Zellen und benannte Bereiche unterhalb mitverschieben."""
    from openpyxl.worksheet.cell_range import CellRange
    neue = []
    for m in list(ws.merged_cells.ranges):
        if m.min_row >= ab_zeile:
            ws.merged_cells.remove(m)
            neue.append(CellRange(min_col=m.min_col, min_row=m.min_row + n, max_col=m.max_col, max_row=m.max_row + n))
    for m in neue:
        ws.merged_cells.add(m)
    try:
        items = list(wb.defined_names.items())
    except Exception:
        items = []
    for name, dn in items:
        txt = str(dn.attr_text or "")
        m = re.match(r"^'?Form'?!\$([A-Z]+)\$(\d+)$", txt)
        if m and int(m.group(2)) >= ab_zeile:
            dn.attr_text = "Form!${}${}".format(m.group(1), int(m.group(2)) + n)


def _schreibe_block(ws, start_zeile, zeilen, spalten_werte, vorlage_zeile):
    n = len(zeilen)
    if n == 0:
        return 0
    ws.insert_rows(start_zeile, n)
    for i, z in enumerate(zeilen):
        r = start_zeile + i
        for col_letter, wert in spalten_werte(z).items():
            if wert in (None, ""):
                continue
            c = ws.cell(r, SPALTEN[col_letter])
            c.value = wert
            try:
                q = ws.cell(vorlage_zeile, SPALTEN[col_letter])
                c.font = copy.copy(q.font)
                c.border = copy.copy(q.border)
                c.alignment = copy.copy(q.alignment)
                c.number_format = q.number_format
            except Exception:
                pass
    return n


def erzeugen(gpkg, kopf, vorlage=None, out_dir=None, log=print, fortschritt=None):
    """kopf: dict(auftragsart, gebietsname, ba_id, projekt_id, onkz, asb, kls_id_bst, termin) - leere Werte werden aus dem Projekt ergaenzt.
    -> dict(xlsm, xlsx, bericht, anzahl (n1, n2, n3), pruefung, kopf, zeilen)"""
    os.environ.setdefault("OPENPYXL_LXML", "False")
    import openpyxl
    t0 = time.time()
    f = fortschritt or (lambda p, t: None)
    gpkg = str(gpkg)
    vorlage = vorlage or VORLAGE
    if not os.path.exists(vorlage):
        raise FileNotFoundError("ZFP222-Vorlage fehlt: {}".format(vorlage))
    out_dir = out_dir or os.path.dirname(gpkg)
    os.makedirs(out_dir, exist_ok=True)
    f(5, "Plan[Goo] lesen")
    p = projekt_lesen(gpkg, log)
    art = kopf.get("auftragsart") or AUFTRAGSARTEN[0]
    onkz = _s(kopf.get("onkz")) or p["onkz"]
    asb = _s(kopf.get("asb")) or p["asb"]
    kls_bst = _s(kopf.get("kls_id_bst")) or (_s(p["bst"]["KLS_ID"].iloc[0]) if len(p["bst"]) else "")
    kopf_voll = {"auftragsart": art, "gebietsname": _s(kopf.get("gebietsname")), "ba_id": _s(kopf.get("ba_id")), "projekt_id": _s(kopf.get("projekt_id")) or p["gebiets_id"],
                 "onkz": onkz, "asb": asb, "kls_id_bst": kls_bst, "termin": kopf.get("termin") or None}
    if not onkz or not asb:
        p["pruefung"].append({"art": "ONKZ/AsB fehlt", "objekt": "", "text": "ONKZ oder AsB nicht bestimmbar - im Kopf eintragen", "blockiert": 1})
    if not kopf_voll["gebietsname"]:
        p["pruefung"].append({"art": "Gebietsname fehlt", "objekt": "", "text": "Gebietsname (G4) ist leer - traegt der Planer ein", "blockiert": 0})
    if not kls_bst:
        p["pruefung"].append({"art": "KLS-ID BSt fehlt", "objekt": "", "text": "KLS-ID der Betriebsstelle (G9, L9.97R) ist leer - traegt der Planer ein", "blockiert": 0})
    f(30, "Zeilen bilden")
    daten = zeilen_bilden(p, onkz, asb, log)

    def bez_hk(z):
        return SYNTAX["HK"].format(hk=z["hk"], anzahl_nvt=z["anzahl_nvt"], onkz=z["onkz"], asb=z["asb"], nvts=z["nvts"])

    def bez_nvt(z):
        return SYNTAX["NVT"].format(nvt=z["nvt"], onkz=z["onkz"], asb=z["asb"], hk=z["hk"])

    def bez_ne4(z):
        return SYNTAX["NE4"].format(gebiet=z["gebiet"], onkz=z["onkz"], asb=z["asb"], hk=z["hk"])

    def ort(z):
        return {"J": z["plz"], "K": z["ort"], "L": z["ortsteil"], "M": z["strasse"], "N": z["hnr"], "O": z["hnr_zs"]}

    def fremd_asb(z):
        return z["asb"] if z["asb"] and z["asb"] != asb else None

    termin = kopf_voll["termin"]
    f(50, "Formblatt fuellen")
    wb = openpyxl.load_workbook(vorlage, keep_vba=True)
    ws = wb["Form"]
    ws["E2"] = art
    ws["G4"] = kopf_voll["gebietsname"]
    ws["G5"] = kopf_voll["ba_id"]
    ws["G6"] = kopf_voll["projekt_id"]
    ws["G7"] = onkz
    ws["G8"] = asb
    if kls_bst:
        ws["G9"] = kls_bst

    def block_zeile(name):
        dn = wb.defined_names[name] if name in wb.defined_names else None
        m = re.search(r"\$(\d+)$", str(dn.attr_text)) if dn is not None else None
        return int(m.group(1)) if m else None

    b1 = block_zeile("Block1") or 11
    n1 = _schreibe_block(ws, b1 + 3, daten["hk"], lambda z: {"A": fremd_asb(z), "B": z["nr"], "C": z["hk"], "E": bez_hk(z), "H": termin, **ort(z)}, b1 + 2)
    _shift_names_and_merges(wb, ws, b1 + 3, n1)
    b2 = block_zeile("Block2") or (16 + n1)
    n2 = _schreibe_block(ws, b2 + 3, daten["nvt"], lambda z: {"A": fremd_asb(z), "B": z["hk"], "C": z["nvt"], "E": bez_nvt(z), "H": termin, **ort(z)}, b2 + 2)
    _shift_names_and_merges(wb, ws, b2 + 3, n2)
    b3 = block_zeile("Block3") or (21 + n1 + n2)
    n3 = _schreibe_block(ws, b3 + 3, daten["ne4"], lambda z: {"A": fremd_asb(z), "B": z["hk"], "C": z["gebiet"], "E": bez_ne4(z), "H": termin, **ort(z)}, b3 + 2)
    _shift_names_and_merges(wb, ws, b3 + 3, n3)
    ws["D4"], ws["D5"], ws["D6"], ws["D7"], ws["D8"] = n1, n2, n3, 0, 0
    st = stamm(gpkg)
    datum = datetime.now().strftime("%Y%m%d_%H%M")
    from ..bestand.kern import ausgabe_pfad
    out_xlsm = ausgabe_pfad(out_dir, "ZFP222_{}_{}.xlsm".format(st, datum), log)
    wb.save(out_xlsm)

    f(80, "Auftragsliste")
    out_xlsx = os.path.splitext(out_xlsm)[0] + "_Auftragsliste.xlsx"
    wb2 = openpyxl.Workbook()
    w = wb2.active
    w.title = "Auftragsliste"
    w.append(["Block", "Nr", "HK-Bez.", "NVt / Gebiets-ID", "Auftragsbezeichnung", "Termin", "PLZ", "Ort", "Ortsteil", "Strasse", "HsNr", "HsNr ZS", "APL", "KLS-ID NVT",
              "ONKZ", "AsB", "Auftragsart", "Gebietsname", "BA-ID", "Projekt-ID"])
    for z in daten["hk"]:
        w.append(["1 HK", z["nr"], z["hk"], "", bez_hk(z), termin, z["plz"], z["ort"], z["ortsteil"], z["strasse"], z["hnr"], z["hnr_zs"], "", "", z["onkz"], z["asb"], art,
                  kopf_voll["gebietsname"], kopf_voll["ba_id"], kopf_voll["projekt_id"]])
    for z in daten["nvt"]:
        w.append(["2 NVt", "", z["hk"], z["nvt"], bez_nvt(z), termin, z["plz"], z["ort"], z["ortsteil"], z["strasse"], z["hnr"], z["hnr_zs"], z["apl"], z["kls_id"], z["onkz"], z["asb"], art,
                  kopf_voll["gebietsname"], kopf_voll["ba_id"], kopf_voll["projekt_id"]])
    for z in daten["ne4"]:
        w.append(["3 NE4", "", z["hk"], z["gebiet"], bez_ne4(z), termin, z["plz"], z["ort"], z["ortsteil"], z["strasse"], z["hnr"], z["hnr_zs"], z["apl"], z["kls_id"], z["onkz"], z["asb"], art,
                  kopf_voll["gebietsname"], kopf_voll["ba_id"], kopf_voll["projekt_id"]])
    w2 = wb2.create_sheet("Pruefung")
    w2.append(["Art", "Objekt", "Hinweis", "blockiert"])
    for b in p["pruefung"]:
        w2.append([b["art"], b["objekt"], b["text"], b["blockiert"]])
    for col, breite in zip("ABCDEFGHIJKLMNOPQRST", (8, 5, 12, 16, 62, 10, 7, 14, 14, 24, 6, 6, 5, 12, 6, 4, 12, 20, 10, 16)):
        w.column_dimensions[col].width = breite
    wb2.save(out_xlsx)
    f(92, "Bericht")
    bericht = _bericht(out_xlsm, gpkg, kopf_voll, daten, p["pruefung"], time.time() - t0)
    log("ZFP222: {} HK, {} NVt, {} NE4 -> {} ({} Pruefhinweise, {} blockierend)".format(n1, n2, n3, os.path.basename(out_xlsm), len(p["pruefung"]),
                                                                                       sum(1 for b in p["pruefung"] if b["blockiert"])))
    f(100, "Fertig")
    return {"xlsm": out_xlsm, "xlsx": out_xlsx, "bericht": bericht, "anzahl": (n1, n2, n3), "pruefung": p["pruefung"], "kopf": kopf_voll, "zeilen": daten,
            "stamm": st, "gpkg": gpkg}


def _bericht(out_xlsm, gpkg, kopf, daten, pruefung, dauer):
    p = os.path.splitext(out_xlsm)[0] + "_bericht.md"
    z = ["# ZFP222 Ringauftraege - {}".format(os.path.basename(gpkg)), "",
         "Stand {}, {:.0f} s. Auftragsart {}. Gebietsname {}. BA-ID {}. Projekt-ID {}. ONKZ {}, AsB {}, KLS-ID BSt {}. Termin {}.".format(
             datetime.now().strftime("%d.%m.%Y %H:%M"), dauer, kopf["auftragsart"], kopf["gebietsname"] or "-", kopf["ba_id"] or "-", kopf["projekt_id"] or "-",
             kopf["onkz"] or "?", kopf["asb"] or "?", kopf["kls_id_bst"] or "-", kopf["termin"] or "-"), "",
         "Block 1 HK: {} | Block 2 NVt: {} | Block 3 NE4: {} | Block 4 und 5: leer (Markus 22.09.2026) | SMA: fuellt die Telekom.".format(len(daten["hk"]), len(daten["nvt"]), len(daten["ne4"])), ""]
    if pruefung:
        z += ["## Pruefung", ""] + ["- {}{}".format("BLOCKIEREND: " if b["blockiert"] else "", b["text"]) for b in pruefung] + [""]
    z += ["## Block 1 HK", "", "| Nr | HK-Bez. | NVT | Auftragsbezeichnung | Montageort |", "|---|---|---|---|---|"]
    for h in daten["hk"]:
        z.append("| {} | {} | {} | {} | {} {} {}, {} {} |".format(h["nr"], h["hk"], h["anzahl_nvt"], SYNTAX["HK"].format(hk=h["hk"], anzahl_nvt=h["anzahl_nvt"], onkz=h["onkz"], asb=h["asb"], nvts=h["nvts"]),
                                                             h["strasse"], h["hnr"], h["hnr_zs"], h["plz"], h["ort"]))
    z += ["", "## Block 2 NVt", "", "| HK-Bez. | NVt | APL | Montageort |", "|---|---|---|---|"]
    for n in daten["nvt"]:
        z.append("| {} | {} | {} | {} {} {}, {} {} {} |".format(n["hk"], n["nvt"], n["apl"], n["strasse"], n["hnr"], n["hnr_zs"], n["plz"], n["ort"], n["ortsteil"]))
    z += ["", "## Vorgehen", "- Die .xlsm in Excel oeffnen, Kopf pruefen (Gebietsname, BA-ID, Projekt-ID, KLS-ID BSt, Termin), dann das Makro 'Auftraege erzeugen' starten - "
          "GF-Codes und PGZ zieht das Formblatt aus dem Blatt VORLAGEN.", "- Die _Auftragsliste.xlsx ist dieselbe Liste ohne Makros (Blatt Pruefung mit den Hinweisen).",
          "- Block 4 (NVt Nachinstallation) und Block 5 (HVt) bleiben leer; SMA fuellt die Telekom.", "", "Formblatt: `{}`".format(os.path.basename(out_xlsm))]
    with open(p, "w", encoding="utf-8") as fh:
        fh.write("\n".join(z))
    return p
