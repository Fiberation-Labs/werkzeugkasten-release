# -*- coding: utf-8 -*-
"""Schritt 7 - Hk-Trasse je Strang: Weg-Vorlage rechnen (Bestand als Weg), Hk-Trasse zeichnen, Vorlage/Bestand uebernehmen, pruefen.
Der Kern liegt in werkzeuge/hk/kern.py (vorlage_rechnen, planung_*, pruefen); hier nur der Dialog."""
