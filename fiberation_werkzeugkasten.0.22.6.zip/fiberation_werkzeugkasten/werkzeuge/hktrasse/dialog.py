# -*- coding: utf-8 -*-
"""Schritt 7 - Dialog "Hk-Trasse je Strang": Hk-Ergebnis aus Schritt 6 laden, je Strang die Weg-Vorlage rechnen (Vzk-Trassen aus Schritt 5,
Bestand aus Schritt 1 als Weg), Hk-Trasse zeichnen mit Fang, Vorlage oder Bestand uebernehmen, speichern, pruefen - Strang fuer Strang wie
Schritt 5 NVT fuer NVT (Markus 22.09.2026). Rohre und Kabel legt der Planer danach in Plan[Goo]."""
import os
import traceback

from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsDefaultValue, QgsProject, QgsSnappingConfig, QgsTolerance,
                       QgsVectorLayer, QgsWkbTypes)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QGridLayout, QHBoxLayout, QHeaderView, QLabel,
                                 QMessageBox, QProgressBar, QPushButton, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout)

from ... import ablauf, ci, dateiwahl, layerbaum, tabelle
from ...dialogbasis import WerkzeugDialog
from ...dateiwahl import DateiFeld
from ..hk import kern
from ..hk.dialog import EBENEN_6, EBENEN_7, ebenen_laden, layer_finden

SCHL = "hktrasse"


class HkTrasseDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self.ergebnis = None            # dict gpkg, stamm, liste (dict), bericht
        self._netz = None               # Netz-Cache aus kern.netz_vorbereiten
        self._netz_schluessel = None
        self._fang_alt = None
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel(SCHL).replace("  ", " ", 1))
        self.setMinimumWidth(900)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel(SCHL), "Je Strang den Weg von der Betriebsstelle rechnen (Bestand aus Schritt 1 als Weg, Vzk-Trassen aus Schritt 5), "
                                                       "dann zeichnet der Planer die Hk-Trasse nach, holt Bestand dazu und prueft. Rohre und Kabel: in Plan[Goo].")
        lay.addWidget(self.kopf)

        # --- Eingaben ---------------------------------------------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Hk-Ergebnis und Weg-Vorlage"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(6)
        g.addWidget(QLabel("Hk-Straenge (Schritt 6):"), 0, 0)
        self.f_hk = DateiFeld("hk", "hk_....gpkg aus Schritt 6 - aufklappen fuer die letzten Ergebnisse", "GeoPackage (*.gpkg)", "Hk-Ergebnis waehlen", ci.STIL_KNOPF_ZWEIT)
        self.f_hk.box.activated.connect(lambda *_: self._laden_klick())
        g.addWidget(self.f_hk, 0, 1, 1, 4)
        self.k_laden = QPushButton("Laden")
        self.k_laden.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_laden.clicked.connect(self._laden_klick)
        g.addWidget(self.k_laden, 0, 5)
        self.h_vzk = QCheckBox("Vzk-Trassen aus Schritt 5 bevorzugen:")
        self.h_vzk.setChecked(True)
        self.h_vzk.setToolTip("Netzkanten auf den Vzk-Trassen kosten fuer den Hk nur 10 % - Tiefbau wird nur einmal bezahlt. Leer = wie in Schritt 6.")
        g.addWidget(self.h_vzk, 1, 0)
        self.f_tra = DateiFeld("trassen", "trassen_....gpkg (leer = wie in Schritt 6)", "GeoPackage (*.gpkg)", "Trassen-Ergebnis waehlen", ci.STIL_KNOPF_ZWEIT, vorbelegen=False)
        g.addWidget(self.f_tra, 1, 1, 1, 5)
        self.h_bestand = QCheckBox("Bestand aus Schritt 1 als Weg:")
        self.h_bestand.setChecked(True)
        self.h_bestand.setToolTip("Die Wegefuehrung ist die Telekom-Trasse: Rohrtrassen mit potenziell freiem Hk-tauglichem Rohr kosten nur den Einzug (5,83 EUR/m, "
                                  "Ein-/Ausstieg ein Kopfloch), andere Telekom-Trassen bekommen als Neubau den Vorzug (70 %). Wo keine Trasse liegt, sucht der Baum den "
                                  "guenstigsten Weg. Leer = wie in Schritt 6.")
        g.addWidget(self.h_bestand, 2, 0)
        self.f_bestand = DateiFeld("bestand", "bestand_....gpkg aus Schritt 1 (leer = wie in Schritt 6)", "GeoPackage (*.gpkg)", "Bestand aus Schritt 1 waehlen",
                                   ci.STIL_KNOPF_ZWEIT, vorbelegen=False)
        g.addWidget(self.f_bestand, 2, 1, 1, 5)
        for h, feld in ((self.h_vzk, self.f_tra), (self.h_bestand, self.f_bestand)):
            h.toggled.connect(lambda an, fe=feld: fe.setEnabled(an))
            h.toggled.connect(lambda *_: self._netz_verwerfen())
        for feld in (self.f_tra, self.f_bestand):
            feld.box.lineEdit().textChanged.connect(lambda *_: self._netz_verwerfen())
        g.setColumnStretch(1, 1)
        lay.addLayout(g)

        k = QHBoxLayout()
        self.k_rechnen = QPushButton("Vorlage rechnen")
        self.k_rechnen.setStyleSheet(ci.STIL_KNOPF)
        self.k_rechnen.setCursor(Qt.PointingHandCursor)
        self.k_rechnen.setToolTip("Weg von der BSt zu den NVT des gewaehlten Strangs (Steinerbaum), Kabelgroesse je Abschnitt, Muffenvorschlaege -> Vorlage (gestrichelt, gesperrt)")
        self.k_rechnen.clicked.connect(lambda: self._rechnen(alle=False))
        self.k_rechnen_alle = QPushButton("Vorlage fuer alle Straenge")
        self.k_rechnen_alle.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_rechnen_alle.clicked.connect(lambda: self._rechnen(alle=True))
        self.k_bericht = QPushButton("Bericht oeffnen")
        self.k_bericht.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_bericht.setEnabled(False)
        self.k_bericht.clicked.connect(lambda: self._oeffnen(self.ergebnis and self.ergebnis.get("bericht")))
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        for x in (self.k_rechnen, self.k_rechnen_alle, self.k_bericht, self.k_log):
            k.addWidget(x)
        k.addStretch(1)
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, SCHL))
        k.addWidget(hilfe)
        schl = QPushButton("Schliessen")
        self.k_schliessen = schl
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.close)
        k.addWidget(schl)
        lay.addLayout(k)
        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)

        self.tabelle = tabelle.Tabelle("hktrasse_straenge", ["Strang", "NVT", "Fasern", "Kabel", "Vorlage km", "im Bestandsrohr", "Telekom-Trasse", "Muffen", "Status"],
                                       self.iface)
        self.tabelle.layer_finder(self._layer)
        self.tabelle.setMinimumHeight(180)
        self.tabelle.setToolTip("Doppelklick: auf den Strang zoomen und ihn waehlen")
        self.tabelle.itemDoubleClicked.connect(self._zeile_zoomen)
        lay.addWidget(self.tabelle, 1)

        # --- Zeichnen ---------------------------------------------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Hk-Trasse zeichnen"))
        z = QHBoxLayout()
        z.setSpacing(8)
        z.addWidget(QLabel("Strang:"))
        self.strang = QComboBox()
        self.strang.setMinimumWidth(140)
        self.strang.currentIndexChanged.connect(lambda *_: self._vorgaben_setzen())
        z.addWidget(self.strang)
        self.k_zeichnen = QPushButton("Zeichnen")
        self.k_zeichnen.setStyleSheet(ci.STIL_KNOPF)
        self.k_zeichnen.setToolTip("QGIS-Zeichenwerkzeug auf der Hk-Trasse, mit Fang auf Weg-Vorlage, Bestand, NVT und BSt; neue Stuecke bekommen den gewaehlten Strang")
        self.k_zeichnen.clicked.connect(self._zeichnen)
        self.k_vorlage = QPushButton("Vorlage uebernehmen")
        self.k_vorlage.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_vorlage.setToolTip("Den gerechneten Weg des Strangs als Hk-Trasse in die Planung kopieren")
        self.k_vorlage.clicked.connect(self._vorlage_uebernehmen)
        self.k_bestand = QPushButton("Bestand uebernehmen")
        self.k_bestand.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_bestand.setToolTip("Im Kartenfenster gewaehlte Bestandsrohre oder Rohrzuege aus Schritt 1 als Hk-Trasse (bestand = 1) in die Planung holen")
        self.k_bestand.clicked.connect(self._bestand_uebernehmen)
        self.k_speichern = QPushButton("Aenderungen speichern")
        self.k_speichern.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_speichern.clicked.connect(lambda: self._speichern() and self._neu_laden())
        self.k_pruefen = QPushButton("Pruefen")
        self.k_pruefen.setStyleSheet(ci.STIL_KNOPF)
        self.k_pruefen.setToolTip("Je Strang: alle NVT ueber die gezeichnete Trasse mit der BSt verbunden, Fasern unter dem Deckel?")
        self.k_pruefen.clicked.connect(self._pruefen)
        # Markus 12.10.: Fehler automatisch beheben statt nur melden - Abzweige/Kreuzungen teilen, nahe Enden zusammenfuehren
        self.k_bereinigen = QPushButton("Trassen bereinigen")
        self.k_bereinigen.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_bereinigen.setToolTip("Hk-Trasse (Planung) aufraeumen: Linien dort teilen, wo das Ende einer anderen Linie im Umkreis von 3 m auf ihr liegt "
                                     "(Abzweig) oder wo sich zwei Linien ohne Knoten kreuzen; Enden innerhalb von 3 m auf einen Punkt einrasten. "
                                     "Attribute bleiben, Laengen werden neu gerechnet. Erst Vorschau, dann speichern und erneut pruefen.")
        self.k_bereinigen.clicked.connect(self._bereinigen)
        for x in (self.k_zeichnen, self.k_vorlage, self.k_bestand, self.k_speichern, self.k_bereinigen, self.k_pruefen):
            z.addWidget(x)
        z.addStretch(1)
        self.lab_stand = QLabel("")
        self.lab_stand.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        z.addWidget(self.lab_stand)
        lay.addLayout(z)
        self._freigeben(False)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(120)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log)
        self.setAcceptDrops(True)
        from ... import fenster
        fenster.einrichten(self, SCHL, 900)
        self._erst_laden()

    def _erst_laden(self):
        """Juengstes Hk-Ergebnis aus Schritt 6 gleich beim Oeffnen laden, damit die Seite nicht grau dasteht."""
        try:
            p = self.f_hk.text().strip() or (dateiwahl.zuletzt("hk") or [""])[0] or dateiwahl.juengstes("hk")
            if p and os.path.exists(p):
                self.ergebnis_setzen(p, still=True)
            else:
                self.balken.setFormat("Hk-Ergebnis aus Schritt 6 waehlen und 'Laden' druecken")
                self._log("Noch kein Hk-Ergebnis geladen: oben ein hk_....gpkg aus Schritt 6 waehlen und 'Laden' druecken.")
        except Exception as e:
            self._log("Hk-Ergebnis nicht automatisch geladen ({!r}) - oben waehlen und 'Laden' druecken.".format(e))

    # --- Hilfen ------------------------------------------------------------------------------------------------------------------------
    def _freigeben(self, an):
        for x in (self.k_rechnen, self.k_rechnen_alle, self.k_zeichnen, self.k_vorlage, self.k_bestand, self.k_speichern, self.k_bereinigen, self.k_pruefen,
                  self.strang):
            x.setEnabled(bool(an))

    def _gpkg(self):
        return (self.ergebnis or {}).get("gpkg")

    def _netz_verwerfen(self):
        self._netz, self._netz_schluessel = None, None

    def _datei_fallen_gelassen(self, p):
        n = os.path.basename(p).lower()
        if not n.endswith(".gpkg"):
            return False
        if n.startswith("hk_"):
            self.ergebnis_setzen(p)
        elif n.startswith("trassen_"):
            self.f_tra.setText(p)
        elif n.startswith("bestand_"):
            self.f_bestand.setText(p)
        return True

    # --- Laden -------------------------------------------------------------------------------------------------------------------------
    def _laden_klick(self):
        p = self.f_hk.text().strip()
        if not p:
            juengst = dateiwahl.zuletzt("hk")
            p = juengst[0] if juengst else ""
        if not p or not os.path.exists(p):
            QMessageBox.information(self, "Hk-Trasse", "Erst Schritt 6 ausfuehren oder ein hk_....gpkg waehlen.")
            return
        self.ergebnis_setzen(p)

    def ergebnis_setzen(self, gpkg, still=False):
        """Hk-Ergebnis aus Schritt 6 laden (auch von Schritt 6 'Weiter' und beim Oeffnen). still=True: keine Fenster, nur Protokoll."""
        gpkg = str(gpkg)
        dateiwahl.merken("hk", gpkg)
        if self.f_hk.text().strip() != gpkg:
            self.f_hk.setText(gpkg)
        basis = os.path.splitext(gpkg)[0]
        try:
            liste = kern.liste_lesen(gpkg)
        except Exception as e:
            self._log("Liste zu {} nicht lesbar ({!r}) - Schritt 6 neu ausfuehren.".format(os.path.basename(gpkg), e))
            self.balken.setFormat("Zu diesem GeoPackage fehlt die Liste aus Schritt 6")
            if not still:
                QMessageBox.warning(self, "Hk-Trasse", "Zu diesem GeoPackage fehlt die _liste.json aus Schritt 6 - dort neu schneiden.")
            return
        self.ergebnis = {"gpkg": gpkg, "stamm": liste.get("stamm", os.path.basename(basis).replace("hk_", "")), "liste": liste,
                         "bericht": basis + "_trasse_bericht.md"}
        self._netz_verwerfen()
        self.k_bericht.setEnabled(os.path.exists(self.ergebnis["bericht"]))
        # Vorgaben aus Schritt 6, wenn der Planer nichts anderes gewaehlt hat
        if not self.f_tra.text().strip() and liste.get("trassen"):
            self.f_tra.box.lineEdit().setPlaceholderText("wie Schritt 6: " + os.path.basename(liste["trassen"]))
        if not self.f_bestand.text().strip() and liste.get("bestand"):
            self.f_bestand.box.lineEdit().setPlaceholderText("wie Schritt 6: " + os.path.basename(liste["bestand"]))
        self._tabelle_fuellen()
        self._layer_laden()
        self._stand_aus_layer()
        self._freigeben(self.strang.count() > 0)
        vorl = len((liste.get("vorlage") or {}))
        self.balken.setFormat("{} Straenge geladen, {} mit Weg-Vorlage - Strang waehlen und 'Vorlage rechnen'".format(self.strang.count(), vorl))
        self._log("Ergebnis geladen: {} ({} Straenge, {} mit Weg-Vorlage). Strang waehlen, dann 'Vorlage rechnen' - oder 'Vorlage fuer alle Straenge'.".format(
            os.path.basename(gpkg), self.strang.count(), vorl))

    def _quellen(self):
        """(trassen_gpkg, bestand_gpkg) fuer vorlage_rechnen: '' = ohne, None = wie Schritt 6."""
        liste = (self.ergebnis or {}).get("liste") or {}
        tra = (self.f_tra.text().strip() or liste.get("trassen") or "") if self.h_vzk.isChecked() else ""
        best = (self.f_bestand.text().strip() or liste.get("bestand") or (dateiwahl.zuletzt("bestand") or [""])[0]) if self.h_bestand.isChecked() else ""
        if best and not os.path.exists(best):
            self._log("Bestand nicht gefunden: {} - Weg ohne Bestand".format(best))
            best = ""
        if tra and not os.path.exists(tra):
            self._log("Trassen nicht gefunden: {} - Weg ohne Vzk-Vorzug".format(tra))
            tra = ""
        return tra, best

    # --- Rechnen -----------------------------------------------------------------------------------------------------------------------
    def _rechnen(self, alle=False):
        if not self._gpkg():
            return
        self.log.clear()
        self._freigeben(False)
        try:
            if not self._speichern():
                return
            tra, best = self._quellen()
            schl = (self._gpkg(), tra, best)
            netz = self._netz if self._netz_schluessel == schl else None
            hks = None if alle else [self.strang.currentText()]
            self._log("Vorlage rechnen fuer {}; Vzk-Trassen: {}; Bestand: {}".format("alle Straenge" if alle else hks[0], os.path.basename(tra) or "ohne", os.path.basename(best) or "ohne"))
            r = kern.vorlage_rechnen(self._gpkg(), hks=hks, trassen_gpkg=tra, bestand_gpkg=best, netz=netz, log=self._log, fortschritt=self._fortschritt)
            self._netz, self._netz_schluessel = r["netz"], schl
            self.ergebnis["liste"] = r["liste"]
            self.k_bericht.setEnabled(True)
            self._tabelle_fuellen()
            self._neu_laden(alle_ebenen=True)
            g = r["gesamt"]
            text = "Weg-Vorlage fuer {}: {:.2f} km, davon {:.2f} km im Bestandsrohr (Kabel einziehen, gruen), {:.2f} km entlang Telekom-Trassen (Neubau, blau), {:.2f} km Neubau ohne Bestand; {} Muffen vorgeschlagen.".format(
                "alle {} Straenge".format(len(r["hks"])) if alle else hks[0], g["weg_km"], g["km_bestandsrohr"], g["km_telekom_trasse"], g["km_neu"], g["muffen"])
            if g.get("km_unbestaetigt"):
                text += "\n\n{:.2f} km davon auf Rohrtrassen ohne Rohr in der Rohrliste ('Rohr unbestaetigt') - vor dem Einzug klaeren.".format(g["km_unbestaetigt"])
            if g.get("netzluecke_m"):
                text += "\n\nNetzluecke {:.0f} m (rot gestrichelt): das Netz aus Schritt 3 war dort unterbrochen - den echten Weg nachzeichnen.".format(g["netzluecke_m"])
            if g.get("fehlt"):
                text += "\n\nNicht von der BSt erreichbar: {}".format(", ".join(g["fehlt"]))
            QMessageBox.information(self, "Hk-Trasse", text + "\n\nJetzt die Hk-Trasse zeichnen oder die Vorlage uebernehmen, Bestand dazu holen, pruefen.")
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "Hk-Trasse - Fehler", "{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])
        finally:
            self._freigeben(self.strang.count() > 0)

    # --- Tabelle -----------------------------------------------------------------------------------------------------------------------
    def _tabelle_fuellen(self):
        liste = (self.ergebnis or {}).get("liste") or {}
        vorl = liste.get("vorlage") or {}
        gewaehlt = self.strang.currentText()
        self.tabelle.setRowCount(0)
        self.strang.blockSignals(True)
        self.strang.clear()
        for s in liste.get("straenge", []):
            i = self.tabelle.rowCount()
            self.tabelle.insertRow(i)
            k = vorl.get(s["name"]) or {}
            werte = [s["name"], "{} ({})".format(s["nvt_anzahl"], s["nvt_liste"]), s["fasern"], "{}E".format(s["kabel"]),
                     "{:.2f}".format(k["weg_km"]) if k else "-", "{:.2f}".format(k.get("km_bestandsrohr", 0.0)) if k else "-",
                     "{:.2f}".format(k.get("km_telekom_trasse", 0.0)) if k else "-", k.get("muffen", "-") if k else "-", s.get("status", "offen")]
            for j, w in enumerate(werte):
                it = QTableWidgetItem(str(w))
                if j in (2, 4, 5, 6, 7):
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.tabelle.setItem(i, j, it)
            self.tabelle.karte_setzen(i, bezug=("hk_gebiete", {"name": str(s["name"])}))
            self.strang.addItem(s["name"])
        if gewaehlt:
            i = self.strang.findText(gewaehlt)
            if i >= 0:
                self.strang.setCurrentIndex(i)
        self.strang.blockSignals(False)
        self.tabelle.resizeColumnsToContents()
        self.tabelle.fertig()
        self._vorgaben_setzen()

    def _zeile_zoomen(self, item):
        name = self.tabelle.item(item.row(), 0).text()
        i = self.strang.findText(name)
        if i >= 0:
            self.strang.setCurrentIndex(i)
        lyr = self._layer("hk_gebiete")
        if lyr is None:
            return
        lyr.selectByExpression("\"name\" = '{}'".format(name.replace("'", "''")))
        try:
            self.iface.mapCanvas().zoomToSelected(lyr)
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def _stand_aus_layer(self):
        """Status je Strang aus hk_gebiete in die Tabelle."""
        lyr = self._layer("hk_gebiete")
        if lyr is None:
            return
        st = {str(f["name"]): str(f["status"]) for f in lyr.getFeatures()}
        for i in range(self.tabelle.rowCount()):
            n = self.tabelle.item(i, 0).text()
            if n in st:
                self.tabelle.item(i, 8).setText(st[n])
        fertig = sum(1 for v in st.values() if v == "geprueft")
        self.lab_stand.setText("{} von {} Straengen geprueft".format(fertig, len(st)))

    # --- Zeichnen ----------------------------------------------------------------------------------------------------------------------
    def _vorgaben_setzen(self):
        """Neue Stuecke, die der Planer zeichnet, bekommen den gewaehlten Strang, bestand 0, Status entwurf und eine uid."""
        lyr = self._layer("hk_planung")
        hk = self.strang.currentText()
        if lyr is None or not hk:
            return
        fl = lyr.fields()
        vorgaben = {"hk": "'{}'".format(hk.replace("'", "''")), "typ": "'Hk-Trasse'", "bestand": "0", "status": "'entwurf'", "quelle": "'planer'",
                    "uid": "'{}_' || substr(replace(uuid(), '-', ''), 2, 6)".format(hk.replace("/", "-").replace(" ", "").replace("'", "''")),
                    "laenge_m": "round($length, 1)", "hinweis": "'gezeichnet'", "quelle_id": "''", "rohrklasse": "''", "mp_id": "''", "bauverfahren": "''", "surface": "''",
                    "allowance": "''", "location_hint": "''", "wesi": "''", "sub_type": "''"}
        for feld, ausdruck in vorgaben.items():
            i = fl.indexOf(feld)
            if i >= 0:
                lyr.setDefaultValueDefinition(i, QgsDefaultValue(ausdruck))

    def _zeichnen(self):
        lyr = self._layer("hk_planung")
        if lyr is None:
            return
        self._vorgaben_setzen()
        self._fang_einrichten()
        try:
            self.iface.setActiveLayer(lyr)
            if not lyr.isEditable():
                lyr.startEditing()
            self.iface.actionAddFeature().trigger()
            self._log("Zeichnen auf der Hk-Trasse fuer {}. Fang auf Weg, Bestand, NVT, BSt. Danach 'Aenderungen speichern'.".format(self.strang.currentText()))
        except Exception as e:
            self._log("Zeichenwerkzeug nicht gestartet: {!r}".format(e))

    def _fang_einrichten(self):
        try:
            proj = QgsProject.instance()
            if self._fang_alt is None:
                self._fang_alt = QgsSnappingConfig(proj.snappingConfig())
            cfg = QgsSnappingConfig(proj)
            cfg.setEnabled(True)
            cfg.setMode(QgsSnappingConfig.AdvancedConfiguration)
            cfg.setIntersectionSnapping(True)
            ziele = [self._layer(n) for n in ("hk_vorlage", "hk_planung", "hk_nvt", "bst")] + self._bestand_layer()
            for lyr in ziele:
                if lyr is None:
                    continue
                linie = lyr.geometryType() == QgsWkbTypes.LineGeometry
                try:
                    typ = (QgsSnappingConfig.VertexFlag | QgsSnappingConfig.SegmentFlag) if linie else QgsSnappingConfig.VertexFlag
                    einst = QgsSnappingConfig.IndividualLayerSettings(True, typ, 12.0, QgsTolerance.Pixels, 0.0, 0.0)
                except Exception:
                    typ = QgsSnappingConfig.VertexAndSegment if linie else QgsSnappingConfig.Vertex
                    einst = QgsSnappingConfig.IndividualLayerSettings(True, typ, 12.0, QgsTolerance.Pixels)
                cfg.setIndividualLayerSettings(lyr, einst)
            proj.setSnappingConfig(cfg)
        except Exception as e:
            self._log("Fang nicht gesetzt: {!r}".format(e))

    def closeEvent(self, ev):
        if self._fang_alt is not None:
            try:
                QgsProject.instance().setSnappingConfig(self._fang_alt)
            except Exception:
                pass
            self._fang_alt = None
        super().closeEvent(ev)

    def _speichern(self):
        lyr = self._layer("hk_planung")
        if lyr is None:
            return True
        if lyr.isEditable():
            if lyr.isModified():
                if not lyr.commitChanges():
                    self._log("Hk-Trasse nicht gespeichert: " + "; ".join(lyr.commitErrors())[:300])
                    return False
                self._log("Hk-Trasse gespeichert.")
                try:
                    from ...gemeinsam import wal_schliessen
                    wal_schliessen(self._gpkg())
                except Exception:
                    pass
            else:
                lyr.rollBack()
        return True

    def _neu_laden(self, alle_ebenen=False):
        namen = EBENEN_6 + EBENEN_7 if alle_ebenen else ("hk_planung", "hk_gebiete", "hk_nvt", "hk_pruefung")
        for n in namen:
            lyr = self._layer(n)
            if lyr is not None:
                try:
                    lyr.dataProvider().reloadData()
                    lyr.reload()
                    lyr.updateExtents()
                    lyr.triggerRepaint()
                except Exception:
                    pass
        if alle_ebenen and self.ergebnis:
            ebenen_laden(self._gpkg(), self.ergebnis["stamm"], SCHL, EBENEN_7, "Hk-Trasse {}", neu=False)   # Ebenen, die vorher leer/ungueltig waren
        self._stand_aus_layer()
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass
        return True

    def _vorlage_uebernehmen(self):
        if not self._gpkg() or not self._speichern():
            return
        try:
            n = kern.vorlage_uebernehmen(self._gpkg(), self.strang.currentText(), log=self._log)
            self._neu_laden()
            if n == 0:
                QMessageBox.information(self, "Vorlage uebernehmen", "Fuer {} gibt es noch keine Vorlage - erst 'Vorlage rechnen'.".format(self.strang.currentText()))
            else:
                self._log("{} Stuecke der Vorlage in die Hk-Trasse uebernommen.".format(n))
        except Exception as e:
            self._log("Vorlage nicht uebernommen: {!r}".format(e))

    def _bestand_layer(self):
        """Layer aus Schritt 1 (Bestandsrohre, Rohrzuege, Telekom-Trassen) im Projekt."""
        aus = []
        for lyr in QgsProject.instance().mapLayers().values():
            if isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == QgsWkbTypes.LineGeometry:
                n = layerbaum.ohne_nummer(lyr.name())
                if n.startswith("Bestandsrohre") or "Rohrzuege" in n or "|layername=bestand_rohr" in lyr.source() or "|layername=bestand_trassen" in lyr.source():
                    aus.append(lyr)
        return aus

    def _bestand_uebernehmen(self):
        from shapely import wkb
        if not self._gpkg() or not self._speichern():
            return
        stuecke = []
        ziel = QgsCoordinateReferenceSystem("EPSG:25832")
        for lyr in self._bestand_layer():
            tr = QgsCoordinateTransform(lyr.crs(), ziel, QgsProject.instance())
            for f in lyr.selectedFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = __import__("qgis.core", fromlist=["QgsGeometry"]).QgsGeometry(g)
                g.transform(tr)
                shp = wkb.loads(bytes(g.asWkb()))
                felder = {k: f[k] for k in ("quelle_id", "rohrklasse", "mp_id", "nutzbarkeit") if lyr.fields().indexOf(k) >= 0}
                stuecke.append(dict(geometry=shp, **felder))
        if not stuecke:
            QMessageBox.information(self, "Bestand uebernehmen", "Erst im Kartenfenster Bestandsrohre, Rohrzuege oder Telekom-Trassen aus Schritt 1 auswaehlen, dann 'Bestand uebernehmen'.")
            return
        try:
            n = kern.bestand_uebernehmen(self._gpkg(), self.strang.currentText(), stuecke, log=self._log)
            self._neu_laden()
            QMessageBox.information(self, "Bestand uebernehmen", "{} Bestandsstuecke als Hk-Trasse fuer {} uebernommen (bestand = 1, MegaPlan-ID bleibt).".format(n, self.strang.currentText()))
        except Exception as e:
            self._log("Bestand nicht uebernommen: {!r}".format(e))

    def _bereinigen(self):
        """Markus 12.10.: Vorschau zeigen, auf Wunsch anwenden, Protokoll, Layer neu laden, danach automatisch pruefen."""
        if not self._gpkg() or not self._speichern():
            return
        try:
            vorschau = kern.trassen_bereinigen(self._gpkg(), anwenden=False, log=self._log)
        except Exception as e:
            self.k_log.setChecked(True)
            self._log("Bereinigen (Vorschau) fehlgeschlagen: {!r}".format(e))
            self._log(traceback.format_exc()[-1000:])
            return
        z = vorschau["zusammen"]
        if not z.get("geaendert"):
            QMessageBox.information(self, "Trassen bereinigen", vorschau["text"] + ("\n\n" + "\n".join("- " + m for m in vorschau["meldungen"][:10])
                                                                                  if vorschau["meldungen"] else ""))
            return
        beispiele = "\n".join("- " + m for m in vorschau["meldungen"][:10])
        if len(vorschau["meldungen"]) > 10:
            beispiele += "\n- ... ({} weitere im Protokoll)".format(len(vorschau["meldungen"]) - 10)
        if QMessageBox.question(self, "Trassen bereinigen", "{}\n\n{}\n\nAenderungen in den Layer 'Hk-Trasse (Planung)' schreiben und danach erneut pruefen?"
                                .format(vorschau["text"], beispiele), QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes) != QMessageBox.Yes:
            self._log("Bereinigen abgebrochen - nichts geaendert.")
            return
        try:
            self.k_log.setChecked(True)
            erg = kern.trassen_bereinigen(self._gpkg(), anwenden=True, log=self._log)
            self._neu_laden()
            self._log("Bereinigt und gespeichert: {}".format(erg["text"]))
        except Exception as e:
            self.k_log.setChecked(True)
            self._log("Bereinigen fehlgeschlagen: {!r}".format(e))
            self._log(traceback.format_exc()[-1000:])
            return
        self._pruefen()

    def _pruefen(self):
        if not self._gpkg() or not self._speichern():
            return
        try:
            befunde, geb = kern.pruefen(self._gpkg(), log=self._log)
            self._neu_laden()
            if self._layer("hk_pruefung") is None:
                ebenen_laden(self._gpkg(), self.ergebnis["stamm"], SCHL, ("hk_pruefung",), "Hk-Trasse {}", neu=False)
                self._stand_aus_layer()
            blockiert = [b for b in befunde if b["blockiert"]]
            zuf = [b for b in befunde if b["art"] == "NVT ohne Zufuehrung"]
            if not befunde:
                QMessageBox.information(self, "Pruefung", "Alle Straenge sind ueber die gezeichnete Hk-Trasse mit der Betriebsstelle verbunden.")
            else:
                QMessageBox.information(self, "Pruefung", "{} Befunde, davon {} blockierend:\n\n{}{}".format(len(befunde), len(blockiert),
                                        "\n".join("- " + b["text"] for b in befunde[:12]),
                                        "\n\n{} NVT ohne Zufuehrung: 'Trassen bereinigen' legt die Zufuehrungen an (Pruefen allein aendert nichts).".format(len(zuf)) if zuf else ""))
        except Exception as e:
            self.k_log.setChecked(True)
            self._log("Pruefung fehlgeschlagen: {!r}".format(e))
            self._log(traceback.format_exc()[-1000:])

    # --- Layer -------------------------------------------------------------------------------------------------------------------------
    def _layer(self, name):
        if not self.ergebnis:
            return None
        return layer_finden(self.ergebnis["gpkg"], name)

    def _layer_laden(self):
        gpkg, st = self._gpkg(), self.ergebnis["stamm"]
        ebenen_laden(gpkg, st, "hk", EBENEN_6, "Hauptkabel {}", neu=False)      # Straenge aus Schritt 6 nur nachladen, wenn sie fehlen
        ebenen_laden(gpkg, st, SCHL, EBENEN_7, "Hk-Trasse {}", neu=True)
        self._vorgaben_setzen()
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass
