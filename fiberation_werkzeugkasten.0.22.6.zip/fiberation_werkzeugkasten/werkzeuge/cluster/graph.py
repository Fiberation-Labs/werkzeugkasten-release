# -*- coding: utf-8 -*-
"""Trassengraph (networkx) aus OSM-Wegen oder Telekom-GDS-Trenches, Kostenmodell je Kante, Adressen anbinden.

Kantenattribute: length (m), cost (EUR Tiefbau inkl. Zuschlaege), klasse (Oberflaechenname), okl (LV-Klasse 1/2/3),
                 bauverfahren, eur_m, highway, name, osm_id/quelle_id, hauptstr, querung (str|None), querung_eur,
                 geometry (LineString), virtuell (bool)
Knotenattribute: x, y, b_road, hauptstr, addr (eingefuegter Adressknoten)
"""
import json
import math
import re

import networkx as nx
from shapely.geometry import LineString
from shapely.strtree import STRtree

from . import costs


def _klasse_osm(highway, surface, cfg):
    o = cfg["osm"]
    if surface and surface in o["klasse_je_surface"]:
        return o["klasse_je_surface"][surface]
    return o["klasse_je_highway"].get(highway, "geb_Oberbau")


def _finish_costs(G):
    for u, v, d in G.edges(data=True):
        d["cost"] = d["length"] * d["eur_m"] + d["querung_eur"]


def _largest_component(G):
    if G.number_of_nodes():
        comp = max(nx.connected_components(G), key=len)
        return G.subgraph(comp).copy()
    return G


def build_osm(roads, obstacles, cfg):
    o = cfg["osm"]
    q = cfg["kosten"]["querung"]
    bv = cfg["kosten"]["bauverfahren_default"]
    G = nx.Graph()
    b_ref = re.compile(r"^\s*B\s*\d")
    roads = roads[~roads.highway.isin(o["ausschluss_highway"])]

    for r in roads.itertuples(index=False):
        nodes = json.loads(r.nodes)
        coords = list(r.geometry.coords)
        if len(nodes) != len(coords):
            nodes = ["{}_{}".format(r.osm_id, i) for i in range(len(coords))]
        klasse = _klasse_osm(r.highway, r.surface, cfg)
        okl = costs.oberflaechenklasse(klasse, cfg)
        hauptstr = r.highway in o["hauptstrasse_highway"]
        is_b = bool(r.ref and b_ref.match(str(r.ref)))
        eur_m = costs.eur_m(bv, okl, cfg) * (o["faktor_hauptstrasse"] if hauptstr else 1.0)
        for i in range(len(coords) - 1):
            u, v = nodes[i], nodes[i + 1]
            (x1, y1), (x2, y2) = coords[i], coords[i + 1]
            L = math.hypot(x2 - x1, y2 - y1)
            if L <= 0:
                continue
            G.add_node(u, x=x1, y=y1)
            G.add_node(v, x=x2, y=y2)
            for n in (u, v):
                if is_b:
                    G.nodes[n]["b_road"] = True
                elif hauptstr:
                    G.nodes[n].setdefault("hauptstr", True)
            if G.has_edge(u, v) and G[u][v]["length"] <= L:
                continue
            G.add_edge(u, v, length=L, klasse=klasse, okl=okl, bauverfahren=bv, eur_m=eur_m, highway=r.highway, name=r.name,
                       quelle_id="osm:{}".format(r.osm_id), hauptstr=hauptstr, is_b=is_b, querung=None, querung_eur=0.0,
                       virtuell=False, geometry=LineString([(x1, y1), (x2, y2)]))

    if obstacles is not None and len(obstacles):
        geoms = list(obstacles.geometry)
        arten = list(obstacles.art)
        tree = STRtree(geoms)
        for u, v, d in G.edges(data=True):
            for h in tree.query(d["geometry"], predicate="intersects"):
                art = arten[h]
                pauschale = q["bahn"] if art == "bahn" else q["gewaesser"]
                if pauschale > d["querung_eur"]:
                    d["querung"], d["querung_eur"] = art, pauschale

    for u, v, d in G.edges(data=True):
        if d["is_b"]:
            continue
        for n in (u, v):
            if G.nodes[n].get("b_road"):
                d["querung_eur"] += q["bundesstrasse"] / 2.0
                d["querung"] = d["querung"] or "bundesstrasse"
            elif G.nodes[n].get("hauptstr") and not d["hauptstr"]:
                d["querung_eur"] += q["hauptstrasse"] / 2.0
                d["querung"] = d["querung"] or "hauptstrasse"
    _finish_costs(G)
    return _largest_component(G)


def beschneiden(G, adressen, bst_xy, abstand_m):
    """Kandidatengraph auf die Umgebung der Adressen (konkave Huelle + abstand_m, BSt eingeschlossen) beschneiden.
    Grund: die OSM-Box umfasst bei L-foermigen oder grossen Gebieten halbe Staedte (Saarbruecken: 206.000 Kanten), das
    Clustering skaliert damit schlecht. Kandidaten weiter als abstand_m von jeder Adresse sind fuer Vzk irrelevant; fuer
    den Hk bleibt die Huelle samt BSt-Korridor erhalten. -> (G, entfernte Kanten, entfernte Meter)"""
    from shapely import concave_hull
    from shapely.geometry import MultiPoint, Point
    pts = [Point(p.x, p.y) for p in adressen.geometry]
    if bst_xy:
        pts.append(Point(bst_xy[0], bst_xy[1]))
    if len(pts) < 4 or not abstand_m:
        return G, 0, 0.0
    try:
        huelle = concave_hull(MultiPoint(pts), ratio=0.3).buffer(float(abstand_m))
    except Exception:
        huelle = MultiPoint(pts).convex_hull.buffer(float(abstand_m))
    from shapely.prepared import prep
    ph = prep(huelle)
    G_voll = G.copy()          # fuer den Lueckenschluss zwischen den Ortsteilen (unten)
    raus = [(u, v) for u, v, d in G.edges(data=True) if not ph.intersects(d["geometry"])]
    meter = sum(G[u][v]["length"] for u, v in raus)
    G.remove_edges_from(raus)
    G.remove_nodes_from([n for n in list(G.nodes) if G.degree(n) == 0])
    # Werkzeugkasten 14.09.2026: nach dem Beschnitt NICHT nur die groesste Komponente behalten. Ortsteile, die nur ueber
    # Strassen ausserhalb der Huelle verbunden sind (Barntrup: der ganze Norden), wuerden sonst verschwinden und ihre
    # Adressen an einen fernen Knoten gezwungen. Es bleibt jede Komponente, die Adressen in Reichweite hat.
    from shapely.strtree import STRtree
    adr_tree = STRtree([Point(p.x, p.y) for p in adressen.geometry])
    behalten = set()
    for comp in nx.connected_components(G):
        for n in comp:
            if len(adr_tree.query(Point(G.nodes[n]["x"], G.nodes[n]["y"]).buffer(150.0))):
                behalten |= comp
                break
    G.remove_nodes_from([n for n in list(G.nodes) if n not in behalten])
    # Markus 18.09.2026 (Barntrup, Schritt 6: 21 NVT ohne Strang): die behaltenen Ortsteile haengen im beschnittenen Netz nicht zusammen,
    # die Landstrassen dazwischen liegen ausserhalb der Huelle. Deshalb je abgetrennter Komponente den kuerzesten Weg im vollen
    # OSM-Netz zur groessten Komponente zuruecknehmen - echte Strassen statt gerader Bruecken.
    komps = sorted(nx.connected_components(G), key=len, reverse=True)
    zurueck = 0.0
    if len(komps) > 1 and G_voll.number_of_edges():
        haupt = set(komps[0])
        for comp in komps[1:]:
            try:
                dist, pfade = nx.multi_source_dijkstra(G_voll, sources=haupt, weight="length")
            except Exception:
                break
            ziel = min((n for n in comp if n in dist), key=lambda n: dist[n], default=None)
            if ziel is None:
                continue
            pfad = pfade[ziel]
            for a, b in zip(pfad[:-1], pfad[1:]):
                if not G.has_edge(a, b):
                    for n in (a, b):
                        if n not in G:
                            G.add_node(n, **G_voll.nodes[n])
                    G.add_edge(a, b, **G_voll[a][b])
                    zurueck += G_voll[a][b]["length"]
            haupt |= set(comp) | set(pfad)
        if zurueck:
            meter -= zurueck
    return G, len(raus), meter


def _node_key(x, y):
    return "{:.2f}_{:.2f}".format(x, y)


def build_gds(edges, cfg):
    """edges: GeoDataFrame aus hld.gds.load (surface, digtype, streetname, is_crossing, quelle_id, geometry LineString)."""
    G = nx.Graph()
    tab = cfg["kosten"]["eur_m_lv"]
    for r in edges.itertuples(index=False):
        coords = list(r.geometry.coords)
        (x1, y1), (x2, y2) = coords[0], coords[-1]
        u, v = _node_key(x1, y1), _node_key(x2, y2)
        if u == v:
            continue
        L = r.geometry.length
        klasse = r.surface or "Asphalt"
        okl = costs.oberflaechenklasse(klasse, cfg)
        bv = r.digtype if r.digtype in tab else cfg["kosten"]["bauverfahren_default"]
        querung = None
        if r.is_crossing:
            querung = "Fahrbahn"
            if bv in ("Offene Bauweise", "Mindertiefe_15x30", "Trenching", "Kabelpflug"):
                bv = "Fahrbahn"
        eur_m = costs.eur_m(bv, okl, cfg)
        extra = {}
        name = r.streetname
        # Comsof-Zusatzattribute (hld.comsof.load): Bestandsrohr, Hauszufuehrungstrasse, Anschlussstueck
        if getattr(r, "bestand", False):
            kap = getattr(r, "kapazitaet", None)
            kap = int(kap) if kap is not None and kap == kap else 1
            klasse, okl, bv = "Bestand", 0, "Einzug"
            eur_m = float((cfg.get("bestand") or {}).get("einzug_eur_m", 5.83))
            querung = None
            name = "Bestandsrohr Comsof {} ({} frei)".format(getattr(r, "duct_class", None) or "", kap).replace("  ", " ")
            extra = dict(seite="B", bestand=True, kapazitaet=kap)
        elif getattr(r, "hauszuf", False):
            # Hauszufuehrungstrasse Strasse -> Bedarfspunkt: Mindertiefe, kein Kandidat fuer die Laengstrassen-Optimierung
            bv = "Mindertiefe_15x30"
            okl = costs.oberflaechenklasse(klasse if r.surface else "Ohne Oberbau", cfg)
            eur_m = costs.eur_m(bv, okl, cfg)
            name = "Hauszufuehrung (Comsof)"
            # Sperrfaktor: das Vzk soll nicht ueber fremde Hauszufuehrungen laufen (sonst entstehen Sterne wie in Barntrup)
            eur_m = eur_m * 8.0
            extra = dict(seite="D", hauszuf=True)
        elif getattr(r, "transition", False):
            name = "Anschlussstueck (Comsof)"
            extra = dict(seite="T")
        hinweis = getattr(r, "hinweis", None)
        if isinstance(hinweis, str) and hinweis:
            extra["hinweis"] = hinweis
        G.add_node(u, x=x1, y=y1)
        G.add_node(v, x=x2, y=y2)
        if G.has_edge(u, v) and G[u][v]["length"] <= L:
            continue
        G.add_edge(u, v, length=L, klasse=klasse, okl=okl, bauverfahren=bv, eur_m=eur_m, highway=None, name=name,
                   quelle_id=r.quelle_id, hauptstr=False, is_b=False, querung=querung, querung_eur=0.0, virtuell=False,
                   geometry=LineString(coords), **extra)
    _finish_costs(G)
    return _largest_component(G)


def _split_edge(G, u, v, splits):
    """splits: Liste (fraction, new_node_id, x, y) sortiert. Ersetzt Kante u-v durch Kette."""
    d = G[u][v]
    G.remove_edge(u, v)
    chain = [(0.0, u)] + [(f, n) for f, n, _, _ in splits] + [(1.0, v)]
    for _, n, x, y in splits:
        G.add_node(n, x=x, y=y, addr=True)
    line = d["geometry"]
    for (fa, a), (fb, b) in zip(chain[:-1], chain[1:]):
        if a == b:
            continue
        frac = max(fb - fa, 1e-9)
        nd = dict(d)
        nd["length"] = max(d["length"] * frac, 0.01)   # nie Laenge 0: Projektionen auf Nullkanten liefern NaN
        nd["querung_eur"] = d["querung_eur"] * frac
        nd["cost"] = nd["length"] * d["eur_m"] + nd["querung_eur"]
        geom = _substring(line, fa, fb)
        if geom.length < 0.005:
            geom = LineString([(G.nodes[a]["x"], G.nodes[a]["y"]), (G.nodes[b]["x"] + 0.01, G.nodes[b]["y"])])
        nd["geometry"] = geom
        if G.has_edge(a, b) and G[a][b]["length"] <= nd["length"]:
            continue
        G.add_edge(a, b, **nd)


def _substring(line, fa, fb):
    """Teilstueck einer Linie zwischen normierten Positionen fa < fb."""
    if len(line.coords) == 2:
        return LineString([line.interpolate(fa, normalized=True), line.interpolate(fb, normalized=True)])
    pts = [line.interpolate(fa, normalized=True)]
    total = line.length
    acc = 0.0
    cs = list(line.coords)
    for p0, p1 in zip(cs[:-1], cs[1:]):
        acc += math.hypot(p1[0] - p0[0], p1[1] - p0[1])
        f = acc / total if total else 1.0
        if fa < f < fb:
            pts.append(p1)
    pts.append(line.interpolate(fb, normalized=True))
    return LineString(pts)


def _strasse_norm(name):
    """Strassennamen vergleichbar machen: 'Sprockhöveler Str.' == 'Sprockhoeveler Straße'."""
    if not name or not isinstance(name, str):
        return ""
    s = name.lower().strip()
    s = s.replace("ß", "ss").replace("ä", "ae").replace("ö", "oe").replace("ü", "ue")
    s = re.sub(r"str\.\s*$|strasse$|str$", "strasse", s)
    s = re.sub(r"[\s\-\.]+", "", s)
    return s


def _attach_addresses_alt(G, adressen, cfg):
    """Jede Adresse auf die naechste Kante projizieren, dort Knoten einfuegen.
    Rueckgabe: dict id -> (node, hauszuf_m, snap_point), Anzahl Warnungen (zu weit)."""
    edges = list(G.edges())
    geoms = [G[u][v]["geometry"] for u, v in edges]
    tree = STRtree(geoms)
    # Anschluss nur an echte Trassenkandidaten (keine Querungen, Ecken, virtuellen Kanten)
    anschluss_ok = [G[u][v].get("seite") not in ("Q", "E", "D") and not G[u][v].get("virtuell") for u, v in edges]
    namen_norm = [_strasse_norm(G[u][v].get("name")) for u, v in edges]
    per_edge = {}
    result = {}
    max_snap = cfg["osm"]["max_snap_m"]
    warn = 0
    seiten_aktiv = cfg["osm"].get("seiten", {}).get("aktiv", False)
    hausquerungen = []   # (adressknoten, gegenknoten) -> Querungskante Fahrbahn
    hat_strasse = "strasse" in adressen.columns
    for row in adressen.itertuples(index=False):
        p = row.geometry
        # kuerzester Stich auf eine zulaessige Kante; die eigene Strasse (Adressfeld) gewinnt nur,
        # wenn sie nicht deutlich weiter weg ist als die naechste Kante (Faktor 1,5, max. 60 m)
        best, bd = None, float("inf")
        for j in tree.query(p.buffer(max_snap)):
            if anschluss_ok[j]:
                dd = geoms[j].distance(p)
                if dd < bd:
                    best, bd = j, dd
        idx = best if best is not None else tree.nearest(p)
        if hat_strasse and best is not None:
            sn = _strasse_norm(getattr(row, "strasse", None))
            if sn:
                sb, sd = None, min(60.0, bd * 1.5)
                for j in tree.query(p.buffer(sd)):
                    if anschluss_ok[j] and namen_norm[j] and (namen_norm[j] == sn or sn in namen_norm[j] or namen_norm[j] in sn):
                        dd = geoms[j].distance(p)
                        if dd < sd:
                            sb, sd = j, dd
                if sb is not None:
                    idx = sb
        u, v = edges[idx]
        line = geoms[idx]
        frac = line.project(p, normalized=True)
        sp = line.interpolate(frac, normalized=True)
        dist = p.distance(sp)
        if dist > max_snap:
            warn += 1
        node = "A_" + str(row.id)
        per_edge.setdefault((u, v), []).append((frac, node, sp.x, sp.y))
        result[str(row.id)] = (node, dist, sp)
        # Gegenseite derselben Strasse: Hauszufuehrung darf die Fahrbahn queren (Fahrbahnpreis + Kopfloch)
        d0 = G[u][v]
        if seiten_aktiv and d0.get("seite") in ("L", "R"):
            gegen = "R" if d0["seite"] == "L" else "L"
            best, bd = None, 30.0
            for j in tree.query(sp.buffer(30.0)):
                a, b = edges[j]
                dj = G[a][b]
                if dj.get("seite") == gegen and dj.get("quelle_id") == d0.get("quelle_id"):
                    dd = geoms[j].distance(sp)
                    if dd < bd:
                        best, bd = j, dd
            if best is not None:
                a, b = edges[best]
                gl = geoms[best]
                gf = gl.project(sp, normalized=True)
                gp = gl.interpolate(gf, normalized=True)
                gnode = node + "_q"
                per_edge.setdefault((a, b), []).append((gf, gnode, gp.x, gp.y))
                hausquerungen.append((node, gnode))
    knoten_alias = {}
    for (u, v), splits in per_edge.items():
        splits.sort()
        merged, seen = [], {}
        for f, n, x, y in splits:
            key = round(f, 6)
            if key in seen:
                knoten_alias[n] = seen[key]
                if not n.endswith("_q"):
                    result[n[2:]] = (seen[key], result[n[2:]][1], result[n[2:]][2])
            else:
                seen[key] = n
                merged.append((f, n, x, y))
        _split_edge(G, u, v, merged)
    if hausquerungen:
        eur_q = costs.eur_m("Fahrbahn", 1, cfg)
        kopfloch = cfg["osm"].get("seiten", {}).get("kopfloch_eur", 508.75)
        for n1, n2 in hausquerungen:
            n1, n2 = knoten_alias.get(n1, n1), knoten_alias.get(n2, n2)
            if n1 == n2 or not (G.has_node(n1) and G.has_node(n2)) or G.has_edge(n1, n2):
                continue
            L = math.hypot(G.nodes[n1]["x"] - G.nodes[n2]["x"], G.nodes[n1]["y"] - G.nodes[n2]["y"])
            if L <= 0.01:
                continue
            G.add_edge(n1, n2, length=L, klasse="Asphalt", okl=1, bauverfahren="Fahrbahn", eur_m=eur_q, highway=None, name="Hausquerung",
                       quelle_id="hausquerung", hauptstr=False, is_b=False, querung="Fahrbahn", querung_eur=kopfloch, virtuell=False, seite="Q",
                       cost=L * eur_q + kopfloch,
                       geometry=LineString([(G.nodes[n1]["x"], G.nodes[n1]["y"]), (G.nodes[n2]["x"], G.nodes[n2]["y"])]))
    return result, warn


def _richtung(line):
    """Einheitsvektor Anfang -> Ende einer Linie."""
    c = list(line.coords)
    dx, dy = c[-1][0] - c[0][0], c[-1][1] - c[0][1]
    n = math.hypot(dx, dy) or 1.0
    return dx / n, dy / n


def nearest_node(G, x, y, exclude_addr=False):
    best, bd = None, float("inf")
    for n, d in G.nodes(data=True):
        if exclude_addr and d.get("addr"):
            continue
        dd = (d["x"] - x) ** 2 + (d["y"] - y) ** 2
        if dd < bd:
            best, bd = n, dd
    return best, math.sqrt(bd)


def attach_external_point(G, x, y, name, cfg):
    """Punkt ausserhalb des Graphen (z. B. BSt) ueber eine virtuelle Luftlinien-Kante anbinden.
    -> (node, dist_m, virtuell)"""
    n, dist = nearest_node(G, x, y, exclude_addr=True)
    if dist <= cfg["graph"]["bst_anbindung_max_m"]:
        return n, dist, False
    bv = cfg["kosten"]["bauverfahren_default"]
    klasse = "Ohne Oberbau"
    okl = costs.oberflaechenklasse(klasse, cfg)
    G.add_node(name, x=x, y=y)
    G.add_edge(name, n, length=dist, klasse=klasse, okl=okl, bauverfahren=bv, eur_m=costs.eur_m(bv, okl, cfg), highway=None,
               name="virtuelle Anbindung " + name, quelle_id="virtuell", hauptstr=False, is_b=False, querung=None, querung_eur=0.0,
               virtuell=True, geometry=LineString([(x, y), (G.nodes[n]["x"], G.nodes[n]["y"])]))
    G[name][n]["cost"] = dist * G[name][n]["eur_m"]
    return name, dist, True


def node_xy(G, n):
    d = G.nodes[n]
    return d["x"], d["y"]


def attach_addresses(G, adressen, cfg, gebaeude=None, flurstuecke=None):
    """Adressen anbinden, HP+-gerecht: Anschlusspunkt = Trassenkante mit dem kuerzesten Stich zum **Flurstueck** der
    Adresse; Stich endet an der Flurstuecksgrenze (+ Ueberstand), der Rest bis zum Gebaeude ist Privatgrund.
    Ohne Flurstuecke: Stich zum Adresspunkt (wie bisher). Eigene Strasse (Adressfeld) gewinnt nur, wenn sie nicht
    deutlich weiter ist (Faktor 1,5). Querungen, Ecken und virtuelle Kanten sind keine Anschlusspunkte.
    Rueckgabe: dict id -> (node, dist_gesamt_m, snap_point, hp_point, dist_grundstueck_m, gebaeude_point), Anzahl Warnungen."""
    if G.number_of_edges() == 0:
        raise RuntimeError("Netz ohne Kanten: keine Strassen im Umkreis der Adressen. Liegen Adressen und Netz im selben Gebiet? "
                           "Bei OSM: osm_cache.json im Ausgabeordner loeschen und neu abrufen, oder andere Netzquelle waehlen.")
    from shapely.ops import nearest_points
    edges = list(G.edges())
    geoms = [G[u][v]["geometry"] for u, v in edges]
    tree = STRtree(geoms)
    anschluss_ok = [G[u][v].get("seite") not in ("Q", "E", "A", "T", "D") and not G[u][v].get("virtuell") and G[u][v]["length"] >= 0.05 for u, v in edges]
    namen_norm = [_strasse_norm(G[u][v].get("name")) for u, v in edges]
    flur_geoms = flur_tree = None
    if flurstuecke is not None and len(flurstuecke):
        flur_geoms = [g for g in flurstuecke.geometry]
        flur_tree = STRtree(flur_geoms)
    geb_geoms = geb_tree = None
    if gebaeude is not None and len(gebaeude):
        geb_geoms = [g for g in gebaeude.geometry]
        geb_tree = STRtree(geb_geoms)
    per_edge = {}
    result = {}
    max_snap = cfg["osm"]["max_snap_m"]
    warn = 0
    seiten_aktiv = cfg["osm"].get("seiten", {}).get("aktiv", False)
    hausquerungen = []
    bestand_taps = []
    querungen_fremdnetz = []
    sr = cfg.get("seitenregel") or {}
    querung_kandidaten = bool(sr.get("querung_kandidaten", True))
    querung_max_m = float(sr.get("querung_max_m", 25.0))
    querung_bauverfahren = sr.get("bauverfahren", "Bodenrakete")
    hat_bestand = any(G[u][v].get("bestand") for u, v in edges[: min(len(edges), 200000)])
    bestand_reichweite = float((cfg.get("bestand") or {}).get("anzapf_reichweite_m", 8.0))
    hat_strasse = "strasse" in adressen.columns
    for row in adressen.itertuples(index=False):
        p = row.geometry
        ziel = p
        if flur_tree is not None:
            hits = flur_tree.query(p, predicate="within")
            if len(hits):
                ziel = flur_geoms[hits[0]]
                if ziel.area > 20000:   # Riesenflurstueck (Hof, Acker): Grenze kann weit vom Haus liegen -> Punkt nehmen
                    ziel = p
        # kuerzester Stich vom Ziel (Flurstueck oder Punkt) auf eine zulaessige Kante; Kandidaten, deren Stich ein fremdes
        # Flurstueck quert (weder das der Adresse noch das der Trasse), kommen erst dran, wenn es sonst keinen gibt
        such = ziel.buffer(max_snap) if ziel is p else ziel.buffer(max_snap / 2)
        best, bd = None, float("inf")
        best_fremd, bd_fremd = None, float("inf")
        for j in tree.query(such):
            if not anschluss_ok[j]:
                continue
            dd = geoms[j].distance(ziel)
            if dd >= max(bd, bd_fremd) and best is not None:
                continue
            fremd = False
            if flur_tree is not None and dd > 0.3:
                a_, b_ = nearest_points(geoms[j], ziel)
                stich = LineString([a_, b_])
                eigene = set(flur_tree.query(a_, predicate="within")) | (set(flur_tree.query(b_, predicate="within")) if ziel is p else set())
                for k in flur_tree.query(stich):
                    if k in eigene or (ziel is not p and flur_geoms[k] is ziel):
                        continue
                    if flur_geoms[k].intersection(stich).length > 0.5 and flur_geoms[k].area <= 20000:
                        fremd = True
                        break
            if fremd:
                if dd < bd_fremd:
                    best_fremd, bd_fremd = j, dd
            elif dd < bd:
                best, bd = j, dd
        if best is None and best_fremd is not None:
            best, bd = best_fremd, bd_fremd
            G.graph["hauszuf_fremd"] = G.graph.get("hauszuf_fremd", 0) + 1
        idx = best if best is not None else tree.nearest(p)
        if hat_strasse and best is not None:
            sn = _strasse_norm(getattr(row, "strasse", None))
            if sn:
                sb, sd = None, min(60.0, max(bd, 0.5) * 1.5)
                for j in tree.query(ziel.buffer(sd)):
                    if anschluss_ok[j] and namen_norm[j] and (namen_norm[j] == sn or sn in namen_norm[j] or namen_norm[j] in sn):
                        dd = geoms[j].distance(ziel)
                        if dd < sd:
                            sb, sd = j, dd
                if sb is not None:
                    idx = sb
        u, v = edges[idx]
        line = geoms[idx]
        if ziel is not p:
            # Eigener HP+ je Haus (Zielbild Gold Mannheim: je Adresse ein eigener Stich senkrecht vor dem Haus, nie ein
            # gemeinsamer Punkt fuer alle Adressen eines Flurstuecks): unter den Kanten derselben Strassenseite, die das
            # Flurstueck (fast) genauso nah beruehren, die mit dem kuerzesten Lot vom Adresspunkt nehmen ...
            d_idx = line.distance(ziel)
            d0 = G[u][v]
            front = [j for j in tree.query(ziel.buffer(d_idx + 1.0))
                     if anschluss_ok[j] and geoms[j].distance(ziel) <= d_idx + 1.0
                     and G[edges[j][0]][edges[j][1]].get("quelle_id") == d0.get("quelle_id")
                     and G[edges[j][0]][edges[j][1]].get("seite") == d0.get("seite")]
            if front:
                idx = min(front, key=lambda j: geoms[j].distance(p))
                u, v = edges[idx]
                line = geoms[idx]
            sp = nearest_points(line, p)[0]           # Lotpunkt des Hauses auf der Trasse
            # ... und der HP+ ist der erste Schnitt der Strecke Trasse -> Haus mit der Flurstuecksgrenze
            hp = None
            if sp.distance(p) > 0.01:
                x = LineString([sp, p]).intersection(ziel.boundary)
                pts = [x] if x.geom_type == "Point" else [g for g in getattr(x, "geoms", []) if g.geom_type == "Point"]
                if pts:
                    hp = min(pts, key=lambda q: q.distance(sp))
            if hp is None:                            # Lot trifft die Grenze nicht (Trasse liegt im Flurstueck o. ae.)
                sp, hp = nearest_points(line, ziel)
            elif flur_tree is not None:
                # Regel 2: der endgueltige Stich (Lot vom Haus) darf kein fremdes Grundstueck queren (Hinterlieger, schraege
                # Lage); sonst den kuerzesten Stich zur eigenen Flurstuecksgrenze nehmen
                stich = LineString([sp, hp])
                eigene = set(flur_tree.query(sp, predicate="within"))
                for k in flur_tree.query(stich):
                    if k in eigene or flur_geoms[k] is ziel or flur_geoms[k].area > 20000:
                        continue
                    if flur_geoms[k].intersection(stich).length > 0.5:
                        # eigenen Grenzpunkt suchen: Punkte entlang der eigenen Flurstuecksgrenze, Stich von der Trasse dorthin
                        # ohne fremdes Grundstueck, kuerzester Gesamtweg Trasse -> Grenze -> Haus (jedes Haus eigener Punkt)
                        rand = ziel.boundary
                        n_s = max(4, min(80, int(rand.length / 2.0)))
                        best_q, best_w = None, float("inf")
                        for i_s in range(n_s):
                            q = rand.interpolate(i_s / float(n_s), normalized=True)
                            sq = nearest_points(line, q)[0]
                            w = sq.distance(q) * 1.5 + q.distance(p)
                            if w >= best_w:
                                continue
                            st2 = LineString([sq, q])
                            eig2 = set(flur_tree.query(sq, predicate="within"))
                            frei = True
                            for k2 in flur_tree.query(st2):
                                if k2 in eig2 or flur_geoms[k2] is ziel or flur_geoms[k2].area > 20000:
                                    continue
                                if flur_geoms[k2].intersection(st2).length > 0.5:
                                    frei = False
                                    break
                            if frei:
                                best_q, best_w = (sq, q), w
                        if best_q is not None:
                            sp, hp = best_q
                        else:
                            sp, hp = nearest_points(line, ziel)
                        G.graph["hauszuf_umgelegt"] = G.graph.get("hauszuf_umgelegt", 0) + 1
                        break
        else:
            sp, hp = nearest_points(line, ziel)          # sp auf der Trasse, hp = Adresspunkt
        if ziel is not p and hp.distance(p) < 0.01:
            hp = p
        frac = line.project(sp, normalized=True)
        dist_hp = sp.distance(hp)
        # Gebaeude: naechster Punkt am Gebaeude, das die Adresse enthaelt (sonst Adresspunkt)
        gp = p
        if geb_tree is not None:
            h = geb_tree.query(p, predicate="within")
            if len(h):
                gp = nearest_points(geb_geoms[h[0]].boundary, hp)[0]
        dist_geb = hp.distance(gp)
        if dist_hp > 30.0:
            G.graph["hauszuf_lang"] = G.graph.get("hauszuf_lang", 0) + 1
        if dist_hp + dist_geb > max_snap:
            warn += 1
        node = "A_" + str(row.id)
        per_edge.setdefault((u, v), []).append((frac, node, sp.x, sp.y))
        result[str(row.id)] = (node, dist_hp + dist_geb, sp, hp, dist_hp, gp)
        d0 = G[u][v]
        # Bestandsrohr in Reichweite: Anzapfen per Kopfloch direkt vor dem Haus als Alternative zur Neubautrasse
        if hat_bestand and not d0.get("bestand"):
            bbest, bbd = None, bestand_reichweite
            for j in tree.query(sp.buffer(bestand_reichweite)):
                a, b = edges[j]
                if G[a][b].get("bestand") and G[a][b]["length"] >= 0.05:
                    dd = geoms[j].distance(sp)
                    if dd < bbd:
                        bbest, bbd = j, dd
            if bbest is not None:
                a, b = edges[bbest]
                bl = geoms[bbest]
                bf = bl.project(sp, normalized=True)
                bp = bl.interpolate(bf, normalized=True)
                bnode = node + "_b"
                per_edge.setdefault((a, b), []).append((bf, bnode, bp.x, bp.y))
                bestand_taps.append((node, bnode))
        gbest = None
        if seiten_aktiv and d0.get("seite") in ("L", "R"):
            gegen = "R" if d0["seite"] == "L" else "L"
            gbest, gbd = None, 30.0
            for j in tree.query(sp.buffer(30.0)):
                a, b = edges[j]
                dj = G[a][b]
                if dj.get("seite") == gegen and dj.get("quelle_id") == d0.get("quelle_id") and dj["length"] >= 0.05:
                    dd = geoms[j].distance(sp)
                    if dd < gbd:
                        gbest, gbd = j, dd
        elif querung_kandidaten and d0.get("seite") not in ("L", "R", "Q", "B", "D", "T", "A"):
            # Gegenseite auf einem fremden Netz (STP/Comsof/GDS): andere Laengstrasse 5..25 m entfernt, etwa parallel,
            # Verbindung quert kein Gebaeude und nicht das eigene Flurstueck (also die Strasse)
            gbest, gbd = None, querung_max_m
            ax, ay = _richtung(line)
            for j in tree.query(sp.buffer(querung_max_m)):
                if not anschluss_ok[j] or j == idx:
                    continue
                a, b = edges[j]
                dj = G[a][b]
                if dj.get("quelle_id") == d0.get("quelle_id") or dj.get("hauszuf") or dj["length"] < 0.05:
                    continue
                dd = geoms[j].distance(sp)
                if dd < 5.0 or dd >= gbd:
                    continue
                bx, by = _richtung(geoms[j])
                if abs(ax * bx + ay * by) < 0.82:      # Winkel > ~35 Grad: keine Gegenseite derselben Strasse
                    continue
                q = nearest_points(geoms[j], sp)[0]
                verb = LineString([sp, q])
                if ziel is not p and verb.intersection(ziel).length > 0.5:
                    continue                            # laeuft ueber das eigene Grundstueck, nicht ueber die Strasse
                if geb_tree is not None and any(geb_geoms[k].intersects(verb) for k in geb_tree.query(verb)):
                    continue
                gbest, gbd = j, dd
        if gbest is not None:
            im_seitenraum = seiten_aktiv and d0.get("seite") in ("L", "R")
            # Seitenraum (Werkzeug 4, 16.09.2026): Gegenseite derselben Strasse ist immer ein Kandidat - der Zweig fehlte in dieser
            # Kopie, dadurch entstanden keine Hausquerungen und jede Strasse mit Haeusern auf beiden Seiten wurde beidseitig gebaut
            if im_seitenraum or gbd >= 5.0:
                if not im_seitenraum:
                    querungen_fremdnetz.append(node)
                a, b = edges[gbest]
                gl = geoms[gbest]
                gf = gl.project(sp, normalized=True)
                gpq = gl.interpolate(gf, normalized=True)
                gnode = node + "_q"
                per_edge.setdefault((a, b), []).append((gf, gnode, gpq.x, gpq.y))
                hausquerungen.append((node, gnode))
    knoten_alias = {}
    for (u, v), splits in per_edge.items():
        splits.sort()
        merged, seen = [], {}
        for f, n, x, y in splits:
            key = round(f, 6)
            if key in seen:
                knoten_alias[n] = seen[key]
                if not (n.endswith("_q") or n.endswith("_b")):
                    r = result[n[2:]]
                    result[n[2:]] = (seen[key],) + tuple(r[1:])
            else:
                seen[key] = n
                merged.append((f, n, x, y))
        _split_edge(G, u, v, merged)
    if bestand_taps:
        eur_t = costs.eur_m(cfg["kosten"]["bauverfahren_default"], 1, cfg)
        kopfloch = float((cfg.get("bestand") or {}).get("anschluss_kopfloch_eur", 508.75))
        for n1, n2 in bestand_taps:
            n1, n2 = knoten_alias.get(n1, n1), knoten_alias.get(n2, n2)
            if n1 == n2 or not (G.has_node(n1) and G.has_node(n2)) or G.has_edge(n1, n2):
                continue
            L = max(0.5, math.hypot(G.nodes[n1]["x"] - G.nodes[n2]["x"], G.nodes[n1]["y"] - G.nodes[n2]["y"]))
            G.add_edge(n1, n2, length=L, klasse="geb_Oberbau", okl=1, bauverfahren=cfg["kosten"]["bauverfahren_default"], eur_m=eur_t, highway=None,
                       name="Anzapfung Bestand (Kopfloch)", quelle_id="bestand_anzapfung", hauptstr=False, is_b=False, querung="Kopfloch Bestand",
                       querung_eur=kopfloch, virtuell=False, seite="A", bestand=False, cost=L * eur_t + kopfloch,
                       geometry=LineString([(G.nodes[n1]["x"], G.nodes[n1]["y"]), (G.nodes[n2]["x"], G.nodes[n2]["y"])]))
    if hausquerungen:
        eur_q = costs.eur_m("Fahrbahn", 1, cfg)
        try:
            eur_p = costs.eur_m(querung_bauverfahren, 1, cfg)
        except Exception:
            eur_p = eur_q
        kopfloch = cfg["osm"].get("seiten", {}).get("kopfloch_eur", 508.75)
        for n1, n2 in hausquerungen:
            n1, n2 = knoten_alias.get(n1, n1), knoten_alias.get(n2, n2)
            if n1 == n2 or not (G.has_node(n1) and G.has_node(n2)) or G.has_edge(n1, n2):
                continue
            L = math.hypot(G.nodes[n1]["x"] - G.nodes[n2]["x"], G.nodes[n1]["y"] - G.nodes[n2]["y"])
            if L <= 0.01:
                continue
            if querung_kandidaten:
                # Markus 08.09.: Hausquerungen mit Pressung (Bodenrakete) als Bauverfahren + Kopfloch
                G.add_edge(n1, n2, length=L, klasse="Asphalt", okl=1, bauverfahren=querung_bauverfahren, eur_m=eur_p, highway=None,
                           name="Hausquerung (Pressung)", quelle_id="hausquerung", hauptstr=False, is_b=False, querung=querung_bauverfahren,
                           querung_eur=kopfloch, virtuell=False, seite="Q", cost=L * eur_p + kopfloch,
                           geometry=LineString([(G.nodes[n1]["x"], G.nodes[n1]["y"]), (G.nodes[n2]["x"], G.nodes[n2]["y"])]))
            else:
                G.add_edge(n1, n2, length=L, klasse="Asphalt", okl=1, bauverfahren="Fahrbahn", eur_m=eur_q, highway=None, name="Hausquerung",
                           quelle_id="hausquerung", hauptstr=False, is_b=False, querung="Fahrbahn", querung_eur=kopfloch, virtuell=False, seite="Q",
                           cost=L * eur_q + kopfloch,
                           geometry=LineString([(G.nodes[n1]["x"], G.nodes[n1]["y"]), (G.nodes[n2]["x"], G.nodes[n2]["y"])]))
        G.graph["hausquerungen_fremdnetz"] = len(hausquerungen)
    return result, warn
