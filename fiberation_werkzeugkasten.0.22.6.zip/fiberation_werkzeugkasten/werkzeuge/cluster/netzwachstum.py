# -*- coding: utf-8 -*-
"""Werkzeug 2 - netzorientierter Gebietsschnitt (Markus 14.09.2026: "netzorientiert", Vorlage Gold Mannheim/Saarbruecken).

Bausteine sind **Strassenabschnitte**: Ketten von Strassenkanten zwischen Kreuzungen (Knoten mit Strassengrad != 2), lange Ketten
in Stuecke von hoechstens `abschnitt_max_adr` Adressen bzw. `abschnitt_max_m` Metern geteilt. Ein Abschnitt wechselt als Ganzes
das Gebiet; eine Strasse wird nur geteilt, wenn es sonst nicht aufgeht (Kapazitaet) - dann adressweise am Rand.

Gebiete **wachsen entlang des Netzes**: von jedem Sitz aus werden benachbarte Abschnitte in Reihenfolge ihres Netzwegs zum Sitz
angelagert (Mehrquellen-Dijkstra ueber die Abschnitts-Nachbarschaft), solange Adressen/WE/SNR/PON/Kassetten passen und jeder
Adressknoten innerhalb `max_dist_m` Vzk-Weg liegt. Das haelt jedes Gebiet zusammenhaengend auf dem Netz - keine Inseln.

**Sperrkanten**: Hauptstrassen (OSM primary/secondary, Bundesstrassen), Bahn und Gewaesser wirken als Grenze: das Wachsen darueber
kostet einen Aufschlag in Metern (cfg["wachstum"]["strafe_*_m"]), Gebiete bleiben also bevorzugt auf einer Seite. Planer-
**Zwangsgrenzen** (Linien/Flaechen aus einem QGIS-Layer) sind hart: Kanten, die sie schneiden, werden nicht ueberschritten.

Sitze: k-means++-Start auf Koordinaten, dann Medoid (Knoten mit kleinster Wegsumme zu den Adressen) je Gebiet, Wiederholung bis
stabil; behalten wird die Iteration mit der kleinsten Summe der Vzk-Baumlaengen. Adressen, die kein Gebiet aufnehmen kann
(voll oder ausser Reichweite), eroeffnen ein neues Gebiet an der am weitesten entfernten offenen Adresse. Kleine Gebiete
(< min_apl) werden aufgeloest, wenn ihre Abschnitte ohne Rest in Nachbargebieten unterkommen.

Rueckgabe wie cluster.run_k: labels je Adresse (int), seeds (Graphknoten je Gebiet) - Kennzahlen/Polygone/Schreiben in kern.
"""
import heapq
import math

import networkx as nx
import numpy as np

INF = float("inf")
SEITEN_KEINE_STRASSE = ("Q", "A", "D", "T")   # Hausquerung, Anzapfung, Hauszufuehrung, Anschlussstueck: keine Bausteine

STANDARD = {
    "aktiv": True,
    "abschnitt_max_adr": 8,          # Adressen je Baustein, laengere Ketten werden geteilt
    "abschnitt_max_m": 250.0,        # Meter je Baustein (nur Ketten mit Adressen)
    "strafe_hauptstrasse_m": 300.0,  # Wachsen ueber eine Hauptstrasse (primary/secondary) hinweg
    "strafe_bundesstrasse_m": 600.0,
    "strafe_bahn_m": 800.0,
    "strafe_gewaesser_m": 500.0,
    "iterationen": 8,
    "polygon_punkte_m": 15.0,        # Stuetzpunkte entlang der Abschnitte fuer die Gebietspolygone
    "nvt_kosten_eur": 15000.0,       # ANNAHME fuer das Verdichten: Gehaeuse + Montage + Standortsicherung + Hk-Anteil je NVT;
                                     # ein Gebiet wird aufgeloest, wenn der Vzk-Baum dadurch um weniger als diesen Betrag waechst
}


def einstellungen(cfg):
    w = dict(STANDARD)
    w.update(cfg.get("wachstum") or {})
    return w


# --- Bausteine -------------------------------------------------------------------------------------------------------------------------
def _strassenkante(d):
    return d.get("seite") not in SEITEN_KEINE_STRASSE and not d.get("virtuell") and not d.get("hauszuf")


def abschnitte(G, addr_nodes, cfg, sperr_kanten=None, log=print):
    """-> (segs, adj, node_seg, adr_seg)
    segs: Liste dict(id, knoten, kanten, laenge, adr [Adressindizes], adr_knoten, name, hauptstr, querung set, sperre)
    adj:  je Abschnitt Liste (nachbar_id, gemeinsamer Knoten)
    node_seg: Knoten -> Abschnitt (Innenknoten eindeutig, Endknoten: erster Abschnitt)
    adr_seg: Adressindex -> Abschnitt"""
    w = einstellungen(cfg)
    sperr = set(frozenset(e) for e in (sperr_kanten or []))
    node_adr = {}
    for i, nd in enumerate(addr_nodes):
        node_adr.setdefault(nd, []).append(i)
    grad = {}
    for u, v, d in G.edges(data=True):
        if _strassenkante(d):
            grad[u] = grad.get(u, 0) + 1
            grad[v] = grad.get(v, 0) + 1
    for n in G.nodes:
        grad.setdefault(n, 0)

    def nachbarn(n):
        return [m for m in G.neighbors(n) if _strassenkante(G[n][m])]

    besucht = set()
    ketten = []

    def laufen(start, nxt):
        knoten, kanten = [start], []
        prev, cur = start, nxt
        while True:
            e = frozenset((prev, cur))
            besucht.add(e)
            kanten.append((prev, cur))
            knoten.append(cur)
            if grad[cur] != 2 or e in sperr or cur == start:
                break
            weiter = [m for m in nachbarn(cur) if frozenset((cur, m)) != e]
            if len(weiter) != 1 or frozenset((cur, weiter[0])) in sperr or frozenset((cur, weiter[0])) in besucht:
                break
            prev, cur = cur, weiter[0]
        return knoten, kanten

    # Startknoten: Kreuzungen/Enden und Knoten an Sperrkanten
    starts = [n for n in G.nodes if grad[n] != 2 and grad[n] > 0]
    for e in sperr:
        starts.extend(list(e))
    for n in starts:
        for m in nachbarn(n):
            if frozenset((n, m)) not in besucht:
                ketten.append(laufen(n, m))
    for u, v, d in G.edges(data=True):      # reine Ringe ohne Kreuzung
        if _strassenkante(d) and frozenset((u, v)) not in besucht:
            ketten.append(laufen(u, v))

    # lange Ketten teilen; Adressen an Innenknoten zaehlen zur Kette, Endknoten spaeter (Kreuzungen)
    segs = []
    max_adr, max_m = int(w["abschnitt_max_adr"]), float(w["abschnitt_max_m"])
    zugeordnet = set()

    def neu(knoten, kanten):
        s = {"id": len(segs), "knoten": knoten, "kanten": kanten, "laenge": sum(G[a][b]["length"] for a, b in kanten),
             "adr": [], "adr_knoten": [], "name": None, "hauptstr": False, "querung": set(), "sperre": False}
        namen, hs = {}, 0
        for a, b in kanten:
            d = G[a][b]
            if d.get("name"):
                namen[d["name"]] = namen.get(d["name"], 0) + d["length"]
            if d.get("hauptstr") or d.get("is_b"):
                hs += d["length"]
            if d.get("querung") in ("bahn", "gewaesser", "bundesstrasse"):
                s["querung"].add(d["querung"])
            if frozenset((a, b)) in sperr:
                s["sperre"] = True
        s["name"] = max(namen, key=namen.get) if namen else None
        s["hauptstr"] = hs > 0.5 * max(s["laenge"], 0.01)
        for n in knoten[1:-1]:
            for i in node_adr.get(n, ()):
                if i not in zugeordnet:
                    s["adr"].append(i)
                    zugeordnet.add(i)
        segs.append(s)
        return s

    for knoten, kanten in ketten:
        innen = knoten[1:-1]
        n_adr = sum(len(node_adr.get(n, ())) for n in innen)
        if n_adr <= max_adr and (sum(G[a][b]["length"] for a, b in kanten) <= max_m or n_adr == 0):
            neu(knoten, kanten)
            continue
        # teilen: entlang der Kette, Schnitt an einem Knoten, sobald Grenze erreicht und weitere Adressen folgen
        teil_k, teil_e, cnt, laenge = [knoten[0]], [], 0, 0.0
        rest_adr = n_adr
        for (a, b) in kanten:
            teil_e.append((a, b))
            teil_k.append(b)
            laenge += G[a][b]["length"]
            here = len(node_adr.get(b, ())) if b != knoten[-1] else 0
            cnt += here
            rest_adr -= here
            if b != knoten[-1] and rest_adr > 0 and (cnt >= max_adr or (laenge >= max_m and cnt > 0)):
                neu(teil_k, teil_e)
                teil_k, teil_e, cnt, laenge = [b], [], 0, 0.0   # b gehoert zum vorigen Teil (Adresse dort gezaehlt)
        if teil_e:
            neu(teil_k, teil_e)

    # Adressen an Kreuzungen/Enden: an den anliegenden Abschnitt mit gleicher Strasse, sonst den mit den wenigsten Adressen
    ende_segs = {}
    for s in segs:
        for n in (s["knoten"][0], s["knoten"][-1]):
            ende_segs.setdefault(n, []).append(s["id"])
    for n, idx in node_adr.items():
        offen = [i for i in idx if i not in zugeordnet]
        if not offen:
            continue
        kand = ende_segs.get(n) or []
        if not kand:
            # Adressknoten ohne Strassenkante (nur Querung o. ae.): naechster Abschnitt ueber Nachbarknoten
            for m in G.neighbors(n):
                if m in ende_segs:
                    kand = ende_segs[m]
                    break
        if not kand:
            continue
        sid = min(kand, key=lambda k: (0 if segs[k]["sperre"] is False else 1, len(segs[k]["adr"])))
        for i in offen:
            segs[sid]["adr"].append(i)
            zugeordnet.add(i)
    for s in segs:
        s["adr_knoten"] = list(dict.fromkeys(addr_nodes[i] for i in s["adr"]))

    # Nachbarschaft ueber gemeinsame Endknoten
    adj = {s["id"]: [] for s in segs}
    for n, ids in ende_segs.items():
        for a in ids:
            for b in ids:
                if a != b:
                    adj[a].append((b, n))
    node_seg = {}
    for s in segs:
        for n in s["knoten"][1:-1]:
            node_seg[n] = s["id"]
    for s in segs:
        for n in (s["knoten"][0], s["knoten"][-1]):
            node_seg.setdefault(n, s["id"])
    adr_seg = {}
    for s in segs:
        for i in s["adr"]:
            adr_seg[i] = s["id"]
    fehlend = [i for i in range(len(addr_nodes)) if i not in adr_seg]
    if fehlend:
        log("Abschnitte: {} Adressen ohne Strassenabschnitt (kein Strassenknoten) - werden adressweise zugewiesen".format(len(fehlend)))
    log("Abschnitte: {} Strassenabschnitte aus {} Ketten, {} mit Adressen, {} Sperrkanten, {} Hauptstrassen-Abschnitte".format(
        len(segs), len(ketten), sum(1 for s in segs if s["adr"]), len(sperr), sum(1 for s in segs if s["hauptstr"])))
    return segs, adj, node_seg, adr_seg


# --- Wachsen ---------------------------------------------------------------------------------------------------------------------------
def _strafe(G, s_von, s_nach, via, w):
    p = 0.0
    if s_nach["sperre"]:
        return INF
    kn = G.nodes[via]
    if (kn.get("b_road") or kn.get("hauptstr")) and not s_von["hauptstr"] and not s_nach["hauptstr"]:
        p += w["strafe_bundesstrasse_m"] if kn.get("b_road") else w["strafe_hauptstrasse_m"]
    elif s_von["hauptstr"] != s_nach["hauptstr"]:
        p += 0.5 * w["strafe_hauptstrasse_m"]
    if "bahn" in s_nach["querung"]:
        p += w["strafe_bahn_m"]
    if "gewaesser" in s_nach["querung"]:
        p += w["strafe_gewaesser_m"]
    if "bundesstrasse" in s_nach["querung"] and not s_nach["hauptstr"]:
        p += 0.5 * w["strafe_bundesstrasse_m"]
    return p


def _lasten_seg(segs, L):
    return {s["id"]: {name: float(np.sum(arr[s["adr"]])) if s["adr"] else 0.0 for name, arr in L.items()} for s in segs}


def _passt(state, j, last, caps):
    for name, cap in caps.items():
        if state[name][j] + last[name] > cap + 1e-9:
            return False
    return True


def zuweisen(G, segs, adj, node_seg, adr_seg, addr_nodes, seeds, L, caps, cfg, log=print):
    """Ein Wachstumsdurchgang fuer feste Sitze. -> (adr_label np.array, seg_label np.array, offen Liste Adressindizes, dist Liste dict)"""
    w = einstellungen(cfg)
    maxd = float(cfg["nvt"]["max_dist_m"])
    k = len(seeds)
    n_adr = len(addr_nodes)
    dist = [nx.single_source_dijkstra_path_length(G, s, weight="length", cutoff=maxd) for s in seeds]
    seg_last = _lasten_seg(segs, L)
    state = {name: np.zeros(k) for name in caps}
    seg_label = np.full(len(segs), -1)
    adr_label = np.full(n_adr, -1)
    heap = []
    for j, s in enumerate(seeds):
        sid = node_seg.get(s)
        if sid is None:
            continue
        heapq.heappush(heap, (0.0, j, sid, 0.0))
    while heap:
        key, j, sid, acc = heapq.heappop(heap)
        if seg_label[sid] >= 0:
            continue
        seg = segs[sid]
        if seg["sperre"]:
            continue
        if seg["adr_knoten"]:
            far = max(dist[j].get(a, INF) for a in seg["adr_knoten"])
            if far > maxd:
                continue
        if not _passt(state, j, seg_last[sid], caps):
            continue
        seg_label[sid] = j
        for name in caps:
            state[name][j] += seg_last[sid][name]
        for i in seg["adr"]:
            adr_label[i] = j
        for nid, via in adj[sid]:
            if seg_label[nid] >= 0:
                continue
            nb = segs[nid]
            basis = min((dist[j].get(n, INF) for n in nb["knoten"]), default=INF)
            if basis == INF:
                continue
            p = acc + _strafe(G, seg, nb, via, w)
            if p == INF:
                continue
            heapq.heappush(heap, (basis + p, j, nid, p))

    # Rest adressweise: Adressen offener Abschnitte an ein Nachbargebiet mit Platz (Strasse wird geteilt, nur wenn es sein muss)
    offen = [i for i in range(n_adr) if adr_label[i] < 0]
    if offen:
        # Nachbargebiete je Abschnitt
        nachbar_geb = {}
        for sid, lab in enumerate(seg_label):
            if lab >= 0:
                continue
            g = set()
            for nid, via in adj[sid]:
                if seg_label[nid] >= 0 and _strafe(G, segs[sid], segs[nid], via, w) < INF:
                    g.add(int(seg_label[nid]))
            nachbar_geb[sid] = g
        reihenfolge = sorted(offen, key=lambda i: min((dist[j].get(addr_nodes[i], INF) for j in range(k)), default=INF))
        for i in reihenfolge:
            nd = addr_nodes[i]
            sid = adr_seg.get(i)
            kand = sorted(nachbar_geb.get(sid, set()) if sid is not None else range(k), key=lambda j: dist[j].get(nd, INF))
            if not kand:
                kand = sorted(range(k), key=lambda j: dist[j].get(nd, INF))
            last = {name: float(arr[i]) for name, arr in L.items()}
            for j in kand:
                if dist[j].get(nd, INF) > maxd:
                    continue
                if _passt(state, j, last, caps):
                    adr_label[i] = j
                    for name in caps:
                        state[name][j] += last[name]
                    break
        offen = [i for i in range(n_adr) if adr_label[i] < 0]
    return adr_label, seg_label, offen, dist


# --- Sitze -----------------------------------------------------------------------------------------------------------------------------
def _kmeanspp(xy, k, rng):
    n = len(xy)
    idx = [int(rng.integers(n))]
    d2 = np.sum((xy - xy[idx[0]]) ** 2, axis=1)
    for _ in range(1, k):
        p = d2 / d2.sum() if d2.sum() > 0 else np.full(n, 1.0 / n)
        nxt = int(rng.choice(n, p=p))
        idx.append(nxt)
        d2 = np.minimum(d2, np.sum((xy - xy[nxt]) ** 2, axis=1))
    return idx


def _medoid(G, members, maxd, kandidaten=15):
    """Adressknoten mit kleinster Summe der Netzwege (Meter) zu allen Mitgliedern; gerechnet fuer die dem Schwerpunkt naechsten."""
    members = list(dict.fromkeys(members))
    if len(members) == 1:
        return members[0]
    xy = np.array([[G.nodes[m]["x"], G.nodes[m]["y"]] for m in members])
    c = xy.mean(axis=0)
    order = np.argsort(np.sum((xy - c) ** 2, axis=1))
    cands = [members[i] for i in order[:kandidaten]]
    best, bs = cands[0], INF
    for m in cands:
        d = nx.single_source_dijkstra_path_length(G, m, weight="length", cutoff=maxd * 2.0)
        s = sum(d.get(o, maxd * 3.0) for o in members)
        if s < bs:
            best, bs = m, s
    return best


def baumlaenge(G, seed, members, cutoff=None):
    """Laenge der Kantenunion der kuerzesten Wege Sitz -> Mitglieder (Vzk-Baum, Meter). cutoff beschraenkt die Suche (Meter)."""
    try:
        _, paths = nx.single_source_dijkstra(G, seed, weight="length", cutoff=cutoff)
    except Exception:
        return 0.0
    kanten = {}
    for m in dict.fromkeys(members):
        p = paths.get(m)
        if not p:
            continue
        for a, b in zip(p[:-1], p[1:]):
            kanten[frozenset((a, b))] = G[a][b]["length"]
    return sum(kanten.values())


def _bewerten(G, addr_nodes, adr_label, seeds, maxd=None):
    total = 0.0
    for j in sorted(set(int(x) for x in adr_label if x >= 0)):
        members = [addr_nodes[i] for i in np.where(adr_label == j)[0]]
        total += baumlaenge(G, seeds[j], members, cutoff=maxd * 1.5 if maxd else None)
    return total


def _eur_m(G):
    """Mittlere Tiefbaukosten je Meter im Netz (laengengewichtet) - fuer die Abwaegung NVT sparen gegen Vzk-Meter."""
    L = sum(d["length"] for _, _, d in G.edges(data=True))
    K = sum(d["length"] * d.get("eur_m", 100.0) for _, _, d in G.edges(data=True))
    return K / L if L else 100.0


# --- Gesamtablauf ----------------------------------------------------------------------------------------------------------------------
def schneiden(G, addr_nodes, we, cfg, sperr_kanten=None, log=print, fortschritt=None):
    """-> dict(labels, seeds, segs, seg_label, baum_m, iterationen, neue_gebiete, aufgeloest, gemischt)"""
    from .cluster import lasten
    f = fortschritt or (lambda p, t: None)
    w = einstellungen(cfg)
    ncfg = cfg["nvt"]
    maxd = float(ncfg["max_dist_m"])
    n = len(addr_nodes)
    L, caps = lasten(we, cfg)
    segs, adj, node_seg, adr_seg = abschnitte(G, addr_nodes, cfg, sperr_kanten, log)
    xy = np.array([[G.nodes[a]["x"], G.nodes[a]["y"]] for a in addr_nodes])
    k0 = max(1, int(math.ceil(n / float(ncfg["ziel_apl"]))))
    rng = np.random.default_rng(42)
    seeds = [addr_nodes[i] for i in _kmeanspp(xy, k0, rng)]
    best = None
    neue_gebiete = 0
    gesehen = set()
    for it in range(int(w["iterationen"])):
        f(40 + int(30 * it / max(1, w["iterationen"])), "Gebiete wachsen (Durchgang {})".format(it + 1))
        adr_label, seg_label, offen, dist = zuweisen(G, segs, adj, node_seg, adr_seg, addr_nodes, seeds, L, caps, cfg, log)
        # offene Adressen: neue Gebiete, beginnend an der am weitesten von allen Sitzen entfernten offenen Adresse; je Durchgang
        # so viele neue Sitze, dass jede offene Adresse einen Sitz in maxd/2 Netzweg hat, dann neu wachsen
        while offen and len(seeds) <= n:
            def entfernung(i):
                nd = addr_nodes[i]
                return min((dist[j].get(nd, INF) for j in range(len(seeds))), default=INF)
            rest = sorted(offen, key=entfernung, reverse=True)
            while rest:
                start = rest[0]
                seeds.append(addr_nodes[start])
                neue_gebiete += 1
                nah = nx.single_source_dijkstra_path_length(G, addr_nodes[start], weight="length", cutoff=maxd / 2.0)
                rest = [i for i in rest if addr_nodes[i] not in nah]
            adr_label, seg_label, offen, dist = zuweisen(G, segs, adj, node_seg, adr_seg, addr_nodes, seeds, L, caps, cfg, log)
        wert = _bewerten(G, addr_nodes, adr_label, seeds, maxd)
        log("  Durchgang {}: {} Gebiete, Vzk-Baum gesamt {:,.0f} m".format(it + 1, len(set(int(x) for x in adr_label if x >= 0)), wert))
        if best is None or wert < best["baum_m"] - 1.0:
            best = {"labels": adr_label.copy(), "seeds": list(seeds), "seg_label": seg_label.copy(), "baum_m": wert, "iterationen": it + 1}
        # Sitze nachziehen
        neu = []
        for j in range(len(seeds)):
            members = [addr_nodes[i] for i in np.where(adr_label == j)[0]]
            neu.append(_medoid(G, members, maxd) if members else seeds[j])
        schluessel = tuple(neu)
        if neu == seeds or schluessel in gesehen:
            break
        gesehen.add(schluessel)
        seeds = neu

    # Verdichten: Gebiete einzeln weglassen (kleinste zuerst) und neu wachsen lassen. Angenommen, wenn alle Adressen unterkommen und
    # (a) das Gebiet kleiner als min_apl war oder (b) der Vzk-Baum um weniger waechst, als ein NVT kostet (nvt_kosten_eur / EUR je m).
    labels, seeds, seg_label = best["labels"], best["seeds"], best["seg_label"]
    aufgeloest = 0
    min_apl = int(ncfg.get("min_apl", 0) or 0)
    eur_m = _eur_m(G)
    schwelle_m = float(w["nvt_kosten_eur"]) / max(eur_m, 1.0)
    if len(seeds) > 1:
        f(72, "Gebiete verdichten")
        baum_ist = _bewerten(G, addr_nodes, labels, seeds, maxd)
        versucht = set()
        while len(seeds) > 1:
            zaehl = {j: int((labels == j).sum()) for j in range(len(seeds))}
            kandidaten = [j for _, j in sorted((c, j) for j, c in zaehl.items() if c > 0) if seeds[j] not in versucht]
            geschafft = False
            for j in kandidaten:
                versucht.add(seeds[j])
                probe = [s_ for jj, s_ in enumerate(seeds) if jj != j]
                l2, s2, offen2, _ = zuweisen(G, segs, adj, node_seg, adr_seg, addr_nodes, probe, L, caps, cfg, log)
                if offen2:
                    continue
                baum2 = _bewerten(G, addr_nodes, l2, probe, maxd)
                if zaehl[j] >= min_apl and baum2 - baum_ist > schwelle_m:
                    continue
                labels, seeds, seg_label, baum_ist = l2, probe, s2, baum2
                aufgeloest += 1
                geschafft = True
                break
            if not geschafft:
                break
        if aufgeloest:
            log("  {} Gebiete aufgeloest (kleiner {} Adressen oder Vzk-Zuwachs unter {:.0f} m = {:,.0f} EUR je NVT bei {:.0f} EUR/m)".format(
                aufgeloest, min_apl, schwelle_m, w["nvt_kosten_eur"], eur_m))
    # leere Gebiete entfernen und Nummern verdichten
    genutzt = sorted(set(int(x) for x in labels if x >= 0))
    umnum = {j: r for r, j in enumerate(genutzt)}
    labels = np.array([umnum.get(int(x), -1) for x in labels])
    seg_label = np.array([umnum.get(int(x), -1) for x in seg_label])
    seeds = [seeds[j] for j in genutzt]
    gemischt = 0
    for s in segs:
        labs = set(int(labels[i]) for i in s["adr"] if labels[i] >= 0)
        s["label"] = int(seg_label[s["id"]]) if seg_label[s["id"]] >= 0 else (labs.pop() if len(labs) == 1 else -1)
        s["gemischt"] = len(set(int(labels[i]) for i in s["adr"] if labels[i] >= 0)) > 1
        gemischt += int(s["gemischt"])
    baum = _bewerten(G, addr_nodes, labels, seeds, maxd)
    log("Netzwachstum: {} Gebiete, Vzk-Baum gesamt {:,.0f} m, {} Strassenabschnitte geteilt, {} Gebiete nachtraeglich eroeffnet".format(
        len(seeds), baum, gemischt, neue_gebiete))
    return {"labels": labels, "seeds": seeds, "segs": segs, "seg_label": seg_label, "baum_m": baum, "iterationen": best["iterationen"],
            "neue_gebiete": neue_gebiete, "aufgeloest": aufgeloest, "gemischt": gemischt}


# --- Hilfen fuer Polygone und Ausgabe ---------------------------------------------------------------------------------------------------
def stuetzpunkte(G, segs, name_von_label, abstand_m=15.0):
    """Punkte entlang der zugewiesenen Abschnitte mit Gebietsnamen - Stuetzpunkte fuer die Voronoi-Polygone, damit die Gebietsgrenzen
    zwischen den Strassen laufen und nicht quer durch Bloecke. Gemischte Abschnitte liefern keine Punkte (Adressen entscheiden)."""
    from shapely.geometry import Point
    out = []
    # nur Abschnitte mit Adressen und kurze Verbinder (< 150 m) zwischen zwei Abschnitten desselben Gebiets; lange leere
    # Zufahrten wuerden die Polygone sonst weit in die Feldmark ziehen
    label_von_knoten = {}
    for s in segs:
        if s.get("label", -1) >= 0 and s["adr"]:
            for n in (s["knoten"][0], s["knoten"][-1]):
                label_von_knoten.setdefault(n, set()).add(s["label"])
    for s in segs:
        lab = s.get("label", -1)
        if lab < 0 or s.get("gemischt") or lab not in name_von_label:
            continue
        if not s["adr"]:
            enden = [label_von_knoten.get(s["knoten"][0], set()), label_von_knoten.get(s["knoten"][-1], set())]
            if s["laenge"] > 150.0 or not (lab in enden[0] and lab in enden[1]):
                continue
        name = name_von_label[lab]
        for a, b in s["kanten"]:
            g = G[a][b].get("geometry")
            if g is None or g.length < 1.0:
                continue
            n_p = max(1, int(g.length // abstand_m))
            for q in range(n_p + 1):
                p = g.interpolate(min(1.0, (q + 0.5) / (n_p + 1)), normalized=True)
                out.append((name, Point(p.x, p.y)))
    return out


def abschnitte_frame(G, segs, name_von_label, crs):
    """GeoDataFrame der Strassenabschnitte (Layer strassenabschnitte)."""
    import geopandas as gpd
    from shapely.ops import linemerge
    from shapely.geometry import MultiLineString
    rows = []
    for s in segs:
        geoms = [G[a][b].get("geometry") for a, b in s["kanten"] if G[a][b].get("geometry") is not None]
        if not geoms:
            continue
        try:
            g = linemerge(MultiLineString(geoms)) if len(geoms) > 1 else geoms[0]
        except Exception:
            g = MultiLineString(geoms)
        lab = s.get("label", -1)
        rows.append({"id": s["id"], "name": s["name"] or "", "nvt": name_von_label.get(lab, "") if lab >= 0 else "",
                     "gemischt": int(bool(s.get("gemischt"))), "apl": len(s["adr"]), "laenge_m": round(s["laenge"], 1),
                     "hauptstr": int(s["hauptstr"]), "querung": ",".join(sorted(s["querung"])), "sperre": int(s["sperre"]),
                     "geometry": g})
    return gpd.GeoDataFrame(rows, crs=crs)


def geteilte_strassen(adr, spalte="nvt"):
    """Strassen (Name), deren Adressen in mehr als einem Gebiet liegen. -> (Anzahl, Liste (strasse, Gebiete))"""
    if "strasse" not in adr:
        return 0, []
    out = []
    for name, grp in adr.groupby(adr["strasse"].astype(str)):
        g = sorted(set(grp[spalte].astype(str)) - {""})
        if len(g) > 1 and name not in ("", "nan", "None"):
            out.append((name, g))
    return len(out), out
