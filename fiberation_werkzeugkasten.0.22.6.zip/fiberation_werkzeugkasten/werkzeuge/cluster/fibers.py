# -*- coding: utf-8 -*-
"""SNR je Adresse fuer die Kapazitaetsrechnung (Ersatz fuer hld.fibers, ohne Telekom-Bruecke)."""


def snr_je_adresse(we, cfg):
    v = cfg["vzk"]
    s = v["snr_je_apl"]
    for grenze, anzahl in sorted(((int(k), a) for k, a in v.get("snr_je_apl_ab_we", {}).items())):
        if we >= grenze:
            s = anzahl
    return s
