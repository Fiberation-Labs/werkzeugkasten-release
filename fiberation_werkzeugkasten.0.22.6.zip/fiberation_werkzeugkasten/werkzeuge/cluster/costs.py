# -*- coding: utf-8 -*-
"""Tiefbau-Preise je Bauverfahren und Oberflaechenklasse (LV-Logik: Klasse 1 / 2 / 3+4)."""


def oberflaechenklasse(surface, cfg):
    """Oberflaechenname (GDS: Asphalt, Pflaster, ... / OSM-Klasse: geb_Oberbau, ...) -> LV-Klasse 1, 2 oder 3."""
    tab = cfg["kosten"]["oberflaechenklasse"]
    if surface in tab:
        return int(tab[surface])
    return int(tab.get("_default", 1))


def eur_m(bauverfahren, okl, cfg):
    """EUR je Meter Kabelgraben fuer Bauverfahren und LV-Oberflaechenklasse."""
    tab = cfg["kosten"]["eur_m_lv"]
    row = tab.get(bauverfahren) or tab.get(cfg["kosten"]["bauverfahren_default"])
    v = row.get(str(okl))
    if v is None:
        v = row.get("1") or max(row.values())
    return float(v)


def ist_annahme(bauverfahren, cfg):
    return bauverfahren in cfg["kosten"].get("annahme_bauverfahren", [])
