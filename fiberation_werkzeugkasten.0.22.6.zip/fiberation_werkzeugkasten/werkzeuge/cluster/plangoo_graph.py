# -*- coding: utf-8 -*-
"""Trassen eines vorhandenen Plan[Goo]-Projekts (GEOMETRY_LINE der .gpkg) als Trassenkandidaten - z. B. eine Comsof-STP, die als
Plan[Goo]-Projekt geliefert wurde, ohne den FPF-Extern-Export (Barntrup 07.09.2026). Der Roboter schneidet dann auf dem Telekom-Netz
neu, kann aber keine anderen Strassen waehlen als die Strukturplanung (nur "verwendete" Trassen sind bekannt).

Felder: SUB_TYPE (Hauszufuehrung), BAUVERFAHREN (Plan[Goo]-Schluessel), SURFACE (geb_/ungeb_/ohne_Oberbau), ALLOWANCE (Zulage),
IS_EXTERNAL_OBJECT (Bestand), TYPE (underground/in_house/aerial). CRS meist EPSG:3857.
"""
import geopandas as gpd
import pandas as pd

BAUVERFAHREN_PG_ZU_LV = {  # Plan[Goo] CONST_METHOD -> unsere LV-Bauverfahren
    "Tiefbau": "Offene Bauweise", "Tiefbau_Mindertiefe": "Mindertiefe_15x30", "Trenching_1": "Trenching", "Trenching_2": "Trenching",
    "Trenching_3": "Trenching", "Trenching_4": "Trenching", "Trenching_5": "Trenching", "Tiefbau_Spuelbohrung": "Spülbohrung",
    "Tiefbau_Verdraengung": "Bodenrakete", "Kabelpflug": "Kabelpflug",
}
SURFACE_PG_ZU_KLASSE = {  # Plan[Goo] SURFACE (+ ALLOWANCE) -> unser Oberflaechenname
    ("geb_Oberbau", "Asphalt"): "Asphalt", ("geb_Oberbau", "Beton"): "Beton", ("geb_Oberbau", "Pflaster_Platten"): "Pflaster",
    ("geb_Oberbau", None): "geb_Oberbau", ("ungeb_Oberbau", None): "Ungebundener Oberbau", ("ohne_Oberbau", None): "Ohne Oberbau",
}


def ist_plangoo_gpkg(path):
    try:
        import pyogrio
        return "GEOMETRY_LINE" in set(pyogrio.list_layers(path)[:, 0])
    except Exception:
        return False


def _drops_erkennen(path, g, crs, tol=0.3):
    """-> Liste bool je Zeile von g: Linie ist (Teil einer) Hauszufuehrung. Erkennung ueber Knotengrade: ein Ende der Linie
    haengt frei (Grad 1) und liegt an einem APL, oder es fuehrt nur weiter in bereits erkannte Zufuehrungslinien."""
    from collections import defaultdict
    from shapely.geometry import Point
    from shapely.strtree import STRtree
    n = len(g)
    if n == 0:
        return []
    try:
        pts = gpd.read_file(path, layer="GEOMETRY_POINT")
        if pts.crs is None:
            pts = pts.set_crs(3857)
        if pts.crs.to_epsg() != crs:
            pts = pts.to_crs(crs)
        apl = [geom for geom, t in zip(pts.geometry, pts["TYPE"].astype(str)) if t == "apl" and geom is not None and not geom.is_empty]
    except Exception:
        apl = []
    apl_tree = STRtree(apl) if apl else None

    def key(x, y):
        return (round(x, 1), round(y, 1))

    enden = []
    grad = defaultdict(int)
    for geom in g.geometry:
        c = list(geom.coords)
        a_, z_ = key(*c[0][:2]), key(*c[-1][:2])
        enden.append((a_, z_))
        grad[a_] += 1
        grad[z_] += 1

    def an_apl(k):
        if apl_tree is None:
            return False
        p = Point(k)
        return any(apl[j].distance(p) <= tol for j in apl_tree.query(p.buffer(tol)))

    drop = [False] * n
    geaendert = True
    while geaendert:
        geaendert = False
        for i in range(n):
            if drop[i]:
                continue
            for k in enden[i]:
                if grad[k] == 1 and an_apl(k):
                    drop[i] = True
                    break
            if not drop[i]:
                # Ende, an dem nur noch erkannte Zufuehrungen haengen (Grad wird durch Herausnahme kleiner)
                pass
        # Ketten: Linie, deren eines Ende nach Abzug der Drops Grad 1 hat und deren dortige Nachbarn alle Drops sind
        grad_rest = defaultdict(int)
        for i in range(n):
            if not drop[i]:
                grad_rest[enden[i][0]] += 1
                grad_rest[enden[i][1]] += 1
        for i in range(n):
            if drop[i]:
                continue
            for k in enden[i]:
                if grad_rest[k] == 1 and grad[k] == 2 and g.geometry.iloc[i].length <= 60.0:
                    # frei haengend, aber urspruenglich verbunden -> die Nachbarn waren Drops
                    drop[i] = True
                    geaendert = True
                    break
    return drop


def load(path, crs, cfg=None):
    """-> GeoDataFrame Kanten wie hld.comsof.load (surface, digtype, streetname, is_crossing, quelle_id, typ, bestand, kapazitaet,
    hauszuf, transition, duct_class, hinweis)."""
    g = gpd.read_file(path, layer="GEOMETRY_LINE")
    if g.crs is None:
        g = g.set_crs(3857)
    if g.crs.to_epsg() != crs:
        g = g.to_crs(crs)
    typ = g["TYPE"].fillna("underground").astype(str) if "TYPE" in g else pd.Series(["underground"] * len(g), index=g.index)
    g = g[typ != "in_house"].copy()          # Hauseinfuehrungen im Gebaeude sind keine Kandidaten
    g = g.explode(index_parts=False, ignore_index=True)
    g = g[g.geometry.length > 0.005].reset_index(drop=True)
    sub = g["SUB_TYPE"].fillna("").astype(str) if "SUB_TYPE" in g else pd.Series([""] * len(g), index=g.index)
    ext = g["IS_EXTERNAL_OBJECT"].fillna(0).astype(int).astype(bool) if "IS_EXTERNAL_OBJECT" in g else pd.Series([False] * len(g), index=g.index)
    bv = g["BAUVERFAHREN"] if "BAUVERFAHREN" in g else pd.Series([None] * len(g), index=g.index)
    sf = g["SURFACE"] if "SURFACE" in g else pd.Series([None] * len(g), index=g.index)
    zu = g["ALLOWANCE"] if "ALLOWANCE" in g else pd.Series([None] * len(g), index=g.index)
    # Hauszufuehrungen ohne Merkmal (Comsof-Drops, die im STP als normale Trasse stehen): Linien, deren Sackgassen-Ende an
    # einem APL liegt oder nur an weitere solche Linien anschliesst, sind Hauszufuehrungen - nie Kandidaten fuer Laengstrassen
    hz = _drops_erkennen(path, g, crs)
    sub = pd.Series([("Hauszufuehrung" if (h or s_ == "Hauszufuehrung") else s_) for h, s_ in zip(hz, sub)], index=g.index)

    def klasse(s, z):
        if not isinstance(s, str):
            return None
        return SURFACE_PG_ZU_KLASSE.get((s, z if isinstance(z, str) else None)) or SURFACE_PG_ZU_KLASSE.get((s, None))

    out = gpd.GeoDataFrame({
        "typ": ["EXISTINGPIPE" if e else ("CUSTOMERDROP" if s == "Hauszufuehrung" else "BURIED") for e, s in zip(ext, sub)],
        "surface": [klasse(s, z) for s, z in zip(sf, zu)],
        "digtype": bv.map(lambda v: BAUVERFAHREN_PG_ZU_LV.get(v) if isinstance(v, str) else None),
        "streetname": g["LOCATION_HINT"] if "LOCATION_HINT" in g else None,
        "is_crossing": (g["LOCATION_HINT"].fillna("").astype(str).str.contains("querung", case=False)) if "LOCATION_HINT" in g else False,
        "quelle_id": "plangoo:" + g["UID"].astype(str),
        "bestand": ext.values,
        "kapazitaet": [1 if e else None for e in ext],
        "hauszuf": (sub == "Hauszufuehrung").values,
        "transition": [False] * len(g),
        "duct_class": None,
        "hinweis": None,
        "geometry": g.geometry,
    }, crs=g.crs)
    return out
