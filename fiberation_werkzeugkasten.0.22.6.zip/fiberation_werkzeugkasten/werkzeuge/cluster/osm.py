# -*- coding: utf-8 -*-
"""Strassen, Bahn, Gewaesser aus OpenStreetMap (Overpass) - mit Datei-Cache.

ALKIS hat keine Strassenachsen, deshalb OSM. Die Trasse selbst liegt spaeter im Seitenraum;
OSM liefert nur den Achsgraph und die Klasse.
"""
import hashlib
import json
import os
import time
import urllib.parse
import urllib.request

import geopandas as gpd
from shapely.geometry import LineString, Point

OVERPASS = "https://overpass-api.de/api/interpreter"
UA = "fiberation-hld-roboter/0.1 (QGIS; Kontakt: Fiberation Planung)"


def _query(bbox4326):
    s, w, n, e = bbox4326
    bb = "{:.6f},{:.6f},{:.6f},{:.6f}".format(s, w, n, e)
    return (
        "[out:json][timeout:120];("
        'way["highway"](' + bb + ");"
        'way["railway"~"^(rail|tram|light_rail|narrow_gauge)$"](' + bb + ");"
        'way["waterway"~"^(river|canal|stream)$"](' + bb + ");"
        ");out geom;"
    )


# --- Lauf-Steuerung (29.09.2026) -------------------------------------------------------------------------------------------------------
# Der Overpass-Abruf lief bisher im Hauptthread: urlopen mit 180 s je Versuch, 2 Versuche je Server, 3 Server -> QGIS bis 18 min
# "reagiert nicht" (Dornberg 29.09.2026, dritter Spiegel private.coffee). Jetzt laeuft das Netz in einem Thread, der Hauptthread pumpt
# Qt-Ereignisse und kann abbrechen. Schritt 0 hatte das schon fuer sich (umfeld.kern._fetch_im_hintergrund), alle anderen Schritte nicht.
_LAUF = {"abbruch": False, "status": None}


class Abgebrochen(RuntimeError):
    """Der Nutzer hat den Overpass-Abruf abgebrochen (Text enthaelt 'abgebrochen', Schritt 0 prueft darauf)."""


def lauf_beginnen(status=None):
    """Vor einem Schrittlauf aufrufen: Abbruch-Merker zuruecksetzen, optional status(text) fuer die Fortschrittsanzeige."""
    _LAUF["abbruch"] = False
    _LAUF["status"] = status


def lauf_beenden():
    _LAUF["status"] = None


def abbrechen():
    """Knopf Abbrechen: der laufende und jeder weitere fetch() dieses Laufs wirft Abgebrochen."""
    _LAUF["abbruch"] = True


def _warten_qt():
    try:
        from qgis.PyQt.QtWidgets import QApplication
        if QApplication.instance() is not None:
            QApplication.processEvents()
    except Exception:
        pass


def _holen(data, stand):
    """Netzteil von fetch() - laeuft im Thread. stand: geteiltes dict (server, versuch, abbruch); Ergebnis in stand['js'] / stand['ex']."""
    fehler = None
    for i, url in enumerate((OVERPASS, "https://overpass.kumi.systems/api/interpreter", "https://overpass.private.coffee/api/interpreter")):
        for attempt in range(2):
            if stand.get("abbruch"):
                return
            stand["server"], stand["versuch"] = i + 1, attempt + 1
            try:
                req = urllib.request.Request(url, data=data, headers={"User-Agent": UA})
                with urllib.request.urlopen(req, timeout=180) as r:
                    kand = json.loads(r.read())
                # Overpass liefert bei Zeit-/Speichergrenze ein unvollstaendiges Ergebnis mit "remark" - das darf nicht
                # als Netz durchgehen (Barntrup 14.09.2026: 2.893 statt 12.118 Kanten, der Norden fehlte komplett)
                if kand.get("remark"):
                    fehler = RuntimeError("Overpass unvollstaendig: " + str(kand["remark"])[:120])
                    continue
                stand["js"] = kand
                return
            except Exception as e:  # Overpass ist launisch: kurz warten, dann Spiegel
                fehler = e
                for _ in range(10):
                    if stand.get("abbruch"):
                        return
                    time.sleep(0.5)
    stand["ex"] = RuntimeError("Overpass nicht erreichbar oder unvollstaendig (alle Server): {}".format(fehler))


def fetch(bbox4326, cache_path=None, query=None, warte=None, abbruch=None, status=None):
    """query: eigene Overpass-Abfrage (WeSi: Gewaesser + Strassen mit ref), sonst Strassen/Bahn/Gewaesser fuer das Netz.
    Netzabruf im Hintergrund-Thread; waehrenddessen warte() (Standard: Qt-Ereignisse pumpen), abbruch() -> True oder abbrechen() wirft
    Abgebrochen, status(text) bekommt 'Overpass Server 2/3, Versuch 1, 45 s'. Cache-Treffer kommen ohne Netz und ohne Warten zurueck."""
    abfrage = query or _query(bbox4326)
    if cache_path:
        # 16.09.2026: Cache nur verwenden, wenn er die Anfrage abdeckt. Vorher wurde osm_cache.json im Ausgabeordner blind gelesen:
        # Selbeck-Cache fuer den Sommersell-Schnitt (2 km weiter) -> 52 Wege ausserhalb der Adresshuelle -> 0 Kanten nach Beschnitt.
        # Je Ausschnitt eine eigene Datei osm_cache_<hash>.json, damit mehrere Ausschnitte im selben Ordner nebeneinander leben;
        # alte osm_cache.json ohne Marke gilt weiter, wenn ihre Elemente die Anfrage abdecken.
        cache_path = _cache_datei(cache_path, bbox4326, abfrage)
        ordner = os.path.dirname(cache_path) or "."
        kandidaten = [cache_path] + sorted(os.path.join(ordner, n) for n in (os.listdir(ordner) if os.path.isdir(ordner) else [])
                                            if n.lower().startswith("osm_cache") and n.lower().endswith(".json"))
        for k in kandidaten:
            if not os.path.exists(k):
                continue
            try:
                with open(k, encoding="utf-8") as f:
                    alt = json.load(f)
            except Exception:
                continue
            if _cache_passt(alt, bbox4326, abfrage):
                return alt
    warte = warte or _warten_qt
    status = status or _LAUF.get("status")

    def abgebrochen():
        return _LAUF["abbruch"] or (abbruch() if abbruch else False)

    if abgebrochen():
        raise Abgebrochen("Overpass-Abruf abgebrochen")
    import threading
    stand = {"server": 1, "versuch": 1}
    data = ("data=" + urllib.parse.quote(abfrage)).encode()
    t = threading.Thread(target=_holen, args=(data, stand), daemon=True)
    t.start()
    t0 = time.time()
    letzte = -1
    while t.is_alive():
        t.join(0.25)
        warte()
        sek = int(time.time() - t0)
        if status and sek != letzte:
            letzte = sek
            try:
                status("Overpass Server {}/3, Versuch {}, {} s".format(stand["server"], stand["versuch"], sek))
            except Exception:
                pass
        if abgebrochen():
            stand["abbruch"] = True  # der Thread stirbt mit seinem urlopen-Zeitlimit von selbst (daemon)
            raise Abgebrochen("Overpass-Abruf abgebrochen nach {} s".format(sek))
    if "ex" in stand:
        raise stand["ex"]
    js = stand.get("js")
    if js is None:
        raise RuntimeError("Overpass-Abruf ohne Ergebnis")
    if cache_path:
        js["_fiberation"] = {"bbox": list(bbox4326), "abfrage": hashlib.md5(abfrage.encode("utf-8")).hexdigest()}
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        with open(cache_path, "w", encoding="utf-8") as f:
            json.dump(js, f)
    return js


def _cache_datei(cache_path, bbox4326, abfrage):
    """osm_cache.json -> osm_cache_<hash8 aus Bbox (4 Nachkommastellen) und Abfrage>.json im selben Ordner."""
    schl = "|".join("{:.4f}".format(float(v)) for v in bbox4326) + "|" + hashlib.md5(abfrage.encode("utf-8")).hexdigest()
    h = hashlib.md5(schl.encode("utf-8")).hexdigest()[:8]
    return os.path.join(os.path.dirname(cache_path), "osm_cache_{}.json".format(h))


def _cache_passt(js, bbox4326, abfrage):
    """Deckt der Cache die Anfrage ab? Neue Caches tragen Bbox und Abfrage-Hash (_fiberation). Alte ohne Marke gelten, wenn die
    Ausdehnung ihrer Elemente die Anfrage-Mitte enthaelt und je Achse mindestens 60 % der Anfrage-Spanne ueberdeckt."""
    s, w, n, e = [float(v) for v in bbox4326]
    m = js.get("_fiberation") if isinstance(js, dict) else None
    if m:
        if m.get("abfrage") != hashlib.md5(abfrage.encode("utf-8")).hexdigest():
            return False
        cs, cw, cn, ce = [float(v) for v in m["bbox"]]
        tol = 1e-5
        return cs <= s + tol and cw <= w + tol and cn >= n - tol and ce >= e - tol
    lats, lons = [], []
    for el in js.get("elements", []) if isinstance(js, dict) else []:
        for g in el.get("geometry", []) or ([{"lat": el["lat"], "lon": el["lon"]}] if "lat" in el else []):
            lats.append(g["lat"])
            lons.append(g["lon"])
    if not lats:
        return False
    ms, mn, mw, me = min(lats), max(lats), min(lons), max(lons)
    mitte_ok = ms <= (s + n) / 2 <= mn and mw <= (w + e) / 2 <= me
    span_ok = (mn - ms) >= 0.6 * (n - s) and (me - mw) >= 0.6 * (e - w)
    return mitte_ok and span_ok


def to_frames(js, crs):
    """-> (strassen, hindernisse) als GeoDataFrames im Ziel-CRS. strassen behalten die OSM-Knoten-IDs je Stuetzpunkt."""
    roads, obst = [], []
    for el in js.get("elements", []):
        if el.get("type") != "way" or "geometry" not in el or len(el["geometry"]) < 2:
            continue
        tags = el.get("tags", {})
        coords = [(p["lon"], p["lat"]) for p in el["geometry"]]
        nodes = el.get("nodes") or list(range(len(coords)))
        if "highway" in tags:
            roads.append({
                "osm_id": el["id"], "highway": tags.get("highway"), "surface": tags.get("surface"),
                "name": tags.get("name"), "ref": tags.get("ref"), "bridge": tags.get("bridge"), "tunnel": tags.get("tunnel"),
                "access": tags.get("access"), "service": tags.get("service"),
                "nodes": json.dumps(nodes), "geometry": LineString(coords),
            })
        else:
            kind = "bahn" if "railway" in tags else "gewaesser"
            obst.append({"osm_id": el["id"], "art": kind, "name": tags.get("name"), "geometry": LineString(coords)})
    r = gpd.GeoDataFrame(roads, crs=4326).to_crs(crs) if roads else gpd.GeoDataFrame({"geometry": []}, crs=crs)
    o = gpd.GeoDataFrame(obst, crs=4326).to_crs(crs) if obst else gpd.GeoDataFrame({"art": [], "geometry": []}, crs=crs)
    return r, o


def load(cfg, adressen, extra_points=None):
    """Puffer um Adressen (+ BSt), holen oder Cache lesen, in Frames wandeln."""
    puffer = cfg["osm"]["puffer_m"]
    pts = list(adressen.geometry)
    for p in extra_points or []:
        pts.append(Point(p[0], p[1]))
    gs = gpd.GeoSeries(pts, crs=cfg["crs"])
    minx, miny, maxx, maxy = gs.total_bounds
    box = gpd.GeoSeries([LineString([(minx - puffer, miny - puffer), (maxx + puffer, maxy + puffer)])], crs=cfg["crs"]).to_crs(4326).total_bounds
    bbox4326 = (box[1], box[0], box[3], box[2])
    cache = cfg["osm"].get("cache") or os.path.join(cfg["out_dir"], "osm_cache.json")
    js = fetch(bbox4326, cache)
    return to_frames(js, cfg["crs"])
