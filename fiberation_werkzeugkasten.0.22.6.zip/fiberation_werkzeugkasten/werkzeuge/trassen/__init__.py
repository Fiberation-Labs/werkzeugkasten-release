# -*- coding: utf-8 -*-
"""Werkzeug 5 - NVT fuer NVT Trassen aufbereiten: Vorlage (Kondensat) je NVT, Planung des Planers, Hauszufuehrungen ableiten, pruefen,
Endstand einfrieren und nach Plan[Goo] uebertragen."""
