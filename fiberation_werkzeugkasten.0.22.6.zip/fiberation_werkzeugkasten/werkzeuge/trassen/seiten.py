# -*- coding: utf-8 -*-
"""Uebernommen aus dem HLD Roboter (hld/seiten.py, Stand 09.09.2026) fuer die Vorlage von Werkzeug 4 (Markus 16.09.2026: "beidseitiger
Ausbau wie im HLD Roboter, Laengstrassen im oeffentlichen Raum nach ZTV 21").

Beidseitige Trassenkandidaten aus Strassenachsen (OSM): je Strasse eine Linie links und rechts im Seitenraum,
Querungen an Knoten und in Abstaenden mit Fahrbahn-Preis. Die Seitenwahl trifft dann der Optimierer.

Optional werden die Seitenlinien an ALKIS-Verkehrsflaechen (tatsaechliche Nutzung 'Strassenverkehr'/'Weg'/'Platz')
ausgerichtet: die Kandidaten laufen dann entlang der Flaechengrenze (Grundstuecksgrenze) statt in festem Abstand.
"""
import math

import networkx as nx
from shapely.geometry import LineString, Point
from shapely.ops import unary_union
from shapely.strtree import STRtree

from ..cluster import costs

# halbe Fahrbahnbreite + Abstand bis Gehwegmitte (m) je OSM-Typ, wenn keine ALKIS-Flaeche vorliegt
ABSTAND_JE_HIGHWAY = {
    "primary": 6.5, "primary_link": 6.0, "secondary": 6.0, "secondary_link": 5.5, "tertiary": 5.0, "tertiary_link": 5.0,
    "residential": 4.0, "living_street": 3.5, "unclassified": 4.0, "service": 3.0, "pedestrian": 3.0, "road": 4.0,
}
EINSEITIG = {"footway", "cycleway", "path", "track", "steps", "bridleway"}  # Wege: eine Linie reicht


def _key(x, y):
    return "{:.2f}_{:.2f}".format(x, y)


def _add_edge(G, p, q, **attr):
    u, v = _key(*p), _key(*q)
    if u == v:
        return
    L = math.hypot(q[0] - p[0], q[1] - p[1])
    if L <= 0.01:
        return
    G.add_node(u, x=p[0], y=p[1])
    G.add_node(v, x=q[0], y=q[1])
    if G.has_edge(u, v) and G[u][v]["length"] <= L:
        return
    attr.setdefault("geometry", LineString([p, q]))
    G.add_edge(u, v, length=L, **attr)


def build(roads, obstacles, cfg, verkehrsflaechen=None):
    """roads: GeoDataFrame OSM-Wege (highway, surface, ref, geometry). verkehrsflaechen: GeoSeries Polygone (ALKIS) oder None."""
    o = cfg["osm"]
    q = cfg["kosten"]["querung"]
    bv = cfg["kosten"]["bauverfahren_default"]
    seiten_cfg = cfg["osm"].get("seiten", {})
    querung_abstand = seiten_cfg.get("querung_abstand_m", 70.0)
    fahrbahn_okl = 1
    eur_fahrbahn = costs.eur_m("Fahrbahn", fahrbahn_okl, cfg)
    kopfloch = seiten_cfg.get("kopfloch_eur", 508.75)   # LV Pos 7.1 Kopfloch Strassenbereich Klasse 1 (ANNAHME 1 m3)
    roads = roads[~roads.highway.isin(o["ausschluss_highway"])].copy()
    G = nx.Graph()

    vf_union = None
    rand_ringe, rand_tree = [], None
    if verkehrsflaechen is not None and len(verkehrsflaechen):
        geoms = [g for g in verkehrsflaechen.geometry if g is not None and not g.is_empty]
        # Flaechengrenzen als einzelne Ringe -> schnelle Naechster-Rand-Suche
        for g in geoms:
            polys = list(g.geoms) if g.geom_type == "MultiPolygon" else [g]
            for p in polys:
                rand_ringe.append(LineString(p.exterior.coords))
        if rand_ringe:
            rand_tree = STRtree(rand_ringe)
            vf_union = True

    def klasse_von(r):
        from ..cluster.graph import _klasse_osm
        return _klasse_osm(r.highway, r.surface, cfg)

    achsen = list(roads.geometry)
    achs_tree = STRtree(achsen)
    # Knotenzaehlung: Stuetzpunkte, die in mehreren Wegen vorkommen = Kreuzungen
    from collections import Counter
    vertex_count = Counter()
    for g in achsen:
        for c in g.coords:
            vertex_count[(round(c[0], 2), round(c[1], 2))] += 1

    # Seitenlinien-Enden: (Punkt, way_idx, seite, Achsknoten-Key). Der Achsknoten-Key sagt, zu welcher Kreuzung das Ende
    # gehoert - unabhaengig davon, wie weit die ALKIS-Projektion das Ende verschoben hat (frueher nur Radius 14 m um den
    # Achsknoten: dadurch blieben ganze Nebenstrassen unverbunden und wurden als Restkomponente verworfen).
    seiten_enden = []
    for idx, r in enumerate(roads.itertuples(index=False)):
        line = r.geometry
        if line.length < 0.5:
            continue
        klasse = klasse_von(r)
        okl = costs.oberflaechenklasse(klasse, cfg)
        hauptstr = r.highway in o["hauptstrasse_highway"]
        eur_m = costs.eur_m(bv, okl, cfg) * (o["faktor_hauptstrasse"] if hauptstr else 1.0)
        basis = dict(klasse=klasse, okl=okl, bauverfahren=bv, eur_m=eur_m, highway=r.highway, name=r.name,
                     quelle_id="osm:{}".format(r.osm_id), hauptstr=hauptstr, is_b=False, querung=None, querung_eur=0.0, virtuell=False)
        achs_a, achs_e = line.coords[0], line.coords[-1]
        if r.highway in EINSEITIG:
            cs = list(line.coords)
            for p, qq in zip(cs[:-1], cs[1:]):
                _add_edge(G, p, qq, seite="M", **basis)
            seiten_enden.append((cs[0], idx, "M", _key(*achs_a)))
            seiten_enden.append((cs[-1], idx, "M", _key(*achs_e)))
            continue
        d = ABSTAND_JE_HIGHWAY.get(r.highway, 4.0)
        for seite, sign in (("L", 1), ("R", -1)):
            try:
                off = line.offset_curve(sign * d, join_style=2)
            except Exception:
                continue
            if off.is_empty:
                continue
            parts = list(off.geoms) if off.geom_type == "MultiLineString" else [off]
            vorher_ende = None
            for pi, part in enumerate(parts):
                cs = list(part.coords)
                if vf_union is not None:
                    # an die Verkehrsflaechengrenze ruecken: Punkt auf den naechsten Flaechenrand projizieren, falls innerhalb 12 m
                    cs = [_an_rand(c, rand_tree, rand_ringe) for c in cs]
                for p, qq in zip(cs[:-1], cs[1:]):
                    _add_edge(G, p, qq, seite=seite, **basis)
                # Luecken zwischen Teilstuecken (offset_curve zerlegt an engen Kurven) schliessen
                if vorher_ende is not None and math.hypot(cs[0][0] - vorher_ende[0], cs[0][1] - vorher_ende[1]) <= 30.0:
                    _add_edge(G, vorher_ende, cs[0], seite=seite, **basis)
                vorher_ende = cs[-1]
                # Zuordnung der Enden zu den Achsknoten: das naeher liegende Achsende (offset_curve kann die Richtung umkehren)
                for c in (cs[0], cs[-1]):
                    da = math.hypot(c[0] - achs_a[0], c[1] - achs_a[1])
                    de = math.hypot(c[0] - achs_e[0], c[1] - achs_e[1])
                    key = _key(*achs_a) if da <= de else _key(*achs_e)
                    if min(da, de) > 3 * d + 12.0:   # inneres Teilstueck-Ende, keinem Achsknoten zuzuordnen
                        key = None
                    seiten_enden.append((c, idx, seite, key))
                # Querungen in Abstaenden (nur von L aus, sonst doppelt)
                if seite == "L" and part.length > querung_abstand:
                    n = int(part.length // querung_abstand)
                    for k in range(1, n + 1):
                        pl = part.interpolate(k * querung_abstand)
                        pr = line.offset_curve(-d, join_style=2)
                        if pr.is_empty:
                            continue
                        prp = pr.interpolate(pr.project(pl))
                        _querung(G, (pl.x, pl.y), (prp.x, prp.y), eur_fahrbahn, kopfloch, fahrbahn_okl, r)
        # Querung an den Wegenden (Kreuzungen)
        # wird unten ueber seiten_enden erledigt

    # Kreuzungen: alle Seitenenden desselben Achsknotens verbinden (dazu alle Enden im Umkreis 14 m);
    # ueber die Achse = Querung (Fahrbahn + Kopfloch), sonst Gehweg-Eck
    okl_e = 1
    eur_eck = costs.eur_m(bv, okl_e, cfg)
    eck_attr = dict(seite="E", klasse="geb_Oberbau", okl=okl_e, bauverfahren=bv, eur_m=eur_eck, highway="eck", name=None, quelle_id="eck",
                    hauptstr=False, is_b=False, querung=None, querung_eur=0.0, virtuell=False)

    def _verbinde(p1, p2, max_m=60.0):
        k1, k2 = _key(*p1), _key(*p2)
        key = (k1, k2) if k1 <= k2 else (k2, k1)
        if key in verbunden or k1 == k2:
            return False
        verbunden.add(key)
        seg = LineString([p1, p2])
        if seg.length > max_m:
            return False
        if any(seg.crosses(achsen[a]) for a in achs_tree.query(seg)):
            _querung(G, p1, p2, eur_fahrbahn, kopfloch, fahrbahn_okl, None)
        else:
            _add_edge(G, p1, p2, **eck_attr)
        return True

    ende_pts = [Point(p) for p, _, _, _ in seiten_enden]
    ende_tree = STRtree(ende_pts)
    je_achsknoten = {}
    for i, (_, _, _, k) in enumerate(seiten_enden):
        if k is not None:
            je_achsknoten.setdefault(k, set()).add(i)
    kreuzungen = [Point(k) for k, n in vertex_count.items() if n >= 2] + [Point(list(g.coords)[i]) for g in achsen for i in (0, -1)]
    verbunden = set()
    for kp in kreuzungen:
        idx = set(int(h) for h in ende_tree.query(kp.buffer(14.0))) | je_achsknoten.get(_key(kp.x, kp.y), set())
        idx = sorted(idx)
        for i in range(len(idx)):
            for j in range(i + 1, len(idx)):
                _verbinde(seiten_enden[idx[i]][0], seiten_enden[idx[j]][0])

    # Restkomponenten anbinden: was jetzt noch unverbunden ist (T-Einmuendung in eine nicht geteilte Achse, verschobene Enden),
    # wird per Lotpunkt an die naechste fremde Kandidatenkante gehaengt (<= 30 m), statt spaeter verworfen zu werden.
    G.graph["reparatur"] = _komponenten_verbinden(G, achsen, achs_tree, eur_fahrbahn, kopfloch, fahrbahn_okl, eck_attr)
    G.graph["ecken"] = _ecken_schliessen(G, achsen, achs_tree, eur_fahrbahn, kopfloch, fahrbahn_okl, eck_attr)

    # Bahn/Gewaesser-Pauschalen wie bisher
    if obstacles is not None and len(obstacles):
        geoms = list(obstacles.geometry)
        arten = list(obstacles.art)
        tree = STRtree(geoms)
        for u, v, d in G.edges(data=True):
            for h in tree.query(d["geometry"], predicate="intersects"):
                pauschale = q["bahn"] if arten[h] == "bahn" else q["gewaesser"]
                if pauschale > d["querung_eur"]:
                    d["querung"], d["querung_eur"] = arten[h], pauschale
    for u, v, d in G.edges(data=True):
        d["cost"] = d["length"] * d["eur_m"] + d["querung_eur"]
    if G.number_of_nodes():
        comps = sorted(nx.connected_components(G), key=len, reverse=True)
        rest_m = sum(G[u][v]["length"] for c in comps[1:] for u in c for v in G[u]) / 2.0
        G.graph["verworfen"] = {"komponenten": len(comps) - 1, "meter": round(rest_m)}
        G = G.subgraph(comps[0]).copy()
    return G


def _kante_teilen(G, u, v, frac, sp):
    """Kante u-v am Lotpunkt sp (normierte Position frac) teilen; gibt den neuen (oder vorhandenen) Knoten zurueck."""
    from ..cluster.graph import _substring
    m = _key(sp.x, sp.y)
    if m in (u, v):
        return m
    d = G[u][v]
    G.remove_edge(u, v)
    G.add_node(m, x=sp.x, y=sp.y)
    for a, b, fa, fb in ((u, m, 0.0, frac), (m, v, frac, 1.0)):
        nd = dict(d)
        f = max(fb - fa, 1e-9)
        nd["length"] = max(d["length"] * f, 0.01)
        nd["querung_eur"] = d["querung_eur"] * f
        geom = _substring(d["geometry"], fa, fb)
        if geom.length < 0.005:
            geom = LineString([(G.nodes[a]["x"], G.nodes[a]["y"]), (G.nodes[b]["x"], G.nodes[b]["y"])])
        nd["geometry"] = geom
        if not (G.has_edge(a, b) and G[a][b]["length"] <= nd["length"]):
            G.add_edge(a, b, **nd)
    return m


def _ecken_schliessen(G, achsen, achs_tree, eur_fahrbahn, kopfloch, fahrbahn_okl, eck_attr, max_m=12.0, faktor=8.0, min_umweg_m=60.0):
    """Einmuendungen schliessen, bei denen die Seitenlinie einer Nebenstrasse dicht neben der durchlaufenden Seitenlinie der Hauptstrasse
    endet, ohne mit ihr verbunden zu sein (Markus 17.09.2026, Selbeck: Alter Kirchweg endet 3,5 m neben der Detmolder Strasse - im Netz
    lag das Haus 133 m vom NVT, im Seitenraum 1.032 m, weil der Baum ueber Obere und Untere Trift durch das Nachbargebiet musste).
    Die Kreuzungsschleife oben verbindet nur Seitenlinien-ENDEN miteinander; laeuft die Hauptstrasse durch, hat sie dort kein Ende, und
    _komponenten_verbinden greift nicht, weil der Graph ueber den langen Weg zusammenhaengt. Hier wird jeder Knoten geprueft, dessen
    kuerzeste Verbindung zu einer fremden Strasse im Graphen unverhaeltnismaessig lang ist. -> {"ecken": n, "meter": m}"""
    n_neu, m_neu = 0, 0.0
    edges = list(G.edges())
    geoms = [G[u][v]["geometry"] for u, v in edges]
    tree = STRtree(geoms)
    for n in list(G.nodes()):
        if n not in G:
            continue
        p = Point(G.nodes[n]["x"], G.nodes[n]["y"])
        eigene = {str(G[n][m].get("quelle_id") or "") for m in G.neighbors(n)}
        best = None
        for j in tree.query(p.buffer(max_m)):
            j = int(j)
            u, v = edges[j]
            if n in (u, v) or not G.has_edge(u, v):
                continue
            d = G[u][v]
            if d.get("seite") == "Q" or d.get("virtuell") or str(d.get("quelle_id") or "") in eigene:
                continue
            dd = geoms[j].distance(p)
            if dd < 0.05 or dd > max_m:
                continue
            if best is None or dd < best[0]:
                best = (dd, j)
        if best is None:
            continue
        dd, j = best
        u, v = edges[j]
        grenze = max(min_umweg_m, faktor * dd)
        try:
            erreichbar = nx.single_source_dijkstra_path_length(G, n, cutoff=grenze, weight="length")
        except Exception:
            continue
        if u in erreichbar or v in erreichbar:
            continue                                      # schon auf kurzem Weg verbunden - kein Eck noetig
        line = geoms[j]
        frac = line.project(p, normalized=True)
        if frac < 0.02:
            ziel = u
        elif frac > 0.98:
            ziel = v
        else:
            ziel = _kante_teilen(G, u, v, frac, line.interpolate(frac, normalized=True))
        q = (G.nodes[ziel]["x"], G.nodes[ziel]["y"])
        pp = (p.x, p.y)
        if _key(*q) == _key(*pp):
            continue
        seg = LineString([pp, q])
        if any(seg.crosses(achsen[a]) for a in achs_tree.query(seg)):
            _querung(G, pp, q, eur_fahrbahn, kopfloch, fahrbahn_okl, None)
        else:
            _add_edge(G, pp, q, **eck_attr)
        n_neu += 1
        m_neu += seg.length
    return {"ecken": n_neu, "meter": round(m_neu, 1)}


def _komponenten_verbinden(G, achsen, achs_tree, eur_fahrbahn, kopfloch, fahrbahn_okl, eck_attr, max_m=30.0, runden=6):
    """Jede Nebenkomponente ueber ihre kuerzeste Verbindung (Knoten -> Lotpunkt auf einer fremden Kandidatenkante, <= max_m)
    an den Rest haengen; kreuzt die Verbindung eine Strassenachse, ist sie eine Querung, sonst ein Gehweg-Eck.
    Mehrere Runden, weil Komponenten auch untereinander verschmelzen. -> {"verbindungen": n, "meter": m}"""
    n_verb, m_verb = 0, 0.0
    for _ in range(runden):
        comps = sorted(nx.connected_components(G), key=len, reverse=True)
        if len(comps) <= 1:
            break
        comp_id = {}
        for ci, c in enumerate(comps):
            for n in c:
                comp_id[n] = ci
        edges = list(G.edges())
        geoms = [G[u][v]["geometry"] for u, v in edges]
        tree = STRtree(geoms)
        neu = 0
        for ci, c in enumerate(comps[1:], 1):
            # Anschlussknoten: erst die losen Enden (schnell), sonst alle Knoten der Komponente. Vorher wurden bei Komponenten
            # ueber 60 Knoten NUR lose Enden geprueft - an einer T-Einmuendung haben die Seitenlinien-Enden aber Grad 2 (Seitenlinie
            # + Querung ueber die Nebenstrasse), also gab es kein loses Ende in 30 m und die ganze Nebenstrasse wurde verworfen
            # (Sommersell 16.09.2026: Wietrogsweg + Im Wietrog, 4,7 km, 3,7 m neben der Barntruper Strasse).
            listen = [[n for n in c if G.degree(n) <= 1], list(c)] if len(c) > 60 else [list(c)]
            best = None
            for knoten in listen:
                for n in knoten:
                    p = Point(G.nodes[n]["x"], G.nodes[n]["y"])
                    for j in tree.query(p.buffer(max_m)):
                        u, v = edges[j]
                        if not G.has_edge(u, v) or comp_id.get(u) == ci or G[u][v].get("seite") == "Q" or G[u][v].get("virtuell"):
                            continue
                        dd = geoms[j].distance(p)
                        if best is None or dd < best[0]:
                            best = (dd, n, j)
                if best is not None:
                    break
            if best is None:
                continue
            dd, n, j = best
            u, v = edges[j]
            line = geoms[j]
            p = Point(G.nodes[n]["x"], G.nodes[n]["y"])
            frac = line.project(p, normalized=True)
            if frac < 0.02:
                ziel = u
            elif frac > 0.98:
                ziel = v
            else:
                sp = line.interpolate(frac, normalized=True)
                ziel = _kante_teilen(G, u, v, frac, sp)
                comp_id[ziel] = comp_id[u]
            q = (G.nodes[ziel]["x"], G.nodes[ziel]["y"])
            pp = (p.x, p.y)
            if _key(*q) == _key(*pp):
                continue
            seg = LineString([pp, q])
            if any(seg.crosses(achsen[a]) for a in achs_tree.query(seg)):
                _querung(G, pp, q, eur_fahrbahn, kopfloch, fahrbahn_okl, None)
            else:
                _add_edge(G, pp, q, **eck_attr)
            # Komponente gilt ab jetzt als Teil der Zielkomponente (verhindert Doppelanbindung in derselben Runde)
            zc = comp_id[ziel]
            for nn in c:
                comp_id[nn] = zc
            neu += 1
            n_verb += 1
            m_verb += seg.length
        if neu == 0:
            break
    return {"verbindungen": n_verb, "meter": round(m_verb)}


def _querung(G, p1, p2, eur_fahrbahn, kopfloch, okl, r):
    _add_edge(G, p1, p2, seite="Q", klasse="Asphalt", okl=okl, bauverfahren="Fahrbahn", eur_m=eur_fahrbahn,
              highway=getattr(r, "highway", None) if r is not None else None, name=getattr(r, "name", None) if r is not None else None,
              quelle_id="querung", hauptstr=False, is_b=False, querung="Fahrbahn", querung_eur=kopfloch, virtuell=False)


def _an_rand(c, rand_tree, rand_ringe, max_m=12.0):
    """Punkt auf die naechste Verkehrsflaechengrenze schieben, wenn sie nah ist (sonst unveraendert)."""
    p = Point(c)
    idx = rand_tree.nearest(p)
    if idx is None:
        return c
    ring = rand_ringe[idx]
    d = ring.distance(p)
    if d > max_m or d < 0.05:
        return c
    np_ = ring.interpolate(ring.project(p))
    return (np_.x, np_.y)
