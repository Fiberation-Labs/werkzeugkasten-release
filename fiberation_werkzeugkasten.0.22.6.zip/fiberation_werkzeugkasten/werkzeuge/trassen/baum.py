# -*- coding: utf-8 -*-
"""Vzk-Baum je NVT fuer die Vorlage (Markus 16.09.2026, Option 3).

Vorher war der Baum die Vereinigung der kuerzesten Kostenpfade vom Sitz zu jedem Haus. Jeder Pfad war fuer sein Haus optimal,
kein Pfad wusste, dass der Nachbar denselben Gehweg ohnehin bezahlt: Ergebnis beide Strassenseiten gebaut UND viele Hausquerungen
(Sommersell 1V01: 2 von 2 Strassen beidseitig, 8 Hausquerungen). Jetzt:

1. Steinerbaum (Mehlhorn) ueber Sitz + alle Adressknoten, Gewicht = Kosten (Seitenraum) oder Laenge (andere Netze).
   Geteilte Gehwege werden von sich aus bevorzugt, Querungen nur wo sie sich rechnen.
2. Seitenregel als Absicherung: Abschnitte, die im Baum parallel zur Gegenseite derselben Strasse liegen, werden probeweise
   gestrichen; die abgehaengten Haeuser werden ueber den billigsten Weg im Restnetz wieder angebunden (meist Hausquerung/Pressung
   zur Gegenseite). Bleibt der Baum dadurch billiger, gilt die Aenderung. Wiederholt, bis nichts mehr besser wird.
3. Vzk-Hoechstlaenge (Regelsatz, 750 m eigen / 1.200 m MBfD): Haeuser mit zu langem Weg im Baum bekommen den billigsten
   Anschluss an einen Baumknoten, ueber den die Hoechstlaenge eingehalten wird - der Steinerbaum nimmt sonst Umwege in Kauf.
4. Hausquerungen sind nur fuer ihr Haus da. Nutzt der Baum eine Hausquerung als Durchgang zur Gegenseite (Hausknoten im Baum
   mit Grad >= 2), ist das ein Seitenwechsel: die Kante wird wie eine Fahrbahnquerung bepreist (Fahrbahn + Kopfloch + Aufschlag)
   und der Baum neu gerechnet, bis kein neuer Durchgang mehr entsteht (Barntruper Str. 43/39A, 16.09.: Luecke in der Suedseite,
   ueberbrueckt ueber zwei Hausquerungen zur Nordseite - billiger als die Querung nur, weil der Aufschlag fehlte).

Der Aufschlag je Fahrbahnquerung (Seitenwechsel) sitzt in kern.seitengraph_laden auf den Kanten (cfg seitenregel.seitenwechsel_aufschlag_eur).
"""
from collections import defaultdict

import networkx as nx
from networkx.algorithms.approximation import steiner_tree
from shapely.geometry import LineString

PARALLEL_M = 16.0   # Abschnitt gilt als parallel zur Gegenseite, wenn ein Knoten naeher als so viele Meter an ihr liegt


def _kosten(G, k, gewicht):
    a, b = tuple(k)
    d = G[a][b]
    return float(d.get(gewicht, d.get("length", 0.0)) or 0.0)


def _summe(G, kanten, gewicht):
    return sum(_kosten(G, k, gewicht) for k in kanten)


def gewichte_fuellen(G, gewicht):
    """Kanten ohne Gewicht (z. B. nachtraeglich angelegte Anschluss- oder Querungskanten) bekommen Laenge x eur_m + Querungspauschale."""
    n = 0
    for u, v, d in G.edges(data=True):
        if d.get(gewicht) is None:
            if gewicht == "length":
                continue
            d[gewicht] = float(d.get("length", 0.0)) * float(d.get("eur_m", 0.0) or 0.0) + float(d.get("querung_eur", 0.0) or 0.0)
            n += 1
    return n


def _baum_graph(G, kanten):
    T = nx.Graph()
    for k in kanten:
        a, b = tuple(k)
        T.add_edge(a, b, length=float(G[a][b].get("length", 0.0)))
    return T


def _stutzen(G, kanten, halten):
    """Blaetter, die weder Terminal noch Sitz sind, wiederholt entfernen (haengende Reststuecke nach dem Streichen eines Abschnitts)."""
    T = _baum_graph(G, kanten)
    geaendert = True
    while geaendert:
        geaendert = False
        for n in [n for n in T.nodes if T.degree(n) <= 1 and n not in halten]:
            if n in T:
                T.remove_node(n)
                geaendert = True
    return {frozenset((a, b)) for a, b in T.edges()}


def _bereinigen(G, kanten, halten, gewicht):
    """Baum-Eigenschaft sichern: Wiederanbindungen und Laengen-Nachbesserungen koennen Pfade durch schon vorhandene Baumteile
    legen und so Zyklen schliessen (Selbeck 16.09.: beide Seiten durchgehend gebaut und 6-8 Querungen dazwischen). Minimalgeruest
    nach Kosten ueber die Baumkanten (bricht jeden Zyklus an der teuersten Kante), danach Blaetter ohne Terminal entfernen."""
    if not kanten:
        return kanten
    T = nx.Graph()
    for k in kanten:
        a, b = tuple(k)
        # Querungen (seite Q) zaehlen zehnfach: ein Zyklus zwischen zwei gebauten Seiten wird an der Querung aufgebrochen,
        # nicht an einem Seitenstueck (Selbeck 16.09.: sonst beide Seiten durchgehend und 6-8 Querungen dazwischen)
        f = 10.0 if G[a][b].get("seite") == "Q" else 1.0
        T.add_edge(a, b, w=_kosten(G, k, gewicht) * f)
    if T.number_of_edges() >= T.number_of_nodes():   # sonst schon ein Wald, Geruest unnoetig
        T = nx.minimum_spanning_tree(T, weight="w")
    return _stutzen(G, {frozenset((a, b)) for a, b in T.edges()}, halten)


def _ohne_gruppe(G, kanten, gruppe, seed, terminals, gewicht):
    """Kantengruppe aus dem Baum streichen und alle abgehaengten Terminals ueber den billigsten Weg im Restnetz (ohne die
    gestrichenen Kanten) wieder anbinden. -> neue Kantenmenge oder None, wenn ein Terminal nicht mehr erreichbar ist."""
    rest = set(kanten) - set(gruppe)
    T = _baum_graph(G, rest)
    T.add_node(seed)
    for t in terminals:
        T.add_node(t)
    basis = set(nx.node_connected_component(T, seed))
    offen = [t for t in terminals if t not in basis]
    if not offen:
        return _stutzen(G, rest, set(terminals) | {seed})
    G2 = nx.restricted_view(G, [], [tuple(k) for k in gruppe])
    while offen:
        try:
            dist, pfade = nx.multi_source_dijkstra(G2, basis, weight=gewicht)
        except Exception:
            return None
        ziel, best = None, float("inf")
        for t in offen:
            for n in nx.node_connected_component(T, t):
                dd = dist.get(n)
                if dd is not None and dd < best:
                    ziel, best = n, dd
        if ziel is None:
            return None
        p = pfade[ziel]
        for a, b in zip(p[:-1], p[1:]):
            rest.add(frozenset((a, b)))
            T.add_edge(a, b)
        basis = set(nx.node_connected_component(T, seed))
        offen = [t for t in offen if t not in basis]
    return _bereinigen(G, rest, set(terminals) | {seed}, gewicht)


def _xy(G, n):
    d = G.nodes[n]
    return float(d["x"]), float(d["y"])


def _geom(G, k):
    a, b = tuple(k)
    g = G[a][b].get("geometry")
    return g if g is not None else LineString([_xy(G, a), _xy(G, b)])


def _richtung(g):
    c = list(g.coords)
    dx, dy = c[-1][0] - c[0][0], c[-1][1] - c[0][1]
    l = (dx * dx + dy * dy) ** 0.5 or 1.0
    return dx / l, dy / l


def parallele_kanten(G, kanten):
    """Baumkanten einer Strassenseite (L/R), die naeher als PARALLEL_M an einer etwa gleich gerichteten Seitenkante eines anderen
    Zuges liegen (= beide Seiten gebaut). Zug = (quelle_id, seite); OSM teilt eine Strasse oft in mehrere Wege, deshalb zaehlt auch
    die Gegenseite eines anderen Weges (Selbeck 16.09.: 150 m Doppelbau an einem Wegewechsel unerkannt). Sequentielle Seitenwechsel
    ueber eine Querung zaehlen nicht (Kanten hintereinander, gemeinsamer Knoten oder Winkel > 30 Grad). -> set(kanten)"""
    seitig = []
    for k in kanten:
        a, b = tuple(k)
        d = G[a][b]
        # L/R = Seitenlinien einer Strasse, M = einlinige Wege (Fuss-, Rad-, Feldweg) - ein Feldweg parallel zur Strassenseite ist
        # genauso ein Doppelbau (Selbeck 16.09.: 150 m Weg neben der Strasse, beide im Baum)
        if d.get("seite") in ("L", "R", "M") and d.get("quelle_id"):
            g = _geom(G, k)
            seitig.append((k, (d["quelle_id"], d["seite"]), g, g.interpolate(0.5, normalized=True), _richtung(g), {a, b}))
    erg = set()
    for k, zug, g, m, r, kn in seitig:
        for k2, zug2, g2, m2, r2, kn2 in seitig:
            if zug2 == zug or kn & kn2:
                continue
            if abs(r[0] * r2[0] + r[1] * r2[1]) < 0.87:          # Winkel > 30 Grad: kreuzend, nicht parallel
                continue
            if m.distance(g2) <= PARALLEL_M:
                erg.add(k)
                break
    return erg


def _abschnitte(G, kanten):
    """Strassenzuege: zusammenhaengende Baumkanten je (Strasse, Seite), die mindestens eine parallel gebaute Kante enthalten.
    Geprueft wird immer der ganze Zug, nicht nur der parallele Teil - sonst entstehen Luecken in einer gebauten Seite, und die
    Haeuser an der Luecke bekommen Hausquerungen, obwohl ihre Seite links und rechts davon gebaut ist (Hinweis Sitzung -32, 16.09.).
    -> Liste (quelle_id, seite, set(kanten))"""
    par = parallele_kanten(G, kanten)
    je_seite = defaultdict(set)
    for k in kanten:
        a, b = tuple(k)
        d = G[a][b]
        if d.get("seite") in ("L", "R", "M") and d.get("quelle_id"):
            je_seite[(d["quelle_id"], d["seite"])].add(k)
    erg = []
    for (q, s), ks in je_seite.items():
        S = nx.Graph()
        S.add_edges_from(tuple(k) for k in ks)
        for comp in nx.connected_components(S):
            zug = {frozenset(e) for e in S.subgraph(comp).edges()}
            if zug & par:
                erg.append((q, s, zug))
    return erg


def doppelt_m(G, kanten):
    """Meter Seitenlinie, die parallel zur Gegenseite derselben Strasse im Baum liegen (beide Seiten gebaut)."""
    return sum(float(G[tuple(k)[0]][tuple(k)[1]].get("length", 0.0)) for k in parallele_kanten(G, kanten))


def seitenregel(G, kanten, seed, terminals, gewicht, runden=30):
    """Parallel gebaute Abschnitte nachpruefen: billigster Abschnitt zuerst probeweise streichen, Haeuser neu anbinden, behalten
    wenn billiger. -> (kanten, anzahl_gestrichen, ersparnis_eur)"""
    n_gestrichen, ersparnis = 0, 0.0
    probiert = set()
    for _ in range(runden):
        kandidaten = []
        for q, s, ks in _abschnitte(G, kanten):
            schl = (q, s, frozenset(ks))
            if schl in probiert:
                continue
            kandidaten.append((_summe(G, ks, gewicht), schl, ks))
        if not kandidaten:
            break
        kandidaten.sort(key=lambda x: x[0])
        verbessert = False
        for k_alt, schl, gruppe in kandidaten:
            probiert.add(schl)
            neu = _ohne_gruppe(G, kanten, gruppe, seed, terminals, gewicht)
            if neu is None:
                continue
            vorher, nachher = _summe(G, kanten, gewicht), _summe(G, neu, gewicht)
            if nachher < vorher - 1.0:
                ersparnis += vorher - nachher
                kanten = neu
                n_gestrichen += 1
                verbessert = True
                break
        if not verbessert:
            break
    return kanten, n_gestrichen, ersparnis


def _laenge_nachbessern(G, kanten, seed, terminals, gewicht, max_dist_m):
    """Terminals mit Baumweg > max_dist_m bekommen eine Abkuerzung: billigster Weg vom Terminal ueber Nicht-Baumknoten zu einem
    Baumknoten n mit laenge(seed->n) + laenge(Abkuerzung) <= max. Die Abkuerzung schliesst mit dem alten Baumweg einen Kreis; der
    wird gezielt an der teuersten alten Kante geoeffnet, deren Wegfall kein Terminal ueber die Hoechstlaenge schiebt (so bleibt
    der Baum ein Baum - kein Zickzack ueber Querungen). Terminals, die auch auf dem kuerzesten Weg zu weit liegen, bleiben unveraendert.
    -> (kanten, anzahl_zu_lang, anzahl_unheilbar)"""
    halten = set(terminals) | {seed}
    T = _baum_graph(G, kanten)
    laengen = nx.single_source_dijkstra_path_length(T, seed, weight="length")
    zu_lang = sorted([t for t in terminals if laengen.get(t, float("inf")) > max_dist_m],
                     key=lambda t: -laengen.get(t, float("inf")))
    unheilbar = 0
    for t in zu_lang:
        if laengen.get(t, float("inf")) <= max_dist_m:
            continue                                     # durch eine fruehere Abkuerzung schon in Ordnung
        baum_knoten = set(T.nodes)
        G3 = G.subgraph([v for v in G.nodes if v not in baum_knoten or v == t])
        try:
            d3, p3 = nx.single_source_dijkstra(G3, t, weight="length")
        except Exception:
            d3, p3 = {t: 0.0}, {t: [t]}
        best, best_p = float("inf"), None
        for n in baum_knoten:
            if n == t:
                continue
            for m in G.neighbors(n):
                if m not in d3 or (m in baum_knoten and m != t):
                    continue
                lm = float(G[m][n].get("length", 0.0))
                if laengen.get(n, float("inf")) + d3[m] + lm > max_dist_m:
                    continue
                pfad = p3[m] + [n]
                c = sum(_kosten(G, frozenset((a, b)), gewicht) for a, b in zip(pfad[:-1], pfad[1:]))
                if c < best:
                    best, best_p = c, pfad
        if best_p is None:
            unheilbar += 1
            continue
        neu = {frozenset((a, b)) for a, b in zip(best_p[:-1], best_p[1:])}
        n = best_p[-1]
        # Kreis oeffnen: alte Baumkanten auf dem Weg n -> t, teuerste zuerst, Hoechstlaenge fuer alle Terminals pruefen
        alt_weg = nx.shortest_path(T, n, t, weight="length")
        alt_kanten = sorted((frozenset((a, b)) for a, b in zip(alt_weg[:-1], alt_weg[1:])), key=lambda k: -_kosten(G, k, gewicht))
        vorher_ok = {x for x in terminals if laengen.get(x, float("inf")) <= max_dist_m}
        gewaehlt = None
        for k in alt_kanten:
            T2 = _baum_graph(G, (kanten | neu) - {k})
            l2 = nx.single_source_dijkstra_path_length(T2, seed, weight="length")
            if l2.get(t, float("inf")) <= max_dist_m and all(l2.get(x, float("inf")) <= max_dist_m for x in vorher_ok):
                gewaehlt = k
                break
        if gewaehlt is None:
            unheilbar += 1
            continue
        kanten = _stutzen(G, (kanten | neu) - {gewaehlt}, halten)
        T = _baum_graph(G, kanten)
        laengen = nx.single_source_dijkstra_path_length(T, seed, weight="length")
    return kanten, len(zu_lang), unheilbar


def transit_hausquerungen(G, kanten):
    """Hausquerungen im Baum, deren Hausknoten noch weitere Baumkanten hat (= Durchgang zur Gegenseite statt Hausanschluss)."""
    T = _baum_graph(G, kanten)
    erg = []
    for k in kanten:
        a, b = tuple(k)
        if G[a][b].get("quelle_id") == "hausquerung":
            haus = b if str(a).endswith("_q") else a
            if T.degree(haus) >= 2:
                erg.append(k)
    return erg


def _als_querung_bepreisen(G, k, gewicht):
    """Hausquerungs-Kante auf den Preis einer Fahrbahnquerung mit Seitenwechsel-Aufschlag heben (G.graph querung_preis aus kern)."""
    a, b = tuple(k)
    d = G[a][b]
    pr = G.graph.get("querung_preis") or {}
    neu = float(d.get("length", 0.0)) * float(pr.get("eur_m", 180.0)) + float(pr.get("kopfloch", 508.75)) + float(pr.get("aufschlag", 0.0))
    alt = float(d.get(gewicht, 0.0) or 0.0)
    if neu > alt:
        d[gewicht] = neu
        d["transit"] = True
        return neu - alt
    return 0.0


def vzk_baum(G, seed, terminals, gewicht="cost", max_dist_m=750.0, log=print, name="", runden=6):
    """-> (kanten: set(frozenset(u, v)), fehlend: [terminal], bericht: dict)"""
    terminals = list(dict.fromkeys(str(t) for t in terminals))
    fehlend = [t for t in terminals if t not in G]
    terminals = [t for t in terminals if t in G]
    gefuellt = gewichte_fuellen(G, gewicht)
    try:
        dist, pfade = nx.single_source_dijkstra(G, seed, weight=gewicht)
    except Exception as e:
        raise RuntimeError("Wegsuche fehlgeschlagen ({})".format(str(e)[:80]))
    erreichbar = [t for t in terminals if t in pfade]
    fehlend += [t for t in terminals if t not in pfade]
    bericht = {"gefuellt": gefuellt, "fehlend": len(fehlend)}
    if not erreichbar:
        return set(), fehlend, bericht
    # Vergleichswert: Vereinigung der Einzelpfade (altes Verfahren)
    pfad_kanten = set()
    for t in erreichbar:
        p = pfade[t]
        pfad_kanten.update(frozenset((a, b)) for a, b in zip(p[:-1], p[1:]))
    bericht["pfade_eur"] = _summe(G, pfad_kanten, gewicht)
    bericht["pfade_doppelt_m"] = doppelt_m(G, pfad_kanten)
    knoten = set(erreichbar) | {seed}
    komp = nx.node_connected_component(G, seed)
    n_seiten, ersparnis, n_lang, unheilbar, n_transit = 0, 0.0, 0, 0, 0
    kanten = set()
    for runde in range(max(1, runden)):
        # 1. Steinerbaum auf der Komponente des Sitzes
        try:
            sub = G.subgraph(komp)
            T = steiner_tree(sub, list(knoten), weight=gewicht, method="mehlhorn")
            kanten = {frozenset((a, b)) for a, b in T.edges()}
            if not all(t in T for t in knoten):
                raise RuntimeError("Steinerbaum ohne alle Terminals")
        except Exception as e:
            log("{}: Steinerbaum nicht moeglich ({}) - Pfadvereinigung".format(name, str(e)[:80]))
            kanten = set(pfad_kanten)
        kanten = _bereinigen(G, kanten, knoten, gewicht)
        if runde == 0:
            bericht["steiner_eur"] = _summe(G, kanten, gewicht)
        # 2. Seitenregel
        kanten, n_seiten, ersparnis = seitenregel(G, kanten, seed, erreichbar, gewicht)   # Zahlen je Durchgang, der letzte zaehlt
        # 3. Vzk-Hoechstlaenge
        kanten, n_l, u_l = _laenge_nachbessern(G, kanten, seed, erreichbar, gewicht, max_dist_m)
        if n_l:
            n_lang, unheilbar = n_l, u_l
            kanten, n2, e2 = seitenregel(G, kanten, seed, erreichbar, gewicht)
            n_seiten, ersparnis = n_seiten + n2, ersparnis + e2
            kanten, _, _ = _laenge_nachbessern(G, kanten, seed, erreichbar, gewicht, max_dist_m)
        # 4. Hausquerungen als Durchgang -> wie Fahrbahnquerung bepreisen und neu rechnen
        transit = transit_hausquerungen(G, kanten)
        if not transit or runde == runden - 1:
            if transit:
                log("{}: {} Hausquerungen bleiben Durchgang zur Gegenseite (Preis einer Fahrbahnquerung)".format(name, len(transit)))
            break
        for k in transit:
            _als_querung_bepreisen(G, k, gewicht)
        n_transit += len(transit)
    bericht["seiten_gestrichen"], bericht["seiten_ersparnis"] = n_seiten, ersparnis
    bericht["zu_lang_unheilbar"] = unheilbar
    bericht["transit_bepreist"] = n_transit
    kanten = _bereinigen(G, kanten, knoten, gewicht)
    T = _baum_graph(G, kanten)
    bericht["zyklen"] = T.number_of_edges() - T.number_of_nodes() + nx.number_connected_components(T)
    bericht["pfade_eur"] = _summe(G, pfad_kanten, gewicht)
    laengen = nx.single_source_dijkstra_path_length(T, seed, weight="length")
    bericht["zu_lang"] = n_lang
    bericht["vzk_max_m"] = max((laengen.get(t, 0.0) for t in erreichbar), default=0.0)
    bericht["baum_eur"] = _summe(G, kanten, gewicht)
    bericht["doppelt_m"] = doppelt_m(G, kanten)
    if log:
        if gewicht == "length":
            log("{}: Steinerbaum {:.0f} m statt {:.0f} m Pfadvereinigung, laengster Vzk-Weg {:.0f} m{}".format(
                name, bericht["baum_eur"], bericht["pfade_eur"], bericht["vzk_max_m"],
                ", {} Haeuser ueber {:.0f} m nachgebessert".format(n_lang, max_dist_m) if n_lang else ""))
        else:
            log("{}: Baum {:,.0f} EUR statt {:,.0f} EUR Pfadvereinigung (Steiner {:,.0f}; Seitenregel {} Abschnitte gestrichen = -{:,.0f}); "
                "beidseitig gebaut {:.0f} m statt {:.0f} m; {} Hausquerungen als Durchgang umbepreist; laengster Vzk-Weg {:.0f} m{}".format(
                    name, bericht["baum_eur"], bericht["pfade_eur"], bericht["steiner_eur"], n_seiten, ersparnis,
                    bericht["doppelt_m"], bericht["pfade_doppelt_m"], n_transit, bericht["vzk_max_m"],
                    ", {} Haeuser ueber {:.0f} m nachgebessert{}".format(
                        n_lang, max_dist_m, " ({} auch auf kuerzestem Weg zu weit - NVT-Sitz pruefen)".format(unheilbar) if unheilbar else "")
                    if n_lang else "").replace(",", "."))
    return kanten, fehlend, bericht
