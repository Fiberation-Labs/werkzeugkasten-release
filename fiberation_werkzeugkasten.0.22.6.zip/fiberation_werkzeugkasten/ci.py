# -*- coding: utf-8 -*-
"""Fiberation-CI fuer Dialoge: Orange, Schwarz/Weiss, Wortmarke, Claim."""
import os

from qgis.PyQt.QtGui import QPixmap
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QVBoxLayout, QWidget

HERE = os.path.dirname(__file__)
ORANGE = "#F5A73E"
ORANGE_DUNKEL = "#D98A1E"
SCHWARZ = "#1A1A1A"
GRAU = "#6B6B6B"
GRAU_HELL = "#E6E6E6"
CLAIM = "Engineering and Consulting"
FIRMA = "Fiberation GmbH"

STIL_KNOPF = (
    "QPushButton {{ background:{o}; color:{s}; border:none; border-radius:6px; padding:8px 16px; font-weight:600; }}"
    "QPushButton:hover {{ background:{od}; }}"
    "QPushButton:disabled {{ background:{g}; color:{gr}; }}"
).format(o=ORANGE, od=ORANGE_DUNKEL, s=SCHWARZ, g=GRAU_HELL, gr=GRAU)
STIL_KNOPF_ZWEIT = (
    "QPushButton {{ background:transparent; color:palette(text); border:1px solid {g}; border-radius:6px; padding:7px 14px; }}"
    "QPushButton:hover {{ border-color:{o}; }}"
).format(g=GRAU, o=ORANGE)
STIL_KACHEL = (
    "QFrame {{ border:1px solid {g}; border-radius:8px; border-top:4px solid {o}; background:palette(base); }}"
).format(g=GRAU_HELL, o=ORANGE)


def dunkles_thema():
    """True, wenn die Fensterfarbe dunkel ist (dann weisses Logo)."""
    try:
        return QApplication.instance().palette().window().color().lightness() < 128
    except Exception:
        return False


def logo_label(hoehe=44, mit_claim=False):
    """QLabel mit der Wortmarke (hell/dunkel je Thema)."""
    datei = "logo_claim.png" if mit_claim else ("logo_dunkel.png" if dunkles_thema() else "logo_hell.png")
    lab = QLabel()
    pm = QPixmap(os.path.join(HERE, "resources", datei))
    if not pm.isNull():
        lab.setPixmap(pm.scaledToHeight(hoehe, 1))
    else:
        lab.setText("Fiberation")
        lab.setStyleSheet("font-size:22px; font-weight:700; color:{};".format(ORANGE))
    return lab


def kopf_widget(titel, unter, logo_hoehe=34, titel_px=18):
    """Kopf aller Dialoge und des Hauptfensters: Logo links, rechts Titel und eine Zeile Untertitel, darunter der orange Strich.
    Als Widget, damit das Hauptfenster den Kopf einer eingebetteten Seite ausblenden und den Text in seinem eigenen Kopf zeigen kann
    (kopf.titel / kopf.unter sind die QLabel, kopf.titel_text / kopf.unter_text die Texte)."""
    w = QWidget()
    w.setObjectName("fwk_kopf")
    lay = QVBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(6)
    zeile = QHBoxLayout()
    zeile.addWidget(logo_label(logo_hoehe))
    zeile.addStretch(1)
    rechts = QVBoxLayout()
    rechts.setSpacing(0)
    w.titel = QLabel(titel)
    w.titel.setStyleSheet("font-size:{}px; font-weight:700;".format(titel_px))
    w.titel.setAlignment(Qt.AlignRight)
    w.unter = QLabel(unter)
    w.unter.setStyleSheet("color:{}; font-size:11px;".format(GRAU))
    w.unter.setAlignment(Qt.AlignRight)
    rechts.addWidget(w.titel)
    rechts.addWidget(w.unter)
    zeile.addLayout(rechts)
    lay.addLayout(zeile)
    strich = QFrame()
    strich.setFixedHeight(3)
    strich.setStyleSheet("background:{}; border:none;".format(ORANGE))
    lay.addWidget(strich)
    w.titel_text = titel
    w.unter_text = unter
    return w


def fuss_text(version):
    return "{} · {} · Version {}".format(FIRMA, CLAIM, version)


def nvt_symbol(farbe=ORANGE, groesse_mm=5.0):
    """NVT-Markersymbol wie in Plan[Goo] (topas_nvt-rectangle: Kreis mit Quadrat), Farbe frei - Vorgabe Fiberation-Orange fuer
    Vorschlaege des Werkzeugkastens, abgegrenzt von Rot (NVt Planung) und Schwarz (Bestand) in Plan[Goo]. -> QgsMarkerSymbol"""
    from qgis.core import QgsMarkerSymbol, QgsSvgMarkerSymbolLayer, QgsUnitTypes
    from qgis.PyQt.QtGui import QColor
    lyr = QgsSvgMarkerSymbolLayer(os.path.join(HERE, "resources", "nvt_orange.svg"), groesse_mm, 0.0)
    lyr.setFillColor(QColor(farbe))
    lyr.setStrokeWidth(0.0)
    lyr.setSizeUnit(QgsUnitTypes.RenderMillimeters)
    sym = QgsMarkerSymbol()
    sym.changeSymbolLayer(0, lyr)
    return sym


def rgba(hex6, alpha=255):
    """'#RRGGBB' + Alpha (0-255) -> 'r,g,b,a' fuer QGIS-Symbole. Achtung: '#RRGGBBAA' liest QGIS als #AARRGGBB - falsche Farbe, fast
    deckend (Befund 16.09.2026: 'gelbe Fuellung' der Ampel war '#FFFFFF00' = deckendes Gelb)."""
    h = hex6.lstrip("#")
    return "{},{},{},{}".format(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), int(alpha))


def label_kasten(lyr, ausdruck, groesse=7.5, rahmen=None, farbe_text="#1A1A1A", min_massstab=None, polygon=False, abstand_mm=None):
    """Label im weissen Kasten (Markus 16.09.2026): halbtransparent weisser Hintergrund, abgerundete Ecken, Rahmen in einer
    Farbe oder nach Ausdruck (z. B. Gebiets- oder Ampelfarbe), HTML im Text erlaubt (<b>, <span style="font-size:10pt;color:#..">).
    Der Kasten hebt den Text von Flurstuecksgrenzen und Karte ab, wo der duenne weisse Rand untergeht.
    rahmen: '#RRGGBB' oder ein QGIS-Ausdruck, der eine Farbe liefert. polygon=True: Label waagerecht im Polygon (Schwerpunkt innen).
    min_massstab: Label erst ab diesem Massstab (z. B. 5000 = ab 1:5000 beim Hineinzoomen)."""
    from qgis.core import (QgsPalLayerSettings, QgsProperty, QgsTextBackgroundSettings, QgsTextFormat, QgsUnitTypes,
                           QgsVectorLayerSimpleLabeling)
    from qgis.PyQt.QtCore import QSizeF
    from qgis.PyQt.QtGui import QColor
    st = QgsPalLayerSettings()
    st.fieldName = ausdruck
    st.isExpression = True
    st.enabled = True
    if min_massstab:
        st.scaleVisibility = True
        st.minimumScale = float(min_massstab)
        st.maximumScale = 0
    st.multilineAlign = QgsPalLayerSettings.MultiLeft if hasattr(QgsPalLayerSettings, "MultiLeft") else 0
    if polygon:
        try:
            from qgis.core import Qgis
            st.placement = Qgis.LabelPlacement.Horizontal
        except Exception:
            st.placement = QgsPalLayerSettings.Horizontal
        st.centroidInside = True
        st.fitInPolygonOnly = False           # sonst faellt das Label bei kleinen Polygonen ganz weg
    elif abstand_mm is not None:
        try:
            st.placement = QgsPalLayerSettings.OrderedPositionsAroundPoint
            st.dist = float(abstand_mm)
        except Exception:
            pass
    # Kasten-Labels sind die Hauptinformation der Ebene: lieber ueberlappen als wegfallen
    try:
        from qgis.core import Qgis
        st.placementSettings().setOverlapHandling(Qgis.LabelOverlapHandling.AllowOverlapIfRequired)
    except Exception:
        pass
    st.priority = 8
    fmt = QgsTextFormat()
    fmt.setSize(groesse)
    fmt.setColor(QColor(farbe_text))
    fmt.setAllowHtmlFormatting(True)          # <b>, <span style="font-size:..;color:..">, seit QGIS 3.14
    hg = QgsTextBackgroundSettings()
    hg.setEnabled(True)
    hg.setType(QgsTextBackgroundSettings.ShapeRectangle)
    hg.setSizeType(QgsTextBackgroundSettings.SizeBuffer)
    hg.setSize(QSizeF(1.0, 0.8))
    hg.setSizeUnit(QgsUnitTypes.RenderMillimeters)
    hg.setRadii(QSizeF(1.0, 1.0))
    hg.setRadiiUnit(QgsUnitTypes.RenderMillimeters)
    hg.setFillColor(QColor(255, 255, 255, 217))
    hg.setStrokeWidth(0.6)
    hg.setStrokeWidthUnit(QgsUnitTypes.RenderMillimeters)
    hg.setStrokeColor(QColor(rahmen if rahmen and str(rahmen).startswith("#") else GRAU))
    fmt.setBackground(hg)
    st.setFormat(fmt)
    if rahmen and not str(rahmen).startswith("#"):
        st.dataDefinedProperties().setProperty(QgsPalLayerSettings.ShapeStrokeColor, QgsProperty.fromExpression(rahmen))
    lyr.setLabelsEnabled(True)
    lyr.setLabeling(QgsVectorLayerSimpleLabeling(st))
    return st


def farb_ausdruck(feld, farben, sonst=GRAU):
    """QGIS-Ausdruck: Feldwert -> Farbe, z. B. farb_ausdruck('ampel', {'rot': '#C62828', ...})."""
    teile = " ".join("WHEN \"{}\" = '{}' THEN '{}'".format(feld, str(k).replace("'", "''"), v) for k, v in farben.items())
    return "CASE {} ELSE '{}' END".format(teile, sonst)
