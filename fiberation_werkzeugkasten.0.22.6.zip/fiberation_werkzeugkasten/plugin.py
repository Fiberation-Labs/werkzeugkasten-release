# -*- coding: utf-8 -*-
"""Fiberation Werkzeugkasten: Menue, Werkzeugleiste, Hauptfenster mit Seiten.

Grundsatz: jedes Werkzeug wird per Knopf ausgeloest. Einzige Automatik ist das Unterdruecken der Plan[Goo]-Startwarnungen
(Schalter in den Einstellungen). Telekom-Dateien werden nie geaendert, alle Eingriffe sind Laufzeit-Patches.
"""
import configparser
import os

from qgis.PyQt.QtCore import QSettings
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox

HERE = os.path.dirname(__file__)
NAME = "Fiberation Werkzeugkasten"
MENUE = "&" + NAME
EINSTELLUNG_WARNUNGEN = "fiberation_werkzeugkasten/startwarnungen_unterdruecken"


def version():
    cp = configparser.ConfigParser()
    try:
        cp.read(os.path.join(HERE, "metadata.txt"), encoding="utf-8")
        return cp.get("general", "version")
    except Exception:
        return "?"


class WerkzeugkastenPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.aktionen = []
        self.startfenster = None

    # --- Lebenszyklus -----------------------------------------------------------------------------------------------------------
    def initGui(self):
        icon = QIcon(os.path.join(HERE, "resources", "icon.svg"))
        mw = self.iface.mainWindow()
        self.aktion_start = QAction(icon, NAME, mw)
        self.aktion_start.triggered.connect(self.oeffnen)
        self.iface.addToolBarIcon(self.aktion_start)
        self.aktionen.append(self.aktion_start)
        from . import ablauf
        eintraege = [("Werkzeugkasten oeffnen", self.oeffnen)]
        for nr, titel_, kurz, lang, schluessel, art, anker in ablauf.SCHRITTE:
            if schluessel:
                eintraege.append(("{}  {}".format(nr, titel_), lambda *_, s=schluessel: self.zeige(s)))
        eintraege += [
            ("Plan[Goo]: Trassenbefuellung Eigenausbau freischalten", self.befuellung),
            ("Plan[Goo]: Projektpfad pruefen (Arbeitskopie)", self.pfad),
            ("Einstellungen", self.einstellungen),
            ("Anleitung", self.anleitung),
        ]
        for text, slot in eintraege:
            a = QAction(text, mw)
            a.triggered.connect(slot)
            self.iface.addPluginToMenu(MENUE, a)
            self.aktionen.append(a)
        try:
            from . import formular
            formular.projekt_beobachten()
        except Exception:
            pass
        if self.warnungen_unterdruecken():
            try:
                from . import patches
                patches.startwarnungen_aus()
            except Exception:
                pass

    def unload(self):
        try:
            from . import formular
            formular.projekt_loslassen()
        except Exception:
            pass
        for a in self.aktionen:
            self.iface.removePluginMenu(MENUE, a)
        if self.aktionen:
            self.iface.removeToolBarIcon(self.aktionen[0])
        self.aktionen = []
        if self.startfenster is not None:
            try:
                self.startfenster.aufraeumen()
            except Exception:
                pass
            self.startfenster = None

    # --- Einstellungen ------------------------------------------------------------------------------------------------------------
    @staticmethod
    def warnungen_unterdruecken():
        return QSettings().value(EINSTELLUNG_WARNUNGEN, True, type=bool)

    @staticmethod
    def warnungen_setzen(wert):
        QSettings().setValue(EINSTELLUNG_WARNUNGEN, bool(wert))

    # --- Hauptfenster und Seiten ------------------------------------------------------------------------------------------------
    def oeffnen(self):
        """Hauptfenster zeigen (Uebersicht, wenn es neu entsteht; sonst die zuletzt offene Seite)."""
        from .startfenster import Werkzeugfenster
        if self.startfenster is None:
            self.startfenster = Werkzeugfenster(self, self.iface.mainWindow())
            self.startfenster.finished.connect(self._start_geschlossen)
            if Werkzeugfenster.angedockt_gewuenscht():
                self.startfenster.andocken()
        self.startfenster.hervorholen()
        return self.startfenster

    def _start_geschlossen(self, *_):
        """Eigenes Fenster geschlossen (angedockt kommt das Signal nicht: das X blendet nur das Panel aus)."""
        if self.startfenster is not None and self.startfenster.ist_angedockt():
            return
        self.startfenster = None

    def zeige(self, schluessel, anker=None):
        """Schritt (oder 'anleitung' mit Kapitel-Anker) als Seite im Hauptfenster oeffnen. Gibt die Seite zurueck."""
        return self.oeffnen().zeige(schluessel, anker=anker)

    def dialog_bauen(self, schluessel):
        """Werkzeugdialog zu einem Schritt erzeugen (wird vom Hauptfenster eingebettet)."""
        mw = self.iface.mainWindow()
        if schluessel == "umfeld":
            from .werkzeuge.umfeld.dialog import UmfeldDialog
            return UmfeldDialog(self.iface, mw)
        if schluessel == "adressen":
            from .werkzeuge.adressen.dialog import AdressenDialog
            return AdressenDialog(self.iface, mw)
        if schluessel == "cluster":
            from .werkzeuge.cluster.dialog import ClusterDialog
            return ClusterDialog(self.iface, mw)
        if schluessel == "standort":
            from .werkzeuge.standort.dialog import StandortDialog
            return StandortDialog(self.iface, mw)
        if schluessel == "trassen":
            from .werkzeuge.trassen.dialog import TrassenDialog
            return TrassenDialog(self.iface, mw)
        if schluessel == "bestand":
            from .werkzeuge.bestand.dialog import BestandDialog
            return BestandDialog(self.iface, mw)
        if schluessel == "hk":
            from .werkzeuge.hk.dialog import HkDialog
            return HkDialog(self.iface, mw)
        if schluessel == "hktrasse":
            from .werkzeuge.hktrasse.dialog import HkTrasseDialog
            return HkTrasseDialog(self.iface, mw)
        if schluessel == "kollo":
            from .werkzeuge.kollo.dialog import KolloDialog
            return KolloDialog(self.iface, mw)
        if schluessel == "zfp":
            from .werkzeuge.zfp.dialog import ZfpDialog
            return ZfpDialog(self.iface, mw)
        if schluessel == "wesi":
            from .werkzeuge.wesi.dialog import WesiDialog
            return WesiDialog(self.iface, mw)
        if schluessel == "uebergabe":
            from .werkzeuge.uebergabe.dialog import UebergabeDialog
            return UebergabeDialog(self.iface, mw)
        raise KeyError(schluessel)

    # --- Schritte (Slots fuer Menue und aeltere Aufrufer) -----------------------------------------------------------------------------
    def umfeld(self):
        return self.zeige("umfeld")

    def adressen(self):
        return self.zeige("adressen")

    def cluster(self):
        return self.zeige("cluster")

    def standort(self):
        return self.zeige("standort")

    def trassen(self):
        return self.zeige("trassen")

    def wesi(self):
        return self.zeige("wesi")

    def uebergabe(self, gpkg=None):
        """Schritt 10; gpkg = Schnitt aus Schritt 3 zum Vorbelegen (Knopf 'Weiter mit 10')."""
        d = self.zeige("uebergabe")
        if gpkg and d is not None:
            d.setze_quelle(gpkg)
        return d

    # --- Plan[Goo]-Helfer -----------------------------------------------------------------------------------------------------------
    def befuellung(self):
        from . import patches
        mw = self.iface.mainWindow()
        try:
            text = patches.befuellung_freischalten(self.iface)
        except Exception as e:
            QMessageBox.critical(mw, NAME, "Freischalten fehlgeschlagen:\n{!r}".format(e)[:700])
            return
        QMessageBox.information(mw, NAME, text)

    def pfad(self):
        from .pfad import PfadDialog
        PfadDialog(self.iface.mainWindow()).exec_()

    def einstellungen(self):
        from .einstellungen import EinstellungenDialog
        EinstellungenDialog(self, self.iface.mainWindow()).exec_()

    def anleitung(self, anker=None):
        """Anleitung als Seite im Hauptfenster; anker = Kapitel (umfeld, w1, w2, w3, trassen, wesi, w4, helfer)."""
        return self.zeige("anleitung", anker=anker if isinstance(anker, str) else None)
