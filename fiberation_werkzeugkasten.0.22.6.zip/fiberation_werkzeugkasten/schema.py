# -*- coding: utf-8 -*-
"""Datenschema aller Ergebnisebenen an einer Stelle (Markus 12.10.2026: "ein Datenschema" - Spalten und Statuswerte standen bisher in
jedem Kern einzeln und die Statuswerte bedeuteten je Ebene etwas anderes).

Ein Statussatz fuer NVT (Schritt 5), Hk-Straenge (Schritt 7) und Trassen: offen -> in Arbeit -> geprueft -> uebertragen.
Die Plan[Goo]-Trassenfelder sind der gemeinsame Kern beider Planungen; leere Werte sind erlaubt.
ergaenzen() bringt aeltere GeoPackages auf den Stand (fehlende Spalten mit Leerwert)."""

STATUS = ("offen", "in Arbeit", "geprueft", "uebertragen")

# Was Plan[Goo] je Trasse kennt (MetaTrasse): CONST_METHOD, SURFACE, ALLOWANCE, LOCATION_HINT, WeSi, SUB_TYPE; dazu BESTANDSTRASSE als bestand
PLANGOO_TRASSE_FELDER = ("bauverfahren", "surface", "allowance", "location_hint", "wesi", "sub_type")

# Schritt 5: Ebenen vorlage, planung, final (+ stand), uebergabe (+ herkunft, hk)
TRASSEN_SPALTEN = ["uid", "nvt", "typ", "sub_type", "bauverfahren", "surface", "allowance", "location_hint", "wesi", "bestand",
                   "laenge_m", "quelle", "kante", "status", "hinweis"]
TRASSEN_UEBERGABE_SPALTEN = TRASSEN_SPALTEN + ["herkunft", "hk"]
TRASSEN_TYPEN = ("Laengstrasse", "Hauszufuehrung", "Zufuehrung")

# Schritt 7: Ebene hk_planung - dieselben Plan[Goo]-Felder wie Schritt 5 plus Hk-Eigenes (Strang, Rohrklasse, MegaPlan-ID)
HK_PLANUNG_SPALTEN = ["uid", "hk", "typ", "bestand", "quelle_id", "rohrklasse", "mp_id", "bauverfahren", "surface", "allowance", "location_hint", "wesi",
                      "sub_type", "laenge_m", "status", "hinweis", "quelle"]

ZAHL_SPALTEN = {"bestand": 0, "laenge_m": 0.0}


def leerwert(spalte):
    return ZAHL_SPALTEN.get(spalte, "")


def ergaenzen(gdf, spalten):
    """Fehlende Spalten mit Leerwert anlegen (aeltere Ergebnisse); gibt gdf zurueck."""
    for c in spalten:
        if c not in gdf:
            gdf[c] = leerwert(c)
    return gdf
