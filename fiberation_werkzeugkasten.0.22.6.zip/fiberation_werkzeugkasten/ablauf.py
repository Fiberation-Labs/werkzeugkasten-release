# -*- coding: utf-8 -*-
"""Der Planungsablauf als Daten (ohne Qt): Schritte, Abschnitte, Helfer. Eine Quelle fuer Hauptfenster, Menue und Anleitung,
damit ueberall dieselben Ueberschriften stehen (Markus 18.09.2026: "die Ueberschriften sind irrefuehrend").

Je Schritt: Nummer, Titel, Kurztext (eine Zeile), Beschreibung (Tooltip), Schluessel (= Name der Seite und des Slots im Plugin,
None = noch nicht gebaut), Schluessel des Ergebnisses in dateiwahl oder None, Anker in der Anleitung."""

SCHRITTE = [
    ("0", "Umfeld und Grundkarten laden", "ALKIS, Orthofoto, Schutzgebiete, Gewaesser und OSM-Umfeld als Layer",
     "ALKIS, Orthofoto und basemap.de des Landes, Schutzgebiete und Gewaesser (BfN, LINFOS, Wasserschutz) als WMS, dazu Baeume, "
     "Gewaesser, Schutzgebiete, Bahn, Freileitungen und Bruecken aus OSM als GeoPackage - alles in EPSG:3857.", "umfeld", "umfeld", "umfeld"),
    ("1", "Bestand aus Telekom-Lieferung", "Bestandsrohre, -kabel, Schaechte, Masten und Trassen aus Extern-Export, Plan[Goo]-Projekt, MegaPlan-Rohranlage oder Comsof-Rohrliste",
     "Aus dem, was die Telekom liefert (Comsof-Extern-Export, Plan[Goo]-Projekt, MegaPlan-Export Rohranlage, Comsof-Rohrliste IN_ExistingPipes), alles herausziehen, was Bestand ist: Rohre mit Rohrklasse, freien Rohren "
     "und Nutzbarkeit, Kabel mit Kabellinie und freien Fasern, Schaechte, Masten, KVz, Muffen, vorhandene Hauptkabel, HVt - jeweils mit "
     "Kennzeichen, ob der Comsof-Plan das Stueck schon nutzt. Layer mit Stil, Tabelle der Kennzahlen, Bericht, GeoPackage.",
     "bestand", "bestand", "bestand"),
    ("2", "Adressen und Bedarf pruefen", "Bedarfsliste gegen ALKIS, Bedarf nach ZTV 21, Bauluecken und fehlende Gebaeude",
     "Telekom-Bedarfsliste oder die APL des offenen Projekts laden, gegen ALKIS-Gebaeude pruefen (Ampel, Dubletten, Lagevorschlaege), "
     "fehlenden Bedarf und moegliche Bauluecken aus ALKIS finden, Bedarf je Adresse nach ZTV 21. Ausgabe: GeoPackage und Pruefbericht.",
     "adressen", "adresspruefung", "w1"),
    ("3", "NVT-Gebiete bilden", "Adressen zu NVT-Gebieten schneiden, Vorgaben des Planers, Namen, Kennzahlen, Ampel",
     "Adressen zu NVT-Gebieten schneiden (netzorientiert, Grenzen nach ZTV 21 je Ausbautreiber), Vorgabe-Gebiete des Planers, "
     "Nummernkreis und Umbenennen, Kennzahlen, Hk-Fasern und Ampel je Gebiet, Sitzvorschlag, Planer-Aenderungen uebernehmen.",
     "cluster", "nvt_gebiete", "w2"),
    ("4", "NVT-Standorte und Sicherung", "NVT auf Gehweg, Bankett oder neben Bestand setzen; Checkliste, Sicherung, Alternative, Gesamtstatus",
     "Sitzvorschlag je NVT gegen ALKIS und OSM pruefen (nie auf der Fahrbahn, Gehwegrest 1,5 m, Abstand Grenze/Gebaeude/Kreuzung, Bonus neben "
     "Bestand-NVT), Korridor, Flurstueck und Adresse. Dann je Standort die Pruef-Checkliste P1-P8, Zustimmung § 127 TKG bzw. Gestattungsvertrag, "
     "Alternativstandort und Gesamtstatus (Gesichert/Offen/Abgelehnt) fuehren; Excel, Pruefblatt und Lageplaene 1:1000.",
     "standort", "nvt_standorte", "w3"),
    ("5", "Trassen je NVT planen", "Vorlage je NVT, Planung zeichnen, Pruefung mit Befunden, Uebertragung nach Plan[Goo]",
     "Je NVT das Kondensat der Trassen (Vzk-Baum, Hauszufuehrungen, Zufuehrung) aus dem Netz von Schritt 3, einem Comsof-Export oder "
     "Plan[Goo]; die Telekom-Trassen aus Schritt 1 bekommen im Weg den Vorzug (der Vzk baut dort neu). Planung mit den Werkzeugen wie in "
     "Plan[Goo] (zeichnen, schneiden, verschmelzen, einrasten, Attribute), pruefen, NVT fuer NVT nach Plan[Goo] uebertragen.", "trassen", "trassen", "trassen"),
    ("6", "Hauptkabel clustern", "NVT zu Hk-Straengen clustern: Deckel NVT und Fasern, Straenge liegen beieinander, Reserve, Nummernkreis",
     "NVT aus Schritt 3 zu Hauptkabel-Straengen clustern (hoechstens 5 NVT und 96 Fasern je Strang, Fasern nach ZTV 21, Straenge sind "
     "Teilbaeume des kuerzesten Wegs von der Betriebsstelle und liegen deshalb beieinander). Der Clusterbaum laeuft auf dem Netz von Schritt 3 "
     "mit Vzk-Trassen (Schritt 5) und Bestand (Schritt 1). Ausgabe: Strang-Polygone mit Reserve, NVT mit Strang und Reihenfolge, "
     "Betriebsstelle, Nummernkreis des BVT. Den Weg je Strang rechnet Schritt 7.", "hk", "hk", "hk"),
    ("7", "Hk-Trasse je Strang", "Weg-Vorlage je Strang (Bestand als Weg), Hk-Trasse zeichnen, Vorlage oder Bestand uebernehmen, pruefen",
     "Strang fuer Strang wie in Schritt 5 NVT fuer NVT: Weg von der Betriebsstelle zu den NVT des Strangs als gestrichelte Vorlage - mit Bestand "
     "aus Schritt 1 faehrt der Hk in potenziell freie Rohre (gruen) und folgt sonst der Telekom-Trasse (blau) -, Kabelgroesse je Abschnitt, "
     "Muffenvorschlaege. Der Planer zeichnet die Hk-Trasse nach oder uebernimmt Vorlage bzw. Bestand, prueft (Verbindung BSt -> NVT, Fasern). "
     "Rohre und Kabel legt er danach in Plan[Goo]; nach Plan[Goo] ueber Schritt 10.", "hktrasse", "hk", "hktrasse"),
    ("8", "Kollokation (Open Access)", "Kollokationspunkte nach ZTV 21 Kap. 13, Kollokationsmuffen, Kollo-Wege auf der Hk-Trasse bis zur BSt mit SNR je Abschnitt",
     "Open-Access-Punkte bestimmen (Materialkonzept 5.0: NVT > 95 WE, bis 4.1 jeder NVT; Gebaeude > 68 WE immer), kleine NVT zu Kollokationsmuffen "
     "buendeln (bis 10 NVT, 96-208 WE, 3 Fasern je WE zur Muffe), je Punkt 3 Kollo-SNR auf der Hk-Trasse aus Schritt 7 bis zur Betriebsstelle; "
     "SNR je Abschnitt zaehlen, Kollokationskabel NVT -> Muffe. Layer, Tabelle, Bericht - der Planer entscheidet, Plan[Goo] legt die Rohre.",
     "kollo", "kollo", "kollo"),
    ("9", "Wegesicherung: Gewaesser und Landesstrassen", "Gewaesserquerungen und Landesstrassen ausserhalb der Ortsdurchfahrt fuer die Antraege",
     "Tiefbautrassen, die ein Gewaesser queren (ALKIS/ATKIS, Durchlaesse, OSM), und Trassen auf Flurstuecken einer Landesstrasse "
     "ausserhalb der Ortsdurchfahrt (Strassen.NRW). Drei Layer mit Stil, Liste und Bericht fuer die Antraege.", "wesi", "wesi", "wesi"),
    ("10", "Uebergabe nach Plan[Goo]", "Leeres Plan[Goo]-Projekt anlegen, dann Schritt fuer Schritt importieren",
     "Neues leeres Plan[Goo]-Projekt anlegen (Ausbautreiber, Offline in Bearbeitung nehmen), dann importieren: Adressen als APL (2), "
     "Gebiete, NVT und Zuordnung (3, Standorte aus 4), gepruefte Trassen (5). Jeder Schritt mit Zahlen vorher und Backup-Zip.",
     "uebergabe", "plangoo", "w4"),
    ("11", "ZFP222 Ringauftraege", "Telekom-Formblatt 'Ringauftraege erzeugen v3.4' aus dem fertigen Plan[Goo]-Projekt fuellen: Kopf, HK, NVt, NE4",
     "Zum Schluss, wenn Plan[Goo] fertig ist: NVT mit Hk-Bezeichnung, Montageort, BSt, ONKZ und AsB aus dem Projekt lesen, Auftragsbezeichnungen nach der "
     "Telekom-Syntax bilden und das Formblatt ZFP222 (.xlsm, Makros bleiben) fuellen - Kopf, Block 1 HK, Block 2 NVt, Block 3 NE4; Block 4 und 5 bleiben "
     "leer, SMA fuellt die Telekom. Dazu eine Auftragsliste (.xlsx) mit Pruefblatt und ein Bericht.", "zfp", "zfp", "zfp"),
]

# Abschnitte im Ablauf: vor welcher Nummer welche Ueberschrift steht. Benannt nach dem Gegenstand, nicht nach einer Phase -
# "Abschliessen" war irrefuehrend, weil die Uebergabe nach Plan[Goo] schon nach Schritt 2 oder 3 beginnen kann.
ABSCHNITTE = {"0": "Grundlagen: Umfeld, Bestand, Adressen", "3": "NVT-Ebene: Gebiete, Standorte, Trassen", "6": "Hauptkabel-Ebene: Straenge, Trasse",
              "9": "Wegesicherung", "10": "Uebergabe und Auftraege"}

# (Knopftext, Tooltip, Slot im Plugin)
HELFER = [
    ("Trassenbefuellung Eigenausbau", "Blendet die Plan[Goo]-Trassenbefuellung auch fuer Eigenausbau ein, mit Regelsatz-Auswahl "
     "(MBfD x12, Eigenausbau x7, Fiberation ZTV 21 + Sonderbedarf).", "befuellung"),
    ("Projektpfad pruefen", "Pfadlaenge gegen die Windows-Grenze pruefen, Arbeitskopie unter C:\\PlanGoo anlegen.", "pfad"),
    ("Einstellungen", "Startwarnungen von Plan[Goo] unterdruecken (einzige Automatik).", "einstellungen"),
    ("Anleitung", "Kurzanleitung zu allen Schritten.", "anleitung"),
]
HELFER_TITEL = "Plan[Goo]-Helfer und Einstellungen"


def schritt(schluessel):
    """Eintrag zu einem Seiten-Schluessel (umfeld, adressen, ...) oder None."""
    for s in SCHRITTE:
        if s[4] == schluessel:
            return s
    return None


def gebaut():
    """Schluessel der gebauten Schritte in Ablaufreihenfolge."""
    return [s[4] for s in SCHRITTE if s[4]]


def nummer(schluessel):
    """'2' fuer adressen usw.; '' wenn unbekannt. Fuer Layer- und Gruppennamen (layerbaum)."""
    s = schritt(schluessel)
    return s[0] if s else ""


def titel(schluessel):
    """'1  Adressen und Bedarf pruefen' fuer Fensterkopf, Menue und Navigation."""
    s = schritt(schluessel)
    return "{}  {}".format(s[0], s[1]) if s else ""
