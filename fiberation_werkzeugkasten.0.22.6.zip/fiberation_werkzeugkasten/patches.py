# -*- coding: utf-8 -*-
"""Laufzeit-Ergaenzungen fuer Plan[Goo] V2 (Telekom VDS). Es wird keine Telekom-Datei geaendert; alles wirkt nur im Speicher der
laufenden QGIS-Sitzung und ist nach einem Neustart wieder weg.

Enthalten:
- befuellung_freischalten(iface): Modul "Automatische Trassenbefuellung" im Reiter Funktionen laden (Telekom laedt es nur fuer
  MBfD-Ausbautreiber), versteckte Regelsatz-/Materialauswahl einblenden, Fiberation-Regelsatz einhaengen, Vorwahl nach Ausbautreiber.
- Regelsatz "Eigenausbau ZTV 21 + Sonderbedarf (Fiberation)": Rechenwerk des MBfD-Befuellers (Mehrfachrohre je Adresse, Zusatzrohre in
  der Hauszufuehrung, Beschriftung im Uebersichtslayer) mit den Regeln fuer Eigenausbau nach ZTV TK-Netz 21.
- hauszufuehrung_kettenlimit(): Grenze von 10 Hauszufuehrungsstuecken bis zur Laengstrasse auf 100 anheben (sonst StopIteration).
- wegsuche_robust(): Wegsuche zuerst mit dem Tracer (stuetzpunktgenau), dann die Telekom-Reihenfolge.
- startwarnungen_aus(): Hinweisfenster zu QGIS-Thema und Sprache beim Plan[Goo]-Start unterdruecken.
"""
import importlib
import types

PLANGOO = "technik_plangoo_v2_vds_main"
ANZEIGENAME = "Eigenausbau ZTV 21 + Sonderbedarf (Fiberation)"

# Regeln fuer den Fiberation-Regelsatz (ZTV TK-Netz 21, Stand Nov. 2025)
SONDERBAU = ("Gewerbe", "Schule", "Krankenhaus", "öff. Gebäude")   # BuildingType-Werte, je +1 SNR (Sonderbedarf, Kap. 8.6.6.1)
WE_MAX_36FS = 512                                                  # Kap. 8.6.3.2: bis 512 WE = 36 Fs, darueber weiteres SNR
USTO_ZUSATZ_AB = None                                              # Geschaeftskunden-Einheiten -> +1 SNR ab Wert; None = aus
HAUSZUF_MAX_STUECKE = 100                                          # Telekom: 10

VERSTECKTE_WIDGETS = ("groupBox_Main_Materials", "LabelRuleSetChoice", "DrD_RuleSetChoice", "Label_MaterialChoice",
                      "DrD_MaterialChoice", "Label_HD_Tranch_Material", "DrD_HD_Tranch_Material", "Radio_NumberPipes",
                      "Radio_Percentage", "ListWidget_Materials", "Label_MaterialInfo")

_KLASSE = None


def _modul(name):
    return importlib.import_module(PLANGOO + "." + name)


def plangoo_geladen():
    try:
        from qgis.utils import plugins
        return PLANGOO in plugins
    except Exception:
        return False


# --- Regelsatz ----------------------------------------------------------------------------------------------------------------------
def klasse():
    """Regelsatz-Klasse (je Sitzung einmal erzeugt; die Telekom-Basisklassen gibt es nur bei geladenem Plan[Goo])."""
    global _KLASSE
    if _KLASSE is not None:
        return _KLASSE
    Basis = _modul("modules.tranch_auto_fill.tranch_filler_vzk_12xmbfd").TranchFillerVZK12xMBfD
    Util = _modul("modules.tranch_auto_fill.tranch_filler_utilities").TranchFillerUtilities
    BuildingType = _modul("core.utilities.constants").BuildingType
    sonder = tuple(bt for bt in BuildingType if bt.value in SONDERBAU)

    def _we(apl):
        try:
            return int(apl.get_hh() or 0)
        except Exception:
            return 0

    def _usto(apl):
        try:
            return int(apl.get_usto() or 0)
        except Exception:
            return 0

    class TranchFillerVZKPushZTV21(Basis):
        """Eigenausbau nach ZTV 21 auf dem Rechenwerk des MBfD-Befuellers."""

        @staticmethod
        def get_display_name():
            return ANZEIGENAME

        # die drei privaten (namensverstuemmelten) Regel-Methoden des MBfD-Befuellers ersetzen
        def _TranchFillerVZK12xMBfD__get_we_specific_mbfd_case(self, apl):
            return _we(apl)

        def _TranchFillerVZK12xMBfD__get_needed_pipes_apl(self, apl):
            """(Rohre gesamt, Kollo-Anteil): 1 SNR je Adresse; +1 bei Sonderbedarf; +1 ueber 36 Fs."""
            n = 1
            if (USTO_ZUSATZ_AB is not None and _usto(apl) >= USTO_ZUSATZ_AB) or \
                    any(Util.has_apl_building_type(apl, bt) for bt in sonder):
                n += 1
            if _we(apl) > WE_MAX_36FS:
                n += 1
            return (n, 0)

        def _TranchFillerVZK12xMBfD__route_needs_special_checks_we(self, apl_list):
            return any(self._TranchFillerVZK12xMBfD__get_needed_pipes_apl(a)[0] > 1 for a in apl_list)

        def _get_not_used_capacity(self, number_apl, has_special_building=False):
            # kein Mindestverband fuer Schulen/Krankenhaeuser (MBfD-Regel); Kapazitaeten 8/22 sind ohnehin >= 6
            return super()._get_not_used_capacity(number_apl, False)

        def create_layer(self):
            """Umgeht einen Fehler der Basisklasse: ab dem zweiten Sonder-APL eines NVT landet der APL als Hauptschluessel
            (Tupel statt Dict) im Sammel-Dict, create_layer bricht dann ab. Eintraege vorher in das Dict ihres NVT einsortieren."""
            d = self._TranchFillerVZK12xMBfD__special_apl_with_pipes_per_nvt
            if d:
                nvt_keys = [k for k, v in d.items() if isinstance(v, dict)]
                for k in [k for k, v in d.items() if isinstance(v, tuple)]:
                    ziel = None
                    try:
                        ziel = k.get_parent()
                    except Exception:
                        ziel = None
                    if ziel is None or not isinstance(d.get(ziel), dict):
                        ziel = nvt_keys[0] if len(nvt_keys) == 1 else None
                    if ziel is None:
                        for n in nvt_keys:
                            try:
                                if k in n.get_children([k.get_type()]):
                                    ziel = n
                                    break
                            except Exception:
                                pass
                    if ziel is not None:
                        d[ziel][k] = d.pop(k)
                    else:
                        d.pop(k)
            return super().create_layer()

    _KLASSE = TranchFillerVZKPushZTV21
    return _KLASSE


def ausbautreiber():
    try:
        GooSettings = _modul("core.components").GooSettings
        s = GooSettings.from_uid("AUSBAUTREIBER")
        return str(s.get_value() or "") if s is not None else ""
    except Exception:
        return ""


def ist_push(treiber):
    t = (treiber or "").lower()
    return t.startswith("eigen") or t.startswith("push") or t in ("demo", "topas", "neubaugebiet_pk", "neubaugebiet_pk_2023")


# --- Befueller einblenden -----------------------------------------------------------------------------------------------------------
def _finde_modul(m, key, tiefe=0):
    """Plan[Goo]-Modulbaum (ModuleBase: m[key], iter -> (key, modul)) rekursiv nach einem Schluessel durchsuchen."""
    try:
        return m[key]
    except Exception:
        pass
    if tiefe > 5:
        return None
    try:
        items = list(m)
    except Exception:
        return None
    for _k, sub in items:
        r = _finde_modul(sub, key, tiefe + 1)
        if r is not None:
            return r
    return None


def reiter_funktionen():
    from qgis.PyQt.QtWidgets import QApplication
    from qgis.utils import plugins
    tab = None
    try:
        tab = _finde_modul(plugins[PLANGOO], "TabFunctions")
    except Exception:
        tab = None
    if tab is None:
        for w in QApplication.allWidgets():
            if hasattr(w, "MainTranchFilling_QFrame") and hasattr(w, "add_ui_module"):
                return w
    return tab


def vzk_modul(haupt):
    try:
        return haupt["AutoFillingModuleVZK"]
    except Exception:
        pass
    return getattr(haupt, "_MainTranchFillingModule__tranch_filling_vzk", None)


def auswahl_einblenden(vzk):
    n = 0
    for name in VERSTECKTE_WIDGETS:
        w = getattr(vzk, name, None)
        if w is not None:
            try:
                w.setVisible(True)
                n += 1
            except Exception:
                pass
    return n


def regelsatz_einhaengen(vzk):
    drd = getattr(vzk, "DrD_RuleSetChoice", None)
    if drd is None:
        return False
    for i in range(drd.count()):
        if drd.itemText(i) == ANZEIGENAME:
            return True
    drd.addItem(ANZEIGENAME, klasse())
    return True


def regelsatz_vorwaehlen(vzk, treiber):
    drd = getattr(vzk, "DrD_RuleSetChoice", None)
    if drd is None:
        return ""
    wunsch = [ANZEIGENAME, "Eigenausbau (x7)"] if ist_push(treiber) else ["MBfD (x12)"]
    for text in wunsch:
        idx = drd.findText(text)
        if idx >= 0:
            drd.setCurrentIndex(idx)
            if ist_push(treiber):
                try:
                    vzk.Radio_NumberPipes.setChecked(True)
                    vzk.SpinBox_Reserve.setValue(1)
                except Exception:
                    pass
            return drd.currentText()
    return drd.currentText()


def befuellung_freischalten(iface):
    """Alles in einem. -> Meldungstext (wirft bei fehlendem Plan[Goo]/Reiter eine RuntimeError)"""
    if not plangoo_geladen():
        raise RuntimeError("Plan[Goo] (technik_plangoo_v2_vds_main) ist nicht geladen.")
    tab = reiter_funktionen()
    if tab is None:
        raise RuntimeError("Plan[Goo]-Reiter 'Funktionen' nicht gefunden. Bitte zuerst Plan[Goo] starten und ein Projekt oeffnen.")
    zeilen = []
    try:
        wegsuche_robust()
        zeilen.append("Wegsuche: Tracer zuerst.")
    except Exception as e:
        zeilen.append("Wegsuche nicht umgestellt: {}".format(str(e)[:80]))
    zeilen.append(hauszufuehrung_kettenlimit())
    if "MainTranchFillingModule" in tab:
        modul = tab["MainTranchFillingModule"]
        kopf = "Die automatische Trassenbefuellung war bereits sichtbar (Reiter Funktionen)."
    else:
        M = _modul("modules.tranch_auto_fill.main_tranch_filling_module")
        frame = tab.MainTranchFilling_QFrame
        frame.show()
        modul = tab.add_ui_module("MainTranchFillingModule", frame, M.MainTranchFillingModule)
        try:
            modul.show()
        except Exception:
            pass
        kopf = "Automatische Trassenbefuellung eingeblendet: Plan[Goo] > Reiter 'Funktionen'."
    vzk = vzk_modul(modul)
    if vzk is None:
        zeilen.append("Vzk-Befueller nicht gefunden - Regelsatz-Auswahl bleibt versteckt.")
    else:
        n = auswahl_einblenden(vzk)
        try:
            ok = regelsatz_einhaengen(vzk)
            satz = "eingehaengt" if ok else "nicht eingehaengt (Auswahl fehlt)"
        except Exception as e:
            satz = "nicht ladbar: {!r}".format(e)[:160]
        treiber = ausbautreiber()
        gewaehlt = regelsatz_vorwaehlen(vzk, treiber)
        zeilen.append("Regelsatz-Auswahl sichtbar ({} Elemente). Regelsatz '{}' {}.".format(n, ANZEIGENAME, satz))
        zeilen.append("Ausbautreiber '{}' -> vorgewaehlt: '{}'.".format(treiber or "?", gewaehlt))
    try:
        from . import hk_modul
        zeilen.append(hk_modul.einhaengen(modul, iface))
    except Exception as e:
        zeilen.append("Hk-Befuellung nicht eingehaengt: {!r}".format(e)[:160])
    return (kopf + "\n\n" + "\n".join(zeilen) + "\n\n"
            "Regelsaetze: 'MBfD (x12)' | 'Eigenausbau (x7)' (ZTV 21: 22x7/8x7, 1 Reserverohr) | '{}' "
            "(zusaetzlich Mehrfachrohre bei Gewerbe/Schule/Krankenhaus/oeff. Gebaeude und > 512 WE).\n"
            "Bodenplatten-/SNR-Zuordnung abwaehlen, wenn die Kapazitaetspruefung abbricht.\n"
            "Gilt nur fuer diese QGIS-Sitzung.".format(ANZEIGENAME))


# --- Kettenlimit --------------------------------------------------------------------------------------------------------------------
def hauszufuehrung_kettenlimit(max_loops=HAUSZUF_MAX_STUECKE):
    """Ersetzt die lokale Konstante 10 im Bytecode von HouseDeliveryTranchSnrInsertion.__get_source_fids_from_apl_to_laengstrasse.
    -> Meldungstext"""
    try:
        HD = _modul("utilities.house_delivery_snr_insertion").HouseDeliveryTranchSnrInsertion
    except Exception as e:
        return "Hauszufuehrungs-Kettenlimit nicht gesetzt (Modul fehlt: {!r})".format(e)[:160]
    name = "_HouseDeliveryTranchSnrInsertion__get_source_fids_from_apl_to_laengstrasse"
    fn = getattr(HD, name, None)
    if fn is None:
        return "Hauszufuehrungs-Kettenlimit nicht gesetzt (Methode fehlt)."
    if getattr(fn, "_fiberation_max_loops", None) == max_loops:
        return "Hauszufuehrungs-Kettenlimit: {} Stuecke (bereits gesetzt).".format(max_loops)
    code = fn.__code__
    treffer = [i for i, c in enumerate(code.co_consts) if type(c) is int and c == 10]
    if len(treffer) != 1:
        return "Hauszufuehrungs-Kettenlimit nicht gesetzt (Konstante 10 kommt {}x vor).".format(len(treffer))
    consts = list(code.co_consts)
    consts[treffer[0]] = int(max_loops)
    neu = types.FunctionType(code.replace(co_consts=tuple(consts)), fn.__globals__, fn.__name__, fn.__defaults__, fn.__closure__)
    neu.__doc__ = fn.__doc__
    neu._fiberation_max_loops = max_loops
    setattr(HD, name, neu)
    return "Hauszufuehrungs-Kettenlimit: {} statt 10 Stuecke bis zur Laengstrasse.".format(max_loops)


# --- Wegsuche -----------------------------------------------------------------------------------------------------------------------
def wegsuche_robust():
    """PathFinder.get_feature_route probiert processing/director/shortestTree vor dem Tracer; in EPSG:3857 liefern die drei an
    Anbindepunkten Pfade mit Zickzack-Stuetzpunkten, die Trassenzuordnung findet dann zu viele Trassen ("kein Verbindungsweg").
    Hier zuerst der Tracer (GEOS-Noding, stuetzpunktgenau), dann die Original-Reihenfolge."""
    PF = _modul("submodules.base.qgis.path_finder")
    if getattr(PF.PathFinder, "_fiberation_robust", False):
        return
    orig = PF.PathFinder.get_feature_route.__func__
    M = PF.PathFinderMethods

    def robust(cls, layer, points, progressbar=None, sub_layer=None, method=M.FIRST_MATCH, epsilon=None):
        eps = PF.EPSILON if epsilon is None else epsilon
        if method == M.FIRST_MATCH:
            r = orig(cls, layer, points, progressbar, sub_layer, M.TRACER, eps)
            if r:
                return r
        return orig(cls, layer, points, progressbar, sub_layer, method, eps)

    PF.PathFinder.get_feature_route = classmethod(robust)
    PF.PathFinder._fiberation_robust = True


# --- Startwarnungen -----------------------------------------------------------------------------------------------------------------
def startwarnungen_aus():
    """check_theme und check_language im Bearbeitung-Modul durch leere Methoden ersetzen. -> Anzahl ersetzter Methoden"""
    try:
        m = _modul("modules.tab_main.bearbeitung")
    except Exception:
        return 0
    n = 0
    for name in dir(m):
        cls = getattr(m, name, None)
        if not isinstance(cls, type):
            continue
        for meth in ("check_theme", "check_language"):
            if meth in cls.__dict__:
                setattr(cls, meth, lambda self: None)
                n += 1
    return n
