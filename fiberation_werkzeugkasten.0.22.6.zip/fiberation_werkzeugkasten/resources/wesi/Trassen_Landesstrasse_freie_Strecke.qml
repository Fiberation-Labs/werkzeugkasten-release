<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.40" styleCategories="Symbology">
 <renderer-v2 type="singleSymbol" symbollevels="0" forceraster="0">
  <symbols><symbol type="line" name="0" alpha="1" clip_to_extent="1">
   <layer class="SimpleLine" enabled="1" locked="0"><Option type="Map"><Option name="line_color" type="QString" value="255,255,255,255"/><Option name="line_width" type="QString" value="1.6"/><Option name="line_width_unit" type="QString" value="MM"/><Option name="line_style" type="QString" value="solid"/><Option name="capstyle" type="QString" value="round"/></Option></layer>
   <layer class="SimpleLine" enabled="1" locked="0"><Option type="Map"><Option name="line_color" type="QString" value="230,81,0,255"/><Option name="line_width" type="QString" value="1.0"/><Option name="line_width_unit" type="QString" value="MM"/><Option name="line_style" type="QString" value="solid"/><Option name="capstyle" type="QString" value="round"/></Option></layer>
  </symbol></symbols>
 </renderer-v2>
 <layerGeometryType>1</layerGeometryType>
</qgis>