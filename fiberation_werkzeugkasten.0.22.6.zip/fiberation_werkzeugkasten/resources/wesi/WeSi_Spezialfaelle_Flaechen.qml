<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.40" styleCategories="Symbology|Labeling">
 <renderer-v2 type="RuleRenderer" symbollevels="0" forceraster="0">
  <rules key="{r0}">
   <rule filter="&quot;art&quot; = 'Gewaesser'" symbol="0" key="{r1}" label="Gewaesserquerung (WeSi)"/>
   <rule filter="&quot;art&quot; LIKE 'Strassen.NRW%'" symbol="1" key="{r2}" label="Landesstrasse freie Strecke - Strassen.NRW (WeSi)"/>
  </rules>
  <symbols>
   <symbol type="fill" name="0" alpha="1" clip_to_extent="1"><layer class="SimpleFill" enabled="1" locked="0">
    <Option type="Map"><Option name="color" type="QString" value="30,120,220,120"/><Option name="outline_color" type="QString" value="13,71,161,255"/><Option name="outline_width" type="QString" value="0.6"/><Option name="outline_width_unit" type="QString" value="MM"/><Option name="style" type="QString" value="solid"/><Option name="outline_style" type="QString" value="solid"/></Option></layer></symbol>
   <symbol type="fill" name="1" alpha="1" clip_to_extent="1"><layer class="SimpleFill" enabled="1" locked="0">
    <Option type="Map"><Option name="color" type="QString" value="255,220,0,120"/><Option name="outline_color" type="QString" value="230,150,0,255"/><Option name="outline_width" type="QString" value="0.6"/><Option name="outline_width_unit" type="QString" value="MM"/><Option name="style" type="QString" value="solid"/><Option name="outline_style" type="QString" value="solid"/></Option></layer></symbol>
  </symbols>
 </renderer-v2>
 <labeling type="simple"><settings calloutType="simple"><text-style fieldName="bezeichnung" fontSize="8" textColor="30,30,30,255"><text-buffer bufferDraw="1" bufferSize="1" bufferColor="255,255,255,255"/></text-style><placement placement="0"/><rendering scaleVisibility="1" scaleMin="1" scaleMax="5000" obstacle="1"/></settings></labeling>
 <layerGeometryType>2</layerGeometryType>
</qgis>