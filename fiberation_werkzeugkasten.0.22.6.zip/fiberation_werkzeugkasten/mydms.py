# -*- coding: utf-8 -*-
"""myDMS-Regelwerk der Telekom (NVT-Grenzen je Gehaeuse und Ausbautreiber), wie Plan[Goo] es prueft.

Markus 30.09.2026: "uebernehme mydms regelwerk in unsere tools". Quelle ist die Tabelle NVT_CAPACITIES in
technik_plangoo_v2_vds_main/utilities/rules/constants.py (myDMS 23499 V29/V34, Seitenangaben dort). Sie wird zur Laufzeit aus dem
installierten Plan[Goo] gelesen, damit ein Plan[Goo]-Update automatisch bei uns ankommt; ohne Plan[Goo] (headless, anderer Rechner)
gilt die Kopie SNAPSHOT vom 30.09.2026.

Bedeutung der Werte (Kommentar in Plan[Goo]): "maximum" = Maximal-/Vollausbau, "warning" = Erstausbau. initial_* gilt fuer einen neuen NVT
(is_external_object False), extend_* fuer die Erweiterung eines Bestands-NVT. tray_slots = Kassettenplaetze fuer Vzk (UNI zaehlt 1),
coupler = Koppler 1:32 = PON-Fasern im Hk, we_count -1 = keine WE-Grenze (UNI-System).
"""
import importlib

PLANGOO = "technik_plangoo_v2_vds_main"
SNAPSHOT_STAND = "Kopie 30.09.2026 (myDMS 23499 V34)"

# (Materialschluessel, Ausbautreiber) -> Grenzen. Reihenfolge wie in Plan[Goo]; die erste passende Zeile gilt.
SNAPSHOT = [
    (("GH_NA", "GH_NAL", "GH_NAC"), ("mbfd2019", "mbfd2020", "mbfd2020_oktober", "mbfd2022", "mbfd2023", "mbfd2023_gwg"),
     {"is_uni_system": False, "warning_coupler": 0, "maximum_coupler": 1, "initial_warning_tray_slots": 16, "initial_maximum_tray_slots": 20,
      "extend_warning_tray_slots": 16, "extend_maximum_tray_slots": 20, "initial_warning_addresses": 8, "initial_maximum_addresses": 10,
      "extend_warning_addresses": 10, "extend_maximum_addresses": 15, "warning_we_count": 22, "maximum_we_count": 30}),
    (("GH_NB", "GH_NBL", "GH_NBC", "GH_NBS"), ("mbfd2019", "mbfd2020", "mbfd2020_oktober", "mbfd2022", "mbfd2023", "mbfd2023_gwg"),
     {"is_uni_system": False, "warning_coupler": 3, "maximum_coupler": 5, "initial_warning_tray_slots": 72, "initial_maximum_tray_slots": 102,
      "extend_warning_tray_slots": 72, "extend_maximum_tray_slots": 102, "initial_warning_addresses": 45, "initial_maximum_addresses": 51,
      "extend_warning_addresses": 51, "extend_maximum_addresses": 60, "warning_we_count": 140, "maximum_we_count": 160}),
    (("GH_OA", "GH_OAL", "GH_OAC"), ("eigen", "eigen_ab_2022", "eigen_ab_2023", "pushgk_2023", "neubaugebiet_pk", "neubaugebiet_pk_2023"),
     {"is_uni_system": False, "warning_coupler": 2, "maximum_coupler": 3, "initial_warning_tray_slots": 14, "initial_maximum_tray_slots": 22,
      "extend_warning_tray_slots": 14, "extend_maximum_tray_slots": 22, "initial_warning_addresses": 14, "initial_maximum_addresses": 22,
      "extend_warning_addresses": 14, "extend_maximum_addresses": 22, "warning_we_count": 80, "maximum_we_count": 96}),
    (("GH_OB", "GH_OBL", "GH_OBC", "GH_OBS", "GH_OBT"),
     ("eigen", "eigen_ab_2022", "eigen_ab_2023", "pushgk_2023", "neubaugebiet_pk", "neubaugebiet_pk_2023", "glasfaserplus_eigen_7er", "topas"),
     {"is_uni_system": False, "warning_coupler": 15, "maximum_coupler": 23, "initial_warning_tray_slots": 40, "initial_maximum_tray_slots": 90,
      "extend_warning_tray_slots": 40, "extend_maximum_tray_slots": 90, "initial_warning_addresses": 40, "initial_maximum_addresses": 90,
      "extend_warning_addresses": 40, "extend_maximum_addresses": 90, "warning_we_count": 680, "maximum_we_count": 736}),
    (("GH_OB", "GH_OBL", "GH_OBC", "GH_OBS", "GH_OBT"), ("pushgk", "pushgk_2022", "pushgk_2023"),
     {"is_uni_system": False, "warning_coupler": 8, "maximum_coupler": 12, "initial_warning_tray_slots": 65, "initial_maximum_tray_slots": 72,
      "extend_warning_tray_slots": 72, "extend_maximum_tray_slots": 96, "initial_warning_addresses": 30, "initial_maximum_addresses": 36,
      "extend_warning_addresses": 36, "extend_maximum_addresses": 48, "warning_we_count": 680, "maximum_we_count": 736}),
    # NVt22 L (Eigen) - myDMS 23499 V34 Seite 61 und 52
    (("GH_OCL", "GH_OCS", "GH_OCR"),
     ("eigen", "eigen_ab_2022", "eigen_ab_2023", "pushgk_2023", "neubaugebiet_pk", "neubaugebiet_pk_2023", "glasfaserplus_eigen_7er",
      "glasfaserplus_eigen_7er_2023", "topas"),
     {"is_uni_system": True, "warning_coupler": 15, "maximum_coupler": 23, "initial_warning_tray_slots": 40, "initial_maximum_tray_slots": 90,
      "extend_warning_tray_slots": 40, "extend_maximum_tray_slots": 90, "initial_warning_addresses": 40, "initial_maximum_addresses": 90,
      "extend_warning_addresses": 40, "extend_maximum_addresses": 90, "warning_we_count": -1, "maximum_we_count": -1}),
    # NVt22 L (Eigen) Gewerbe - myDMS 23499 V34 Seite 128
    (("GH_OCL", "GH_OCS", "GH_OCR"), ("pushgk", "pushgk_2022", "pushgk_2023", "glasfaserplus_gwg_2023"),
     {"is_uni_system": True, "warning_coupler": 8, "maximum_coupler": 12, "initial_warning_tray_slots": 72, "initial_maximum_tray_slots": 90,
      "extend_warning_tray_slots": 72, "extend_maximum_tray_slots": 90, "initial_warning_addresses": 50, "initial_maximum_addresses": 60,
      "extend_warning_addresses": 60, "extend_maximum_addresses": 90, "warning_we_count": -1, "maximum_we_count": -1}),
    # NVt22 L (BF) - myDMS 23499 V34 Seite 156
    (("GH_NCR", "GH_NCS", "GH_NCL"),
     ("mbfd2019", "mbfd2020", "mbfd2020_oktober", "mbfd2022", "mbfd2023", "mbfd2023_gwg", "glasfaserplus_mbfd_2023"),
     {"is_uni_system": True, "warning_coupler": 8, "maximum_coupler": 12, "initial_warning_tray_slots": 40, "initial_maximum_tray_slots": 72,
      "extend_warning_tray_slots": 40, "extend_maximum_tray_slots": 72, "initial_warning_addresses": 45, "initial_maximum_addresses": 51,
      "extend_warning_addresses": 51, "extend_maximum_addresses": 60, "warning_we_count": -1, "maximum_we_count": -1}),
    (("GH_NCR", "GH_NCS", "GH_NCL"), ("mbfd2023_gwg", "glasfaserplus_mbfd_gwg_2023"),
     {"is_uni_system": True, "warning_coupler": 8, "maximum_coupler": 12, "initial_warning_tray_slots": 40, "initial_maximum_tray_slots": 72,
      "extend_warning_tray_slots": 40, "extend_maximum_tray_slots": 72, "initial_warning_addresses": 45, "initial_maximum_addresses": 51,
      "extend_warning_addresses": 51, "extend_maximum_addresses": 60, "warning_we_count": -1, "maximum_we_count": -1}),
    # NVt22 XS (Eigen)
    (("GH_OCLXS",),
     ("eigen", "eigen_ab_2022", "eigen_ab_2023", "pushgk_2023", "neubaugebiet_pk", "neubaugebiet_pk_2023", "glasfaserplus_eigen_7er",
      "glasfaserplus_eigen_7er_2023"),
     {"is_uni_system": True, "warning_coupler": 2, "maximum_coupler": 3, "initial_warning_tray_slots": 14, "initial_maximum_tray_slots": 22,
      "extend_warning_tray_slots": 14, "extend_maximum_tray_slots": 22, "initial_warning_addresses": 14, "initial_maximum_addresses": 22,
      "extend_warning_addresses": 14, "extend_maximum_addresses": 22, "warning_we_count": -1, "maximum_we_count": -1}),
    # NVt22 XS (BF)
    (("GH_NCLXS",), ("mbfd2019", "mbfd2020", "mbfd2020_oktober", "mbfd2022", "mbfd2023", "mbfd2023_gwg"),
     {"is_uni_system": True, "warning_coupler": 0, "maximum_coupler": 2, "initial_warning_tray_slots": 13, "initial_maximum_tray_slots": 15,
      "extend_warning_tray_slots": 13, "extend_maximum_tray_slots": 15, "initial_warning_addresses": 10, "initial_maximum_addresses": 13,
      "extend_warning_addresses": 13, "extend_maximum_addresses": 15, "warning_we_count": -1, "maximum_we_count": -1}),
]

# Vorgabe-Ausbautreiber je Regelsatz, wenn die Adressen keinen nennen
TREIBER_VORGABE = {"eigen": "eigen_ab_2023", "mbfd": "mbfd2023", "mbfd_xs": "mbfd2023"}
MATERIAL_JE_REGELSATZ = {"eigen": "GH_OCL", "mbfd": "GH_NCL", "mbfd_xs": "GH_NCLXS"}

_cache = None


def tabelle():
    """-> (Liste (materialien, treiber, grenzen), quelle). Zuerst das installierte Plan[Goo], sonst SNAPSHOT."""
    global _cache
    if _cache is not None:
        return _cache
    try:
        mod = importlib.import_module(PLANGOO + ".utilities.rules.constants")
        zeilen = []
        for (mats, treiber), lim in mod.NVT_CAPACITIES.items():
            mats_ = tuple(str(m) for m in mats)
            if "tuple of material keys" in mats_:
                continue
            zeilen.append((mats_, tuple(str(getattr(t, "value", t)) for t in treiber), dict(lim)))
        if zeilen:
            _cache = (zeilen, "Plan[Goo] myDMS-Regelwerk (installiert)")
            return _cache
    except Exception:
        pass
    _cache = (SNAPSHOT, SNAPSHOT_STAND)
    return _cache


def grenzen(material_key, treiber=None):
    """Grenzen fuer ein Gehaeuse und einen Ausbautreiber. Ohne Treffer beim Treiber gilt die erste Zeile des Gehaeuses. -> dict | None"""
    zeilen, _ = tabelle()
    t = (treiber or "").strip().lower()
    erste = None
    for mats, treiber_liste, lim in zeilen:
        if material_key not in mats:
            continue
        erste = erste or lim
        if t and t in treiber_liste:
            return dict(lim)
    return dict(erste) if erste else None


def nvt_grenzen(regelsatz, treiber=None):
    """myDMS-Grenzen auf die Schluessel unseres Regelsatzes (cluster.config.REGELSAETZE) abgebildet. -> dict | {}
    max_apl = Erstausbau (warning), max_apl_hart = Maximalausbau (maximum) fuer einen neuen NVT; max_pon_fasern = Koppler maximum,
    pon_warn = Koppler warning; max_kassetten = Vzk-Kassettenplaetze maximum (hk_kassetten 0, Hk zaehlt in Plan[Goo] nicht mit),
    kassetten_warn = warning; max_we aus we_count, sonst Koppler x 32."""
    key = MATERIAL_JE_REGELSATZ.get(regelsatz or "eigen", "GH_OCL")
    t = treiber or TREIBER_VORGABE.get(regelsatz or "eigen", "eigen_ab_2023")
    lim = grenzen(key, t)
    if not lim:
        return {}
    _, quelle = tabelle()
    max_we = lim["maximum_we_count"] if lim.get("maximum_we_count", -1) > 0 else lim["maximum_coupler"] * 32
    return {"max_apl": lim["initial_warning_addresses"], "max_apl_hart": lim["initial_maximum_addresses"],
            "apl_erw_weich": lim["extend_warning_addresses"], "apl_erw_hart": lim["extend_maximum_addresses"],
            "max_pon_fasern": lim["maximum_coupler"], "pon_warn": lim["warning_coupler"],
            "max_kassetten": lim["initial_maximum_tray_slots"], "kassetten_warn": lim["initial_warning_tray_slots"], "hk_kassetten": 0,
            "max_we": max_we, "mydms_material": key, "mydms_treiber": t, "mydms_quelle": quelle}
