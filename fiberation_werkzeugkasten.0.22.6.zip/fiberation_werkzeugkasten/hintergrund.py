# -*- coding: utf-8 -*-
"""Lange Kernlaeufe (ALKIS-WFS, Overpass, Rechnen) in einem eigenen Prozess, damit QGIS bedienbar bleibt und Abbrechen greift
(Markus 12.10.2026, Punkt 5: Netzabrufe aus dem Hauptfenster).

Warum ein Prozess und kein Thread: pyproj/GeoPandas im QgsTask-Thread stuerzen ab, sobald QGIS im Hauptthread gleichzeitig PROJ nutzt
(Zugriffsverletzung in pyproj CRS.__init__, 12.10.2026 im Test reproduziert). Ein Kindprozess mit demselben QGIS-Python ist davon frei,
isoliert Abstuerze und laesst sich hart abbrechen.

starten(dialog, beschreibung, modul, funktion, args, kwargs, fertig, aufraeumen=None):
  ruft im Kindprozess fiberation_werkzeugkasten.<modul>.<funktion>(*args, log=..., fortschritt=..., **kwargs). Argumente muessen JSON-faehig
  sein (Pfade, Zahlen, Listen, dicts). Das Ergebnis geht durch <funktion>_zusammenfassung(r) (oder lauf_zusammenfassung) des Moduls - ein
  JSON-faehiges dict mit dem, was der Dialog braucht (Pfade, Zahlen). log/fortschritt kommen zeilenweise zurueck und landen in
  dialog._log / dialog._fortschritt. fertig(ergebnis, fehler, rueckverfolgung) laeuft im Hauptthread.
  aufraeumen = (ordner, muster): beim Abbruch werden Dateien dieses Musters, die seit dem Start entstanden sind, samt -wal/-journal
  geloescht (halb geschriebene GeoPackages, Pruefer B8).
Der Prozess haengt NICHT am Dialog (Pruefer B1): wird die Seite geschlossen, laeuft er zu Ende oder wird ueber abbrechen() beendet;
Rueckrufe pruefen vorher, ob der Dialog noch lebt. abbrechen(dialog) beendet den Kindprozess. laeuft(dialog) / warten(dialog) fuer Tests."""
import glob
import json
import os
import sys
import tempfile
import time

from qgis.core import QgsApplication
from qgis.PyQt.QtCore import QProcess, QProcessEnvironment

PAKET = os.path.dirname(os.path.abspath(__file__))
_LAEUFE = {}            # id(dialog) -> dict(prozess, ...) - haelt die Prozesse am Leben, unabhaengig vom Dialog


class Abgebrochen(Exception):
    pass


def _lebt(dialog):
    try:
        from qgis.PyQt import sip
        return not sip.isdeleted(dialog)
    except Exception:
        return True


def python():
    """Das QGIS-Python fuer den Kindprozess: unter einem Python (Tests) sys.executable, in QGIS python-qgis(-ltr).bat neben QGIS.
    -> (programm, feste Argumente) - nie qgis-ltr-bin.exe als Rueckfall (Pruefer B2)."""
    if os.path.basename(sys.executable).lower().startswith("python"):
        return sys.executable, []
    kandidaten = []
    try:
        prefix = QgsApplication.prefixPath()                     # .../apps/qgis-ltr
        kandidaten.append(os.path.normpath(os.path.join(prefix, "..", "..", "bin")))
    except Exception:
        pass
    exe_ordner = os.path.dirname(sys.executable)
    kandidaten += [exe_ordner, os.path.normpath(os.path.join(exe_ordner, "..", "bin"))]
    for bin_ in kandidaten:
        for name in ("python-qgis-ltr.bat", "python-qgis.bat"):
            p = os.path.join(bin_, name)
            if os.path.exists(p):
                return p, []
    raise RuntimeError("QGIS-Python nicht gefunden (python-qgis-ltr.bat neben QGIS) - Lauf kann nicht gestartet werden.")


def _zitat(p):
    return '"' + str(p).replace('"', '') + '"'


def starten(dialog, beschreibung, modul, funktion, args, kwargs, fertig, aufraeumen=None):
    ordner = tempfile.mkdtemp(prefix="werkzeugkasten_")
    spec = {"pfad": os.path.dirname(PAKET), "modul": "fiberation_werkzeugkasten." + modul, "funktion": funktion, "args": list(args or []),
            "kwargs": dict(kwargs or {}), "ergebnis": os.path.join(ordner, "ergebnis.json")}
    spec_pfad = os.path.join(ordner, "auftrag.json")
    with open(spec_pfad, "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, default=str)
    try:
        programm, feste = python()
    except Exception as e:
        fertig(None, e, "")
        return None
    proz = QProcess()                               # kein Elternteil: ueberlebt das Schliessen der Seite (Pruefer B1)
    env = QProcessEnvironment.systemEnvironment()
    env.insert("PYTHONIOENCODING", "utf-8")
    env.insert("PYTHONUNBUFFERED", "1")
    env.insert("QT_QPA_PLATFORM", "offscreen")
    proz.setProcessEnvironment(env)
    proz.setProcessChannelMode(QProcess.MergedChannels)
    lauf = {"prozess": proz, "puffer": b"", "abgebrochen": False, "fertig": False, "start": time.time(), "aufraeumen": aufraeumen, "ordner": ordner}
    _LAEUFE[id(dialog)] = lauf

    def lesen():
        try:
            lauf["puffer"] += bytes(proz.readAllStandardOutput())
        except RuntimeError:
            return
        while b"\n" in lauf["puffer"]:
            zeile, lauf["puffer"] = lauf["puffer"].split(b"\n", 1)
            z = zeile.decode("utf-8", "replace").rstrip("\r")
            if not _lebt(dialog):
                continue
            if z.startswith("LOG "):
                dialog._log(z[4:])
            elif z.startswith("FORTSCHRITT "):
                p, _, t = z[12:].partition("|")
                try:
                    dialog._fortschritt(float(p), t)
                except Exception:
                    pass
            elif z.startswith(("FERTIG", "FEHLER")):
                pass
            elif z.strip():
                dialog._log("  " + z)

    def abschluss(fehler, erg=None, rv=""):
        if lauf["fertig"]:
            return
        lauf["fertig"] = True
        _LAEUFE.pop(id(dialog), None)
        try:
            import shutil
            shutil.rmtree(ordner, ignore_errors=True)
        except Exception:
            pass
        if lauf["abgebrochen"]:
            _aufraeumen(lauf)
            fehler, erg = Abgebrochen("abgebrochen"), None
        if not _lebt(dialog):
            return                                  # Seite ist zu: Ergebnis liegt auf der Platte, mehr ist nicht zu tun
        try:
            fertig(erg, fehler, rv)
        except Exception as e:
            try:
                dialog._log("Abschluss des Hintergrundlaufs fehlgeschlagen: {!r}".format(e))
            except Exception:
                pass

    def ende(code, status):
        lesen()
        erg = None
        try:
            with open(spec["ergebnis"], encoding="utf-8") as f:
                erg = json.load(f)
        except Exception:
            erg = None
        if erg is None:
            abschluss(RuntimeError("Hintergrundlauf ohne Ergebnis (Exit {}) - Einzelheiten im Protokoll".format(code)))
        elif "fehler" in erg:
            abschluss(RuntimeError(erg["fehler"]), None, erg.get("rueckverfolgung", ""))
        else:
            abschluss(None, erg)

    def fehler_start(err):
        if err == QProcess.FailedToStart:
            abschluss(RuntimeError("Kindprozess konnte nicht starten: {} (Pruefer B2)".format(programm)))
        elif err == QProcess.Crashed and not lauf["abgebrochen"]:
            abschluss(RuntimeError("Kindprozess abgestuerzt - Einzelheiten im Protokoll"))

    proz.readyReadStandardOutput.connect(lesen)
    proz.finished.connect(ende)
    proz.errorOccurred.connect(fehler_start)
    skript = os.path.join(PAKET, "hintergrund_lauf.py")
    if programm.lower().endswith(".bat"):
        # "cmd /c call <bat> ...": mit 'call' vorn streicht cmd die Anfuehrungszeichen um Pfade mit Leerzeichen nicht mehr (Pruefer B3);
        # PyQt kennt setNativeArguments nicht, Qt zitiert die Einzelargumente selbst
        proz.setProgram("cmd")
        proz.setArguments(["/c", "call", programm, skript, spec_pfad])
    else:
        proz.setProgram(programm)
        proz.setArguments(feste + [skript, spec_pfad])
    proz.start()
    if _lebt(dialog):
        dialog._log("{} - laeuft im Hintergrund, QGIS bleibt bedienbar.".format(beschreibung))
    return proz


def _aufraeumen(lauf):
    """Nach einem Abbruch: Dateien des Ergebnismusters, die seit dem Start entstanden sind, samt Nebenlaeufern loeschen (Pruefer B8)."""
    a = lauf.get("aufraeumen")
    if not a:
        return
    ordner, muster = a
    try:
        for p in glob.glob(os.path.join(ordner, muster)):
            if os.path.getmtime(p) >= lauf["start"] - 1:
                for q in (p, p + "-wal", p + "-shm", p + "-journal"):
                    if os.path.exists(q):
                        os.remove(q)
    except Exception:
        pass


def abbrechen(dialog):
    """Laufenden Kindprozess beenden; der OSM-Abruf im eigenen Prozess bekommt sein Abbruchsignal."""
    try:
        from .werkzeuge.cluster import osm
        osm.abbrechen()
    except Exception:
        pass
    lauf = _LAEUFE.get(id(dialog))
    if lauf is not None:
        lauf["abgebrochen"] = True
        try:
            lauf["prozess"].kill()
        except Exception:
            pass


def laeuft(dialog):
    lauf = _LAEUFE.get(id(dialog))
    try:
        return lauf is not None and lauf["prozess"].state() != QProcess.NotRunning
    except Exception:
        return False


def alle_abbrechen():
    """Beim Schliessen des Werkzeugfensters: keine verwaisten Kindprozesse."""
    for lauf in list(_LAEUFE.values()):
        lauf["abgebrochen"] = True
        try:
            lauf["prozess"].kill()
        except Exception:
            pass


def warten(dialog, sekunden=600):
    """Nur fuer Tests: Ereignisschleife treiben, bis der Kindprozess fertig ist."""
    from qgis.PyQt.QtWidgets import QApplication
    t0 = time.time()
    while laeuft(dialog) and time.time() - t0 < sekunden:
        QApplication.processEvents()
        time.sleep(0.02)
    for _ in range(5):
        QApplication.processEvents()
