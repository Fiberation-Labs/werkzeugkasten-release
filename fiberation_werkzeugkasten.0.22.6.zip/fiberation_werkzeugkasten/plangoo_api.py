# -*- coding: utf-8 -*-
"""Die eine Stelle, an der der Werkzeugkasten das Plan[Goo]-Plugin (technik_plangoo_v2_vds_main) anfasst (Markus 12.10.2026).

Vorher lagen importlib-Aufrufe in sieben Modulen; ein Plan[Goo]-Update brach dann an sieben Stellen. Jetzt: alle Zugriffe hier,
mit Versionsangabe fuers Protokoll. Die Core-API ist nicht oeffentlich dokumentiert - was hier steht, ist aus dem Plugin-Quellcode
im QGIS-Profil abgelesen (Memory: Plan[Goo]-Quellcode liegt lesbar unter plugins/technik_plangoo_v2_vds_main)."""
import importlib
import os

M = "technik_plangoo_v2_vds_main"
GEPRUEFT_MIT = "2.x (Stand 12.10.2026)"


def ordner():
    """Installationsordner des Plan[Goo]-Plugins (ohne Import - der Import braucht eine laufende QGIS-Oberflaeche), sonst None."""
    import sys
    kandidaten = list(sys.path) + [os.path.join(os.environ.get("APPDATA", ""), "QGIS", "QGIS3", "profiles", "default", "python", "plugins")]
    for basis in kandidaten:
        p = os.path.join(str(basis), M)
        if os.path.isfile(os.path.join(p, "metadata.txt")):
            return p
    return None


def verfuegbar():
    return ordner() is not None


def version():
    """Version aus der metadata.txt des Plan[Goo]-Plugins oder ''."""
    p = ordner()
    if not p:
        return ""
    try:
        for z in open(os.path.join(p, "metadata.txt"), encoding="utf-8", errors="replace"):
            k, _, w = z.partition("=")
            if k.strip().lower() == "version":          # Plan[Goo] schreibt "version = 2.25.6" mit Leerzeichen
                return w.strip()
    except Exception:
        pass
    return ""


def modul(name):
    """Untermodul von Plan[Goo], z. B. 'core.components' oder 'core.utilities.constants'."""
    return importlib.import_module(M + "." + name)


def klasse(pfad, name):
    return getattr(modul(pfad), name)


def konstanten():
    return modul("core.utilities.constants")


def komponenten():
    return modul("core.components")


def instanz():
    """Aktive Plan[Goo]-Projektinstanz oder None (auch None, wenn Plan[Goo] gar nicht installiert ist)."""
    try:
        return modul("core.project.instance").GooInstances.get_active_instance()
    except ImportError:
        return None


def instanz_noetig():
    inst = instanz()
    if inst is None:
        raise RuntimeError("Kein Plan[Goo]-Projekt geoeffnet (In Bearbeitung nehmen).")
    return inst
