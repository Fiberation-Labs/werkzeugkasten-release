# -*- coding: utf-8 -*-
"""Attributformular fuer die Planungslayer (Markus 27.10.2026): zeichnet der Planer eine Trasse von Hand, zeigt QGIS danach das
Attributformular. Dort sollen die Plan[Goo]-Felder dieselben Auswahllisten haben wie die Leiste "Trassenattribute" im Dialog
(Bestand, Bauverfahren, Oberflaeche, Zulage, Lagehinweis, WeSi, Hauszufuehrung) - keine freien Textfelder, nichts erfinden.

einrichten(lyr, listen, fest=(), alias=None) -> Zahl der Felder mit Auswahlliste.
  listen: dict Feldname -> Liste von (Anzeige, Wert). Nur Felder, die der Layer hat, werden eingerichtet.
  fest:   Felder, die das Werkzeug selbst setzt (uid, nvt, laenge_m, quelle, kante, status) - im Formular nur lesbar.
  alias:  dict Feldname -> Beschriftung im Formular und in der Attributtabelle.
Das Formular wird fuer den Layer ausdruecklich eingeschaltet (SuppressOff), sonst greift die globale QGIS-Einstellung
"Attributformular beim Erstellen unterdruecken" und der Planer sieht die Listen nie.

Falle: QgsEditFormConfig kommt als Kopie - Aenderungen daran erst mit setEditFormConfig zurueckgeben. ValueMap-Konfiguration ist seit
QGIS 3.x eine Liste einelementiger dicts {Anzeige: Wert} (die Reihenfolge bleibt so erhalten; ein dict wuerde Werte alphabetisch sortieren)."""
from qgis.core import QgsEditFormConfig, QgsEditorWidgetSetup

LEER = "- leer -"


def liste(werte, leer=True):
    """Werteliste (Text) -> Liste (Anzeige, Wert); leerer Wert wird als '- leer -' gezeigt und steht vorn."""
    paare = []
    if leer and "" not in werte:
        paare.append((LEER, ""))
    for w in werte:
        paare.append((LEER if w == "" else str(w), w))
    return paare


def einrichten(lyr, listen, fest=(), alias=None):
    fl = lyr.fields()
    n = 0
    for feld, paare in listen.items():
        i = fl.indexOf(feld)
        if i < 0:
            continue
        lyr.setEditorWidgetSetup(i, QgsEditorWidgetSetup("ValueMap", {"map": [{str(a): w} for a, w in paare]}))
        n += 1
    cfg = lyr.editFormConfig()
    for feld in fest:
        i = fl.indexOf(feld)
        if i >= 0:
            cfg.setReadOnly(i, True)
    aus = getattr(QgsEditFormConfig, "SuppressOff", None)
    if aus is None:
        aus = QgsEditFormConfig.FeatureFormSuppress.SuppressOff
    cfg.setSuppress(aus)
    lyr.setEditFormConfig(cfg)
    for feld, text in (alias or {}).items():
        i = fl.indexOf(feld)
        if i >= 0:
            lyr.setFieldAlias(i, text)
    return n


def hat_liste(lyr, feld):
    """-> True, wenn das Feld eine Auswahlliste (ValueMap) traegt."""
    i = lyr.fields().indexOf(feld)
    return i >= 0 and lyr.editorWidgetSetup(i).type() == "ValueMap"


# --- Schritt 5: Planung ---------------------------------------------------------------------------------------------------------------------
# Markus 27.10.2026, zweiter Anlauf: der Layer "5 Planung" kommt oft aus dem gespeicherten QGIS-Projekt, nicht aus dem Dialog - dann hat
# der Dialog ihn nie angefasst und das Formular zeigte Textfelder. Darum haengt die Einrichtung am Projekt: jeder Planung-Layer bekommt
# die Listen, sobald er im Projekt auftaucht (Projekt oeffnen, Dialog laedt, Planer zieht die gpkg selbst hinein).

def ist_planung(lyr):
    """-> True fuer einen Vektorlayer aus einer trassen_*.gpkg, Ebene planung, mit den Plan[Goo]-Feldern."""
    try:
        quelle = lyr.source() if hasattr(lyr, "source") else ""
        return ("layername=planung" in quelle and "|layername=planung_" not in quelle and hasattr(lyr, "fields")
                and lyr.fields().indexOf("bauverfahren") >= 0 and lyr.fields().indexOf("nvt") >= 0)
    except Exception:
        return False


def trassen_planung(lyr):
    """Formular der Planung (Schritt 5) wie die Leiste Trassenattribute. -> Zahl der Felder mit Auswahlliste."""
    from . import schema
    from .werkzeuge.trassen import kern
    return einrichten(lyr, {
        "bestand": [("nein", 0), ("ja", 1)],
        "bauverfahren": liste(kern.BAUVERFAHREN_PG),
        "surface": liste(kern.SURFACE_PG),
        "allowance": liste(kern.ALLOWANCE_PG),
        "location_hint": liste(kern.LOCATION_PG),
        "wesi": liste(kern.WESI_PG),
        "sub_type": [("nein", ""), ("ja", "Hauszufuehrung")],
        "typ": liste(schema.TRASSEN_TYPEN, leer=False)},
        fest=("uid", "nvt", "laenge_m", "quelle", "kante", "status"),
        alias={"bestand": "Bestand", "bauverfahren": "Bauverfahren", "surface": "Oberflaeche", "allowance": "Zulage",
               "location_hint": "Lagehinweis", "wesi": "WeSi", "sub_type": "Hauszufuehrung", "typ": "Typ", "laenge_m": "Laenge m",
               "hinweis": "Hinweis", "status": "Status", "nvt": "NVT"})


def layer_einrichten(lyr):
    """Ein beliebiger Layer: passt er zu einem Schritt, bekommt er dessen Formular. -> Name des Schritts oder None."""
    if ist_planung(lyr):
        trassen_planung(lyr)
        return "planung"
    return None


_beobachter = {"verbunden": False}


def projekt_beobachten():
    """Einmal beim Plugin-Start: alle Layer, die jetzt oder spaeter im Projekt liegen, bekommen ihr Formular. -> Zahl der jetzt eingerichteten."""
    from qgis.core import QgsProject
    n = 0
    for lyr in list(QgsProject.instance().mapLayers().values()):
        if layer_einrichten(lyr):
            n += 1
    if not _beobachter["verbunden"]:
        QgsProject.instance().layersAdded.connect(_layer_hinzu)
        _beobachter["verbunden"] = True
    return n


def _layer_hinzu(layer_liste):
    for lyr in layer_liste:
        try:
            layer_einrichten(lyr)
        except Exception:
            pass


def projekt_loslassen():
    if _beobachter["verbunden"]:
        try:
            from qgis.core import QgsProject
            QgsProject.instance().layersAdded.disconnect(_layer_hinzu)
        except Exception:
            pass
        _beobachter["verbunden"] = False
