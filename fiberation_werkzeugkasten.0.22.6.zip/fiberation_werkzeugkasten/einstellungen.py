# -*- coding: utf-8 -*-
"""Einstellungen: Startwarnungen von Plan[Goo] unterdruecken (an/aus), Materialkonzept-Version fuer MBfD (regelwerk)."""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QCheckBox, QComboBox, QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from . import ci, regelwerk


class EinstellungenDialog(QDialog):
    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.setWindowTitle("Fiberation Werkzeugkasten - Einstellungen")
        self.setMinimumWidth(520)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 16, 20, 14)
        lay.setSpacing(10)
        lay.addWidget(ci.logo_label(36))
        self.haken = QCheckBox("Startwarnungen von Plan[Goo] unterdruecken (QGIS-Thema nicht 'default', Sprache)")
        self.haken.setChecked(plugin.warnungen_unterdruecken())
        lay.addWidget(self.haken)
        hinweis = QLabel("Wirkt beim Laden des Plugins. Plan[Goo] wird alphabetisch nach diesem Plugin geladen, deshalb greift die "
                         "Unterdrueckung vor der ersten Warnung. Eine Aenderung wird beim naechsten QGIS-Start wirksam.")
        hinweis.setWordWrap(True)
        hinweis.setStyleSheet("color:{};".format(ci.GRAU))
        lay.addWidget(hinweis)
        zeile = QHBoxLayout()
        zeile.addWidget(QLabel("Materialkonzept (MBfD):"))
        self.mk = QComboBox()
        for v in regelwerk.MK_VERSIONEN:
            self.mk.addItem("{} - {}".format(v, regelwerk.mk_text(v)), v)
        i = self.mk.findData(regelwerk.materialkonzept())
        self.mk.setCurrentIndex(i if i >= 0 else 0)
        self.mk.setToolTip("Steht im Zuwendungsbescheid des Foerdergebiets. Gilt fuer Schritt 2 (Bedarf), 3 (Regelsatz), 8 (Kollokation).")
        zeile.addWidget(self.mk, 1)
        lay.addLayout(zeile)
        mk_hinweis = QLabel("Vorgabe 5.0, solange kein Zuwendungsbescheid vorliegt (30.09.2026). Ab 4.1 zusaetzliche Hk-Reserveverbaende, "
                            "ab 5.0 Kollokationspunkt nur bei NVT ueber 95 WE und Kollokationsmuffen. Wirkt sofort auf neue Laeufe.")
        mk_hinweis.setWordWrap(True)
        mk_hinweis.setStyleSheet("color:{};".format(ci.GRAU))
        lay.addWidget(mk_hinweis)
        knoepfe = QHBoxLayout()
        knoepfe.addStretch(1)
        ab = QPushButton("Abbrechen")
        ab.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        ab.clicked.connect(self.reject)
        ok = QPushButton("Speichern")
        ok.setStyleSheet(ci.STIL_KNOPF)
        ok.setCursor(Qt.PointingHandCursor)
        ok.clicked.connect(self._speichern)
        knoepfe.addWidget(ab)
        knoepfe.addWidget(ok)
        lay.addLayout(knoepfe)
        from . import fenster
        fenster.einrichten(self, "einstellungen", None, eigenes_fenster=False, scrollen=False)

    def _speichern(self):
        self.plugin.warnungen_setzen(self.haken.isChecked())
        regelwerk.materialkonzept_setzen(self.mk.currentData())
        if self.haken.isChecked():
            from . import patches
            patches.startwarnungen_aus()
        self.accept()
