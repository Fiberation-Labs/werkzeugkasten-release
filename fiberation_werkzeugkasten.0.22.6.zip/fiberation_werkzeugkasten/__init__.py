# -*- coding: utf-8 -*-
"""Fiberation Werkzeugkasten - QGIS-Plugin: Planer-Werkzeuge fuer Plan[Goo] V2 (Telekom VDS)."""
import os

# openpyxl darf in QGIS kein lxml nutzen: GDAL (GML-Leser der ALKIS-WFS) und lxml bringen je ein libxml2 mit; beim zweiten Excel im selben
# Prozess gibt es sonst eine Zugriffsverletzung (QGIS stuerzt ab). Wirkt nur, wenn openpyxl noch nicht importiert ist - deshalb hier ganz vorn.
os.environ.setdefault("OPENPYXL_LXML", "False")


def classFactory(iface):
    from .plugin import WerkzeugkastenPlugin
    return WerkzeugkastenPlugin(iface)
