# -*- coding: utf-8 -*-
"""Zentrales Regelwerk: Ausbautreiber -> Regelsatz (Eigenausbau / MBfD) und Materialkonzept-Version. Ohne Qt-Pflicht.

Markus 30.09.2026: MBfD wurde bis 0.17.6 an vier Stellen verschieden erkannt (Adressen, Cluster, Trassen, Kollo) und die
Materialkonzept-Version kannte nur Schritt 8. Hier steht beides einmal; alle Schritte lesen von hier.

Regelsatz:      "eigen" (Eigenausbau ZTV 21, SNR 7) oder "mbfd" (Bundesfoerderung, ZTV 21 Kap. 13, SNR 12, 4 Fs je WE + 2 je Gebaeude,
                HUEP, Kollokation). Erkannt am Ausbautreiber/Sponsor (Plan[Goo] SETTINGS.AUSBAUTREIBER bzw. Spalte sponsor) oder am
                Regelsatz-Namen im Gebietslayer aus Schritt 3.
Materialkonzept: 3.0 / 3.1 / 4.0 / 4.1 / 5.0 - steht im Zuwendungsbescheid. Vorgabe 5.0, solange kein Bescheid vorliegt
                (Markus 30.09.2026: "Konzept ab 5.0, habe keine Zuwendungsbescheide bisher"). Ab 4.1 zusaetzliche Hk-Reserveverbaende,
                ab 5.0 Kollokationspunkte nur bei NVT > 95 WE (sonst Kollokationsmuffen) und Bauluecken mit vorbereiten.
"""

MK_VERSIONEN = ("5.0", "4.1", "4.0", "3.1", "3.0")
MK_VORGABE = "5.0"
EINSTELLUNG_MK = "fiberation_werkzeugkasten/materialkonzept"

_MBFD_WOERTER = ("mbfd", "gf+", "glasfaserplus", "foerder", "förder", "bundesf", "baygibit", "gigabitr")


def ist_mbfd_text(text):
    """True, wenn ein Ausbautreiber-/Sponsor-/Regelsatz-Text auf Bundesfoerderung hinweist."""
    t = (text or "").lower()
    return any(w in t for w in _MBFD_WOERTER)


def regelsatz_fuer(treiber):
    """Ausbautreiber (Text) -> Schluessel des Regelsatzes in cluster.config.REGELSAETZE."""
    return "mbfd" if ist_mbfd_text(treiber) else "eigen"


def regelsatz_aus_gebieten(gebiete, vorgabe="eigen"):
    """Regelsatz-Schluessel aus dem Gebietslayer von Schritt 3 (Spalte regelsatz = Name, z. B. 'MBfD ZTV 21 (Gf-NVt 22 L BF)')."""
    try:
        if gebiete is None or not len(gebiete) or "regelsatz" not in gebiete:
            return vorgabe
        name = str(gebiete["regelsatz"].iloc[0] or "")
    except Exception:
        return vorgabe
    if not name:
        return vorgabe
    if "xs" in name.lower() and ist_mbfd_text(name):
        return "mbfd_xs"
    return "mbfd" if ist_mbfd_text(name) else "eigen"


def ist_mbfd_regelsatz(schluessel_oder_name):
    return ist_mbfd_text(schluessel_oder_name)


def materialkonzept():
    """Eingestellte Materialkonzept-Version (Einstellungen-Dialog, QSettings). Ohne QGIS: Umgebungsvariable
    FIBERATION_MATERIALKONZEPT oder Vorgabe."""
    import os
    v = os.environ.get("FIBERATION_MATERIALKONZEPT", "")
    if not v:
        try:
            from qgis.PyQt.QtCore import QSettings
            v = QSettings().value(EINSTELLUNG_MK, MK_VORGABE, type=str) or MK_VORGABE
        except Exception:
            v = MK_VORGABE
    return v if v in MK_VERSIONEN else MK_VORGABE


def materialkonzept_setzen(v):
    from qgis.PyQt.QtCore import QSettings
    QSettings().setValue(EINSTELLUNG_MK, v if v in MK_VERSIONEN else MK_VORGABE)


def mk_ab(version, mindestens):
    """True, wenn Materialkonzept `version` >= `mindestens` (Zeichenketten '4.1' usw.)."""
    def _t(s):
        try:
            return tuple(int(x) for x in str(s).split("."))
        except Exception:
            return (0,)
    return _t(version) >= _t(mindestens)


# Plan[Goo]-Materialschluessel der Gehaeuse (core/templates/materiallisten/materials.json, geprueft 30.09.2026):
#   Eigenausbau NVt22 L: GH_OCL Langmatz / GH_OCS Sichert / GH_OCR Raycap, XS: GH_OCLXS
#   MBfD (BF) NVt22 L: GH_NCL Langmatz / GH_NCS Sichert / GH_NCR Raycap, XS: GH_NCLXS (Ausbautreiber mbfd2022/2023, glasfaserplus_mbfd_2023)
#   Dornberg-Angebot 521_10_BLFD: 16 NVT GH_NCL, die 74 APL tragen im Angebot kein Material (Gf-AP HUEP AP_HA..AP_HF setzt Plan[Goo] spaeter).
NVT_MATERIAL = {"eigen": "GH_OCL", "mbfd": "GH_NCL", "mbfd_xs": "GH_NCLXS"}
NVT_MATERIAL_ALLE = {"eigen": ("GH_OCL", "GH_OCS", "GH_OCR", "GH_OCLXS"), "mbfd": ("GH_NCL", "GH_NCS", "GH_NCR", "GH_NCLXS"),
                     "mbfd_xs": ("GH_NCLXS", "GH_NCL", "GH_NCS", "GH_NCR")}


def nvt_material_key(regelsatz):
    """Vorgabe-Gehaeuse fuer neue NVT je Regelsatz (Langmatz wie in den Telekom-Angeboten)."""
    return NVT_MATERIAL.get(regelsatz or "eigen", "GH_OCL")


def nvt_material_passt(key, regelsatz):
    """True, wenn ein vorhandenes Gehaeuse-Material zum Regelsatz (Ausbautreiber) passt."""
    return (key or "") in NVT_MATERIAL_ALLE.get(regelsatz or "eigen", ())


def mk_text(version=None):
    v = version or materialkonzept()
    zeilen = {
        "5.0": "Kollokationspunkt nur NVT > 95 WE, kleinere NVT ueber Kollokationsmuffen; Bauluecken/nicht gefoerderte Adressen bis zur Grundstuecksgrenze mit vorbereiten; Hk-Reserveverbaende 12x12",
        "4.1": "jeder NVT ist Kollokationspunkt, keine Muffen; zusaetzliche Hk-Reserveverbaende 12x12 (bis 1 km +1, darueber +2), Vzk zu Schulen/Krankenhaeusern +1x 12x12",
        "4.0": "jeder NVT ist Kollokationspunkt, keine Muffen, keine zusaetzlichen Reserveverbaende",
        "3.1": "jeder NVT ist Kollokationspunkt, keine Muffen, keine zusaetzlichen Reserveverbaende",
        "3.0": "jeder NVT ist Kollokationspunkt, keine Muffen, keine zusaetzlichen Reserveverbaende",
    }
    return zeilen.get(v, "")
