# -*- coding: utf-8 -*-
"""Fensterverhalten fuer alle Dialoge: eigenes Fenster mit Schliessen/Minimieren/Maximieren, scrollbarer Inhalt, Groesse und Lage
merken, nie ausserhalb des Bildschirms.

einrichten(dialog, schluessel, inhalt_min_breite) am Ende des Konstruktors aufrufen:
- Der Dialog wird ein eigenstaendiges Fenster (Qt.Window, kein Eltern-Fenster): mit den drei Knoepfen in der Titelleiste und einem
  eigenen Eintrag in der Windows-Taskleiste. Er kann hinter QGIS rutschen; der Knopf in der Werkzeugleiste holt ihn wieder nach vorn.
- Der bereits gebaute Inhalt wandert in einen QScrollArea; der Dialog darf kleiner sein als sein Inhalt (Laptop, QGIS daneben).
- Beim Anzeigen werden Groesse und Lage vom letzten Mal wiederhergestellt und auf den sichtbaren Bildschirmbereich begrenzt. Ein Fenster,
  das ausserhalb geschoben oder auf einem abgesteckten zweiten Monitor gelassen wurde, kommt beim naechsten Oeffnen zurueck.
hervorholen(dialog) zeigt ein Fenster, holt es in den sichtbaren Bereich, entminimiert es und legt es nach vorn.
einbetten(dialog) macht aus einem so eingerichteten Dialog wieder eine Seite fuer das Hauptfenster (Markus 18.09.2026: eine Kachel
oeffnet im selben Fenster, nicht in einem neuen): Fensterflags weg, Waechter weg, eigener Kopf und Schliessen-Knopf ausgeblendet.
"""
from qgis.PyQt.QtCore import QEvent, QObject, QPoint, QRect, QSettings, Qt
from qgis.PyQt.QtWidgets import QAbstractScrollArea, QApplication, QScrollArea, QVBoxLayout, QWidget

SCHLUESSEL = "fiberation_werkzeugkasten/fenster/"
MIN_BREITE_DIALOG = 480
MIN_HOEHE_DIALOG = 320
FLAGS = Qt.Window | Qt.WindowSystemMenuHint | Qt.WindowMinimizeButtonHint | Qt.WindowMaximizeButtonHint | Qt.WindowCloseButtonHint


def _bildschirme():
    try:
        g = [s.availableGeometry() for s in QApplication.screens()]
        if g:
            return g
    except Exception:
        pass
    return [QApplication.desktop().availableGeometry()]


def qgis_fenster():
    """Hauptfenster von QGIS (Bezug fuer die Lage), sonst None."""
    try:
        for w in QApplication.topLevelWidgets():
            if w.objectName() == "QgisApp" or w.metaObject().className() == "QgisApp":
                return w
    except Exception:
        pass
    return None


def _bildschirm_fuer(rect, bezug=None):
    """Bildschirmbereich, der den groessten Teil von rect enthaelt; sonst der des Bezugsfensters; sonst der erste."""
    beste, flaeche = None, 0
    for g in _bildschirme():
        s = g.intersected(rect)
        a = s.width() * s.height() if s.isValid() else 0
        if a > flaeche:
            beste, flaeche = g, a
    if beste is not None:
        return beste
    if bezug is not None:
        try:
            for g in _bildschirme():
                if g.contains(bezug.frameGeometry().center()):
                    return g
        except Exception:
            pass
    return _bildschirme()[0]


def sichtbar_machen(rect, bezug=None):
    """Fenstergeometrie so verschieben und ggf. verkleinern, dass sie ganz im sichtbaren Bereich eines Bildschirms liegt."""
    g = _bildschirm_fuer(rect, bezug)
    r = QRect(rect)
    if r.width() > g.width():
        r.setWidth(g.width())
    if r.height() > g.height():
        r.setHeight(g.height())
    if r.right() > g.right():
        r.moveRight(g.right())
    if r.bottom() > g.bottom():
        r.moveBottom(g.bottom())
    if r.left() < g.left():
        r.moveLeft(g.left())
    if r.top() < g.top():
        r.moveTop(g.top())
    return r


def _rahmen_versatz(d):
    """Hoehe der Titelleiste (frameGeometry gegen geometry), damit auch der Rahmen im Bild bleibt."""
    try:
        return d.frameGeometry().height() - d.geometry().height()
    except Exception:
        return 0


def hervorholen(dialog):
    """Fenster zeigen, in den sichtbaren Bereich holen, entminimieren, nach vorn legen."""
    if dialog.isMinimized():
        dialog.setWindowState(dialog.windowState() & ~Qt.WindowMinimized)
    dialog.show()
    if not dialog.isMaximized():
        r = dialog.geometry()
        v = _rahmen_versatz(dialog)
        rahmen = QRect(r.x(), r.y() - v, r.width(), r.height() + v)
        neu = sichtbar_machen(rahmen, qgis_fenster())
        if neu != rahmen:
            dialog.setGeometry(QRect(neu.x(), neu.y() + v, neu.width(), neu.height() - v))
    dialog.raise_()
    dialog.activateWindow()


class _Waechter(QObject):
    """Merkt Groesse und Lage beim Schliessen/Verstecken, stellt sie beim Anzeigen wieder her und haelt das Fenster sichtbar."""

    def __init__(self, dialog, schluessel):
        super().__init__(dialog)
        self.dialog = dialog
        self.schluessel = SCHLUESSEL + schluessel
        self._wiederhergestellt = False

    def eventFilter(self, obj, ev):
        t = ev.type()
        if t == QEvent.Show:
            if not self._wiederhergestellt:
                self._wiederhergestellt = True
                self._wiederherstellen()
            else:
                self._begrenzen()
        elif t in (QEvent.Hide, QEvent.Close):
            self._merken()
        return False

    def _merken(self):
        try:
            if self.dialog.isMinimized() or self.dialog.isMaximized():
                return
            r = self.dialog.geometry()
            QSettings().setValue(self.schluessel, "{},{},{},{}".format(r.x(), r.y(), r.width(), r.height()))
        except Exception:
            pass

    def _begrenzen(self):
        d = self.dialog
        if d.isMaximized():
            return
        neu = sichtbar_machen(d.geometry(), qgis_fenster())
        if neu != d.geometry():
            d.setGeometry(neu)

    def _wiederherstellen(self):
        d = self.dialog
        roh = QSettings().value(self.schluessel, "", type=str) or ""
        rect = None
        try:
            x, y, w, h = [int(v) for v in roh.split(",")]
            if w >= 200 and h >= 150:
                rect = QRect(x, y, w, h)
        except Exception:
            rect = None
        bezug = qgis_fenster()
        if rect is None:
            # erstes Oeffnen: Wunschgroesse, hoechstens 90 % des Bildschirms, mittig ueber QGIS
            g = _bildschirm_fuer(bezug.frameGeometry() if bezug is not None else d.frameGeometry(), bezug)
            sh = d.sizeHint()
            inhalt = getattr(d, "_fwk_inhalt", None)
            if inhalt is not None:
                si = inhalt.sizeHint()
                sh.setWidth(max(sh.width(), si.width() + 24, inhalt.minimumWidth() + 24))
                sh.setHeight(max(sh.height(), si.height() + 8))
            w = min(max(sh.width(), d.minimumWidth()), int(g.width() * 0.9))
            h = min(max(sh.height(), d.minimumHeight()), int(g.height() * 0.9))
            mitte = bezug.frameGeometry().center() if bezug is not None else g.center()
            rect = QRect(QPoint(mitte.x() - w // 2, mitte.y() - h // 2), d.size())
            rect.setWidth(w)
            rect.setHeight(h)
        d.setGeometry(sichtbar_machen(rect, bezug))


def einrichten(dialog, schluessel, inhalt_min_breite=None, eigenes_fenster=True, scrollen=True):
    """Eigenes Fenster mit drei Knoepfen, Inhalt scrollbar, Mindestgroesse lockern, Groesse/Lage merken und sichtbar halten."""
    alt = dialog.layout()
    if scrollen and alt is not None and dialog.findChild(QScrollArea, "fwk_scroll") is None:
        inhalt = QWidget()
        inhalt.setLayout(alt)  # Qt uebernimmt das Layout vom Dialog auf das Inhalts-Widget
        if inhalt_min_breite:
            inhalt.setMinimumWidth(inhalt_min_breite)
        scroll = QScrollArea(dialog)
        scroll.setObjectName("fwk_scroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setSizeAdjustPolicy(QAbstractScrollArea.AdjustToContents)  # Wunschgroesse = Inhalt
        scroll.setWidget(inhalt)
        dialog._fwk_inhalt = inhalt
        # Drag und Drop faellt durch bis zum Dialog (dragEnterEvent/dropEvent dort)
        scroll.setAcceptDrops(False)
        scroll.viewport().setAcceptDrops(False)
        inhalt.setAcceptDrops(False)
        aussen = QVBoxLayout(dialog)
        aussen.setContentsMargins(0, 0, 0, 0)
        aussen.addWidget(scroll)
        dialog.setMinimumWidth(MIN_BREITE_DIALOG)
        dialog.setMinimumHeight(MIN_HOEHE_DIALOG)
    if eigenes_fenster:
        # kein Eltern-Fenster mehr: eigener Taskleisten-Eintrag, Minimieren/Maximieren/Schliessen funktionieren wie bei jedem Fenster
        dialog.setParent(None)
        dialog.setWindowFlags(FLAGS)
    else:
        dialog.setWindowFlags(dialog.windowFlags() | Qt.WindowMaximizeButtonHint | Qt.WindowCloseButtonHint)
    dialog.setSizeGripEnabled(True)
    dialog._fwk_waechter = _Waechter(dialog, schluessel)
    dialog.installEventFilter(dialog._fwk_waechter)


def einbetten(dialog):
    """Dialog als Seite eines anderen Fensters vorbereiten: kein eigenes Fenster, keine Groessen-/Lage-Verwaltung, kein Groessengriff.
    Kopf (ci.kopf_widget, Attribut kopf) und Schliessen-Knopf (Attribut k_schliessen) werden ausgeblendet - der Kopf des Hauptfensters
    zeigt Titel und Untertitel, die Navigation ersetzt Schliessen. Der Aufrufer haengt den Dialog danach in sein Layout/QStackedWidget."""
    w = getattr(dialog, "_fwk_waechter", None)
    if w is not None:
        try:
            dialog.removeEventFilter(w)
        except Exception:
            pass
        dialog._fwk_waechter = None
    dialog.setWindowFlags(Qt.Widget)
    dialog.setSizeGripEnabled(False)
    dialog.setMinimumWidth(0)
    dialog.setMinimumHeight(0)
    for name in ("kopf", "k_schliessen"):
        wdg = getattr(dialog, name, None)
        if wdg is not None:
            try:
                wdg.hide()
            except Exception:
                pass
    return dialog
