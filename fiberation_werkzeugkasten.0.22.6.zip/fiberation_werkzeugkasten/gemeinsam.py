# -*- coding: utf-8 -*-
"""Gemeinsame Kernhilfen aller Schritte (Markus 12.10.2026: "mache alles einheitlich und kuerze redundante Funktionen").

Vorher hatte jeder Kern seine eigene Fassung von _s (Wert -> Text), der natuerlichen Sortierung, von wal_schliessen und der uid-Vergabe.
Hier steht jede Hilfe einmal; die Kerne binden sie unter ihrem alten Namen ein (_s = gemeinsam.s), damit die Aufrufe gleich bleiben."""
import math
import re
import uuid

_LEER = ("None", "nan", "NULL", "NaT")
_TEILE = re.compile(r"(\d+)")


def s(v, leer=""):
    """Wert -> Text ohne Rand; None, NaN, QVariant-Null und die Texte None/nan/NULL werden `leer`."""
    if v is None:
        return leer
    try:
        from qgis.PyQt.QtCore import QVariant
        if isinstance(v, QVariant):
            return leer if v.isNull() else s(v.value(), leer)
    except Exception:
        pass
    try:
        if isinstance(v, float) and math.isnan(v):
            return leer
    except Exception:
        pass
    t = str(v).strip()
    return leer if t in _LEER else t


def s_oder_none(v):
    """Wie s(), aber None statt leerem Text (fuer GeoPackage-Textspalten, die NULL bleiben sollen)."""
    t = s(v)
    return t if t != "" else None


def s_ganz(v):
    """Wie s(), zusaetzlich ohne ein angehaengtes '.0' (Hausnummern und Flurstuecke aus Zahlenspalten: 12.0 -> 12)."""
    t = s(v)
    return t[:-2] if t.endswith(".0") else t


def natsort(n):
    """Sortierschluessel: Zahlen in Texten als Zahlen (1V2 vor 1V10), Gross/Klein egal."""
    return [int(t) if t.isdigit() else t.lower() for t in _TEILE.split(str(n))]


def wal_schliessen(gpkg):
    """GeoPandas/GDAL laesst das GeoPackage im WAL-Modus zurueck, wenn es geoeffnet war; Checkpoint und zurueck auf DELETE-Journal,
    damit QGIS und der Kern denselben Stand lesen."""
    import sqlite3
    try:
        con = sqlite3.connect(gpkg)
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        con.execute("PRAGMA journal_mode=DELETE")
        con.commit()
        con.close()
    except Exception:
        pass


def uid(praefix, kuerzel=""):
    """Kurze eindeutige Kennung '<praefix>_<kuerzel><6 hex>'; Schraegstriche und Leerzeichen im Praefix werden ersetzt."""
    p = str(praefix or "").replace("/", "-").replace(" ", "") or "x"
    return "{}_{}{}".format(p, kuerzel, uuid.uuid4().hex[:6])
