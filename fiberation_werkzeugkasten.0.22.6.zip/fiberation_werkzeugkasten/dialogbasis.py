# -*- coding: utf-8 -*-
"""Gemeinsame Basis aller Schritt-Dialoge (Markus 12.10.2026: einheitlich, keine zwoelf Kopien derselben Hilfen).

WerkzeugDialog liefert, was jeder Dialog gleich braucht: Ueberschrift, Zahlenfeld, Protokoll, Fortschritt, Datei oeffnen, Abbrechen des
OSM-Abrufs, Beschriftung eines Layers und Drag-and-Drop. Ein Dialog ueberschreibt nur _datei_fallen_gelassen(pfad) -> True, wenn er die
Datei genommen hat. Erwartet werden die Widgets self.log (QTextEdit) und self.balken (QProgressBar), wo Protokoll und Fortschritt genutzt werden."""
import os

from qgis.core import QgsPalLayerSettings, QgsTextBufferSettings, QgsTextFormat, QgsVectorLayerSimpleLabeling
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import QApplication, QDialog, QDoubleSpinBox, QLabel, QMessageBox, QSpinBox

from . import ci


class WerkzeugDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface

    # --- Oberflaeche ---------------------------------------------------------------------------------------------------------------------
    def _ueberschrift(self, t):
        lab = QLabel(t.upper())
        lab.setStyleSheet("font-size:11px; font-weight:700; letter-spacing:1px; color:{}; margin-top:4px;".format(ci.ORANGE_DUNKEL))
        return lab

    def _spin(self, a, b, v, breite=None):
        """Zahlenfeld: ganze Grenzen -> QSpinBox, sonst QDoubleSpinBox mit einer Nachkommastelle und Schritt 0,5."""
        if all(isinstance(x, int) and not isinstance(x, bool) for x in (a, b, v)):
            s = QSpinBox()
            s.setRange(a, b)
        else:
            s = QDoubleSpinBox()
            s.setRange(float(a), float(b))
            s.setDecimals(1)
            s.setSingleStep(0.5)
        s.setValue(v)
        if breite:
            s.setMaximumWidth(breite)
        return s

    # --- Protokoll und Fortschritt ----------------------------------------------------------------------------------------------------------
    def _log(self, text):
        log = getattr(self, "log", None)
        if log is None:
            return
        log.append(str(text))
        log.verticalScrollBar().setValue(log.verticalScrollBar().maximum())
        QApplication.processEvents()

    def _fortschritt(self, prozent, text):
        """Nie rueckwaerts (Abrufe teilen Kacheln nach und erhoehen die Gesamtzahl), ausser bei 0 (Neustart) und 100 (fertig)."""
        balken = getattr(self, "balken", None)
        if balken is None:
            return
        wert = int(max(0, min(100, prozent)))
        if wert < balken.value() and wert not in (0, 100):
            wert = balken.value()
        balken.setValue(wert)
        balken.setFormat("{}  %p%".format(text))
        QApplication.processEvents()

    def _oeffnen(self, pfad):
        if pfad and os.path.exists(pfad):
            import subprocess
            subprocess.Popen(["cmd", "/c", "start", "", pfad], shell=False)

    def _abbrechen(self):
        from . import hintergrund
        hintergrund.abbrechen(self)
        self._log("Abbruch angefordert.")

    def _lauf_fehler(self, titel, fehler, rueckverfolgung=""):
        """Einheitlicher Abschluss eines fehlgeschlagenen Kernlaufs (auch aus dem Hintergrund)."""
        from .werkzeuge.cluster import osm
        from . import hintergrund
        if isinstance(fehler, (osm.Abgebrochen, hintergrund.Abgebrochen)):
            self._fortschritt(0, "Abgebrochen")
            self._log("Abgebrochen: {}".format(fehler))
            return
        self._fortschritt(0, "Fehler")
        if hasattr(self, "k_log"):
            self.k_log.setChecked(True)
        self._log("Fehler: {!r}".format(fehler))
        if rueckverfolgung:
            self._log(rueckverfolgung[-1500:])
        QMessageBox.critical(self, titel, "{!r}\n\nEinzelheiten im Protokoll.".format(fehler)[:600])

    # --- Layer ----------------------------------------------------------------------------------------------------------------------------
    def _label(self, lyr, feld, groesse, fett, ausdruck=False, massstab=None):
        """Einfache Beschriftung: Feld oder Ausdruck, Groesse in pt, fett, weisser Puffer; massstab = ab diesem Nenner sichtbar."""
        st = QgsPalLayerSettings()
        st.fieldName = feld
        st.isExpression = bool(ausdruck)
        st.enabled = True
        if massstab:
            st.scaleVisibility = True
            st.minimumScale = massstab
            st.maximumScale = 0
        if hasattr(QgsPalLayerSettings, "MultiLeft"):
            st.multilineAlign = QgsPalLayerSettings.MultiLeft
        fmt = QgsTextFormat()
        fmt.setSize(groesse)
        fmt.setColor(QColor("#1A1A1A"))
        f = fmt.font()
        f.setBold(bool(fett))
        fmt.setFont(f)
        puffer = QgsTextBufferSettings()
        puffer.setEnabled(True)
        puffer.setSize(0.8)
        puffer.setColor(QColor("#FFFFFF"))
        fmt.setBuffer(puffer)
        st.setFormat(fmt)
        lyr.setLabelsEnabled(True)
        lyr.setLabeling(QgsVectorLayerSimpleLabeling(st))

    # --- Drag and Drop ------------------------------------------------------------------------------------------------------------------
    def dragEnterEvent(self, ev):
        if ev.mimeData().hasUrls():
            ev.acceptProposedAction()

    def dropEvent(self, ev):
        for u in ev.mimeData().urls():
            p = u.toLocalFile()
            if p and self._datei_fallen_gelassen(p):
                self._log("Datei uebernommen: " + p)
                ev.acceptProposedAction()
                return

    def _datei_fallen_gelassen(self, p):
        """Vom Dialog ueberschreiben: Datei p in das passende Feld nehmen. -> True, wenn genommen."""
        return False
