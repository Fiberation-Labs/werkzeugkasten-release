# -*- coding: utf-8 -*-
"""Layerbaum-Regeln fuer alle Schritte (Markus 18.09.2026): jeder erzeugte Layer und jede Gruppe traegt vorn die Schrittnummer
("2 Adressen", "3 NVT-Gebiete ..."), und die Gruppen ordnen sich im Layerbaum nach Nummer - unten Schritt 0 (Grundkarten), darueber 1, 2, ...
Spaetere Schritte zeichnen also ueber frueheren. Gruppen ohne Nummer (Plan[Goo]-Layer, eigene Layer des Planers) bleiben, wo sie sind.

gruppe(schluessel, rest, ueber=None)  -> neue, leere QgsLayerTreeGroup "<nr> <rest>" an der richtigen Stelle (eine gleichnamige alte
                                          Gruppe wird samt Layern entfernt). ueber = Gruppennamen, ueber denen die Gruppe liegen soll
                                          (Schritt 0: OSM ueber amtlich ueber Grundkarten).
einhaengen(gruppe, lyr, schluessel, sichtbar=True) -> Layer umbenennen ("<nr> <Name>"), ins Projekt, in die Gruppe; gibt den Knoten zurueck.
layername(schluessel, titel) / gruppenname(schluessel, rest) -> die Namen, wie sie im Baum stehen (fuer findGroup / Vergleiche).
ohne_nummer(name) -> Name ohne fuehrende Schrittnummer."""
import re

from qgis.core import QgsProject, QgsVectorLayer

from . import ablauf

_MUSTER = re.compile(r"^(\d+)\s+(.*)$")


def nummer(schluessel):
    s = ablauf.schritt(schluessel)
    return s[0] if s else ""


def gruppenname(schluessel, rest):
    n = nummer(schluessel)
    return "{} {}".format(n, rest) if n != "" else rest


def layername(schluessel, titel):
    n = nummer(schluessel)
    if n == "" or _MUSTER.match(titel):
        return titel
    return "{} {}".format(n, titel)


def ohne_nummer(name):
    m = _MUSTER.match(name or "")
    return m.group(2) if m else name


def _nummer_von(name):
    m = _MUSTER.match(name or "")
    return int(m.group(1)) if m else None


def leeren(name):
    """Gleichnamige Gruppe samt Layern entfernen."""
    wurzel = QgsProject.instance().layerTreeRoot()
    alt = wurzel.findGroup(name)
    if alt is not None:
        for l in alt.findLayers():
            QgsProject.instance().removeMapLayer(l.layerId())
        wurzel.removeChildNode(alt)


def einfuegeindex(nr, ueber=None):
    """Stelle im Wurzelknoten fuer eine Gruppe mit Nummer nr: Schritt 0 (Grundkarten) immer ganz unten, auch unter Plan[Goo]-Layern;
    sonst direkt ueber der ersten Gruppe mit kleinerer Nummer; gibt es keine, unter allen nummerierten Gruppen; gibt es gar keine
    nummerierten, ganz oben. `ueber` zieht noetigenfalls hoeher (Schritt 0: OSM ueber amtlich ueber Grundkarten)."""
    wurzel = QgsProject.instance().layerTreeRoot()
    kinder = wurzel.children()
    idx, letzter = None, None
    if nr == 0:
        idx = len(kinder)
        for u in (ueber or []):
            g = wurzel.findGroup(u)
            if g is not None and g in kinder:
                idx = min(idx, kinder.index(g))
        return idx
    for i, k in enumerate(kinder):
        if k.nodeType() != k.NodeGroup:
            continue
        n = _nummer_von(k.name())
        if n is None:
            continue
        letzter = i
        if n < nr and idx is None:
            idx = i
    if idx is None:
        idx = (letzter + 1) if letzter is not None else 0
    for u in (ueber or []):
        g = wurzel.findGroup(u)
        if g is not None and g in kinder:
            idx = min(idx, kinder.index(g))
    return idx


def aufraeumen(name_neu):
    """Markus 12.10.2026: entsteht eine neue Gruppe des Werkzeugkastens, klappen alle anderen nummerierten Gruppen im Layerbaum zu und
    ihre Beschriftungen gehen aus - keine Ueberlagerungen in der Karte, Baum und Karte bleiben aufgeraeumt. Gruppen ohne Nummer
    (Plan[Goo], eigene Layer des Planers) bleiben unberuehrt. Gibt die Zahl der Layer zurueck, deren Beschriftung ausging."""
    wurzel = QgsProject.instance().layerTreeRoot()
    n = 0
    for k in wurzel.children():
        if k.nodeType() != k.NodeGroup or _nummer_von(k.name()) is None or k.name() == name_neu:
            continue
        k.setExpanded(False)
        for kn in k.findLayers():
            l = kn.layer()
            if isinstance(l, QgsVectorLayer) and l.labelsEnabled():
                l.setLabelsEnabled(False)
                l.triggerRepaint()
                n += 1
    return n


def gruppe(schluessel, rest, ueber=None):
    name = gruppenname(schluessel, rest)
    leeren(name)
    nr = _nummer_von(name)
    wurzel = QgsProject.instance().layerTreeRoot()
    if nr is None:
        return wurzel.insertGroup(0, name)
    g = wurzel.insertGroup(einfuegeindex(nr, ueber), name)
    try:
        aufraeumen(name)
    except Exception:
        pass
    return g


def benennen(lyr, schluessel):
    lyr.setName(layername(schluessel, lyr.name()))
    return lyr


def einhaengen(gruppe_, lyr, schluessel, sichtbar=True):
    benennen(lyr, schluessel)
    QgsProject.instance().addMapLayer(lyr, False)
    knoten = gruppe_.addLayer(lyr)
    knoten.setItemVisibilityChecked(bool(sichtbar))
    return knoten


def layer_in_gruppe(gruppenname_, titel):
    """Layer mit diesem Titel (mit oder ohne Nummer) in der Gruppe, sonst None."""
    g = QgsProject.instance().layerTreeRoot().findGroup(gruppenname_)
    if g is None:
        return None
    for kn in g.findLayers():
        l = kn.layer()
        if l is not None and (l.name() == titel or ohne_nummer(l.name()) == ohne_nummer(titel)):
            return l
    return None


def layer_aus_gpkg(gpkg, layername):
    """Der im Projekt geladene Layer mit dieser GeoPackage-Quelle (Pfad|layername=...), sonst None - gemeinsam fuer alle Schritte."""
    if not gpkg:
        return None
    quelle = "{}|layername={}".format(gpkg, layername).replace("\\", "/").lower()
    for lyr in QgsProject.instance().mapLayers().values():
        try:
            if lyr.source().replace("\\", "/").lower() == quelle:
                return lyr
        except Exception:
            continue
    return None
