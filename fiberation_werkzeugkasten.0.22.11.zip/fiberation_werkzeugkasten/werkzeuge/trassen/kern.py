# -*- coding: utf-8 -*-
"""Werkzeug 5 - Kern ohne Qt: NVT fuer NVT Trassen aufbereiten (Markus 16.09.2026).

Ablauf je Projekt (Option A, Markus 16.09.2026):
  1. kondensat_erzeugen: aus dem Netzgraphen (Werkzeug 3, Comsof-Extern-Export oder Plan[Goo]-GeoPackage) je NVT den Vzk-Baum
     (kuerzeste Wege vom Sitz zu jeder Adresse), die Hauszufuehrungen (Stiche) und die Zufuehrungstrasse zum NVT ableiten. Kanten
     zwischen zwei Abzweigen werden zu einer Trasse verschmolzen. Alles andere bleibt als grauer Kandidatenlayer daneben.
     Ergebnis: trassen_<stamm>_<datum>.gpkg mit Ebenen vorlage (gesperrt, gestrichelt), planung (leer, Ebene des Planers), final
     (Endstaende), kandidaten, nvt_status (mit planung_n/planung_m), adressen, pruefung. Aeltere Dateien mit Ebene arbeit hebt migrieren().
  2. Der Planer zeichnet in der Planung nach (QGIS-Werkzeuge, Fang auf Vorlage) oder kopiert die Vorlage (vorlage_uebernehmen) und
     verschiebt; hauszufuehrungen_ableiten faellt je Adresse das Lot auf die naechste Laengstrasse der Planung (Fusspunkt wird
     Stuetzpunkt). Kernwerkzeuge: einrasten, verschmelzen, loeschen, attribute_setzen, kandidaten_uebernehmen - alle auf der Planung.
  3. pruefen (Planung): je NVT Luecken, Dopplungen, Kreuzungen ohne Knoten, nicht angebundene Adressen, Zufuehrung (genau eine Trasse
     am NVT), fehlende Attribute, WeSi-Spezialfaelle (Werkzeug 9). Layer pruefung mit Punktmarken. Ohne blockierende Punkte: geprueft.
  4. Uebergabe nach Plan[Goo]: nur noch in Schritt 10 als Kondensat mit der Hk-Trasse (uebergabe/kondensat.py); den gemeinsamen Schreiber
     tranchen_anlegen() stellt dieser Kern. Die Ebene final nimmt den Endstand des Kondensats auf.
     Status uebertragen. Gemeinsame Strassenstuecke zweier NVT werden nur einmal geschrieben (Feld kante).

Attribute der Ebenen in Plan[Goo]-Schluesseln: bauverfahren (CONST_METHOD: Tiefbau, Tiefbau_Mindertiefe, Trenching_1,
Tiefbau_Spuelbohrung, Tiefbau_Verdraengung, Kabelpflug), surface (geb_Oberbau/ungeb_Oberbau/ohne_Oberbau), allowance (Asphalt/Beton/
Pflaster_Platten), location_hint, wesi, bestand (0/1), sub_type (Hauszufuehrung oder leer). Unbekanntes bleibt leer und wird gemeldet -
nichts erfinden (Regel Markus 07.09.2026).
"""
import math
import os
import pickle
import re
from collections import defaultdict
from datetime import datetime

CRS = 25832
from ... import schema, plangoo_api

STATUS = schema.STATUS
# Markus 12.10.2026: die Zufuehrung muss mit ihrem Ende auf dem NVT-Punkt liegen - keine Luecke. Enden bis NVT_EINRAST_M werden bei der
# Pruefung auf den Punkt gezogen; danach gilt nur ein Ende bis NVT_SNAP_M als "am NVT". Weiter weg = blockierender Befund NVT-Anbindung.
NVT_SNAP_M = 0.05
REST_M = 1.0          # Markus 27.10.2026: Laengstrasse/Zufuehrung kuerzer als 1 m mit freiem Ende = Reststueck (loeschen), keine Luecke
NVT_EINRAST_M = 0.5
TYPEN = schema.TRASSEN_TYPEN

LV_ZU_PG = {"Offene Bauweise": "Tiefbau", "Mindertiefe_15x30": "Tiefbau_Mindertiefe", "Trenching": "Trenching_1",
            "Spülbohrung": "Tiefbau_Spuelbohrung", "Spuelbohrung": "Tiefbau_Spuelbohrung", "Bodenrakete": "Tiefbau_Verdraengung",
            "Kabelpflug": "Kabelpflug"}
KLASSE_ZU_PG = {"Asphalt": ("geb_Oberbau", "Asphalt"), "Beton": ("geb_Oberbau", "Beton"), "Pflaster": ("geb_Oberbau", "Pflaster_Platten"),
                "Platten": ("geb_Oberbau", "Pflaster_Platten"), "geb_Oberbau": ("geb_Oberbau", ""), "Ungebundener Oberbau": ("ungeb_Oberbau", ""),
                "ungebundener Oberbau": ("ungeb_Oberbau", ""), "Ohne Oberbau": ("ohne_Oberbau", ""), "ohne_Oberbau": ("ohne_Oberbau", "")}
BAUVERFAHREN_PG = ("Tiefbau", "Tiefbau_Mindertiefe", "Trenching_1", "Trenching_2", "Trenching_3", "Trenching_4", "Trenching_5",
                   "Tiefbau_Spuelbohrung", "Tiefbau_Verdraengung", "Kabelpflug")
SURFACE_PG = ("geb_Oberbau", "ungeb_Oberbau", "ohne_Oberbau")
ALLOWANCE_PG = ("", "Asphalt", "Beton", "Pflaster_Platten")
LOCATION_PG = ("", "Gehweg", "Fahrbahn", "Gruenstreifen", "Radweg", "Parkstreifen", "Privatgrund", "Querung", "Hausquerung Pressung")
WESI_PG = ("", "offen", "beantragt", "genehmigt", "abgelehnt")
ARBEIT_SPALTEN = schema.TRASSEN_SPALTEN
# Ebenen im GeoPackage (Markus 16.09.2026, Option A): vorlage = erzeugtes Kondensat, gesperrt, nur zum Nachzeichnen; planung = die Ebene
# des Planers (zeichnen, Vorlage uebernehmen, Hauszufuehrungen ableiten, pruefen, uebertragen); final = eingefrorener Stand je Uebertragung.
EBENEN = ("vorlage", "planung", "final")


from ... import gemeinsam
_s = gemeinsam.s


_natsort = gemeinsam.natsort


def stamm_von(gpkg):
    return re.sub(r"[^A-Za-z0-9_\-]+", "_", re.sub(r"^nvt_gebiete_", "", os.path.splitext(os.path.basename(str(gpkg)))[0])).strip("_")[:40]


wal_schliessen = gemeinsam.wal_schliessen


# --- Quellen ----------------------------------------------------------------------------------------------------------------------------
def _cfg(gebiete_gpkg):
    import geopandas as gpd
    from ..cluster import config
    treiber = None
    try:
        geb = gpd.read_file(gebiete_gpkg, layer="nvt_gebiete")
        rs = config.regelwerk.regelsatz_aus_gebieten(geb)
        a_ = gpd.read_file(gebiete_gpkg, layer="adressen")
        treiber = str(a_["sponsor"].iat[0]) if "sponsor" in a_ and len(a_) else None
    except Exception:
        rs = "eigen"
    return config.erzeugen(rs, out_dir=os.path.dirname(gebiete_gpkg), treiber=treiber or None)


def graph_laden(gebiete_gpkg, adr, quelle_art="netz", quelle_pfad=None, log=print):
    """-> (G, adr) mit Adressknoten. netz = Graph aus Werkzeug 3 (_graph.pkl), comsof = Verwendbare Trassen, plangoo = GEOMETRY_LINE."""
    from ..cluster import graph, kern as ckern
    if quelle_art == "netz":
        pkl = os.path.splitext(gebiete_gpkg)[0] + "_graph.pkl"
        if not os.path.exists(pkl):
            raise RuntimeError("Netzgraph fehlt ({}) - Werkzeug 3 neu schneiden oder andere Quelle waehlen.".format(os.path.basename(pkl)))
        with open(pkl, "rb") as fh:
            G = pickle.load(fh)
        knoten = adr["knoten"].astype(str).tolist() if "knoten" in adr else ["A_" + str(i) for i in adr["id"]]
        ok = [k in G for k in knoten]
        if not all(ok):
            log("Netz Werkzeug 3: {} Adressen ohne Knoten im Graphen, werden ausgelassen".format(ok.count(False)))
        adr = adr[ok].reset_index(drop=True)
        adr["knoten"] = [k for k, o in zip(knoten, ok) if o]
        log("Netz Werkzeug 3: {} Kanten, {} Adressen angebunden".format(G.number_of_edges(), len(adr)))
        return G, adr
    cfg = _cfg(gebiete_gpkg)
    if quelle_art in ("seiten", "seiten_ohne_alkis"):
        return seitengraph_laden(gebiete_gpkg, adr, cfg, alkis=(quelle_art == "seiten"), log=log)
    if quelle_art == "comsof":
        edges = comsof_laden(quelle_pfad, log)
        G = graph.build_gds(edges, cfg)
        log("Netz Comsof: {} Trassen -> {} Kanten".format(len(edges), G.number_of_edges()))
    elif quelle_art == "plangoo":
        G = ckern.netz_laden("plangoo", cfg, adr, log=log, pfad=quelle_pfad)
    else:
        raise ValueError("Quelle unbekannt: " + str(quelle_art))
    adr = adr.copy()
    if "we_kap" not in adr:
        adr["we_kap"] = 1
    ckern.anbinden(G, adr, cfg, log=log)
    return G, adr


def seitengraph_laden(gebiete_gpkg, adr, cfg, alkis=True, log=print):
    """Beidseitige Kandidaten im Seitenraum wie im HLD Roboter: OSM-Strassen (Cache neben dem Schnitt) -> je Strasse Linie links und
    rechts (Abstand je Strassentyp, an ALKIS-Verkehrsflaechenrand gerueckt, wenn verfuegbar), Querungen an Kreuzungen und alle 70 m
    (Fahrbahn + Kopfloch), Gehweg-Ecken; Adressen haengen an der nahen Seite, Hausquerung (Pressung) zur Gegenseite als Alternative.
    Der Vzk-Baum entscheidet dann nach Kosten (Gehweg 148 EUR/m gegen Querung ~1.950 EUR), ob eine Strasse beidseitig gebaut wird.
    -> (G, adr) mit Adressknoten"""
    import copy
    from ..cluster import graph, kern as ckern, osm
    from . import seiten
    cfg = copy.deepcopy(cfg)
    cfg["osm"]["seiten"] = {"aktiv": True, "querung_abstand_m": 70.0, "kopfloch_eur": 508.75}
    sr = cfg.setdefault("seitenregel", {"querung_kandidaten": True, "querung_max_m": 25.0, "bauverfahren": "Bodenrakete"})
    # Markus 16.09.2026 (Option 3): je Fahrbahnquerung (Seitenwechsel) ein Aufschlag fuer Verkehrssicherung/Genehmigung, ANNAHME 500 EUR,
    # damit der Baum die Seite nicht fuer ein paar Meter Gehweg wechselt. Hausquerungen (Pressung) bleiben ohne Aufschlag.
    sr.setdefault("seitenwechsel_aufschlag_eur", 500.0)
    roads, obst = osm.load(cfg, adr)
    if not len(roads):
        raise RuntimeError("OSM lieferte keine Strassen im Umkreis der Adressen.")
    verkehr = None
    if alkis:
        try:
            from ..adressen import alkis as a_alkis
            from ..standort import alkis_flaechen
            minx, miny, maxx, maxy = adr.total_bounds
            laender = a_alkis.laender_fuer_bbox(minx, miny, maxx, maxy)
            land = laender[0] if laender else None
            if land:
                erg = alkis_flaechen.laden(minx, miny, maxx, maxy, land, log=log, rand_m=150.0)
                verkehr = erg.get("verkehr")
                if verkehr is not None and not len(verkehr):
                    verkehr = None
            else:
                log("ALKIS: Land nicht bestimmbar - Seitenlinien in festem Abstand zur Achse.")
        except Exception as e:
            log("ALKIS-Verkehrsflaechen nicht geladen ({}) - Seitenlinien in festem Abstand zur Achse.".format(str(e)[:120]))
    G = seiten.build(roads, obst, cfg, verkehr)
    rep, verw, eck = G.graph.get("reparatur") or {}, G.graph.get("verworfen") or {}, G.graph.get("ecken") or {}
    log("Seitenraum: {} Strassen -> {} Kanten{}; Seitenlinien verknuepft: {} Nachverbindungen, {} Einmuendungen geschlossen, verworfen {} Stuecke".format(
        len(roads), G.number_of_edges(), ", an ALKIS-Verkehrsflaechen ausgerichtet" if verkehr is not None else ", fester Abstand zur Achse",
        rep.get("verbindungen", 0), eck.get("ecken", 0), verw.get("komponenten", 0)))
    G, raus, meter = graph.beschneiden(G, adr, None, cfg["graph"]["beschnitt_m"])
    adr = adr.copy()
    if "we_kap" not in adr:
        adr["we_kap"] = 1
    ckern.anbinden(G, adr, cfg, log=log)
    aufschlag = float(sr.get("seitenwechsel_aufschlag_eur", 0.0) or 0.0)
    n_q = 0
    for _, _, d in G.edges(data=True):
        if d.get("cost") is None:
            d["cost"] = float(d.get("length", 0.0)) * float(d.get("eur_m", 0.0) or 0.0) + float(d.get("querung_eur", 0.0) or 0.0)
        if aufschlag and d.get("quelle_id") == "querung":
            d["cost"] += aufschlag
            n_q += 1
    log("Seitenraum: {} Kanten nach Beschnitt, {} Adressen angebunden, {} Hausquerungen als Kandidat, {} Fahrbahnquerungen mit {:.0f} EUR Aufschlag".format(
        G.number_of_edges(), len(adr), sum(1 for _, _, d in G.edges(data=True) if d.get("quelle_id") == "hausquerung"), n_q, aufschlag))
    G.graph["gewicht"] = "cost"
    from ..cluster import costs
    G.graph["querung_preis"] = {"eur_m": costs.eur_m("Fahrbahn", 1, cfg), "kopfloch": cfg["osm"]["seiten"].get("kopfloch_eur", 508.75),
                                "aufschlag": aufschlag}
    return G, adr


def comsof_laden(pfad, log=print):
    """Comsof-FPF-Extern-Export, Layer 'Verwendbare Trassen' -> Kantenrahmen wie cluster.plangoo_graph.load (ohne Bestandskabel)."""
    import geopandas as gpd
    import pandas as pd
    g = gpd.read_file(pfad, layer="Verwendbare Trassen")
    g = g.set_crs(CRS, allow_override=True) if g.crs is None else (g.to_crs(CRS) if g.crs.to_epsg() != CRS else g)
    g = g.explode(index_parts=False, ignore_index=True)
    g = g[g.geometry.length > 0.005].reset_index(drop=True)
    typ = g["TYPE"].fillna("BURIED").astype(str) if "TYPE" in g else pd.Series(["BURIED"] * len(g))
    keep = typ != "EXISTINGCABLE"
    g, typ = g[keep].reset_index(drop=True), typ[keep].reset_index(drop=True)
    dig = {"Mindertiefe_15x30": "Mindertiefe_15x30", "Offene Bauweise": "Offene Bauweise", "Offene Bauweise Tief": "Offene Bauweise",
           "Kabelpflug": "Kabelpflug", "Spülbohrung": "Spülbohrung", "Spuelbohrung": "Spülbohrung", "Trenching": "Trenching"}
    out = gpd.GeoDataFrame({
        "typ": typ,
        "surface": g["SURFACE"] if "SURFACE" in g else None,
        "digtype": g["DIG_TYPE"].map(lambda v: dig.get(v) if isinstance(v, str) else None) if "DIG_TYPE" in g else None,
        "streetname": g["STREETTYPE"] if "STREETTYPE" in g else None,
        "is_crossing": g["CROSSING"].fillna(False).astype(bool) if "CROSSING" in g else False,
        "quelle_id": "comsof:" + (g["ID"].astype(str) if "ID" in g else g.index.astype(str)),
        "bestand": typ.eq("EXISTINGPIPE").values,
        "kapazitaet": pd.to_numeric(g["MAX_DUCTS"], errors="coerce").where(typ.eq("EXISTINGPIPE")) if "MAX_DUCTS" in g else None,
        "hauszuf": typ.eq("CUSTOMERDROP").values,
        "transition": typ.eq("TRANSITION").values,
        "duct_class": g["DUCT_CLASS"] if "DUCT_CLASS" in g else None,
        "hinweis": None,
        "geometry": g.geometry,
    }, crs=CRS)
    out = out[~out["hauszuf"]].reset_index(drop=True)
    log("Comsof: {} verwendbare Trassen ({} Bestandsrohre)".format(len(out), int(out["bestand"].sum())))
    return out


def ist_comsof(pfad):
    try:
        import pyogrio
        return "Verwendbare Trassen" in set(pyogrio.list_layers(pfad)[:, 0])
    except Exception:
        return False


# --- Kondensat --------------------------------------------------------------------------------------------------------------------------
def _xy(G, n):
    return (G.nodes[n]["x"], G.nodes[n]["y"])


def _kante_geom(G, u, v):
    """Kantengeometrie in Richtung u -> v (Adressknoten sitzen auf der Strasse, die Kante ist ein Strassenstueck)."""
    from shapely.geometry import LineString
    d = G[u][v]
    g = d.get("geometry")
    ux, uy = _xy(G, u)
    vx, vy = _xy(G, v)
    if g is None or g.is_empty or g.geom_type != "LineString":
        return LineString([(ux, uy), (vx, vy)])
    c = list(g.coords)
    if math.hypot(c[0][0] - vx, c[0][1] - vy) < math.hypot(c[0][0] - ux, c[0][1] - uy):
        c = c[::-1]
    # Enden exakt auf die Knoten legen (Kantengeometrie kann um Zentimeter abweichen -> sonst Scheinluecken)
    c[0], c[-1] = (ux, uy), (vx, vy)
    return LineString(c) if len(c) >= 2 else LineString([(ux, uy), (vx, vy)])


def _attribute(G, u, v):
    """Attribute einer Netzkante in Plan[Goo]-Schluesseln. Alle Netzkanten sind Laengstrassen; Hauszufuehrungen entstehen je Adresse
    (Adressknoten liegt auf der Strasse, der Stich zum Haus ist keine Kante)."""
    d = G[u][v]
    bv_lv = _s(d.get("bauverfahren"))
    klasse = _s(d.get("klasse"))
    sf, al = KLASSE_ZU_PG.get(klasse, ("", ""))
    seite = _s(d.get("seite"))
    bv = LV_ZU_PG.get(bv_lv, "")
    lage = "Querung" if d.get("querung") else ""
    if seite in ("L", "R", "E"):
        lage = "Gehweg"
    elif seite == "Q":
        lage = "Querung"
        if bv_lv == "Fahrbahn" or d.get("transit"):
            bv = "Tiefbau"                      # offene Querung der Fahrbahn (auch eine Hausquerung, die der Baum als Seitenwechsel nutzt)
        elif _s(d.get("quelle_id")) == "hausquerung":
            bv = bv or "Tiefbau_Verdraengung"   # Hausquerung als Pressung (Bodenrakete)
        sf, al = sf or "geb_Oberbau", al or "Asphalt"
    if d.get("telekom_nah"):
        # Netzkante liegt auf einer Telekom-Trasse: gleiche Attribute wie sonst, nur die Quelle traegt den Zusatz (Wegesicherung, KMU)
        return {"typ": "Laengstrasse", "sub_type": "", "bauverfahren": bv, "surface": sf, "allowance": al,
                "location_hint": lage, "wesi": "", "bestand": 1 if d.get("bestand") else 0,
                "quelle": ("querung" if d.get("transit") else _s(d.get("quelle_id") or d.get("osm_id") or d.get("name")))
                + (" " + seite if seite in ("L", "R") else "") + " +telekom"}
    if d.get("telekom_trasse") or d.get("ankopplung"):
        # Markus 22.09.2026: "auch im Vzk sollen die Trassen der Telekom genutzt werden - hilft bei Wegesicherung und KMU".
        # EINE Quelle je Art (nicht die MegaPlan-ID je Segment), sonst bricht jede Kette am naechsten Segment: Alverdissen hatte
        # 816 Telekom-Stuecke mit im Mittel 5,7 m. Lage: Telekom liegt im Regelfall im Seitenraum (ANNAHME Gehweg).
        return {"typ": "Laengstrasse", "sub_type": "", "bauverfahren": bv or "Tiefbau", "surface": sf or "geb_Oberbau", "allowance": al,
                "location_hint": lage or "Gehweg", "wesi": "", "bestand": 1 if d.get("bestand") else 0,
                "quelle": "ankopplung telekom" if d.get("ankopplung") else "telekom-trasse"}
    return {"typ": "Laengstrasse", "sub_type": "", "bauverfahren": bv, "surface": sf, "allowance": al,
            "location_hint": lage, "wesi": "", "bestand": 1 if d.get("bestand") else 0,
            "quelle": ("querung" if d.get("transit") else _s(d.get("quelle_id") or d.get("osm_id") or d.get("name")))
            + (" " + seite if seite in ("L", "R") else "")}


def dopplungen_entfernen(rows, log=None):
    """Laengstrassen, die vollstaendig auf einer anderen Laengstrasse desselben NVT liegen, streichen. Entsteht im Kondensat, wenn der
    Netzgraph zwei Knoten auf derselben Koordinate hat (z. B. Hausquerungs-Kante neben der Strassenkante): der Baum fuehrt dasselbe
    Stueck zweimal. rows: Liste dict (nur ein NVT); -> bereinigte Liste"""
    from shapely.strtree import STRtree
    laengs = [r for r in rows if r.get("typ") == "Laengstrasse" and r.get("geometry") is not None and not r["geometry"].is_empty]
    if len(laengs) < 2:
        return rows
    geoms = [r["geometry"] for r in laengs]
    tree = STRtree(geoms)
    raus = set()
    for i, g in enumerate(geoms):
        if i in raus:
            continue
        for j in tree.query(g):
            if j == i or j in raus:
                continue
            h = geoms[j]
            if h.length <= g.length + 1e-6 and g.buffer(0.05).covers(h) and (h.length < g.length - 1e-6 or j > i):
                raus.add(j)
    weg = {id(laengs[j]) for j in raus}
    rows = [r for r in rows if id(r) not in weg]
    # Teilueberlagerungen (zwei Seitenlinien auf demselben Verkehrsflaechenrand, OSM-Wege die sich ueberlappen): die kuerzere Trasse
    # verliert das gemeinsame Stueck; Reststuecke unter 0,5 m entfallen, mehrere Reste werden eigene Trassen
    from shapely.geometry import LineString
    laengs = [r for r in rows if r.get("typ") == "Laengstrasse" and r.get("geometry") is not None and not r["geometry"].is_empty]
    geoms = [r["geometry"] for r in laengs]
    tree = STRtree(geoms)
    getrimmt, neu_rows, entfernt = 0, [], set()
    for i, g in enumerate(geoms):
        if id(laengs[i]) in entfernt:
            continue
        for j in tree.query(g):
            if j == i or id(laengs[j]) in entfernt:
                continue
            h = geoms[j]
            if h.length > g.length or (h.length == g.length and j < i):
                continue                                   # nur die kuerzere wird beschnitten
            ueberlappung = h.intersection(g.buffer(0.05)).length
            if ueberlappung <= 0.5:
                continue
            rest = h.difference(g.buffer(0.05))
            teile = [t for t in (list(rest.geoms) if rest.geom_type == "MultiLineString" else ([rest] if rest.geom_type == "LineString" else [])) if t.length >= 0.5]
            getrimmt += 1
            if not teile:
                entfernt.add(id(laengs[j]))
                continue
            laengs[j]["geometry"] = teile[0]
            laengs[j]["laenge_m"] = round(teile[0].length, 1)
            geoms[j] = teile[0]
            for k, t in enumerate(teile[1:], 1):
                r2 = dict(laengs[j])
                r2["uid"] = "{}_{}".format(laengs[j]["uid"], k)
                r2["geometry"] = t
                r2["laenge_m"] = round(t.length, 1)
                r2["kante"] = ""
                neu_rows.append(r2)
    if (raus or getrimmt) and log:
        log("  {} doppelte Laengstrassenstuecke gestrichen, {} Teilueberlagerungen beschnitten".format(len(raus), getrimmt))
    return [r for r in rows if id(r) not in entfernt] + neu_rows


def vernoden(rows, tol=0.1):
    """Vorlage knotenrein machen: (a) Endpunkte, die bis tol m neben einer anderen Trasse liegen, auf sie ziehen (Endpunkt der anderen
    bevorzugt) und dort einen Stuetzpunkt setzen (T-Stoss mit Knoten); (b) echte Kreuzungen zweier Trassen ohne gemeinsamen Stuetzpunkt
    bekommen in beiden einen Stuetzpunkt. Noetig, weil Seitenlinien verschiedener Strassen sich an Ecken kreuzen koennen. In place,
    -> (bewegte Endpunkte, gesetzte Kreuzungsknoten)"""
    from shapely.geometry import LineString, Point
    from shapely.ops import nearest_points
    from shapely.strtree import STRtree
    idx = [i for i, r in enumerate(rows) if r.get("geometry") is not None and r["geometry"].geom_type == "LineString" and r["geometry"].length > 0.01]
    if len(idx) < 2:
        return 0, 0

    def stuetzpunkt(line, q):
        c = list(line.coords)
        if any(abs(x - q.x) < 1e-6 and abs(y - q.y) < 1e-6 for x, y in c):
            return line
        for k in range(len(c) - 1):
            if LineString([c[k], c[k + 1]]).distance(q) < 1e-3:
                c.insert(k + 1, (q.x, q.y))
                return LineString(c)
        return line

    geoms = {i: rows[i]["geometry"] for i in idx}
    tree = STRtree([geoms[i] for i in idx])
    bewegt = 0
    for i in idx:
        g = geoms[i]
        c = list(g.coords)
        for pos in (0, -1):
            p = Point(c[pos])
            best, bd, nahe = None, tol + 1e-9, []
            for j_ in tree.query(p.buffer(tol)):
                j = idx[j_]
                if j == i:
                    continue
                d = geoms[j].distance(p)
                if d <= tol:
                    nahe.append(j)
                if d < bd:
                    best, bd = j, d
            if best is None:
                continue
            og = geoms[best]
            ends = [Point(og.coords[0]), Point(og.coords[-1])]
            ep = min(ends, key=lambda e: e.distance(p))
            q = ep if ep.distance(p) <= tol else nearest_points(og, p)[0]
            if q.distance(p) > 1e-6:
                c[pos] = (q.x, q.y)
                geoms[i] = LineString(c)
                g = geoms[i]
                bewegt += 1
            # jede Trasse, die durch den Punkt laeuft (auch die zweite an einem Eck), bekommt dort einen Stuetzpunkt
            for j in nahe:
                oj = geoms[j]
                if Point(oj.coords[0]).distance(q) <= 1e-6 or Point(oj.coords[-1]).distance(q) <= 1e-6:
                    continue
                if oj.distance(q) < 1e-3:
                    geoms[j] = stuetzpunkt(oj, q)
    tree = STRtree([geoms[i] for i in idx])
    knoten = 0
    for a_, i in enumerate(idx):
        g = geoms[i]
        for j_ in tree.query(g):
            j = idx[j_]
            if j <= i:
                continue
            h = geoms[j]
            inter = g.intersection(h)
            if inter.is_empty or inter.geom_type not in ("Point", "MultiPoint"):
                continue
            for p in (list(inter.geoms) if inter.geom_type == "MultiPoint" else [inter]):
                if Point(g.coords[0]).distance(p) < 1e-6 or Point(g.coords[-1]).distance(p) < 1e-6:
                    pass
                neu_g, neu_h = stuetzpunkt(g, p), stuetzpunkt(h, p)
                if neu_g is not g or neu_h is not h:
                    knoten += 1
                g, h = neu_g, neu_h
            geoms[i], geoms[j] = g, h
    for i in idx:
        if geoms[i] is not rows[i]["geometry"]:
            rows[i]["geometry"] = geoms[i]
            rows[i]["laenge_m"] = round(geoms[i].length, 1)
    return bewegt, knoten


def vernoden_frame(gdf, nvt, tol=0.1):
    """vernoden() auf die Zeilen eines NVT in einem GeoDataFrame anwenden (Geometrien und laenge_m werden zurueckgeschrieben).
    -> (bewegte Endpunkte, Kreuzungsknoten)"""
    m = gdf["nvt"].astype(str) == str(nvt)
    idx = list(gdf.index[m])
    rows = [{"geometry": gdf.geometry.loc[i]} for i in idx]
    bew, kn = vernoden(rows, tol)
    for i, r in zip(idx, rows):
        if r["geometry"] is not gdf.geometry.loc[i]:
            gdf.loc[i, "geometry"] = r["geometry"]
            gdf.loc[i, "laenge_m"] = round(r["geometry"].length, 1)
    return bew, kn


def hauszufuehrungen_verketten(rows):
    """Hinterlieger: liegen mehrere Hauszufuehrungen desselben Fusspunkts auf einer Linie (Haus hinter Haus), ueberlagern sie sich. Dann
    beginnt die laengere am Adresspunkt der kuerzeren (Kette Fusspunkt -> Haus 1 -> Haus 2), so wie Plan[Goo] es braucht. rows: Liste dict
    mit typ Hauszufuehrung und geometry LineString(Fuss, Adresse); wird in place geaendert, -> Anzahl verkettet."""
    from shapely.geometry import LineString, Point
    gruppen = defaultdict(list)
    for r in rows:
        if r.get("typ") != "Hauszufuehrung" or r.get("geometry") is None:
            continue
        c = r["geometry"].coords
        gruppen[(round(c[0][0], 2), round(c[0][1], 2))].append(r)
    n = 0
    for _, grp in gruppen.items():
        if len(grp) < 2:
            continue
        grp.sort(key=lambda r: r["geometry"].length)
        for i, r in enumerate(grp):
            seg = r["geometry"]
            ende = Point(seg.coords[-1])
            start = None
            for q in grp[:i]:
                pz = Point(q["geometry"].coords[-1])
                if seg.distance(pz) < 0.02 and pz.distance(ende) > 0.05 and (start is None or pz.distance(ende) < start.distance(ende)):
                    start = pz
            if start is not None:
                r["geometry"] = LineString([(start.x, start.y), (ende.x, ende.y)])
                r["laenge_m"] = round(r["geometry"].length, 1)
                r["hinweis"] = (_s(r.get("hinweis")) + "; " if _s(r.get("hinweis")) else "") + "Hinterlieger, an Nachbar-Hauszufuehrung"
                n += 1
    return n


def _ketten(H, kanten_attr, fest):
    """Kanten des Baums H zu Ketten zwischen Abzweigen (Grad != 2), festen Knoten und Attributwechseln zusammenfassen.
    -> Liste [(attr, [Knotenfolge])]"""
    import networkx as nx
    gesehen = set()
    ketten = []

    def key(a, b):
        return frozenset((a, b))

    start = [n for n in H.nodes if H.degree(n) != 2 or n in fest]
    if not start:
        start = [next(iter(H.nodes))]
    for s in start:
        for nb in list(H.neighbors(s)):
            if key(s, nb) in gesehen:
                continue
            attr = kanten_attr[key(s, nb)]
            folge = [s, nb]
            gesehen.add(key(s, nb))
            cur, prev = nb, s
            while H.degree(cur) == 2 and cur not in fest:
                nxt = [x for x in H.neighbors(cur) if x != prev][0]
                if key(cur, nxt) in gesehen or kanten_attr[key(cur, nxt)] != attr:
                    break
                gesehen.add(key(cur, nxt))
                folge.append(nxt)
                prev, cur = cur, nxt
            ketten.append((attr, folge))
    # Kreise ohne Abzweig (selten)
    for a, b in H.edges:
        if key(a, b) not in gesehen:
            gesehen.add(key(a, b))
            ketten.append((kanten_attr[key(a, b)], [a, b]))
    return ketten


GEBIET_TOLERANZ_M = 15.0   # Grenze laeuft auf der Strassenmitte, der Seitenraum liegt daneben: so viel Randstreifen gilt noch als eigenes Gebiet


def _fremdflaeche(gebiet_poly, name, toleranz_m=GEBIET_TOLERANZ_M):
    """Flaeche der anderen NVT-Gebiete ohne den eigenen Randstreifen (Markus 17.09.2026: eine Trasse darf nicht durch ein fremdes
    NVT-Gebiet laufen - Selbeck: 1V02 baute durch 1V01). Freies Land ausserhalb aller Gebiete bleibt erlaubt, sonst haengen
    Randadressen ab, deren Zuwegung ueber den Acker fuehrt. -> Geometrie oder None"""
    from shapely.ops import unary_union
    fremd = [p for n, p in gebiet_poly.items() if n != name and p is not None and not p.is_empty]
    if not fremd:
        return None
    f = unary_union(fremd)
    eigen = gebiet_poly.get(name)
    if eigen is not None and not eigen.is_empty:
        f = f.difference(eigen.buffer(toleranz_m))
    return None if f.is_empty else f


def _fremd_markieren(rows, fremd, mindest_m=1.0):
    """Trassenstuecke, die trotz der Regel durch ein fremdes Gebiet laufen (zurueckgeholte Anbindung), im Feld hinweis kennzeichnen.
    -> (Anzahl Stuecke, Laenge in m)"""
    if fremd is None or fremd.is_empty:
        return 0, 0.0
    n, m = 0, 0.0
    for r in rows:
        g = r.get("geometry")
        if g is None or g.is_empty:
            continue
        try:
            drin = g.intersection(fremd).length
        except Exception:
            continue
        if drin > mindest_m:
            n += 1
            m += drin
            r["hinweis"] = "; ".join(x for x in (r.get("hinweis") or "",
                                                 "laeuft {:.0f} m durch ein fremdes NVT-Gebiet - Gebiete in Werkzeug 3 pruefen".format(drin)) if x)
    return n, round(m, 1)


def kondensat_erzeugen(gebiete_gpkg, quelle_art="netz", quelle_pfad=None, standorte_gpkg=None, out_dir=None, bestand_gpkg=None, log=print, fortschritt=None):
    """-> dict(gpkg, nvt (Liste), arbeit (GeoDataFrame), kandidaten, stamm, out_dir)
    bestand_gpkg: Ergebnis aus Schritt 1 - die Telekom-Trassen liegen als Kanten im Netz und bekommen im Weg den Vorzug; der Vzk baut dort
    trotzdem neu (Markus 22.09.2026: 'die Wegefuehrung ist die Trasse, Vzk baut neue Infrastruktur')."""
    import geopandas as gpd
    import networkx as nx
    import pandas as pd
    from shapely.geometry import LineString, Point
    from shapely.ops import linemerge
    from ..cluster import graph
    f = fortschritt or (lambda p, t: None)
    f(2, "Lesen")
    adr = gpd.read_file(gebiete_gpkg, layer="adressen")
    sitz = gpd.read_file(gebiete_gpkg, layer="nvt_sitz")
    for df in (adr, sitz):
        if df.crs is None or df.crs.to_epsg() != CRS:
            df.set_crs(CRS, allow_override=True, inplace=True)
    adr["nvt"] = adr["nvt"].astype(str).str.strip()
    adr = adr[adr["nvt"] != ""].reset_index(drop=True)
    adr["id"] = adr["id"].astype(str)
    gebiet_poly = {}
    try:
        gebiete = gpd.read_file(gebiete_gpkg, layer="nvt_gebiete")
        if gebiete.crs is None or gebiete.crs.to_epsg() != CRS:
            gebiete = gebiete.set_crs(CRS, allow_override=True)
        gebiet_poly = {str(r["name"]).strip(): r.geometry for _, r in gebiete.iterrows() if r.geometry is not None and not r.geometry.is_empty}
    except Exception as e:
        log("NVT-Gebiete nicht lesbar ({}) - Trassen werden nicht auf das eigene Gebiet begrenzt.".format(str(e)[:80]))
    standorte = {}
    if standorte_gpkg and os.path.exists(standorte_gpkg):
        try:
            from ..standort.kern import standorte_fuer_netz
            standorte = standorte_fuer_netz(standorte_gpkg, log)
        except Exception as e:
            log("Standorte nicht lesbar: {}".format(str(e)[:80]))
    f(8, "Netz")
    G, adr = graph_laden(gebiete_gpkg, adr, quelle_art, quelle_pfad, log)
    bestand_weg = None
    if bestand_gpkg and os.path.exists(str(bestand_gpkg)):
        f(9, "Bestand aus Schritt 1 als Wegefuehrung")
        from ..bestand import netz as bnetz
        try:
            # Markus 22.09.2026: im Vzk steuern die Telekom-Trassen nur den Weg (Netzkanten daneben werden billiger), sie kommen NICHT
            # als zweites Netz dazu - sonst pendelt der Baum zwischen Gehweglinie und Trasse (Alverdissen: 1.009 statt 529 Stuecke).
            bestand_weg = bnetz.steuern(G, str(bestand_gpkg), cfg=_cfg(gebiete_gpkg), bbox=tuple(adr.total_bounds),
                                        abstand_m=bnetz.NAH_ABSTAND_M if str(quelle_art).startswith("seiten") else bnetz.SPERR_ABSTAND_M, log=log)
        except Exception as e:
            log("ACHTUNG: Bestand aus Schritt 1 nicht eingeblendet ({}) - Vorlage nur auf dem Netz".format(str(e)[:160]))
        if bestand_weg and G.graph.get("gewicht", "length") == "length":
            # Netz nach Laenge (OSM-Achse): der Vorzug wirkt nur ueber ein Gewicht - Laenge x Faktor neben der Telekom-Trasse
            for _, _, d in G.edges(data=True):
                d["weg"] = float(d.get("length", 0.0) or 0.0) * (bnetz.ANTEIL_TRASSE if d.get("telekom_nah") else 1.0)
            G.graph["gewicht"] = "weg"
    namen = sorted(adr["nvt"].unique().tolist(), key=_natsort)
    sitz_xy = {str(r["name"]).strip(): (r.geometry.x, r.geometry.y) for _, r in sitz.iterrows() if r.geometry is not None}
    rows, nvt_rows, genutzt = [], [], {}
    n_ges = max(len(namen), 1)
    from . import baum
    try:
        cfg_k = _cfg(gebiete_gpkg)
        max_vzk = float(cfg_k["nvt"]["max_dist_m"])
        # Mitbenutzung: liegt eine Trasse schon im Baum eines frueheren NVT, kostet sie fuer den naechsten nur noch Rohr + Einzug
        # (ein Graben, zwei Kabel) - sonst bauen zwei NVT dieselbe Strasse auf beiden Seiten (Selbeck 16.09.: 1V01 rechts, 1V02 links)
        mitnutz_eur_m = float(cfg_k["kosten"]["eur_m_lv"]["Einzug"]["1"]) + float(cfg_k["kosten"].get("rohr_einbau_eur_m", 4.9))
    except Exception:
        max_vzk, mitnutz_eur_m = 750.0, 10.7
    gewicht = G.graph.get("gewicht", "length")
    for i, name in enumerate(namen):
        f(10 + 80 * i / n_ges, "Kondensat {}".format(name))
        sub = adr[adr["nvt"] == name]
        # Markus 22.09.2026: "die NVT sollen in 4 final entschieden sein und dann nicht mehr wandern" - der Baum waechst vom gesicherten
        # Standort aus Schritt 4; nur ohne Standortdatei gilt der Sitzvorschlag aus Schritt 3.
        fest_standort = name in standorte
        xy = standorte.get(name) or sitz_xy.get(name)
        if xy is None:
            xy = (sub.geometry.x.mean(), sub.geometry.y.mean())
        # Markus 17.09.2026: Trassen duerfen nicht ausserhalb des eigenen NVT-Polygons laufen (Selbeck: 1V02 lief durch 1V01 und
        # umgekehrt, weil die Mitbenutzung fremde Trassen billig machte). Baum nur im Teilgraph des eigenen Gebiets (+ Toleranz).
        fremd = _fremdflaeche(gebiet_poly, name)
        seed = graph.nearest_node(G, xy[0], xy[1], exclude_addr=True)[0]
        try:
            # Markus 16.09.2026 (Option 3): kostenminimaler Steinerbaum + Seitenregel + Vzk-Hoechstlaenge statt Vereinigung der
            # Einzelpfade (die baute beide Strassenseiten UND Hausquerungen). Seitenraum-Graph nach Kosten, sonst nach Laenge.
            kanten, fehl, _bericht = baum.vzk_baum(G, seed, sub["knoten"].astype(str).tolist(), gewicht=gewicht,
                                                   max_dist_m=max_vzk, log=log, name=name)
        except Exception as e:
            log("{}: Wegsuche fehlgeschlagen ({})".format(name, str(e)[:80]))
            continue
        if gewicht == "cost":
            n_mit = 0
            for k in kanten:
                a, b = tuple(k)
                d = G[a][b]
                if not d.get("mitbenutzt") and not str(a).startswith("A_") and not str(b).startswith("A_"):
                    d["mitbenutzt"] = name
                    d["cost"] = float(d.get("length", 0.0)) * mitnutz_eur_m
                    n_mit += 1
            if i + 1 < len(namen):
                log("  {}: {} Trassenkanten fuer die folgenden NVT zur Mitbenutzung freigegeben ({:.2f} EUR/m)".format(name, n_mit, mitnutz_eur_m))
        H = nx.Graph()
        kanten_attr = {}
        fehlend = len(fehl)
        for k in kanten:
            a, b = tuple(k)
            H.add_edge(a, b)
            kanten_attr[frozenset((a, b))] = tuple(sorted(_attribute(G, a, b).items()))
        for n in H.nodes:
            H.nodes[n]["x"], H.nodes[n]["y"] = _xy(G, n)
        fest = {seed}
        n_tr = 0
        hz_gesehen = set()
        # Hauszufuehrungen: vom Adressknoten auf der Strasse zum Adresspunkt - eine je Koordinate (mehrere APL in einem Gebaeude)
        for k, p in zip(sub["knoten"].astype(str), sub.geometry):
            if k not in G or p is None:
                continue
            kx, ky = _xy(G, k)
            if math.hypot(p.x - kx, p.y - ky) < 0.05:
                continue
            schl = (round(kx, 2), round(ky, 2), round(p.x, 2), round(p.y, 2))
            if schl in hz_gesehen:
                continue
            hz_gesehen.add(schl)
            n_tr += 1
            rows.append({"typ": "Hauszufuehrung", "sub_type": "Hauszufuehrung", "bauverfahren": "Tiefbau_Mindertiefe", "surface": "", "allowance": "",
                         "location_hint": "", "wesi": "", "bestand": 0, "quelle": "adresse:" + k, "uid": "{}_{:04d}".format(name, n_tr), "nvt": name,
                         "laenge_m": round(math.hypot(p.x - kx, p.y - ky), 1), "kante": "", "status": "entwurf", "hinweis": "",
                         "geometry": LineString([(kx, ky), (p.x, p.y)])})
        hauszufuehrungen_verketten([r for r in rows if r["nvt"] == name and r["typ"] == "Hauszufuehrung"])
        for attr_t, folge in _ketten(H, kanten_attr, fest):
            attr = dict(attr_t)
            teile = [_kante_geom(G, a, b) for a, b in zip(folge[:-1], folge[1:])]
            geom = linemerge(teile) if len(teile) > 1 else teile[0]
            if geom.geom_type == "MultiLineString":
                geom = LineString([c for part in geom.geoms for c in part.coords])
            if geom.length < 0.05:
                continue
            kante = "|".join(sorted((str(folge[0]), str(folge[-1]))))
            geteilt = genutzt.get(kante)
            rows.append(dict(attr, uid="{}_{:04d}".format(name, n_tr + 1), nvt=name, laenge_m=round(geom.length, 1), kante=kante,
                             status="entwurf", hinweis="gemeinsam mit {}".format(geteilt) if geteilt and geteilt != name else "",
                             geometry=geom))
            genutzt.setdefault(kante, name)
            n_tr += 1
        # doppelte Strassenstuecke (zwei Graphknoten auf einer Koordinate) streichen
        meine = [r for r in rows if r["nvt"] == name]
        bereinigt = dopplungen_entfernen(meine, log)
        if len(bereinigt) < len(meine):
            behalten_ids = {id(r) for r in bereinigt}
            rows = [r for r in rows if r["nvt"] != name or id(r) in behalten_ids]
            n_tr = len(bereinigt)
        # Zufuehrung: vom Netzknoten (seed) zum NVT-Punkt (Standort aus Werkzeug 4, sonst Sitz). Ein Standort aus Schritt 4 ist
        # entschieden - er wird NICHT mehr verschoben (Markus 22.09.2026); nur der Sitzvorschlag darf ausweichen.
        ziel = standorte.get(name) or xy
        sx, sy = _xy(G, seed)
        if fest_standort:
            pass
        elif math.hypot(ziel[0] - sx, ziel[1] - sy) <= 0.05:
            # NVT-Punkt liegt auf dem Netzknoten: 2,5 m zur Seite, sonst enden dort mehrere Trassen am NVT (Befueller braucht genau eine)
            nb = [_xy(G, m) for m in G.neighbors(seed)]
            dx = sx - (sum(p[0] for p in nb) / len(nb)) if nb else 1.0
            dy = sy - (sum(p[1] for p in nb) / len(nb)) if nb else 0.0
            l = math.hypot(dx, dy) or 1.0
            dx, dy = (dx / l, dy / l) if l > 1e-6 else (1.0, 0.0)
            ziel = (sx - dy * 2.5, sy + dx * 2.5)
        # NVT-Punkt darf nicht auf oder dicht neben einer Laengstrasse liegen (Pruefung: genau eine Trasse endet am NVT, keine Luecke):
        # bei < 1 m Abstand 2,5 m senkrecht von der Trasse weg, zur abgewandten Seite
        nah = [] if fest_standort else [(r["geometry"].distance(Point(*ziel)), r["geometry"]) for r in rows
                                        if r["nvt"] == name and r["typ"] != "Hauszufuehrung" and r["geometry"] is not None]
        nah = [x for x in nah if x[0] < 1.0]
        if nah:
            dz, gz = min(nah, key=lambda x: x[0])
            fp = gz.interpolate(gz.project(Point(*ziel)))
            f2 = gz.interpolate(min(gz.length, gz.project(Point(*ziel)) + 1.0))
            tx, ty = f2.x - fp.x, f2.y - fp.y
            tl = math.hypot(tx, ty) or 1.0
            nx_, ny_ = -ty / tl, tx / tl
            if dz > 1e-6 and (ziel[0] - fp.x) * nx_ + (ziel[1] - fp.y) * ny_ < 0:
                nx_, ny_ = -nx_, -ny_
            ziel = (fp.x + nx_ * 2.5, fp.y + ny_ * 2.5)
        if math.hypot(ziel[0] - sx, ziel[1] - sy) > 0.05:
            rows.append({"typ": "Zufuehrung", "sub_type": "", "bauverfahren": "Tiefbau_Mindertiefe", "surface": "ohne_Oberbau", "allowance": "",
                         "location_hint": "Gruenstreifen", "wesi": "", "bestand": 0, "quelle": "zufuehrung", "uid": "{}_ZUF".format(name),
                         "nvt": name, "laenge_m": round(math.hypot(ziel[0] - sx, ziel[1] - sy), 1), "kante": "", "status": "entwurf",
                         "hinweis": "", "geometry": LineString([(sx, sy), ziel])})
        # knotenrein: Endpunkte einrasten, Kreuzungen und T-Stoesse mit Stuetzpunkt (Seitenlinien verschiedener Strassen kreuzen sich)
        bew, kn = vernoden([r for r in rows if r["nvt"] == name])
        bew2, kn2 = vernoden([r for r in rows if r["nvt"] == name])      # zweiter Durchgang: neue Stuetzpunkte koennen neue Treffer ergeben
        # Splitter raus und Restluecken schliessen (Markus 17.09.2026): sonst meldet die Pruefung auf einer frisch erzeugten Vorlage
        # Kurzstuecke (0,00 m Hauszufuehrung, 0,08 m Eck) und Luecken (0,30 m), die der Planer nicht verursacht hat.
        n_kurz = 0
        for tol_ in (0.5, 0.1, 0.1):
            b_, k_ = vernoden([r for r in rows if r["nvt"] == name], tol=tol_)
            bew, kn = bew + b_, kn + k_
            kurz = [r for r in rows if r["nvt"] == name and r.get("geometry") is not None and r["geometry"].length < 0.1]
            if kurz:
                weg = {id(r) for r in kurz}
                rows = [r for r in rows if id(r) not in weg]
                n_kurz += len(kurz)
        if bew or kn or bew2 or kn2 or n_kurz:
            log("  {}: {} Endpunkte eingerastet, {} Kreuzungsknoten gesetzt, {} Splitter unter 0,1 m entfernt".format(
                name, bew + bew2, kn + kn2, n_kurz))
        n_drau, m_drau = _fremd_markieren([r for r in rows if r["nvt"] == name], fremd)
        if n_drau:
            log("  {}: ACHTUNG {} Trassenstuecke ({:.0f} m) laufen durch ein fremdes NVT-Gebiet - Gebiete oder Zuordnung in Werkzeug 3 pruefen".format(
                name, n_drau, m_drau))
        if fest_standort:
            log("  {}: NVT-Standort aus Schritt 4 uebernommen (nicht verschoben)".format(name))
        meine_rows = [r for r in rows if r["nvt"] == name]
        laenge = sum(r["laenge_m"] for r in meine_rows)
        nvt_rows.append({"name": name, "status": "offen", "apl": int(len(sub)), "trassen": len(meine_rows), "laenge_m": round(laenge, 1),
                         "ohne_weg": fehlend, "hinweis": "; ".join(
                             (["{} Adressen ohne Weg im Netz".format(fehlend)] if fehlend else [])
                             + (["{} Adressen ueber {:.0f} m Vzk-Weg auch auf kuerzestem Weg - NVT-Sitz pruefen".format(
                                 _bericht.get("zu_lang_unheilbar", 0), max_vzk)] if _bericht.get("zu_lang_unheilbar") else [])
                             + (["{} Trassenstuecke ({:.0f} m) durch ein fremdes NVT-Gebiet - Gebiete in Werkzeug 3 pruefen".format(
                                 n_drau, m_drau)] if n_drau else [])),
                         "geometry": Point(*ziel)})
    f(92, "Schreiben")
    out_dir = out_dir or os.path.dirname(os.path.abspath(gebiete_gpkg))
    os.makedirs(out_dir, exist_ok=True)
    stamm = stamm_von(gebiete_gpkg)
    gpkg = os.path.join(out_dir, "trassen_{}_{}.gpkg".format(stamm, datetime.now().strftime("%Y%m%d_%H%M")))
    arbeit = gpd.GeoDataFrame(rows, crs=CRS)[ARBEIT_SPALTEN + ["geometry"]] if rows else gpd.GeoDataFrame({c: [] for c in ARBEIT_SPALTEN}, geometry=[], crs=CRS)
    ebene_schreiben(gpkg, arbeit, "vorlage")
    ebene_schreiben(gpkg, arbeit.iloc[0:0], "planung")
    for r in nvt_rows:
        r["planung_n"], r["planung_m"] = 0, 0.0
    # Kandidaten: alle Netzkanten, die in keinem Baum liegen (grau, zum Dazunehmen)
    kand_rows = []
    for u, v, d in G.edges(data=True):
        if str(u).startswith("A_") or str(v).startswith("A_"):
            continue
        k = "|".join(sorted((str(u), str(v))))
        g = d.get("geometry") or LineString([_xy(G, u), _xy(G, v)])
        at = _attribute(G, u, v)
        kand_rows.append({"kante": k, "bauverfahren": at["bauverfahren"], "surface": at["surface"], "allowance": at["allowance"],
                          "bestand": at["bestand"], "quelle": at["quelle"], "laenge_m": round(g.length, 1), "geometry": g})
    gpd.GeoDataFrame(kand_rows, crs=CRS).to_file(gpkg, layer="kandidaten", driver="GPKG")
    nvt_df = gpd.GeoDataFrame(nvt_rows, crs=CRS)
    nvt_df.to_file(gpkg, layer="nvt_status", driver="GPKG")
    a = adr[["id", "nvt", "knoten", "geometry"] + [c for c in ("strasse", "hnr", "hnr_zs", "kls_id") if c in adr]].copy()
    a.to_file(gpkg, layer="adressen", driver="GPKG")
    wal_schliessen(gpkg)
    log("Vorlage: {} NVT, {} Trassen ({:.1f} km), {} Kandidaten -> {}".format(len(nvt_rows), len(arbeit), arbeit["laenge_m"].sum() / 1000.0 if len(arbeit) else 0,
                                                                              len(kand_rows), os.path.basename(gpkg)))
    f(100, "Fertig")
    if bestand_weg:
        km_tr = arbeit.loc[arbeit["quelle"].astype(str).str.contains("telekom"), "laenge_m"].sum() / 1000 if len(arbeit) else 0.0
        log("Telekom-Trassen als Wegefuehrung: {:.1f} km der Vorlage liegen auf einer Telekom-Trasse (Quelle '... +telekom'; gebaut wird neu) - "
            "hilft bei Wegesicherung und KMU".format(km_tr))
    return {"gpkg": gpkg, "nvt": nvt_df, "arbeit": arbeit, "stamm": stamm, "out_dir": out_dir, "bestand_weg": bestand_weg}


def rahmen_anlegen(gebiete_gpkg, standorte_gpkg=None, out_dir=None, log=print, fortschritt=None):
    """Leeres Trassen-Ergebnis OHNE Vorlage (Markus 09.10.2026: "ohne Vorlage erzeugen arbeiten"): NVT-Liste mit Status, Adressen je NVT,
    leere Vorlage/Planung/Endstand und leere Kandidaten - nur aus den NVT-Gebieten (Schritt 3) und den Standorten (Schritt 4). Kein Netz,
    kein OSM-Abruf, kein Steinerbaum. Danach arbeitet der Planer mit Trasse zeichnen oder Auswahl uebernehmen wie gewohnt.
    -> dict(gpkg, nvt (GeoDataFrame), adressen (Anzahl), stamm, out_dir)"""
    import geopandas as gpd
    from osgeo import ogr, osr
    from shapely.geometry import Point
    f = fortschritt or (lambda p, t: None)
    f(5, "Lesen")
    adr = gpd.read_file(gebiete_gpkg, layer="adressen")
    sitz = gpd.read_file(gebiete_gpkg, layer="nvt_sitz")
    for df in (adr, sitz):
        if df.crs is None or df.crs.to_epsg() != CRS:
            df.set_crs(CRS, allow_override=True, inplace=True)
    adr["nvt"] = adr["nvt"].astype(str).str.strip()
    adr = adr[adr["nvt"] != ""].reset_index(drop=True)
    if not len(adr):
        raise RuntimeError("Keine Adresse mit NVT-Zuordnung in {} - erst Schritt 3 rechnen.".format(os.path.basename(gebiete_gpkg)))
    adr["id"] = adr["id"].astype(str)
    adr["knoten"] = ["A_" + str(i) for i in adr["id"]]          # kein Netz: Platzhalter, nur die Vorlagenrechnung braucht echte Knoten
    standorte = {}
    if standorte_gpkg and os.path.exists(str(standorte_gpkg)):
        try:
            from ..standort.kern import standorte_fuer_netz
            standorte = standorte_fuer_netz(standorte_gpkg, log)
        except Exception as e:
            log("Standorte nicht lesbar: {}".format(str(e)[:80]))
    sitz_xy = {str(r["name"]).strip(): (r.geometry.x, r.geometry.y) for _, r in sitz.iterrows() if r.geometry is not None}
    namen = sorted(adr["nvt"].unique().tolist(), key=_natsort)
    f(40, "NVT")
    nvt_rows = []
    for name in namen:
        sub = adr[adr["nvt"] == name]
        if name in standorte:
            xy, herkunft = standorte[name], "Standort aus Schritt 4"
        elif name in sitz_xy:
            xy, herkunft = sitz_xy[name], "Sitzvorschlag aus Schritt 3"
        else:
            xy, herkunft = (float(sub.geometry.x.mean()), float(sub.geometry.y.mean())), "Adressschwerpunkt (kein Sitz gefunden)"
        nvt_rows.append({"name": name, "status": "offen", "apl": int(len(sub)), "trassen": 0, "laenge_m": 0.0, "ohne_weg": 0,
                         "hinweis": "Rahmen ohne Vorlage; NVT-Punkt = " + herkunft, "planung_n": 0, "planung_m": 0.0, "geometry": Point(*xy)})
    f(70, "Schreiben")
    out_dir = out_dir or os.path.dirname(os.path.abspath(gebiete_gpkg))
    os.makedirs(out_dir, exist_ok=True)
    stamm = stamm_von(gebiete_gpkg)
    gpkg = os.path.join(out_dir, "trassen_{}_{}.gpkg".format(stamm, datetime.now().strftime("%Y%m%d_%H%M")))
    if os.path.exists(gpkg):
        os.remove(gpkg)
    nvt_df = gpd.GeoDataFrame(nvt_rows, crs=CRS)
    nvt_df.to_file(gpkg, layer="nvt_status", driver="GPKG")
    a = adr[["id", "nvt", "knoten", "geometry"] + [c for c in ("strasse", "hnr", "hnr_zs", "kls_id") if c in adr]].copy()
    a.to_file(gpkg, layer="adressen", driver="GPKG")
    for name in EBENEN:
        _leer_anlegen(gpkg, name, extra=("stand",) if name == "final" else ())
    # Kandidaten leer, mit den Spalten der Vorlagenrechnung, damit der Dialog den Layer wie gewohnt findet
    ogr.UseExceptions()
    ds = ogr.Open(gpkg, 1)
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(CRS)
    lyr = ds.CreateLayer("kandidaten", srs, ogr.wkbLineString, ["GEOMETRY_NAME=geometry"])
    for c in ("kante", "bauverfahren", "surface", "allowance", "quelle"):
        lyr.CreateField(ogr.FieldDefn(c, ogr.OFTString))
    lyr.CreateField(ogr.FieldDefn("bestand", ogr.OFTInteger))
    lyr.CreateField(ogr.FieldDefn("laenge_m", ogr.OFTReal))
    ds = None
    wal_schliessen(gpkg)
    log("Rahmen ohne Vorlage: {} NVT, {} Adressen, Vorlage/Planung/Kandidaten leer -> {}".format(len(nvt_rows), len(a), os.path.basename(gpkg)))
    f(100, "Fertig")
    return {"gpkg": gpkg, "nvt": nvt_df, "adressen": int(len(a)), "stamm": stamm, "out_dir": out_dir}


# --- Lesen / Schreiben -------------------------------------------------------------------------------------------------------------------
def ebenen(gpkg):
    import pyogrio
    try:
        return set(pyogrio.list_layers(gpkg)[:, 0])
    except Exception:
        return set()


def _leer_anlegen(gpkg, name, extra=()):
    """Leere Linien-Ebene mit den Arbeitsspalten (+ extra) anlegen - GeoPandas kann keinen leeren Rahmen ohne Geometrietyp schreiben."""
    from osgeo import ogr, osr
    ogr.UseExceptions()
    ds = ogr.Open(gpkg, 1)
    for i in range(ds.GetLayerCount()):
        if ds.GetLayerByIndex(i).GetName() == name:
            ds.DeleteLayer(i)
            break
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(CRS)
    lyr = ds.CreateLayer(name, srs, ogr.wkbLineString, ["GEOMETRY_NAME=geometry"])
    for c in list(ARBEIT_SPALTEN) + list(extra):
        typ = ogr.OFTInteger if c == "bestand" else (ogr.OFTReal if c == "laenge_m" else ogr.OFTString)
        lyr.CreateField(ogr.FieldDefn(c, typ))
    ds = None


def ebene_loeschen(gpkg, name):
    from osgeo import ogr
    ogr.UseExceptions()
    ds = ogr.Open(gpkg, 1)
    for i in range(ds.GetLayerCount()):
        if ds.GetLayerByIndex(i).GetName() == name:
            ds.DeleteLayer(i)
            break
    ds = None


def ebene_lesen(gpkg, ebene="planung"):
    """Trassenebene (planung, vorlage, final) als GeoDataFrame mit allen Arbeitsspalten; fehlende Ebene -> leerer Rahmen."""
    import geopandas as gpd
    if ebene not in ebenen(gpkg):
        a = gpd.GeoDataFrame({c: [] for c in ARBEIT_SPALTEN}, geometry=[], crs=CRS)
    else:
        a = gpd.read_file(gpkg, layer=ebene)
    if a.crs is None or a.crs.to_epsg() != CRS:
        a = a.set_crs(CRS, allow_override=True)
    for c in ARBEIT_SPALTEN:
        if c not in a:
            a[c] = "" if c not in ("bestand", "laenge_m") else 0
    a["nvt"] = a["nvt"].astype(str)
    a["uid"] = a["uid"].astype(str)
    return a


def ebene_schreiben(gpkg, a, ebene="planung", extra=()):
    b = a.copy()
    for c in b.columns:
        if b[c].dtype == object and c != "geometry":
            b[c] = b[c].astype(str).replace({"None": "", "nan": ""})
    if not len(b):
        _leer_anlegen(gpkg, ebene, extra)
    else:
        b["laenge_m"] = [round(g.length, 1) if g is not None else 0 for g in b.geometry]
        b.to_file(gpkg, layer=ebene, driver="GPKG")
    wal_schliessen(gpkg)


# Rueckwaertskompatible Namen: die Werkzeuge arbeiten auf der Planung
def arbeit_lesen(gpkg, ebene="planung"):
    return ebene_lesen(gpkg, ebene)


def arbeit_schreiben(gpkg, a, ebene="planung"):
    ebene_schreiben(gpkg, a, ebene)


def migrieren(gpkg, log=print):
    """Aeltere Ergebnisse (0.7.0, eine Ebene 'arbeit') auf Vorlage + Planung heben; nvt_status um planung_n/planung_m ergaenzen."""
    vorhanden = ebenen(gpkg)
    if "arbeit" in vorhanden and "vorlage" not in vorhanden:
        a = ebene_lesen(gpkg, "arbeit")
        ebene_schreiben(gpkg, a, "vorlage")
        # vom Planer gezeichnete Stuecke der alten Arbeitskopie wandern in die Planung, der Rest ist Vorlage
        pl = a[a["quelle"].astype(str) == "planer"]
        ebene_schreiben(gpkg, pl, "planung")
        ebene_loeschen(gpkg, "arbeit")
        log("Ergebnis auf Vorlage/Planung gehoben: {} Vorlage, {} Planung (gezeichnet)".format(len(a), len(pl)))
        vorhanden = ebenen(gpkg)
    if "vorlage" not in vorhanden:
        _leer_anlegen(gpkg, "vorlage")
    if "planung" not in vorhanden:
        _leer_anlegen(gpkg, "planung")
    if "final" not in vorhanden:
        _leer_anlegen(gpkg, "final", extra=("stand",))
    n = nvt_lesen(gpkg)
    if "planung_n" not in n or "planung_m" not in n:
        pl = ebene_lesen(gpkg, "planung")
        n["planung_n"] = [int((pl["nvt"] == str(x)).sum()) for x in n["name"]]
        n["planung_m"] = [round(float(pl[pl["nvt"] == str(x)]["laenge_m"].sum()), 1) for x in n["name"]]
        n.to_file(gpkg, layer="nvt_status", driver="GPKG")
    wal_schliessen(gpkg)


def status_aktualisieren(gpkg, nvt, geaendert=False):
    """Planungszahlen je NVT nachfuehren; offen -> in Arbeit, sobald die Planung Trassen hat; leer -> offen (ausser uebertragen).
    geaendert=True (nach einer gespeicherten Bearbeitung): geprueft faellt auf in Arbeit zurueck - erst die Pruefung macht wieder geprueft
    (Markus 12.10.: ein Strang mit Fehler darf nicht als geprueft stehen)."""
    n = nvt_lesen(gpkg)
    m = n["name"].astype(str) == str(nvt)
    if not m.any():
        return None
    pl = ebene_lesen(gpkg, "planung")
    pl = pl[pl["nvt"] == str(nvt)]
    n.loc[m, "planung_n"] = int(len(pl))
    n.loc[m, "planung_m"] = round(float(pl["laenge_m"].sum()), 1) if len(pl) else 0.0
    st = str(n.loc[m, "status"].iloc[0])
    if len(pl) and st == "offen":
        n.loc[m, "status"] = "in Arbeit"
    elif not len(pl) and st in ("in Arbeit", "geprueft"):
        n.loc[m, "status"] = "offen"
    elif geaendert and st == "geprueft":
        n.loc[m, "status"] = "in Arbeit"
        n.loc[m, "hinweis"] = "nach Aenderung erneut pruefen"
    n.to_file(gpkg, layer="nvt_status", driver="GPKG")
    wal_schliessen(gpkg)
    if geaendert and st == "geprueft":
        trassen_status_setzen(gpkg, nvt, "in Arbeit")
    return str(n.loc[m, "status"].iloc[0])


def vorlage_uebernehmen(gpkg, nvt, log=print):
    """Vorlage dieses NVT in die Planung kopieren (vorhandene Planung des NVT wird ersetzt). -> Anzahl"""
    import geopandas as gpd
    import pandas as pd
    v = ebene_lesen(gpkg, "vorlage")
    v = v[v["nvt"] == str(nvt)].copy()
    p = ebene_lesen(gpkg, "planung")
    p = p[p["nvt"] != str(nvt)]
    v["status"] = "entwurf"
    v["hinweis"] = "aus Vorlage"
    neu = gpd.GeoDataFrame(pd.concat([p, v], ignore_index=True), crs=CRS) if len(p) else v
    ebene_schreiben(gpkg, neu, "planung")
    status_aktualisieren(gpkg, nvt)
    log("Vorlage uebernommen: {} Trassen fuer {}".format(len(v), nvt))
    return len(v)


def hauszufuehrungen_ableiten(gpkg, nvt, max_m=60.0, log=print):
    """Je Adresse des NVT die Hauszufuehrung neu vom Adresspunkt auf die naechste Laengstrasse/Zufuehrung der PLANUNG faellen (Lot).
    Der Fusspunkt wird Stuetzpunkt der getroffenen Trasse (T-Stoss mit Knoten). Vom Planer gezeichnete Hauszufuehrungen (quelle planer)
    bleiben; abgeleitete oder aus der Vorlage uebernommene werden ersetzt. -> dict(neu, behalten, ohne (Liste Adressen ohne Trasse in max_m))"""
    import geopandas as gpd
    import pandas as pd
    from shapely.geometry import LineString, Point
    from shapely.ops import nearest_points
    from shapely.strtree import STRtree
    a = ebene_lesen(gpkg, "planung")
    adr = gpd.read_file(gpkg, layer="adressen")
    adr = adr[adr["nvt"].astype(str) == str(nvt)]
    mine = a["nvt"] == str(nvt)
    hz = mine & (a["typ"] == "Hauszufuehrung")
    behalten = a[hz & (a["quelle"].astype(str) == "planer")]
    a = a[~(hz & (a["quelle"].astype(str) != "planer"))].reset_index(drop=True)
    ziel_idx = [i for i in a.index if a.at[i, "nvt"] == str(nvt) and a.at[i, "typ"] != "Hauszufuehrung" and a.geometry.loc[i] is not None]
    if not ziel_idx:
        raise RuntimeError("Planung von {} hat keine Laengstrasse - erst zeichnen oder Vorlage uebernehmen.".format(nvt))
    geoms = {i: a.geometry.loc[i] for i in ziel_idx}
    tree = STRtree([geoms[i] for i in ziel_idx])
    behalten_pts = [Point(g.coords[-1]) for g in behalten.geometry if g is not None] + [Point(g.coords[0]) for g in behalten.geometry if g is not None]
    rows, ohne, n_beh, n_gem = [], [], 0, 0
    erledigt = []          # Adresspunkte, die in diesem Lauf schon eine Hauszufuehrung bekommen haben (mehrere APL auf einer Koordinate)
    vergeben = set(a["uid"].astype(str))
    nr = 1
    for _, r in adr.iterrows():
        p = r.geometry
        if p is None:
            continue
        label = "{} {}{}".format(_s(r.get("strasse")), _s(r.get("hnr")), _s(r.get("hnr_zs"))).strip()
        if any(q.distance(p) <= 1.0 for q in behalten_pts):
            n_beh += 1
            continue
        if any(q.distance(p) <= 0.05 for q in erledigt):
            n_gem += 1     # gleiche Koordinate wie eine schon versorgte Adresse: eine Hauszufuehrung je Gebaeude
            continue
        kand = tree.query(p.buffer(max_m))
        if not len(kand):
            ohne.append(label)
            continue
        j = min(kand, key=lambda k: geoms[ziel_idx[k]].distance(p))
        idx = ziel_idx[j]
        line = geoms[idx]
        d = line.distance(p)
        if d > max_m:
            ohne.append(label)
            continue
        if d < 0.05:
            continue          # Adresse liegt auf der Trasse
        fuss = nearest_points(line, p)[0]
        oc = list(line.coords)
        ends = [Point(oc[0]), Point(oc[-1])]
        ep = min(ends, key=lambda e: e.distance(fuss))
        if ep.distance(fuss) <= 0.05:
            fuss = ep
        elif not any(abs(c[0] - fuss.x) < 1e-6 and abs(c[1] - fuss.y) < 1e-6 for c in oc):
            for k in range(len(oc) - 1):
                if LineString([oc[k], oc[k + 1]]).distance(fuss) < 1e-6:
                    oc.insert(k + 1, (fuss.x, fuss.y))
                    break
            geoms[idx] = LineString(oc)
            a.loc[idx, "geometry"] = geoms[idx]
        while "{}_{:04d}".format(nvt, nr) in vergeben:
            nr += 1
        uid = "{}_{:04d}".format(nvt, nr)
        vergeben.add(uid)
        g = LineString([(fuss.x, fuss.y), (p.x, p.y)])
        erledigt.append(p)
        rows.append({"uid": uid, "nvt": str(nvt), "typ": "Hauszufuehrung", "sub_type": "Hauszufuehrung", "bauverfahren": "Tiefbau_Mindertiefe",
                     "surface": "", "allowance": "", "location_hint": "", "wesi": "", "bestand": 0, "laenge_m": round(g.length, 1),
                     "quelle": "adresse:" + _s(r.get("id")), "kante": "", "status": "entwurf", "hinweis": "abgeleitet", "geometry": g})
    n_kette = hauszufuehrungen_verketten(rows)
    neu = gpd.GeoDataFrame(pd.concat([a, gpd.GeoDataFrame(rows, crs=CRS)], ignore_index=True), crs=CRS) if rows else a
    # knotenrein: Fusspunkte, die auf einer zweiten Trasse liegen (T-Stoss der Vorlage), bekommen auch dort einen Stuetzpunkt
    bew, kn = vernoden_frame(neu, nvt)
    if bew or kn:
        log("  {} Endpunkte eingerastet, {} Knoten gesetzt".format(bew, kn))
    ebene_schreiben(gpkg, neu, "planung")
    status_aktualisieren(gpkg, nvt)
    log("Hauszufuehrungen {}: {} abgeleitet ({} Hinterlieger verkettet), {} vom Planer behalten, {} Adressen teilen sich eine Koordinate, {} ohne Trasse in {:.0f} m".format(
        nvt, len(rows), n_kette, n_beh, n_gem, len(ohne), max_m))
    for o in ohne[:20]:
        log("  ohne Trasse: " + o)
    return {"neu": len(rows), "behalten": n_beh, "gemeinsam": n_gem, "ohne": ohne}


def nvt_lesen(gpkg):
    import geopandas as gpd
    return gpd.read_file(gpkg, layer="nvt_status")


def status_setzen(gpkg, name, status, hinweis=None):
    n = nvt_lesen(gpkg)
    m = n["name"].astype(str) == str(name)
    n.loc[m, "status"] = status
    if hinweis is not None:
        n.loc[m, "hinweis"] = hinweis
    n.to_file(gpkg, layer="nvt_status", driver="GPKG")
    wal_schliessen(gpkg)


def neue_uid(a, nvt):
    vorhanden = set(a["uid"].astype(str))
    i = 1
    while "{}_{:04d}".format(nvt, i) in vorhanden:
        i += 1
    return "{}_{:04d}".format(nvt, i)


# --- Werkzeuge auf der Arbeitskopie ---------------------------------------------------------------------------------------------------------
def attribute_setzen(gpkg, uids, werte, log=print):
    """werte: dict Spalte -> Wert (nur ARBEIT_SPALTEN ausser uid/nvt/kante/laenge_m). -> Anzahl"""
    a = arbeit_lesen(gpkg)
    m = a["uid"].astype(str).isin({str(u) for u in uids})
    erlaubt = {"typ", "sub_type", "bauverfahren", "surface", "allowance", "location_hint", "wesi", "bestand", "status", "hinweis"}
    for k, v in werte.items():
        if k in erlaubt:
            a.loc[m, k] = v
    if "sub_type" in werte:
        a.loc[m, "typ"] = "Hauszufuehrung" if werte["sub_type"] == "Hauszufuehrung" else a.loc[m, "typ"].where(a.loc[m, "typ"] == "Zufuehrung", "Laengstrasse")
    arbeit_schreiben(gpkg, a)
    log("Attribute gesetzt: {} Trassen, {}".format(int(m.sum()), ", ".join("{}={}".format(k, v) for k, v in werte.items())))
    return int(m.sum())


def nvt_zuweisen(gpkg, uids, ziel, log=print):
    """Markus 27.10.2026: Trassen einem anderen NVT zuordnen (Stueck lag im falschen NVT). nvt und uid-Vorsatz wechseln, der uid-Rest
    bleibt, wenn er im Ziel frei ist; Quell- und Ziel-NVT fallen auf 'in Arbeit' (erneut pruefen). -> dict(n, uids {alt: neu}, quellen)"""
    a = arbeit_lesen(gpkg)
    ziel = str(ziel)
    m = a["uid"].astype(str).isin({str(u) for u in uids})
    quellen = sorted(set(a.loc[m, "nvt"].astype(str)) - {ziel})
    vorhanden = set(a["uid"].astype(str))
    neu = {}
    for idx in a.index[m]:
        alt = str(a.at[idx, "uid"])
        if str(a.at[idx, "nvt"]) == ziel:
            continue
        rest = alt.split("_", 1)[1] if "_" in alt else alt
        kand = "{}_{}".format(ziel, rest)
        if kand in vorhanden:
            kand = neue_uid(a, ziel)
        vorhanden.add(kand)
        a.at[idx, "uid"] = kand
        a.at[idx, "nvt"] = ziel
        a.at[idx, "kante"] = ""
        if str(a.at[idx, "status"]) in ("geprueft", "uebertragen"):
            a.at[idx, "status"] = "in Arbeit"
        neu[alt] = kand
    if neu:
        arbeit_schreiben(gpkg, a)
        for n in quellen + [ziel]:
            status_aktualisieren(gpkg, n, geaendert=True)
    log("Zu NVT {}: {} Trassen aus {}".format(ziel, len(neu), ", ".join(quellen) or "-"))
    return {"n": len(neu), "uids": neu, "quellen": quellen}


def einrasten(gpkg, nvt=None, uids=None, toleranz=0.1, log=print):
    """Endpunkte, die in `toleranz` m eine andere Trasse (Endpunkt oder Linie) treffen, dorthin ziehen; die andere Linie bekommt dort einen
    Stuetzpunkt (T-Stoss mit Knoten). Dieselbe Regel wie Schritt 7 und das Kondensat (werkzeuge/topologie). -> Anzahl bewegte Endpunkte"""
    from .. import topologie
    a = arbeit_lesen(gpkg)
    st = topologie._in_stuecke(a)
    ziel = set(a.index if nvt is None else a[a["nvt"] == str(nvt)].index)
    if uids:
        ziel &= set(a[a["uid"].astype(str).isin({str(u) for u in uids})].index)
    mehrteilig = {idx for idx, g in zip(a.index, a.geometry) if g is not None and g.geom_type != "LineString"}
    fest = {i for i, s in enumerate(st) if s["quelle"] in mehrteilig}      # Mehrfachlinien: weder bewegen noch Ziel (Pruefer B6)
    nur = {i for i, s in enumerate(st) if s["quelle"] in ziel}
    st, _, z = topologie.enden_an_linien(st, toleranz, nur=nur, fest=fest)
    if mehrteilig & ziel:
        log("Einrasten: {} Mehrfachlinien ausgelassen (erst in Einzellinien zerlegen)".format(len(mehrteilig & ziel)))
    je_quelle = {}
    for s in st:
        je_quelle.setdefault(s["quelle"], []).append(s["geom"])
    geaendert = 0
    for idx, geoms in je_quelle.items():
        if len(geoms) == 1 and a.geometry.loc[idx] is not None and a.geometry.loc[idx].geom_type == "LineString" \
                and not geoms[0].equals_exact(a.geometry.loc[idx], 1e-9):
            a.loc[idx, "geometry"] = geoms[0]
            geaendert += 1
    if geaendert:
        arbeit_schreiben(gpkg, a)
    log("Einrasten ({} m): {} Endpunkte bewegt, {} Trassen geaendert".format(toleranz, z["enden_bewegt"], geaendert))
    return z["enden_bewegt"]


def teilen(gpkg, nvt=None, toleranz=0.1, abzweige=True, kreuzungen=True, uids=None, log=print):
    """Phillip 27.10.2026: Trassen der Planung automatisch an allen Abzweigen und Kreuzungen teilen - je NVT fuer sich (nvt=None: alle NVT).
    Abzweig = Ende einer Trasse liegt bis toleranz m auf dem Inneren einer anderen (Hausstich-Fusspunkt, Einmuendung): die andere wird dort
    geteilt, das Ende auf den Teilungspunkt gesetzt. Kreuzung = zwei Trassen schneiden sich ohne Ende dort: beide werden geteilt. Dieselben
    Regeln wie Schritt 7 (werkzeuge/topologie). Teile behalten die Attribute, der erste Teil die uid, weitere bekommen neue uids; kante wird
    geleert (das Stueck ist keine Vorlagenkante mehr). Mehrfachlinien bleiben unberuehrt. Trassen verschiedener NVT werden nicht
    gegeneinander geteilt. Einteilige Mehrfachlinien (GeoPackage-Ebene vom Typ MultiLineString) gelten als einfache Linien.
    uids (nur markierte): nur diese Trassen werden an ihren Abzweigen geteilt (abzweigende Trassen duerfen unmarkiert sein, ihr Ende wird
    gesetzt); an Kreuzungen mit einer markierten Trasse wird auch die unmarkierte geteilt, sonst bliebe dort ein halber Knoten. Die NVT
    ergeben sich dann aus den markierten Trassen, nvt wird ignoriert.
    -> dict(abzweige, kreuzungen, linien, neu, nvt=[geaenderte NVT])"""
    from .. import topologie
    a = arbeit_lesen(gpkg)
    ziel = None
    if uids is not None:
        ziel = set(a.index[a["uid"].astype(str).isin({str(u) for u in uids})])
        namen = sorted(set(a.loc[list(ziel), "nvt"].astype(str)) - {""})
    else:
        namen = [str(nvt)] if nvt is not None else sorted(set(a["nvt"].astype(str)) - {""})
    zahl = {"abzweige": 0, "kreuzungen": 0, "linien": 0, "neu": 0, "nvt": []}
    neu_zeilen, mehrteilig = [], 0
    for n in namen:
        teil = a[a["nvt"] == n]
        einfach = teil[[_einzellinie(g) is not None for g in teil.geometry]]
        mehrteilig += len(teil) - len(einfach) - int(teil.geometry.isna().sum())
        if len(einfach) < 2:
            continue
        st = topologie._in_stuecke(einfach)
        z = {}

        def nur():                      # Stueck-Indizes der markierten Trassen - neu je Regel, weil sich die Indizes beim Teilen verschieben
            return None if ziel is None else {k for k, s in enumerate(st) if s["quelle"] in ziel}
        if abzweige:
            st, _, z1 = topologie.abzweige_teilen(st, toleranz, nur=nur())
            z.update(z1)
        if kreuzungen:
            st, _, z2 = topologie.kreuzungen_teilen(st, toleranz, nur=nur())
            z.update(z2)
        je_quelle = {}
        for s in st:
            je_quelle.setdefault(s["quelle"], []).append(s["geom"])
        geaendert = False
        for idx, geoms in je_quelle.items():
            alt = _einzellinie(a.geometry.loc[idx])
            if len(geoms) == 1:
                if not geoms[0].equals_exact(alt, 1e-9):             # Abzweig-Ende auf den Teilungspunkt gesetzt
                    a.loc[idx, "geometry"] = geoms[0]
                    geaendert = True
                continue
            geaendert = True
            zahl["linien"] += 1
            a.loc[idx, "geometry"] = geoms[0]
            a.loc[idx, "kante"] = ""
            basis = a.loc[idx].to_dict()
            for g in geoms[1:]:
                row = dict(basis)
                row["uid"] = _naechste_uid(a, neu_zeilen, n)
                row["geometry"] = g
                row["laenge_m"] = round(g.length, 1)
                neu_zeilen.append(row)
        zahl["abzweige"] += z.get("abzweige", 0)
        zahl["kreuzungen"] += z.get("kreuzungen", 0)
        if geaendert:
            zahl["nvt"].append(n)
    if neu_zeilen:
        import geopandas as gpd
        import pandas as pd
        a = gpd.GeoDataFrame(pd.concat([a, gpd.GeoDataFrame(neu_zeilen, geometry="geometry", crs=a.crs)], ignore_index=True), geometry="geometry", crs=a.crs)
    zahl["neu"] = len(neu_zeilen)
    if zahl["nvt"]:
        arbeit_schreiben(gpkg, a)
        for n in zahl["nvt"]:
            status_aktualisieren(gpkg, n, geaendert=True)
    if mehrteilig:
        log("Teilen: {} Mehrfachlinien ausgelassen (erst in Einzellinien zerlegen)".format(mehrteilig))
    log("Teilen ({} m, {}): {} Abzweige, {} Kreuzungen - {} Trassen geteilt, {} neue Teilstuecke".format(
        toleranz, "{} markierte Trassen".format(len(ziel)) if ziel is not None else ("alle NVT" if nvt is None else "NVT {}".format(nvt)), zahl["abzweige"], zahl["kreuzungen"], zahl["linien"], zahl["neu"]))
    return zahl


def _einzellinie(g):
    """LineString oder einteilige Mehrfachlinie -> LineString, sonst None."""
    if g is None or g.is_empty:
        return None
    if g.geom_type == "LineString":
        return g
    if g.geom_type == "MultiLineString" and len(g.geoms) == 1:
        return g.geoms[0]
    return None


def _naechste_uid(a, neu_zeilen, nvt):
    """wie neue_uid, kennt aber auch die noch nicht geschriebenen Teilstuecke."""
    vorhanden = set(a["uid"].astype(str)) | {str(r["uid"]) for r in neu_zeilen}
    i = 1
    while "{}_{:04d}".format(nvt, i) in vorhanden:
        i += 1
    return "{}_{:04d}".format(nvt, i)


def verschmelzen(gpkg, uids, log=print):
    """Ausgewaehlte, aneinanderhaengende Trassen mit gleichen Attributen zu einer Trasse. -> Anzahl neuer Trassen"""
    from shapely.ops import linemerge
    a = arbeit_lesen(gpkg)
    sel = a[a["uid"].astype(str).isin({str(u) for u in uids})]
    if len(sel) < 2:
        return 0
    schl = lambda r: (r["nvt"], r["typ"], r["sub_type"], r["bauverfahren"], r["surface"], r["allowance"], r["location_hint"], r["wesi"], int(r["bestand"] or 0))
    gruppen = defaultdict(list)
    for idx, r in sel.iterrows():
        gruppen[schl(r)].append(idx)
    neu_n, raus = 0, []
    for k, idxs in gruppen.items():
        if len(idxs) < 2:
            continue
        merged = linemerge([a.geometry.loc[i] for i in idxs])
        teile = list(merged.geoms) if merged.geom_type == "MultiLineString" else [merged]
        if len(teile) >= len(idxs):
            continue
        basis = a.loc[idxs[0]].to_dict()
        for t in teile:
            row = dict(basis)
            row["uid"] = neue_uid(a, basis["nvt"])
            row["geometry"] = t
            row["kante"] = ""
            row["laenge_m"] = round(t.length, 1)
            a = a._append(row, ignore_index=True) if hasattr(a, "_append") else a.append(row, ignore_index=True)
            neu_n += 1
        raus += idxs
    if raus:
        a = a.drop(index=raus).reset_index(drop=True)
        arbeit_schreiben(gpkg, a)
    log("Verschmolzen: {} -> {} Trassen".format(len(raus), neu_n))
    return neu_n


def loeschen(gpkg, uids, log=print):
    a = arbeit_lesen(gpkg)
    m = a["uid"].astype(str).isin({str(u) for u in uids})
    a = a[~m].reset_index(drop=True)
    arbeit_schreiben(gpkg, a)
    log("Geloescht: {} Trassen".format(int(m.sum())))
    return int(m.sum())


def kandidaten_uebernehmen(gpkg, nvt, kanten, log=print):
    """Kandidatenstuecke (Feld kante) als Laengstrassen in die Arbeitskopie des NVT aufnehmen. -> Anzahl"""
    import geopandas as gpd
    a = arbeit_lesen(gpkg)
    k = gpd.read_file(gpkg, layer="kandidaten")
    sel = k[k["kante"].astype(str).isin({str(x) for x in kanten})]
    rows = []
    vergeben = set(a["uid"].astype(str))
    nr = 1
    for _, r in sel.iterrows():
        while "{}_{:04d}".format(nvt, nr) in vergeben:
            nr += 1
        uid = "{}_{:04d}".format(nvt, nr)
        vergeben.add(uid)
        rows.append({"uid": uid, "nvt": str(nvt),
                     "typ": "Laengstrasse", "sub_type": "", "bauverfahren": _s(r.get("bauverfahren")), "surface": _s(r.get("surface")),
                     "allowance": _s(r.get("allowance")), "location_hint": "", "wesi": "", "bestand": int(r.get("bestand") or 0),
                     "laenge_m": round(r.geometry.length, 1), "quelle": _s(r.get("quelle")), "kante": _s(r.get("kante")), "status": "entwurf",
                     "hinweis": "aus Kandidaten uebernommen", "geometry": r.geometry})
    if rows:
        a = gpd.GeoDataFrame(list(a.to_dict("records")) + rows, crs=CRS)
        arbeit_schreiben(gpkg, a)
    log("Kandidaten uebernommen: {} fuer {}".format(len(rows), nvt))
    return [r["uid"] for r in rows]


# Fremde Linienlayer in die Planung (Markus 08.10.2026: "egal welchen Linienlayer markieren und in die Planung uebernehmen, z. B. die
# Angebotsplanung - korrekt mit allen fuer Plan[Goo] notwendigen Attributen"). Feldnamen, die wir kennen (Gross-/Kleinschreibung egal):
# Plan[Goo] GEOMETRY_LINE (BAUVERFAHREN, SURFACE, ALLOWANCE, LOCATION_HINT, WESI, SUB_TYPE, IS_EXTERNAL_OBJECT, TYPE) und unsere eigenen
# Arbeitsspalten (Vorlage, Kandidaten, Planung eines anderen Ergebnisses). Werte werden nur uebernommen, wenn sie im Plan[Goo]-Wertevorrat
# stehen - nichts erfinden; was fehlt, fuellt die Attributmaske (Vorgabe) oder bleibt leer und faellt in der Pruefung auf.
FREMD_FELDER = {
    "bauverfahren": ("bauverfahren", "const_method", "constmethod", "digtype"),
    "surface": ("surface", "oberflaeche"),
    "allowance": ("allowance", "zulage"),
    "location_hint": ("location_hint", "locationhint", "lagehinweis"),
    "wesi": ("wesi", "wesi_status"),
    "sub_type": ("sub_type", "subtype", "typ"),
    "bestand": ("bestand", "is_external_object", "bestandstrasse"),
    "typ_pg": ("type",),
}
FREMD_WERTE = {"bauverfahren": set(BAUVERFAHREN_PG), "surface": set(SURFACE_PG), "allowance": set(x for x in ALLOWANCE_PG if x),
               "location_hint": set(x for x in LOCATION_PG if x), "wesi": set(x for x in WESI_PG if x)}


def attribute_aus_fremd(attrs, vorgabe=None):
    """Attribute einer fremden Linie (dict Feldname -> Wert) auf unsere Arbeitsspalten abbilden.
    -> (dict Arbeitsspalten, Liste verworfener Werte 'feld=wert', typ_pg (underground/in_house/aerial/''))"""
    low = {str(k).lower(): v for k, v in (attrs or {}).items()}
    verworfen = []

    def wert(spalte):
        for name in FREMD_FELDER[spalte]:
            if name in low and _s(low[name]) != "":
                return _s(low[name])
        return ""

    out = {"bauverfahren": "", "surface": "", "allowance": "", "location_hint": "", "wesi": "", "sub_type": "", "bestand": 0}
    for sp in ("bauverfahren", "surface", "allowance", "location_hint", "wesi"):
        v = wert(sp)
        if not v:
            continue
        if v in FREMD_WERTE[sp]:
            out[sp] = v
            continue
        treffer = [w for w in FREMD_WERTE[sp] if w.lower() == v.lower()]      # nur Schreibweise anders
        if treffer:
            out[sp] = treffer[0]
        else:
            verworfen.append("{}={}".format(sp, v))
    sub = wert("sub_type")
    if sub.lower().replace("ü", "ue") in ("hauszufuehrung", "customerdrop", "drop"):
        out["sub_type"] = "Hauszufuehrung"
    b = wert("bestand")
    out["bestand"] = 1 if b.lower() in ("1", "true", "ja", "existingpipe", "existing") else 0
    for k, v in (vorgabe or {}).items():
        if k == "bestand":
            if not out["bestand"] and v is not None and v != "":
                out["bestand"] = int(v or 0)
        elif k in out and not out[k] and v:
            out[k] = v
    return out, verworfen, wert("typ_pg").lower()


def auswahl_uebernehmen(gpkg, nvt, linien, quelle="Auswahl", vorgabe=None, log=print):
    """Markierte Linien eines beliebigen Layers in die Planung des NVT aufnehmen (anhaengen, nichts ersetzen).
    linien: Liste (shapely-Geometrie in EPSG:25832, dict Attribute). quelle: Layername fuers Protokoll. vorgabe: Werte der Attributmaske
    fuer leere Felder (dict Arbeitsspalte -> Wert). -> dict(uids, inhouse, zu_kurz, verworfen (Liste), mit_bauverfahren, mit_surface,
    hauszuf, bestand, laenge_m, quelle)"""
    import geopandas as gpd
    from shapely.geometry import LineString
    a = arbeit_lesen(gpkg)
    rows, verworfen = [], []
    erg = {"uids": [], "inhouse": 0, "zu_kurz": 0, "verworfen": verworfen, "mit_bauverfahren": 0, "mit_surface": 0, "hauszuf": 0,
           "bestand": 0, "laenge_m": 0.0, "quelle": quelle}
    vergeben = set(a["uid"].astype(str))
    nr = 1
    for geom, attrs in linien:
        if geom is None or geom.is_empty:
            continue
        teile = list(geom.geoms) if geom.geom_type == "MultiLineString" else [geom]
        att, verw, typ_pg = attribute_aus_fremd(attrs, vorgabe)
        if typ_pg == "in_house":
            erg["inhouse"] += 1          # Hauseinfuehrung im Gebaeude: die Uebertragung legt nur UNDERGROUND an
            continue
        for v in verw:
            if v not in verworfen:
                verworfen.append(v)
        low = {str(k).lower(): v for k, v in (attrs or {}).items()}
        fremd = _s(low.get("uid", ""))
        for t in teile:
            if t.geom_type != "LineString" or t.length < 0.05:
                erg["zu_kurz"] += 1
                continue
            while "{}_{:04d}".format(nvt, nr) in vergeben:
                nr += 1
            uid = "{}_{:04d}".format(nvt, nr)
            vergeben.add(uid)
            hinweis = "aus Layer '{}' uebernommen".format(quelle) + (" ({})".format(fremd) if fremd else "") + (" - oberirdisch" if typ_pg == "aerial" else "")
            rows.append({"uid": uid, "nvt": str(nvt), "typ": "Hauszufuehrung" if att["sub_type"] == "Hauszufuehrung" else "Laengstrasse",
                         "sub_type": att["sub_type"], "bauverfahren": att["bauverfahren"], "surface": att["surface"], "allowance": att["allowance"],
                         "location_hint": att["location_hint"], "wesi": att["wesi"], "bestand": int(att["bestand"]), "laenge_m": round(t.length, 1),
                         "quelle": "auswahl:" + str(quelle)[:60], "kante": "", "status": "entwurf", "hinweis": hinweis, "geometry": LineString(t.coords)})
            erg["mit_bauverfahren"] += 1 if att["bauverfahren"] else 0
            erg["mit_surface"] += 1 if att["surface"] else 0
            erg["hauszuf"] += 1 if att["sub_type"] else 0
            erg["bestand"] += int(att["bestand"])
            erg["laenge_m"] += t.length
    if rows:
        a = gpd.GeoDataFrame(list(a.to_dict("records")) + rows, crs=CRS)
        arbeit_schreiben(gpkg, a)
        status_aktualisieren(gpkg, nvt)
    erg["uids"] = [r["uid"] for r in rows]
    erg["laenge_m"] = round(erg["laenge_m"], 1)
    log("Auswahl uebernommen: {} Trassen ({:.0f} m) aus '{}' fuer {}; Bauverfahren bei {}, Oberflaeche bei {}, Hauszufuehrung {}, Bestand {}{}{}".format(
        len(rows), erg["laenge_m"], quelle, nvt, erg["mit_bauverfahren"], erg["mit_surface"], erg["hauszuf"], erg["bestand"],
        "; {} Hauseinfuehrungen (in_house) ausgelassen".format(erg["inhouse"]) if erg["inhouse"] else "",
        "; nicht im Plan[Goo]-Wertevorrat, leer gelassen: " + ", ".join(verworfen[:8]) if verworfen else ""))
    return erg


# --- Pruefung -------------------------------------------------------------------------------------------------------------------------
def pruefen(gpkg, nvt, toleranz=0.1, wesi_gpkg=None, log=print):
    """-> dict(zeilen (Liste dict art/text/blockiert/x/y/uid), blockiert (int), status)"""
    import geopandas as gpd
    from shapely.geometry import Point
    from shapely.strtree import STRtree
    a = arbeit_lesen(gpkg)
    t = a[a["nvt"] == str(nvt)].reset_index(drop=True)
    adr = gpd.read_file(gpkg, layer="adressen")
    adr = adr[adr["nvt"].astype(str) == str(nvt)]
    nvt_df = nvt_lesen(gpkg)
    nrow = nvt_df[nvt_df["name"].astype(str) == str(nvt)]
    nvt_pt = nrow.geometry.iloc[0] if len(nrow) else None
    zeilen = []

    def melde(art, text, geom, blockiert=True, uid="", uid2="", radius=25.0):
        """uid/uid2: betroffene Trassen - der Dialog waehlt sie aus und laesst sie blinken. radius: Zoomfenster in m (Markus 17.09.2026)."""
        p = geom if geom.geom_type == "Point" else geom.representative_point()
        zeilen.append({"nvt": str(nvt), "art": art, "text": text, "blockiert": 1 if blockiert else 0, "uid": uid, "uid2": uid2,
                       "radius_m": float(radius), "geometry": Point(p.x, p.y)})

    if not len(t):
        melde("keine Trassen", "Planung des NVT ist leer - Vorlage uebernehmen oder Trassen zeichnen", nvt_pt or Point(0, 0), radius=150.0)
        return _pruefung_abschliessen(gpkg, nvt, zeilen, log)
    if nvt_pt is not None:
        n_gezogen = _auf_nvt_ziehen(gpkg, a, t, nvt_pt, log)
        if n_gezogen:
            t = arbeit_lesen(gpkg)
            t = t[t["nvt"] == str(nvt)].reset_index(drop=True)
    geoms = list(t.geometry)
    tree = STRtree(geoms)
    # 0. Reststuecke (Markus 27.10.2026, Barntrup 1V7007: 0,6 m Probelinie, ein Ende 0,49 m neben der Nachbartrasse - als Luecke gemeldet,
    #    Einrasten haette eine Schleife gebaut). Kurze Laengstrasse/Zufuehrung mit einem freien Ende: loeschen, keine weiteren Befunde dazu.
    tol0 = max(toleranz, 0.02)
    rest = set()
    for i, g in enumerate(geoms):
        if t["typ"].iat[i] == "Hauszufuehrung" or not (0.1 <= g.length < REST_M):
            continue
        frei = []
        for pos in (0, -1):
            p = Point(g.coords[pos])
            if nvt_pt is not None and p.distance(nvt_pt) <= NVT_SNAP_M:
                continue
            if not any(geoms[j].distance(p) <= tol0 for j in tree.query(p.buffer(tol0)) if j != i):
                frei.append(p)
        if frei:
            rest.add(i)
            melde("Reststueck", "{}: {:.2f} m, ein Ende frei - loeschen (Befund waehlen, dann Loeschen)".format(t["uid"].iat[i], g.length),
                  frei[0], uid=t["uid"].iat[i], radius=12.0)
    # 1. Attribute
    for i, r in t.iterrows():
        fehlt = [k for k in ("bauverfahren", "surface") if not _s(r[k])]
        if r["typ"] != "Hauszufuehrung" and fehlt:
            melde("Attribut fehlt", "{}: {}".format(r["uid"], ", ".join(fehlt)), geoms[i], blockiert=False, uid=r["uid"])
        if geoms[i].length < 0.1:
            melde("Kurzstueck", "{}: {:.2f} m".format(r["uid"], geoms[i].length), geoms[i], uid=r["uid"])
    # 2. Luecken: Endpunkt nahe (aber nicht auf) einer anderen Trasse
    for i, g in enumerate(geoms):
        if i in rest:
            continue
        for pos in (0, -1):
            p = Point(g.coords[pos])
            # Markus 27.10.2026: das Ende auf dem NVT-Punkt ist keine Luecke, auch wenn die Strassentrasse 0,49 m daneben laeuft
            # (1V7007: Zufuehrung 0,6 m vom Knoten zum NVT, der NVT steht seitlich der Trasse)
            if nvt_pt is not None and p.distance(nvt_pt) <= NVT_SNAP_M:
                continue
            nah = [j for j in tree.query(p.buffer(max(toleranz, 0.5))) if j != i and j not in rest]
            d_min = min([geoms[j].distance(p) for j in nah], default=None)
            if d_min is not None and 0.02 < d_min <= max(toleranz, 0.5):
                nah_uid = t["uid"].iat[min(nah, key=lambda j: geoms[j].distance(p))] if nah else ""
                melde("Luecke", "{}: Endpunkt {:.2f} m neben anderer Trasse".format(t["uid"].iat[i], d_min), p, uid=t["uid"].iat[i],
                      uid2=nah_uid, radius=12.0)
    # 3. Kreuzungen ohne Knoten, Dopplungen
    for i, g in enumerate(geoms):
        for j in tree.query(g):
            if j <= i:
                continue
            h = geoms[j]
            inter = g.intersection(h)
            if inter.is_empty:
                continue
            if inter.geom_type in ("LineString", "MultiLineString") and inter.length > 0.5:
                melde("Dopplung", "{} und {} ueberlagern sich {:.1f} m".format(t["uid"].iat[i], t["uid"].iat[j], inter.length), inter,
                      uid=t["uid"].iat[i], uid2=t["uid"].iat[j])
                continue
            pts = list(inter.geoms) if inter.geom_type == "MultiPoint" else ([inter] if inter.geom_type == "Point" else [])
            for p in pts:
                knoten_g = any(abs(c[0] - p.x) < 1e-6 and abs(c[1] - p.y) < 1e-6 for c in g.coords)
                knoten_h = any(abs(c[0] - p.x) < 1e-6 and abs(c[1] - p.y) < 1e-6 for c in h.coords)
                if not (knoten_g and knoten_h):
                    melde("Kreuzung ohne Knoten", "{} x {}".format(t["uid"].iat[i], t["uid"].iat[j]), p, uid=t["uid"].iat[i], uid2=t["uid"].iat[j],
                          radius=15.0)
    # 4. Zusammenhang und Adressen
    import networkx as nx
    # Zusammenhang: zwei Trassen haengen zusammen, wenn ein Endpunkt der einen auf der anderen liegt (Endpunkt oder Stuetzpunkt -
    # T-Stoss mit Knoten ist in Plan[Goo] eine gueltige Verbindung). Knoten = Trassen, Kanten = Beruehrungen.
    tol = max(toleranz, 0.02)
    K = nx.Graph()
    K.add_nodes_from(range(len(geoms)))
    for i, g in enumerate(geoms):
        for pos in (0, -1):
            p = Point(g.coords[pos])
            for j in tree.query(p.buffer(tol)):
                if j != i and geoms[j].distance(p) <= tol:
                    K.add_edge(i, j)
                    # Beruehrung mitten auf der anderen Trasse ohne Stuetzpunkt dort: fuer die Telekom-Wegsuche kein Knoten
                    h = geoms[j]
                    if Point(h.coords[0]).distance(p) > tol and Point(h.coords[-1]).distance(p) > tol and \
                            not any(math.hypot(c[0] - p.x, c[1] - p.y) <= tol for c in h.coords[1:-1]):
                        melde("T-Stoss ohne Knoten", "{} trifft {} ohne Stuetzpunkt".format(t["uid"].iat[i], t["uid"].iat[j]), p,
                              uid=t["uid"].iat[i], uid2=t["uid"].iat[j], radius=15.0)
    if nvt_pt is not None:
        # Markus 12.10.: Ende muss auf dem NVT-Punkt liegen (NVT_SNAP_M), Befund nennt Strang und NVT
        an_nvt = [i for i, g in enumerate(geoms) if Point(g.coords[0]).distance(nvt_pt) <= NVT_SNAP_M or Point(g.coords[-1]).distance(nvt_pt) <= NVT_SNAP_M]
        if len(an_nvt) == 0:
            j, dj = min(((i, min(Point(g.coords[0]).distance(nvt_pt), Point(g.coords[-1]).distance(nvt_pt))) for i, g in enumerate(geoms)), key=lambda x: x[1])
            melde("NVT-Anbindung", "NVT {}: keine Trasse endet auf dem NVT-Punkt (Toleranz {} m) - naechstes Ende: Strang {} in {:.2f} m".format(
                nvt, NVT_SNAP_M, t["uid"].iat[j], dj), nvt_pt, uid=t["uid"].iat[j], radius=max(40.0, dj * 2))
        elif len(an_nvt) > 1:
            melde("NVT-Anbindung", "NVT {}: {} Trassen enden auf dem NVT-Punkt ({}) - genau eine Zufuehrung noetig".format(
                nvt, len(an_nvt), ", ".join(t["uid"].iat[i] for i in an_nvt[:4])), nvt_pt, uid=t["uid"].iat[an_nvt[0]], uid2=t["uid"].iat[an_nvt[1]], radius=40.0)
        if an_nvt:
            comp = set()
            for s0 in an_nvt:
                comp |= nx.node_connected_component(K, s0)
            for i in range(len(geoms)):
                if i not in comp:
                    melde("nicht verbunden", "{} haengt nicht am NVT-Netz".format(t["uid"].iat[i]), geoms[i], uid=t["uid"].iat[i],
                          radius=max(30.0, geoms[i].length))
    for _, r in adr.iterrows():
        p = r.geometry
        if p is None:
            continue
        d = min([geoms[j].distance(p) for j in tree.query(p.buffer(2.0))], default=None)
        if d is None or d > 1.0:
            melde("Adresse ohne Anschluss", "{} {}{} ohne Hauszufuehrung (naechste Trasse {})".format(_s(r.get("strasse")), _s(r.get("hnr")), _s(r.get("hnr_zs")),
                                                                                                  "{:.0f} m".format(d) if d is not None else "> 2 m"), p,
                  blockiert=False, radius=40.0)
    # 5. WeSi
    if wesi_gpkg and os.path.exists(wesi_gpkg):
        try:
            fl = gpd.read_file(wesi_gpkg, layer="WeSi_Spezialfaelle_Flaechen")
            ftree = STRtree(list(fl.geometry))
            for i, g in enumerate(geoms):
                for j in ftree.query(g, predicate="intersects"):
                    melde("WeSi", "{}: {} ({})".format(t["uid"].iat[i], _s(fl["art"].iat[j]), _s(fl["bezeichnung"].iat[j])), g.intersection(fl.geometry.iloc[j]), blockiert=False, uid=t["uid"].iat[i])
        except Exception:
            pass
    return _pruefung_abschliessen(gpkg, nvt, zeilen, log)


def _auf_nvt_ziehen(gpkg, a, t, nvt_pt, log):
    """Enden der Planung dieses NVT, die bis NVT_EINRAST_M neben dem NVT-Punkt liegen (aber nicht darauf), auf den Punkt setzen - je Trasse
    das naechste Ende. Schreibt die Planung, wenn sich etwas bewegt hat. -> Anzahl gezogene Enden"""
    from shapely.geometry import LineString, Point
    neu = {}
    for _, r in t.iterrows():
        g = r.geometry
        if g is None or g.geom_type != "LineString":
            continue
        c = [tuple(p[:2]) for p in g.coords]
        d0, d1 = Point(c[0]).distance(nvt_pt), Point(c[-1]).distance(nvt_pt)
        pos, d = (0, d0) if d0 <= d1 else (-1, d1)
        if NVT_SNAP_M < d <= NVT_EINRAST_M:
            c[pos] = (nvt_pt.x, nvt_pt.y)
            neu[str(r["uid"])] = (LineString(c), d)
    if not neu:
        return 0
    for idx in a.index:
        u = str(a.loc[idx, "uid"])
        if u in neu:
            a.loc[idx, "geometry"] = neu[u][0]
    arbeit_schreiben(gpkg, a)
    for u, (_, d) in neu.items():
        log("Zufuehrung {}: Ende um {:.2f} m auf den NVT-Punkt gezogen".format(u, d))
    return len(neu)


def trassen_status_setzen(gpkg, nvt, status):
    """Status der Planungstrassen eines NVT (ausser 'uebertragen') - damit der Layer gepruefte Straenge dauerhaft zeigen kann (Markus 12.10.)."""
    a = arbeit_lesen(gpkg)
    m = (a["nvt"] == str(nvt)) & (a["status"].astype(str) != "uebertragen")
    if m.any():
        a.loc[m, "status"] = status
        arbeit_schreiben(gpkg, a)
    return int(m.sum())


def _pruefung_abschliessen(gpkg, nvt, zeilen, log):
    import geopandas as gpd
    import pyogrio
    from shapely.geometry import Point
    try:
        alt = gpd.read_file(gpkg, layer="pruefung") if "pruefung" in set(pyogrio.list_layers(gpkg)[:, 0]) else None
    except Exception:
        alt = None
    leer = {"nvt": [], "art": [], "text": [], "blockiert": [], "uid": [], "uid2": [], "radius_m": []}
    neu = gpd.GeoDataFrame(zeilen, crs=CRS) if zeilen else gpd.GeoDataFrame(leer, geometry=[], crs=CRS)
    if alt is not None and len(alt):
        alt = alt[alt["nvt"].astype(str) != str(nvt)]
        import pandas as pd
        for c in ("uid2", "radius_m"):                       # aeltere Ergebnisse kennen die Spalten noch nicht
            if c not in alt:
                alt[c] = "" if c == "uid2" else 25.0
        neu = gpd.GeoDataFrame(pd.concat([alt, neu], ignore_index=True), crs=CRS)
    if len(neu):
        neu.to_file(gpkg, layer="pruefung", driver="GPKG")
    else:
        gpd.GeoDataFrame({"nvt": ["-"], "art": ["keine"], "text": ["keine Befunde"], "blockiert": [0], "uid": [""], "uid2": [""],
                          "radius_m": [25.0]}, geometry=[Point(0, 0)], crs=CRS).to_file(gpkg, layer="pruefung", driver="GPKG")
    wal_schliessen(gpkg)
    blockiert = sum(1 for z in zeilen if z["blockiert"])
    status = "geprueft" if blockiert == 0 else "in Arbeit"
    status_setzen(gpkg, nvt, status, "{} Befunde, {} blockierend".format(len(zeilen), blockiert))
    trassen_status_setzen(gpkg, nvt, status)
    log("Pruefung {}: {} Befunde, {} blockierend -> {}".format(nvt, len(zeilen), blockiert, status))
    return {"zeilen": zeilen, "blockiert": blockiert, "status": status}


# --- Nach Plan[Goo] -------------------------------------------------------------------------------------------------------------------
def tranchen_anlegen(t, a, inst, erg, fertig_kanten=(), log=print, fortschritt=None):
    """Zeilen t (GeoDataFrame mit den Plan[Goo]-Feldern bauverfahren, surface, allowance, location_hint, wesi, sub_type, bestand) als
    Plan[Goo]-Trassen anlegen; Status und Hinweis werden in a (gleicher Index) nachgefuehrt. Gemeinsam fuer die Uebergabe je NVT und das
    Kondensat aus Schritt 10 (Markus 12.10.: einheitliches Schema, leere Felder sind erlaubt). -> erg (angelegt, uebersprungen, fehler, meldungen)"""
    import importlib
    from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY, QgsProject
    f = fortschritt or (lambda p, t_: None)
    M = "technik_plangoo_v2_vds_main"
    GooTranch = plangoo_api.klasse("core.components.tranch", "GooTranch")
    C = plangoo_api.konstanten()
    MT, DbT, TT = C.MetaTrasse, C.DbMetaDataTypes, C.GooTranchTypes
    layer = inst.get_tranch_layer()
    ct = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:{}".format(CRS)), layer.crs(), QgsProject.instance())
    fertig = set(fertig_kanten or ())
    conn = inst.get_connection()
    try:
        conn.auto_commit_insert = False
    except Exception:
        pass
    n_ges = max(len(t), 1)
    try:
        for i, (idx, r) in enumerate(t.iterrows()):
            f(5 + 90 * i / n_ges, "Trasse {}/{}".format(i + 1, n_ges))
            if _s(r.get("kante")) and r["kante"] in fertig:
                erg["uebersprungen"] += 1
                a.loc[idx, "status"] = "uebertragen"
                a.loc[idx, "hinweis"] = "gemeinsames Stueck, von anderem NVT uebertragen"
                continue
            g = r.geometry
            if g is None or g.geom_type != "LineString" or g.length < 0.05:
                erg["uebersprungen"] += 1
                continue
            pts = [ct.transform(QgsPointXY(x, y)) for x, y in g.coords]
            meta = []
            if _s(r.get("bauverfahren")):
                meta.append((MT.CONST_METHOD.value[0], r["bauverfahren"], DbT.STR))
            if _s(r.get("surface")):
                meta.append((MT.SURFACE.value[0], r["surface"], DbT.STR))
            if _s(r.get("allowance")):
                meta.append((MT.ALLOWANCE.value[0], r["allowance"], DbT.STR))
            if _s(r.get("location_hint")):
                meta.append((MT.LOCATION_HINT.value[0], r["location_hint"], DbT.STR))
            if _s(r.get("wesi")):
                meta.append((MT.WeSi.value[0], r["wesi"], DbT.STR))
            if _s(r.get("sub_type")) == "Hauszufuehrung":
                meta.append((MT.SUB_TYPE.value[0], "Hauszufuehrung", DbT.STR))
            try:
                best = int(float(r.get("bestand") or 0))
            except (TypeError, ValueError):
                best = 0
            if best:
                meta.append((MT.BESTANDSTRASSE.value[0], 1, DbT.INT))
            try:
                tr = GooTranch.create_from_poly_line_with_meta_list(pts, TT.UNDERGROUND, meta_values=meta or None)
                try:
                    tr.reload_properties(repaint=False)
                except Exception:
                    pass
                erg["angelegt"] += 1
                a.loc[idx, "status"] = "uebertragen"
                a.loc[idx, "hinweis"] = "Plan[Goo] {}".format(tr.get_uid() if hasattr(tr, "get_uid") else "")
            except Exception as e:
                erg["fehler"] += 1
                if len(erg["meldungen"]) < 30:
                    erg["meldungen"].append("{}: {!r}".format(r.get("uid"), e)[:200])
    finally:
        try:
            conn.auto_commit_insert = True
        except Exception:
            pass
        try:
            conn.commit()
        except Exception:
            pass
        try:
            layer.reload()
            layer.triggerRepaint()
        except Exception:
            pass
    return erg


