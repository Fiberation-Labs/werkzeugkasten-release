# -*- coding: utf-8 -*-
"""Werkzeug 5 - Dialog "NVT fuer NVT: Trassen aufbereiten" (Markus 16.09.2026, Oberflaeche nach dem Plan[Goo]-Trassenreiter).

Zwei Ebenen (Markus 16.09.2026, Option A): VORLAGE = erzeugtes Kondensat, gesperrt und gestrichelt, nur zum Nachzeichnen und Fangen;
PLANUNG = Ebene des Planers. Werkzeuge wie in Plan[Goo] (Vorlage uebernehmen, Hauszufuehrungen ableiten, zeichnen, umzeichnen, schneiden,
verschmelzen, einrasten, Luecken finden, loeschen, Kandidaten uebernehmen, Auswahl uebernehmen = markierte Linien eines beliebigen Layers,
Markus 08.10.2026) und die Attributmaske (Bestandstrasse, Bauverfahren, Oberflaeche,
Zulage, Lagehinweis, WeSi, Hauszufuehrung). Zeichnen/umzeichnen/schneiden sind die QGIS-Werkzeuge auf der Planung (Fang auf Vorlage/Planung/
Adressen/NVT wird gesetzt); der Rest laeuft ueber den Kern auf dem GeoPackage. Pruefen je NVT, dann "Nach Plan[Goo] uebertragen" fuer genau
Nach Plan[Goo] geht es in Schritt 10 als Kondensat aller NVT mit der Hk-Trasse.
"""
import os
import traceback

from qgis.core import (QgsCategorizedSymbolRenderer, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsDefaultValue, QgsFeatureRequest,
                       QgsGeometry, QgsLineSymbol, QgsMarkerSymbol, QgsPalLayerSettings, QgsPointXY, QgsProject, QgsRectangle,
                       QgsRendererCategory, QgsRuleBasedRenderer, QgsSnappingConfig, QgsTextBufferSettings, QgsTextFormat, QgsTolerance,
                       QgsVectorLayer, QgsVectorLayerSimpleLabeling, QgsWkbTypes)
from qgis.PyQt import sip
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFrame, QGridLayout, QHBoxLayout,
                                 QHeaderView, QInputDialog, QLabel, QLineEdit, QMessageBox, QProgressBar, QPushButton, QRadioButton, QTableWidget,
                                 QTableWidgetItem, QTextEdit, QVBoxLayout)

from ... import ablauf, ci, dateiwahl, formular, layerbaum, tabelle
from ...dialogbasis import WerkzeugDialog
from ...dateiwahl import DateiFeld
from . import kern

STATUS_FARBE = {"offen": "#6B6B6B", "in Arbeit": "#E0A800", "geprueft": "#2E8B57", "uebertragen": "#1565C0"}


class _AuswahlSlot(object):
    """Layer.selectionChanged -> Dialog._auswahl_zaehlen; loest sich selbst, wenn der Dialog schon zerstoert ist (Seite geschlossen,
    Plugin neu geladen) - sonst meldet QGIS bei jeder Auswahl "wrapped C/C++ object ... has been deleted" (Markus 27.10.2026)."""

    def __init__(self, dialog, lyr):
        self.dialog, self.lyr = dialog, lyr

    def __call__(self, *_):
        try:
            if sip.isdeleted(self.dialog):
                raise RuntimeError("Dialog zerstoert")
            self.dialog._auswahl_zaehlen()
        except RuntimeError:
            self.loesen()

    def loesen(self):
        try:
            self.lyr.selectionChanged.disconnect(self)
        except Exception:
            pass
        self.dialog = None


class TrassenDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self._auswahl_slots = []
        self.gpkg = None
        self.nvt = None
        self._nvt_zeilen = []
        self._pf_zeilen = []
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel("trassen").replace("  ", " ", 1))
        self.setMinimumWidth(900)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel("trassen"), "Vorlage (gestrichelt, gesperrt) je NVT aus dem Netz von Werkzeug 3; der Planer zeichnet die Planung (orange), prueft, ueberträgt.")
        lay.addWidget(self.kopf)

        # --- Vorlage erzeugen: Schnitt, Optionen, Ausgabe ------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Vorlage erzeugen"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(6)
        g.addWidget(QLabel("NVT-Gebiete (2):"), 0, 0)
        self.f_geb = DateiFeld("nvt_gebiete", "nvt_gebiete_....gpkg aus Werkzeug 3 (mit _graph.pkl daneben) - aufklappen fuer die letzten Ergebnisse",
                               "GeoPackage (*.gpkg)", "NVT-Gebiete waehlen", ci.STIL_KNOPF_ZWEIT)
        g.addWidget(self.f_geb, 0, 1, 1, 3)
        opt = QHBoxLayout()
        self.h_seiten = QCheckBox("beidseitig im Seitenraum (Gehweg)")
        self.h_seiten.setChecked(True)
        self.h_seiten.setToolTip("Je Strasse Kandidaten links und rechts, Querungen an Kreuzungen und alle 70 m, Hausquerung (Pressung) als Alternative; "
                                 "der Vzk-Baum entscheidet nach Kosten, ob eine Strasse beidseitig gebaut wird. Aus = Trasse auf der Strassenachse.")
        self.h_alkis = QCheckBox("an ALKIS-Verkehrsflaechen ausrichten")
        self.h_alkis.setChecked(True)
        self.h_alkis.setToolTip("Seitenlinien auf den Rand der amtlichen Verkehrsflaeche ruecken (offener WFS: NRW, BW u. a.); sonst fester Abstand je Strassentyp.")
        self.h_stosi = QCheckBox("NVT-Standorte aus Werkzeug 4")
        self.h_stosi.setChecked(True)
        self.h_stosi.setToolTip("Zufuehrung zum gesicherten Standort aus Werkzeug 4 statt zum Sitzvorschlag, falls eine Standortdatei zum Schnitt vorliegt.")
        for h in (self.h_seiten, self.h_alkis, self.h_stosi):
            opt.addWidget(h)
        opt.addStretch(1)
        g.addLayout(opt, 1, 1, 1, 3)
        self.h_seiten.toggled.connect(lambda an: self.h_alkis.setEnabled(an))
        self.h_bestand = QCheckBox("Telekom-Trassen aus Schritt 1 als Wegefuehrung:")
        self.h_bestand.setChecked(True)
        self.h_bestand.setToolTip("Netzkanten, die naeher als 8 m an einer Telekom-Trasse aus Schritt 1 liegen, kosten im Weg nur 70 % - der Baum waehlt die Seite "
                                  "und den Zug, auf dem die Telekom schon liegt. Das hilft spaeter bei Wegesicherung und KMU (Markus 22.09.2026). Die Trasse kommt "
                                  "NICHT als zweites Netz dazu, der Vzk baut neu (bestand = 0); betroffene Stuecke tragen den Zusatz '+telekom' in der Spalte quelle. "
                                  "Leer = juengstes Schritt-1-Ergebnis.")
        g.addWidget(self.h_bestand, 2, 0)
        self.f_bestand = DateiFeld("bestand", "bestand_....gpkg aus Schritt 1 (leer = juengstes Ergebnis)", "GeoPackage (*.gpkg)", "Bestand aus Schritt 1 waehlen",
                                   ci.STIL_KNOPF_ZWEIT, vorbelegen=False)
        g.addWidget(self.f_bestand, 2, 1, 1, 3)
        self.h_bestand.toggled.connect(lambda an: self.f_bestand.setEnabled(an))
        g.addWidget(QLabel("Ausgabeordner:"), 3, 0)
        self.out = QLineEdit()
        self.out.setPlaceholderText("leer = neben dem Schnitt")
        g.addWidget(self.out, 3, 1, 1, 2)
        o = QPushButton("Waehlen")
        o.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        o.clicked.connect(self._out_waehlen)
        g.addWidget(o, 3, 3)
        g.setColumnStretch(1, 1)
        lay.addLayout(g)
        k0 = QHBoxLayout()
        self.k_kond = QPushButton("Vorlage erzeugen")
        self.k_kond.setStyleSheet(ci.STIL_KNOPF)
        self.k_kond.setCursor(Qt.PointingHandCursor)
        self.k_kond.clicked.connect(self._kondensat)
        self.k_rahmen = QPushButton("Nur Rahmen anlegen")
        self.k_rahmen.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_rahmen.setCursor(Qt.PointingHandCursor)
        self.k_rahmen.setToolTip("Leeres Ergebnis ohne Vorlage: NVT-Liste und Adressen aus Schritt 3 (NVT-Punkt aus Schritt 4, wenn angehakt), "
                                 "kein OSM-Abruf, kein Steinerbaum - danach direkt 'Trasse zeichnen' oder 'Auswahl uebernehmen'")
        self.k_rahmen.clicked.connect(self._rahmen)
        self.k_abbruch = QPushButton("Abbrechen")
        self.k_abbruch.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_abbruch.setEnabled(False)
        self.k_abbruch.setToolTip("Laufenden OpenStreetMap-Abruf (Overpass) abbrechen - der Schritt endet dann ohne Ergebnis.")
        self.k_abbruch.clicked.connect(self._abbrechen)
        self.k_laden = dateiwahl.ErgebnisKnopf("trassen", self._ergebnis_setzen, "Trassen-Ergebnis (GeoPackage) waehlen", stil=ci.STIL_KNOPF_ZWEIT)
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.setToolTip("Protokoll ein- und ausblenden; bei Fehlern klappt es von selbst auf")
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        for b in (self.k_kond, self.k_rahmen, self.k_abbruch, self.k_laden, self.k_log):
            k0.addWidget(b)
        k0.addStretch(1)
        lay.addLayout(k0)
        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(110)
        self.log.setMaximumHeight(180)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log)

        # --- NVT-Liste --------------------------------------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("NVT - aufsteigend, Status je NVT"))
        self.tab_nvt = tabelle.Tabelle("trassen_nvt", ["NVT", "Status", "APL", "Vorlage", "Planung", "Planung m", "Hinweis"], self.iface, mehrfach=False)
        self.tab_nvt.layer_finder(self._layer)
        self.tab_nvt.setMinimumHeight(160)
        self.tab_nvt.itemSelectionChanged.connect(self._nvt_gewaehlt)
        self.tab_nvt.itemDoubleClicked.connect(lambda *_: self._zoom_nvt())
        lay.addWidget(self.tab_nvt)
        kn = QHBoxLayout()
        self.k_naechster = QPushButton("Naechster offener NVT")
        self.k_naechster.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_naechster.clicked.connect(self._naechster)
        self.k_zoom_nvt = QPushButton("Hinzoomen")
        self.k_zoom_nvt.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_zoom_nvt.clicked.connect(self._zoom_nvt)
        self.h_nur = QCheckBox("nur diesen NVT in der Karte zeigen")
        self.h_nur.setChecked(True)
        self.h_nur.toggled.connect(lambda *_: self._filter_setzen())
        self.lab_nvt = QLabel("kein NVT gewaehlt")
        self.lab_nvt.setStyleSheet("font-weight:600; color:{};".format(ci.ORANGE_DUNKEL))
        for w_ in (self.k_naechster, self.k_zoom_nvt, self.h_nur):
            kn.addWidget(w_)
        kn.addStretch(1)
        kn.addWidget(self.lab_nvt)
        lay.addLayout(kn)

        # --- Werkzeuge (wie Plan[Goo]) auf der Planung des gewaehlten NVT --------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Planung bearbeiten - gewaehlter NVT"))
        w = QGridLayout()
        w.setHorizontalSpacing(8)
        w.setVerticalSpacing(6)
        self.k_vorlage = self._werkzeug("Vorlage uebernehmen", self._vorlage, "Die Vorlage dieses NVT in die Planung kopieren, um sie zu verschieben statt neu zu zeichnen (ersetzt die Planung des NVT)")
        self.k_vorlage.setStyleSheet(ci.STIL_KNOPF)
        self.k_hz = self._werkzeug("Hauszufuehrungen ableiten", self._hauszuf, "Je Adresse das Lot vom Adresspunkt auf die naechste Laengstrasse der Planung; vom Planer gezeichnete bleiben")
        self.k_hz.setStyleSheet(ci.STIL_KNOPF)
        self.k_zeichnen = self._werkzeug("Trasse zeichnen", self._zeichnen, "QGIS-Werkzeug: neue Trasse in die Planung zeichnen (Attribute: dieser NVT, Laengstrasse); Fang auf Vorlage, Planung und Adressen ist an")
        self.k_umz = self._werkzeug("Umzeichnen", lambda: self._qgis_werkzeug("actionReshapeFeatures"), "QGIS-Werkzeug: Linienverlauf umzeichnen (Reshape)")
        self.k_schn = self._werkzeug("Schneiden", lambda: self._qgis_werkzeug("actionSplitFeatures"), "QGIS-Werkzeug: Trasse an einer gezeichneten Linie teilen")
        self.k_verschm = self._werkzeug("Verschmelzen", self._verschmelzen, "Gewaehlte, aneinanderhaengende Trassen mit gleichen Attributen zu einer")
        self.k_einr = self._werkzeug("Einrasten", self._einrasten, "Endpunkte der gewaehlten Linien innerhalb der Toleranz auf die Nachbartrasse ziehen (Knoten setzen)")
        self.k_teilen = self._werkzeug("Teilen an Abzweigen", self._teilen,
                                       "Trassen automatisch an allen Abzweigen (Hausstich-Fusspunkte, Einmuendungen; Ende bis Toleranz auf einer anderen Trasse) "
                                       "und an allen Kreuzungen teilen - nur die markierten Trassen, dieser NVT oder alle NVT. Attribute bleiben, Teile bekommen neue uids.")
        self.k_lueck = self._werkzeug("Luecken finden", self._luecken, "Luecken, T-Stoesse ohne Knoten, nicht verbundene Trassen dieses NVT")
        self.k_loesch = self._werkzeug("Loeschen", self._loeschen, "Gewaehlte Trassen aus der Planung entfernen")
        self.k_nvt = self._werkzeug("Zu NVT verschieben", self._nvt_zuweisen,
                                    "Markierte Trassen (auch die anderer NVT) einem anderen NVT zuordnen - nvt und uid wechseln, beide NVT erneut pruefen")
        self.k_kand = self._werkzeug("Kandidaten uebernehmen", self._kandidaten, "Im Layer 'Kandidaten' markierte graue Stuecke in die Planung dieses NVT")
        self.k_auswahl = self._werkzeug("Auswahl uebernehmen", self._auswahl,
                                        "Markierte Linien des AKTIVEN Layers (beliebiger Linienlayer, z. B. die Angebotsplanung oder die Vorlage) in die Planung "
                                        "dieses NVT anhaengen. Plan[Goo]-Attribute (Bauverfahren, Oberflaeche, Zulage, Lagehinweis, WeSi, Hauszufuehrung, Bestand) "
                                        "werden uebernommen, wenn der Layer sie traegt; leere Felder fuellt die Attributmaske unten als Vorgabe.")
        self.k_speich = self._werkzeug("Aenderungen speichern", self._speichern, "Offene QGIS-Bearbeitung der Planung in das GeoPackage schreiben")
        for i, b in enumerate((self.k_vorlage, self.k_hz, self.k_zeichnen, self.k_umz,
                               self.k_schn, self.k_teilen, self.k_verschm, self.k_einr,
                               self.k_lueck, self.k_loesch, self.k_nvt, self.k_kand, self.k_auswahl, self.k_speich)):
            w.addWidget(b, i // 4, i % 4)
        tolz = QHBoxLayout()
        tolz.setSpacing(6)
        tolz.addWidget(QLabel("Toleranz m:"))
        self.s_tol = QDoubleSpinBox()
        self.s_tol.setRange(0.01, 5.0)
        self.s_tol.setDecimals(2)
        self.s_tol.setSingleStep(0.05)
        self.s_tol.setValue(0.10)
        self.s_tol.setToolTip("Einrasten und Pruefung: bis zu diesem Abstand gelten Endpunkte als verbunden")
        tolz.addWidget(self.s_tol)
        tolz.addWidget(QLabel("Hauszuf. max m:"))
        self.s_hz = QDoubleSpinBox()
        self.s_hz.setRange(5.0, 300.0)
        self.s_hz.setDecimals(0)
        self.s_hz.setSingleStep(5.0)
        self.s_hz.setValue(60.0)
        self.s_hz.setToolTip("Laengste Hauszufuehrung beim Ableiten; Adressen weiter weg werden gemeldet")
        tolz.addWidget(self.s_hz)
        w.addLayout(tolz, 3, 0, 1, 2)
        for c in range(4):
            w.setColumnStretch(c, 1)
        lay.addLayout(w)

        # --- Attribute (wie Plan[Goo]) -------------------------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Trassenattribute - fuer die gewaehlten Trassen"))
        g = QGridLayout()
        g.setHorizontalSpacing(8)
        g.setVerticalSpacing(6)
        self.a_bestand = self._combo(["- keine Aenderung -", "nein", "ja"])
        self.a_bv = self._combo(["- keine Aenderung -"] + list(kern.BAUVERFAHREN_PG))
        self.a_sf = self._combo(["- keine Aenderung -"] + list(kern.SURFACE_PG))
        self.a_al = self._combo(["- keine Aenderung -", "- leer -"] + [x for x in kern.ALLOWANCE_PG if x])
        self.a_lh = self._combo(["- keine Aenderung -", "- leer -"] + [x for x in kern.LOCATION_PG if x])
        self.a_wesi = self._combo(["- keine Aenderung -", "- leer -"] + [x for x in kern.WESI_PG if x])
        self.a_hz = self._combo(["- keine Aenderung -", "nein", "ja"])
        for i, (t_, c) in enumerate((("Bestand:", self.a_bestand), ("Bauverfahren:", self.a_bv), ("Oberflaeche:", self.a_sf), ("Zulage:", self.a_al),
                                     ("Lagehinweis:", self.a_lh), ("WeSi:", self.a_wesi), ("Hauszufuehrung:", self.a_hz))):
            g.addWidget(QLabel(t_), i // 4, (i % 4) * 2)
            g.addWidget(c, i // 4, (i % 4) * 2 + 1)
        self.lab_sel = QLabel("0 Trassen gewaehlt")
        self.lab_sel.setStyleSheet("color:{};".format(ci.GRAU))
        self.lab_sel.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        g.addWidget(self.lab_sel, 1, 6)
        self.k_attr = QPushButton("Speichern")
        self.k_attr.setStyleSheet(ci.STIL_KNOPF)
        self.k_attr.clicked.connect(self._attribute)
        g.addWidget(self.k_attr, 1, 7)
        for c in (1, 3, 5, 7):
            g.setColumnStretch(c, 1)
        lay.addLayout(g)

        # --- Pruefen und uebertragen -------------------------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Pruefen"))
        self.tab_pf = tabelle.Tabelle("trassen_befunde", ["Art", "Befund", "blockiert"], self.iface, mehrfach=False)
        self.tab_pf.layer_finder(self._layer)
        self.tab_pf.setMinimumHeight(150)
        # Markus 17.09.: Befund anwaehlen -> betroffene Trassen werden ausgewaehlt und blinken in der Karte; Doppelklick zoomt hin
        self.tab_pf.itemDoubleClicked.connect(lambda *_: self._befund_zeigen(zoom=True))
        self.tab_pf.itemSelectionChanged.connect(lambda: self._befund_zeigen(zoom=False))
        lay.addWidget(self.tab_pf, 1)
        kp = QHBoxLayout()
        self.k_pruef = QPushButton("NVT pruefen")
        self.k_pruef.setStyleSheet(ci.STIL_KNOPF)
        self.k_pruef.clicked.connect(self._pruefen)
        self.k_befund = QPushButton("Befund zeigen")
        self.k_befund.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_befund.setToolTip("Betroffene Trassen auswaehlen, blinken lassen und hinzoomen (auch per Doppelklick auf den Befund)")
        self.k_befund.clicked.connect(lambda: self._befund_zeigen(zoom=True))
        self.k_aufheben = QPushButton("Auswahl aufheben")
        self.k_aufheben.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_aufheben.setToolTip("Befundliste und Trassenauswahl in der Karte leeren")
        self.k_aufheben.clicked.connect(self._auswahl_aufheben)
        kp.addWidget(self.k_pruef)
        kp.addWidget(self.k_befund)
        kp.addWidget(self.k_aufheben)
        kp.addStretch(1)
        # Markus 12.10.: keine Uebergabe je NVT mehr - nach Plan[Goo] geht es nur noch in Schritt 10 als Kondensat mit der Hk-Trasse
        lab_ueber = QLabel("Nach Plan[Goo]: Schritt 10 (Kondensat aus allen geprueften NVT und der Hk-Trasse)")
        lab_ueber.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        kp.addWidget(lab_ueber)
        lay.addLayout(kp)
        fuss = QHBoxLayout()
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, "trassen"))
        fuss.addWidget(hilfe)
        schl = QPushButton("Schliessen")
        self.k_schliessen = schl
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.close)
        fuss.addWidget(schl)
        fuss.addStretch(1)
        lay.addLayout(fuss)
        from ... import fenster
        fenster.einrichten(self, "trassen", 900)

    # --- Hilfen ------------------------------------------------------------------------------------------------------------------------
    def _werkzeug(self, text, slot, tip):
        b = QPushButton(text)
        b.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        b.setToolTip(tip)
        b.clicked.connect(slot)
        return b

    def _combo(self, werte):
        c = QComboBox()
        for v in werte:
            c.addItem(v)
        return c

    def _werkzeuge_an(self, an):
        for b in (self.k_vorlage, self.k_hz, self.k_zeichnen, self.k_umz, self.k_schn, self.k_verschm, self.k_einr, self.k_lueck, self.k_loesch, self.k_nvt, self.k_kand,
                  self.k_auswahl, self.k_speich, self.k_attr, self.k_pruef, self.k_naechster, self.k_zoom_nvt):
            b.setEnabled(an)

    def _out_waehlen(self):
        p = dateiwahl.ordner_waehlen(self, "Ausgabeordner waehlen", "ausgabe", self.out.text())
        if p:
            self.out.setText(p)

    def showEvent(self, ev):
        super().showEvent(ev)
        self.f_geb.vorbelegen()

    def _datei_fallen_gelassen(self, p):
        n = os.path.basename(p).lower()
        if n.startswith("trassen_") and n.endswith(".gpkg"):
            self._ergebnis_setzen(p)
        elif n.startswith("nvt_gebiete_") and n.endswith(".gpkg"):
            self.f_geb.setText(p)
        else:
            return False
        return True

    # --- Kondensat / Laden -------------------------------------------------------------------------------------------------------------
    def _kondensat(self):
        self.log.clear()
        self.k_kond.setEnabled(False)
        self.k_rahmen.setEnabled(False)
        from ..cluster import osm
        osm.lauf_beginnen(status=lambda txt: self._fortschritt(self.balken.value(), txt))
        self.k_abbruch.setEnabled(True)
        try:
            geb = self.f_geb.text()
            if not geb or not os.path.exists(geb):
                self._log("NVT-Gebiete-Datei nicht gefunden.")
                return
            dateiwahl.merken("nvt_gebiete", geb)
            art, pfad = ("seiten" if self.h_alkis.isChecked() else "seiten_ohne_alkis") if self.h_seiten.isChecked() else "netz", None
            st = None
            if self.h_stosi.isChecked():
                from ..uebergabe.dialog import passende_standorte
                st = passende_standorte(geb)
                if st:
                    self._log("Standorte aus Werkzeug 4: " + os.path.basename(st))
            bestand = None
            if self.h_bestand.isChecked():
                bestand = self.f_bestand.text().strip() or (dateiwahl.zuletzt("bestand") or [None])[0]
                if bestand and os.path.exists(bestand):
                    self._log("Bestand aus Schritt 1 als Wegefuehrung: " + os.path.basename(bestand))
                    if not self.f_bestand.text().strip():
                        self.f_bestand.setText(bestand)
                else:
                    self._log("Kein Schritt-1-Ergebnis gefunden - Vorlage ohne Telekom-Trassen (Schritt 1 ausfuehren oder Datei waehlen).")
                    bestand = None
            r = kern.kondensat_erzeugen(geb, art, pfad, standorte_gpkg=st, out_dir=dateiwahl.ausgabeordner(self.out.text()), bestand_gpkg=bestand, log=self._log,
                                        fortschritt=self._fortschritt)
            self._ergebnis_setzen(r["gpkg"])
            QMessageBox.information(self, "Vorlage", "{} NVT, {} Trassen ({:.1f} km) als Vorlage.\n\nDen ersten NVT waehlen - die Karte zeigt seine Vorlage "
                                    "gestrichelt (gesperrt) und die noch leere Planung in Orange. Entweder 'Trasse zeichnen' (Fang auf die Vorlage ist an) "
                                    "oder 'Vorlage in Planung uebernehmen' und verschieben; danach 'Hauszufuehrungen ableiten'."
                                    .format(len(r["nvt"]), len(r["arbeit"]), r["arbeit"]["laenge_m"].sum() / 1000.0 if len(r["arbeit"]) else 0))
        except osm.Abgebrochen as e:
            self._fortschritt(0, "Abgebrochen")
            self._log("Abgebrochen: {}".format(e))
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "Vorlage - Fehler", "{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])
        finally:
            self.k_kond.setEnabled(True)
            self.k_rahmen.setEnabled(True)
            self.k_abbruch.setEnabled(False)
            osm.lauf_beenden()

    def _rahmen(self):
        """Leeres Ergebnis ohne Vorlage (Markus 09.10.2026: "ohne Vorlage erzeugen arbeiten"): NVT-Liste und Adressen aus Schritt 3, sonst
        nichts - der Planer zeichnet direkt oder holt Linien mit "Auswahl uebernehmen". Kein OSM-Abruf, deshalb kein Abbrechen noetig."""
        self.log.clear()
        self.k_rahmen.setEnabled(False)
        self.k_kond.setEnabled(False)
        try:
            geb = self.f_geb.text()
            if not geb or not os.path.exists(geb):
                self._log("NVT-Gebiete-Datei nicht gefunden.")
                return
            dateiwahl.merken("nvt_gebiete", geb)
            st = None
            if self.h_stosi.isChecked():
                from ..uebergabe.dialog import passende_standorte
                st = passende_standorte(geb)
                if st:
                    self._log("Standorte aus Werkzeug 4: " + os.path.basename(st))
            r = kern.rahmen_anlegen(geb, standorte_gpkg=st, out_dir=dateiwahl.ausgabeordner(self.out.text()), log=self._log, fortschritt=self._fortschritt)
            self._ergebnis_setzen(r["gpkg"])
            QMessageBox.information(self, "Rahmen ohne Vorlage", "{} NVT mit {} Adressen angelegt, Vorlage und Planung sind leer.\n\nNVT waehlen, dann "
                                    "'Trasse zeichnen' oder einen Linienlayer markieren und 'Auswahl uebernehmen'; danach 'Hauszufuehrungen ableiten' und "
                                    "'NVT pruefen'. 'Vorlage uebernehmen' und 'Kandidaten uebernehmen' haben in diesem Ergebnis nichts zu holen."
                                    .format(len(r["nvt"]), r["adressen"]))
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "Rahmen - Fehler", "{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])
        finally:
            self.k_rahmen.setEnabled(True)
            self.k_kond.setEnabled(True)

    def _ergebnis_setzen(self, gpkg):
        dateiwahl.merken("trassen", gpkg)
        self.gpkg = gpkg
        self.nvt = None
        try:
            kern.migrieren(gpkg, log=self._log)
        except Exception as e:
            self._log("Ergebnis konnte nicht auf Vorlage/Planung gehoben werden: {!r}".format(e))
        self._layer_laden()
        self._fang_einrichten()
        self._nvt_fuellen()
        self._werkzeuge_an(True)
        self._log("Ergebnis: " + gpkg)
        if self.tab_nvt.rowCount():
            self._naechster()

    # --- NVT-Liste ---------------------------------------------------------------------------------------------------------------------
    def _nvt_fuellen(self):
        aktuell = self.nvt
        self.tab_nvt.blockSignals(True)
        self.tab_nvt.setRowCount(0)
        self._nvt_zeilen = []
        try:
            n = kern.nvt_lesen(self.gpkg)
        except Exception as e:
            self._log("NVT-Liste nicht lesbar: {!r}".format(e))
            self.tab_nvt.blockSignals(False)
            return
        n = n.iloc[sorted(range(len(n)), key=lambda i: kern._natsort(n["name"].iat[i]))]
        self.tab_nvt.setRowCount(len(n))
        zeile_aktuell = None
        for zi, (_, r) in enumerate(n.iterrows()):
            werte = [str(r["name"]), str(r["status"]), str(int(r.get("apl") or 0)), str(int(r.get("trassen") or 0)),
                     str(int(r.get("planung_n") or 0)), "{:.0f}".format(float(r.get("planung_m") or 0)), str(r.get("hinweis") or "")]
            for si, wv in enumerate(werte):
                it = QTableWidgetItem(wv)
                if si == 1:
                    it.setForeground(QColor(STATUS_FARBE.get(wv, "#333333")))
                self.tab_nvt.setItem(zi, si, it)
            g = r.geometry
            self._nvt_zeilen.append({"name": str(r["name"]), "status": str(r["status"]), "xy": (g.x, g.y) if g is not None else None})
            self.tab_nvt.karte_setzen(zi, xy=(g.x, g.y) if g is not None else None, bezug=("NVT", {"name": str(r["name"])}))
            if str(r["name"]) == aktuell:
                zeile_aktuell = zi
        for c in (0, 1, 2, 3, 4, 5):
            self.tab_nvt.resizeColumnToContents(c)
        self.tab_nvt.fertig()
        self.tab_nvt.blockSignals(False)
        if zeile_aktuell is not None:
            self.tab_nvt.selectRow(zeile_aktuell)

    def _nvt_gewaehlt(self):
        zeilen = self.tab_nvt.auswahl_indizes()
        if not zeilen or zeilen[0] >= len(self._nvt_zeilen):
            return
        z = self._nvt_zeilen[zeilen[0]]
        self.nvt = z["name"]
        self.lab_nvt.setText("NVT {} - {}".format(z["name"], z["status"]))
        self._filter_setzen()
        self._vorgaben_setzen()
        self._pruefliste_zeigen()
        self._auswahl_zaehlen()

    def _naechster(self):
        for zi, z in enumerate(self._nvt_zeilen):
            if z["status"] in ("offen", "in Arbeit"):
                self.tab_nvt.selectRow(zi)
                self._zoom_nvt()
                return
        self._log("Alle NVT sind geprueft oder uebertragen.")

    def _zoom_nvt(self):
        if not self.nvt:
            return
        lyr = self._layer("Vorlage") or self._layer("Planung")
        try:
            canvas = self.iface.mapCanvas()
            ct = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:25832"), canvas.mapSettings().destinationCrs(), QgsProject.instance())
            if lyr is not None:
                ext = self._nvt_extent(lyr)
                if ext.isEmpty() and self._layer("Planung") is not None:
                    ext = self._nvt_extent(self._layer("Planung"))
                if ext.isEmpty():
                    z = next((x for x in self._nvt_zeilen if x["name"] == self.nvt), None)
                    if z and z["xy"]:
                        ext = QgsRectangle(z["xy"][0] - 100, z["xy"][1] - 100, z["xy"][0] + 100, z["xy"][1] + 100)
                ext.grow(max(ext.width(), ext.height(), 50) * 0.08)
                canvas.setExtent(ct.transformBoundingBox(ext))
                canvas.refresh()
        except Exception as e:
            self._log("Zoom nicht moeglich: {!r}".format(e))

    # --- Layer -------------------------------------------------------------------------------------------------------------------------
    def _gruppenname(self):
        return layerbaum.gruppenname("trassen", "Trassen {}".format(os.path.basename(self.gpkg).replace("trassen_", "").replace(".gpkg", "")))

    def _layer(self, titel):
        if not self.gpkg:
            return None
        return layerbaum.layer_in_gruppe(self._gruppenname(), titel)

    def _layer_laden(self):
        gruppe = layerbaum.gruppe("trassen", "Trassen {}".format(os.path.basename(self.gpkg).replace("trassen_", "").replace(".gpkg", "")))
        for lname, titel in (("pruefung", "Befunde"), ("nvt_status", "NVT"), ("planung", "Planung"), ("vorlage", "Vorlage"), ("final", "Endstand"),
                             ("adressen", "Adressen"), ("kandidaten", "Kandidaten")):
            lyr = QgsVectorLayer("{}|layername={}".format(self.gpkg, lname), titel, "ogr")
            if not lyr.isValid():
                continue
            lyr.setCrs(QgsCoordinateReferenceSystem("EPSG:25832"))
            if lname == "planung":
                # Markus 12.10.: gepruefte Straenge sind final und dauerhaft sichtbar - eigene Farbe je Status, darunter der Typ
                wurzel = QgsRuleBasedRenderer.Rule(None)
                nicht_fertig = "coalesce(\"status\", '') NOT IN ('geprueft', 'uebertragen')"
                for filt, sym, name in (("\"status\" = 'geprueft'", {"color": "#2E8B57", "width": "1.3"}, "geprueft (final)"),
                                        ("\"status\" = 'uebertragen'", {"color": "#1565C0", "width": "1.1"}, "nach Plan[Goo] uebertragen"),
                                        ("{} AND \"typ\" = 'Laengstrasse'".format(nicht_fertig), {"color": ci.ORANGE, "width": "0.9"}, "Laengstrasse (in Arbeit)"),
                                        ("{} AND \"typ\" = 'Hauszufuehrung'".format(nicht_fertig), {"color": ci.ORANGE_DUNKEL, "width": "0.45"}, "Hauszufuehrung (in Arbeit)"),
                                        ("{} AND \"typ\" = 'Zufuehrung'".format(nicht_fertig), {"color": "#1A1A1A", "width": "1.2", "line_style": "dash"}, "Zufuehrung zum NVT (in Arbeit)")):
                    wurzel.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple(sym), 0, 0, filt, name))
                lyr.setRenderer(QgsRuleBasedRenderer(wurzel))
                self._label(lyr, "if(\"status\" = 'uebertragen', 'PG ', '') || coalesce(\"bauverfahren\", '?') || ' | ' || coalesce(\"surface\", '?')", 6.5, False, True, 1500)
                self._formular_einrichten(lyr)
            elif lname == "vorlage":
                # gesperrte Vorlage: gestrichelt, blasses Orange, ohne Label - nur zum Nachzeichnen und Fangen
                kats = [QgsRendererCategory("Laengstrasse", QgsLineSymbol.createSimple({"color": "#F2B27A", "width": "0.8", "line_style": "dash"}), "Laengstrasse (Vorlage)"),
                        QgsRendererCategory("Hauszufuehrung", QgsLineSymbol.createSimple({"color": "#F2B27A", "width": "0.35", "line_style": "dash"}), "Hauszufuehrung (Vorlage)"),
                        QgsRendererCategory("Zufuehrung", QgsLineSymbol.createSimple({"color": "#8A8A8A", "width": "0.8", "line_style": "dot"}), "Zufuehrung (Vorlage)")]
                lyr.setRenderer(QgsCategorizedSymbolRenderer("typ", kats))
                lyr.setReadOnly(True)
            elif lname == "final":
                lyr.renderer().setSymbol(QgsLineSymbol.createSimple({"color": "#1565C0", "width": "0.5"}))
            elif lname == "kandidaten":
                lyr.renderer().setSymbol(QgsLineSymbol.createSimple({"color": "#9E9E9E", "width": "0.4"}))
            elif lname == "nvt_status":
                kats = [QgsRendererCategory(s, ci.nvt_symbol(f, 5.0), s) for s, f in STATUS_FARBE.items()]
                kats[0] = QgsRendererCategory("offen", ci.nvt_symbol(ci.ORANGE, 5.0), "offen")
                lyr.setRenderer(QgsCategorizedSymbolRenderer("status", kats))
                self._label(lyr, "\"name\" || '\\n' || \"status\"", 8, True, True)
            elif lname == "adressen":
                lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({"name": "circle", "color": "#1A1A1A", "outline_color": "#FFFFFF", "outline_width": "0.2", "size": "1.8"}))
            elif lname == "pruefung":
                kats = [QgsRendererCategory(1, QgsMarkerSymbol.createSimple({"name": "triangle", "color": "#C62828", "outline_color": "#FFFFFF", "outline_width": "0.3", "size": "4.5"}), "blockiert"),
                        QgsRendererCategory(0, QgsMarkerSymbol.createSimple({"name": "triangle", "color": "#E0A800", "outline_color": "#FFFFFF", "outline_width": "0.3", "size": "4"}), "Hinweis")]
                lyr.setRenderer(QgsCategorizedSymbolRenderer("blockiert", kats))
                self._label(lyr, "\"art\"", 7, False, True, 3000)
            knoten = layerbaum.einhaengen(gruppe, lyr, "trassen")
            if lname == "kandidaten":
                knoten.setItemVisibilityChecked(True)
            if lname == "final":
                knoten.setItemVisibilityChecked(False)
        lyr = self._layer("Planung")
        if lyr is not None:
            # Markus 27.10. (QGIS-Protokoll): ein geschlossener Dialog blieb am Layer haengen - "wrapped C/C++ object of type QCheckBox
            # has been deleted" bei jeder Auswahl. Darum ein Slot, der sich bei totem Dialog selbst loest, und closeEvent loest ihn auch.
            slot = _AuswahlSlot(self, lyr)
            self._auswahl_slots.append(slot)
            lyr.selectionChanged.connect(slot)
        self._basis = {}
        for titel in ("Planung", "Vorlage", "Endstand", "Adressen", "Befunde"):
            l = self._layer(titel)
            if l is not None:
                lab = l.labeling().settings().fieldName if l.labeling() is not None else None
                self._basis[titel] = (l.renderer().clone(), lab)
        self._filter_setzen()
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def _filter_setzen(self):
        """Nur den gewaehlten NVT zeigen - ueber regelbasierte Darstellung (ein SQL-Subset scheitert am OGR-Provider, sobald mehrere
        Ebenen desselben GeoPackages geladen sind, und ist im Bearbeitungsmodus gesperrt)."""
        filt_nvt = "\"nvt\" = '{}'".format(self.nvt.replace("'", "''")) if (self.nvt and self.h_nur.isChecked()) else ""
        for titel, (basis, lab) in getattr(self, "_basis", {}).items():
            lyr = self._layer(titel)
            if lyr is None:
                continue
            # Markus 12.10.: in der Planung bleiben gepruefte und uebertragene Straenge immer sichtbar, der Filter trifft nur den Rest
            filt = "({} OR coalesce(\"status\", '') IN ('geprueft', 'uebertragen'))".format(filt_nvt) if (filt_nvt and titel == "Planung") else filt_nvt
            if not filt:
                lyr.setRenderer(basis.clone())
            else:
                rb = basis.clone() if isinstance(basis, QgsRuleBasedRenderer) else QgsRuleBasedRenderer.convertFromRenderer(basis)
                if rb is None:
                    continue
                wurzel = rb.rootRule()
                kinder = wurzel.children()
                if kinder:
                    for regel in kinder:
                        f0 = regel.filterExpression()
                        regel.setFilterExpression("({}) AND {}".format(f0, filt) if f0 and not regel.isElse() else filt)
                else:
                    wurzel.setFilterExpression(filt)
                lyr.setRenderer(rb)
            if lab and lyr.labeling() is not None:
                st = lyr.labeling().settings()
                st.fieldName = "if({}, {}, NULL)".format(filt, lab) if filt else lab
                st.isExpression = True
                lyr.setLabeling(QgsVectorLayerSimpleLabeling(st))
            lyr.triggerRepaint()
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def _nvt_extent(self, lyr):
        """Ausdehnung der Trassen des gewaehlten NVT ohne Subset."""
        req = QgsFeatureRequest().setFilterExpression("\"nvt\" = '{}'".format(self.nvt.replace("'", "''"))).setNoAttributes()
        ext = QgsRectangle()
        for f in lyr.getFeatures(req):
            g = f.geometry()
            if g is not None and not g.isEmpty():
                ext.combineExtentWith(g.boundingBox())
        return ext

    def _fang_einrichten(self):
        """Fang (Snapping) fuer das Nachzeichnen: Stuetzpunkte und Segmente von Vorlage, Planung, Adressen und NVT, 12 Pixel, Schnittpunkte.
        Die alte Projekt-Einstellung wird gemerkt und beim Schliessen zurueckgesetzt."""
        try:
            proj = QgsProject.instance()
            if getattr(self, "_fang_alt", None) is None:
                self._fang_alt = QgsSnappingConfig(proj.snappingConfig())
            cfg = QgsSnappingConfig(proj)
            cfg.setEnabled(True)
            cfg.setMode(QgsSnappingConfig.AdvancedConfiguration)
            cfg.setIntersectionSnapping(True)
            for titel in ("Vorlage", "Planung", "Adressen", "NVT"):
                lyr = self._layer(titel)
                if lyr is None:
                    continue
                try:
                    typ = QgsSnappingConfig.VertexFlag | QgsSnappingConfig.SegmentFlag if titel in ("Vorlage", "Planung") else QgsSnappingConfig.VertexFlag
                    einst = QgsSnappingConfig.IndividualLayerSettings(True, typ, 12.0, QgsTolerance.Pixels, 0.0, 0.0)
                except Exception:
                    typ = QgsSnappingConfig.VertexAndSegment if titel in ("Vorlage", "Planung") else QgsSnappingConfig.Vertex
                    einst = QgsSnappingConfig.IndividualLayerSettings(True, typ, 12.0, QgsTolerance.Pixels)
                cfg.setIndividualLayerSettings(lyr, einst)
            proj.setSnappingConfig(cfg)
            self._log("Fang an: Vorlage, Planung (Stuetzpunkte + Segmente), Adressen, NVT - 12 Pixel.")
        except Exception as e:
            self._log("Fang nicht gesetzt: {!r}".format(e))

    def closeEvent(self, ev):
        for slot in list(getattr(self, "_auswahl_slots", [])):
            slot.loesen()
        self._auswahl_slots = []
        alt = getattr(self, "_fang_alt", None)
        if alt is not None:
            try:
                QgsProject.instance().setSnappingConfig(alt)
            except Exception:
                pass
            self._fang_alt = None
        super().closeEvent(ev)

    def _vorgaben_setzen(self):
        """Neue Trassen, die der Planer zeichnet, bekommen diesen NVT, Typ Laengstrasse, Status entwurf und eine uid."""
        lyr = self._layer("Planung")
        if lyr is None or not self.nvt:
            return
        fl = lyr.fields()
        vorgaben = {"nvt": "'{}'".format(self.nvt.replace("'", "''")), "typ": "'Laengstrasse'", "status": "'entwurf'", "sub_type": "''",
                    "uid": "'{}_N' || substr(replace(uuid(), '-', ''), 2, 6)".format(self.nvt.replace("'", "''")),
                    "bauverfahren": "''", "surface": "''", "allowance": "''", "location_hint": "''", "wesi": "''", "bestand": "0",
                    "hinweis": "'gezeichnet'", "laenge_m": "round($length, 1)", "quelle": "'planer'", "kante": "''"}
        for feld, ausdruck in vorgaben.items():
            i = fl.indexOf(feld)
            if i >= 0:
                lyr.setDefaultValueDefinition(i, QgsDefaultValue(ausdruck))
        self._formular_einrichten(lyr)

    def _formular_einrichten(self, lyr):
        """Markus 27.10.2026: das QGIS-Attributformular nach dem Zeichnen zeigt dieselben Auswahllisten wie die Leiste Trassenattribute."""
        try:
            n = formular.trassen_planung(lyr)
            if not getattr(self, "_formular_gemeldet", False):
                self._log("Attributformular der Planung: {} Felder mit Auswahlliste wie die Leiste Trassenattribute.".format(n))
                self._formular_gemeldet = True
        except Exception as e:
            self._log("Attributformular nicht eingerichtet: {!r}".format(e))

    def _auswahl_zaehlen(self):
        n = len(self._auswahl_uids())
        self.lab_sel.setText("{} Trassen gewaehlt{}".format(n, " (nur dieser NVT)" if self.h_nur.isChecked() else ""))

    def _auswahl_uids(self):
        """Gewaehlte Trassen der Planung; bei 'nur diesen NVT zeigen' nur die des gewaehlten NVT (ausgeblendete Trassen koennen ueber
        Ausdruecke trotzdem in der Auswahl landen)."""
        lyr = self._layer("Planung")
        if lyr is None:
            return []
        if self.h_nur.isChecked() and self.nvt:
            return [str(f["uid"]) for f in lyr.selectedFeatures() if str(f["nvt"]) == str(self.nvt)]
        return [str(f["uid"]) for f in lyr.selectedFeatures()]

    def _speichern(self):
        """Offene QGIS-Bearbeitung der Planung festschreiben (der Kern liest dann den aktuellen Stand)."""
        lyr = self._layer("Planung")
        if lyr is None:
            return True
        if lyr.isEditable():
            if lyr.isModified():
                if not lyr.commitChanges():
                    self._log("Planung nicht gespeichert: " + "; ".join(lyr.commitErrors())[:300])
                    return False
                self._log("Planung gespeichert.")
                try:
                    kern.wal_schliessen(self.gpkg)
                    if self.nvt:
                        st = kern.status_aktualisieren(self.gpkg, self.nvt, geaendert=True)
                        if st == "in Arbeit":
                            self._log("NVT {}: nach der Aenderung erneut pruefen (Status in Arbeit).".format(self.nvt))
                except Exception as e:
                    self._log("Status nicht nachgefuehrt: {!r}".format(e))
            else:
                lyr.rollBack()
        return True

    def _neu_laden(self):
        for titel in ("Planung", "Vorlage", "Endstand", "Befunde", "NVT"):
            lyr = self._layer(titel)
            if lyr is not None:
                try:
                    lyr.dataProvider().reloadData()
                    lyr.reload()
                    lyr.updateExtents()
                    lyr.triggerRepaint()
                except Exception:
                    pass
        self._nvt_fuellen()
        self._filter_setzen()
        self._auswahl_zaehlen()
        z = next((x for x in self._nvt_zeilen if x["name"] == self.nvt), None)
        if z:
            self.lab_nvt.setText("NVT {} - {}".format(z["name"], z["status"]))

    # --- QGIS-Werkzeuge auf der Planung ------------------------------------------------------------------------------------------------------
    def _qgis_werkzeug(self, aktion):
        lyr = self._layer("Planung")
        if lyr is None:
            return
        try:
            self.iface.setActiveLayer(lyr)
            if not lyr.isEditable():
                lyr.startEditing()
            getattr(self.iface, aktion)().trigger()
            self._log("QGIS-Werkzeug aktiv: {}. Danach 'Aenderungen speichern'.".format(aktion.replace("action", "")))
        except Exception as e:
            self._log("Werkzeug nicht gestartet: {!r}".format(e))

    def _zeichnen(self):
        self._vorgaben_setzen()
        self._qgis_werkzeug("actionAddFeature")

    # --- Kern-Werkzeuge ------------------------------------------------------------------------------------------------------------------
    def _kern_aktion(self, name, fn):
        if not self.gpkg or not self.nvt:
            return
        if not self._speichern():
            return
        try:
            fn()
            self._neu_laden()
        except Exception as e:
            self._log("{}: Fehler {!r}".format(name, e))
            self._log(traceback.format_exc()[-1000:])
            QMessageBox.critical(self, name, "{!r}".format(e)[:500])

    def _vorlage(self):
        if not self.gpkg or not self.nvt:
            return
        n = kern.nvt_lesen(self.gpkg)
        z = n[n["name"].astype(str) == str(self.nvt)]
        pn = int(z["planung_n"].iloc[0] or 0) if len(z) and "planung_n" in z else 0
        text = "Vorlage von NVT {} in die Planung kopieren?".format(self.nvt)
        if pn:
            text += "\n\nACHTUNG: die Planung dieses NVT hat schon {} Trassen - sie werden ersetzt.".format(pn)
        if QMessageBox.question(self, "Vorlage uebernehmen", text, QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self._kern_aktion("Vorlage uebernehmen", lambda: kern.vorlage_uebernehmen(self.gpkg, self.nvt, log=self._log))

    def _hauszuf(self):
        if not self.gpkg or not self.nvt:
            return
        erg = {}

        def lauf():
            erg.update(kern.hauszufuehrungen_ableiten(self.gpkg, self.nvt, max_m=self.s_hz.value(), log=self._log))
        self._kern_aktion("Hauszufuehrungen ableiten", lauf)
        if erg:
            ohne = erg.get("ohne") or []
            QMessageBox.information(self, "Hauszufuehrungen", "NVT {}: {} abgeleitet, {} vom Planer gezeichnete behalten, {} Adressen teilen sich eine "
                                    "Koordinate (eine Hauszufuehrung je Gebaeude), {} Adressen ohne Trasse in {:.0f} m.{}".format(
                self.nvt, erg.get("neu", 0), erg.get("behalten", 0), erg.get("gemeinsam", 0), len(ohne), self.s_hz.value(),
                "\n\nOhne Trasse:\n" + "\n".join(ohne[:15]) + ("\n..." if len(ohne) > 15 else "") if ohne else ""))

    def _verschmelzen(self):
        uids = self._auswahl_uids()
        if len(uids) < 2:
            QMessageBox.information(self, "Verschmelzen", "Mindestens zwei aneinanderhaengende Trassen in der Planung waehlen.")
            return
        self._kern_aktion("Verschmelzen", lambda: kern.verschmelzen(self.gpkg, uids, log=self._log))

    def _einrasten(self):
        uids = self._auswahl_uids()
        self._kern_aktion("Einrasten", lambda: kern.einrasten(self.gpkg, self.nvt, uids or None, self.s_tol.value(), log=self._log))

    def _teilen(self):
        """Phillip 27.10.2026: Planung an allen Abzweigen und Kreuzungen teilen (kern.teilen) - gewaehlter NVT oder alle NVT."""
        if not self.gpkg or not self.nvt:
            QMessageBox.information(self, "Teilen", "Erst ein Trassen-Ergebnis laden und in der Liste einen NVT waehlen.")
            return
        box = QMessageBox(self)
        box.setWindowTitle("Teilen an Abzweigen und Kreuzungen")
        box.setText("Trassen der Planung an allen Abzweigen (Ende bis {:.2f} m auf einer anderen Trasse, z. B. Hausstich-Fusspunkt) und an allen "
                    "Kreuzungen teilen?\n\nDie Teile behalten ihre Attribute; Trassen verschiedener NVT werden nicht gegeneinander geteilt.".format(self.s_tol.value()))
        uids = self._auswahl_uids()
        k_mark = box.addButton("Nur markierte ({})".format(len(uids)), QMessageBox.AcceptRole) if uids else None
        k_nvt = box.addButton("Nur NVT {}".format(self.nvt), QMessageBox.AcceptRole)
        k_alle = box.addButton("Alle NVT", QMessageBox.AcceptRole)
        box.addButton("Abbrechen", QMessageBox.RejectRole)
        box.exec_()
        k = box.clickedButton()
        if k is None or k not in (k_mark, k_nvt, k_alle):
            return
        nvt = self.nvt if k is k_nvt else None
        auswahl = uids if k is k_mark else None
        erg = {}

        def lauf():
            erg.update(kern.teilen(self.gpkg, nvt, self.s_tol.value(), uids=auswahl, log=self._log))
        self._kern_aktion("Teilen", lauf)
        if erg:
            bereich = "{} markierte Trassen".format(len(auswahl)) if auswahl else ("Alle NVT" if nvt is None else "NVT {}".format(nvt))
            QMessageBox.information(self, "Teilen", "{}: {} Abzweige und {} Kreuzungen gefunden, {} Trassen geteilt, {} neue Teilstuecke.{}".format(
                bereich, erg["abzweige"], erg["kreuzungen"], erg["linien"], erg["neu"],
                "\n\nGeaenderte NVT bitte erneut pruefen (ein gepruefter NVT steht wieder auf in Arbeit)." if erg["nvt"] else ""))

    def _nvt_zuweisen(self):
        """Markus 27.10.: ein Stueck Trasse lag im falschen NVT. Alle markierten Trassen zaehlen, auch bei 'nur diesen NVT zeigen'."""
        lyr = self._layer("Planung")
        if lyr is None or not self.gpkg:
            return
        uids = [str(f["uid"]) for f in lyr.selectedFeatures()]
        if not uids:
            QMessageBox.information(self, "Zu NVT verschieben", "Trassen in der Planung markieren (Haken 'nur diesen NVT' ggf. ausschalten).")
            return
        namen = [z["name"] for z in self._nvt_zeilen]
        if not namen:
            return
        vor = namen.index(self.nvt) if self.nvt in namen else 0
        ziel, ok = QInputDialog.getItem(self, "Zu NVT verschieben", "{} markierte Trassen zuordnen zu NVT:".format(len(uids)), namen, vor, False)
        if not ok or not ziel:
            return
        erg = {}

        def lauf():
            erg.update(kern.nvt_zuweisen(self.gpkg, uids, ziel, log=self._log))
        self._kern_aktion("Zu NVT verschieben", lauf)
        if erg:
            QMessageBox.information(self, "Zu NVT verschieben", "{} Trassen zu NVT {} verschoben{}. Beide NVT stehen auf 'in Arbeit' - erneut pruefen.".format(
                erg.get("n", 0), ziel, " (aus {})".format(", ".join(erg["quellen"])) if erg.get("quellen") else ""))

    def _loeschen(self):
        uids = self._auswahl_uids()
        if not uids:
            QMessageBox.information(self, "Loeschen", "Trassen in der Planung waehlen.")
            return
        if QMessageBox.question(self, "Loeschen", "{} Trassen aus der Planung loeschen?".format(len(uids)), QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self._kern_aktion("Loeschen", lambda: kern.loeschen(self.gpkg, uids, log=self._log))

    def _kandidaten(self):
        lyr = self._layer("Kandidaten")
        kanten = [str(f["kante"]) for f in lyr.selectedFeatures()] if lyr is not None else []
        if not kanten:
            QMessageBox.information(self, "Kandidaten", "Im Layer 'Kandidaten' Stuecke markieren (graue Linien).")
            return
        self._kern_aktion("Kandidaten", lambda: kern.kandidaten_uebernehmen(self.gpkg, self.nvt, kanten, log=self._log))
        if lyr is not None:
            lyr.removeSelection()

    def _auswahl(self):
        """Markierte Linien des aktiven Layers (egal welcher Linienlayer) in die Planung dieses NVT (Markus 08.10.2026)."""
        from shapely import wkt
        if not self.gpkg or not self.nvt:
            QMessageBox.information(self, "Auswahl uebernehmen", "Erst ein Trassen-Ergebnis laden und in der Liste den NVT waehlen, in dessen Planung die Linien sollen.")
            return
        lyr = self.iface.activeLayer()
        planung = self._layer("Planung")
        if lyr is None or not isinstance(lyr, QgsVectorLayer) or lyr.geometryType() != QgsWkbTypes.LineGeometry:
            QMessageBox.information(self, "Auswahl uebernehmen", "Im Layerbaum einen LINIENLAYER aktiv setzen (anklicken) und darin die Trassen markieren, "
                                    "z. B. die Angebotsplanung, einen Plan[Goo]-Trassenlayer oder die Vorlage.")
            return
        if planung is not None and lyr.id() == planung.id():
            QMessageBox.information(self, "Auswahl uebernehmen", "Der aktive Layer ist die Planung selbst - die Trassen sind schon drin.")
            return
        feats = list(lyr.selectedFeatures())
        if not feats:
            QMessageBox.information(self, "Auswahl uebernehmen", "Im Layer '{}' sind keine Linien markiert.".format(lyr.name()))
            return
        ct = QgsCoordinateTransform(lyr.crs(), QgsCoordinateReferenceSystem("EPSG:{}".format(kern.CRS)), QgsProject.instance())
        namen = [f_.name() for f_ in lyr.fields()]
        linien = []
        for f in feats:
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            if not ct.isShortCircuited():
                g.transform(ct)
            attrs = {n: f[n] for n in namen}
            for k, v in list(attrs.items()):
                attrs[k] = None if (v is None or (hasattr(v, "isNull") and v.isNull())) else v
            linien.append((wkt.loads(g.asWkt()), attrs))
        vorgabe = self._masken_werte()
        text = ("{} markierte Linien aus '{}' in die Planung von NVT {} anhaengen?\n\nPlan[Goo]-Attribute werden aus dem Layer uebernommen, soweit er sie "
                "traegt (Bauverfahren, Oberflaeche, Zulage, Lagehinweis, WeSi, Hauszufuehrung, Bestand).").format(len(linien), lyr.name(), self.nvt)
        text += ("\nLeere Felder bekommen die Vorgabe der Attributmaske: " + ", ".join("{}={}".format(k, v) for k, v in vorgabe.items())) if vorgabe else \
            "\nDie Attributmaske steht auf '- keine Aenderung -': Felder, die der Layer nicht liefert, bleiben leer und fallen in der Pruefung auf."
        if QMessageBox.question(self, "Auswahl uebernehmen", text, QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes) != QMessageBox.Yes:
            return
        erg = {}

        def lauf():
            erg.update(kern.auswahl_uebernehmen(self.gpkg, self.nvt, linien, quelle=lyr.name(), vorgabe=vorgabe, log=self._log))

        self._kern_aktion("Auswahl uebernehmen", lauf)
        if erg.get("uids"):
            n = len(erg["uids"])
            fehlt = [t for t, k in (("Bauverfahren", "mit_bauverfahren"), ("Oberflaeche", "mit_surface")) if erg.get(k, 0) < n]
            zusatz = ""
            if fehlt:
                zusatz += "\n\nOhne {}: {} Trassen - in der Planung markieren und ueber die Attributmaske setzen (die Pruefung verlangt beides).".format(
                    " und ".join(fehlt), n - min(erg.get("mit_bauverfahren", 0), erg.get("mit_surface", 0)))
            if erg.get("verworfen"):
                zusatz += "\n\nNicht im Plan[Goo]-Wertevorrat, leer gelassen: " + ", ".join(erg["verworfen"][:6])
            if erg.get("inhouse"):
                zusatz += "\n\n{} Hauseinfuehrungen im Gebaeude (in_house) ausgelassen.".format(erg["inhouse"])
            QMessageBox.information(self, "Auswahl uebernehmen", "{} Trassen ({:.0f} m) aus '{}' in die Planung von {} uebernommen.{}\n\nDanach: "
                                    "'Einrasten' auf die Nachbartrassen und 'Luecken finden'.".format(n, erg.get("laenge_m", 0), lyr.name(), self.nvt, zusatz))
            try:
                lyr.removeSelection()
            except Exception:
                pass

    def _masken_werte(self):
        """Werte der Attributmaske als dict Arbeitsspalte -> Wert ('- keine Aenderung -' ausgelassen, '- leer -' = '')."""
        werte = {}
        w = self.a_bestand.currentText()
        if w != "- keine Aenderung -":
            werte["bestand"] = 1 if w == "ja" else 0
        for combo, feld in ((self.a_bv, "bauverfahren"), (self.a_sf, "surface"), (self.a_al, "allowance"), (self.a_lh, "location_hint"), (self.a_wesi, "wesi")):
            w = combo.currentText()
            if w == "- keine Aenderung -":
                continue
            werte[feld] = "" if w == "- leer -" else w
        w = self.a_hz.currentText()
        if w != "- keine Aenderung -":
            werte["sub_type"] = "Hauszufuehrung" if w == "ja" else ""
        return werte

    def _attribute(self):
        uids = self._auswahl_uids()
        if not uids:
            QMessageBox.information(self, "Trassenattribute", "Trassen in der Planung waehlen, dann Speichern.")
            return
        werte = self._masken_werte()
        if not werte:
            QMessageBox.information(self, "Trassenattribute", "Keine Aenderung gewaehlt.")
            return
        self._kern_aktion("Attribute", lambda: kern.attribute_setzen(self.gpkg, uids, werte, log=self._log))

    # --- Pruefen / Uebertragen -----------------------------------------------------------------------------------------------------------
    def _wesi_datei(self):
        for p in dateiwahl.kandidaten("wesi"):
            return p
        return None

    def _pruefen(self, nur_luecken=False):
        if not self.gpkg or not self.nvt:
            return
        if not self._speichern():
            return
        try:
            r = kern.pruefen(self.gpkg, self.nvt, toleranz=self.s_tol.value(), wesi_gpkg=self._wesi_datei(), log=self._log)
            self._neu_laden()
            self._pruefliste_zeigen(nur_luecken)
            z = next((x for x in self._nvt_zeilen if x["name"] == self.nvt), None)
            if z:
                self.lab_nvt.setText("NVT {} - {}".format(z["name"], z["status"]))
            if r["blockiert"] == 0 and not nur_luecken:
                QMessageBox.information(self, "Pruefung", "NVT {}: keine blockierenden Befunde{} - Status geprueft.\n\nSind alle NVT geprueft, geht es in Schritt 10 als Kondensat nach Plan[Goo].".format(
                    self.nvt, ", {} Hinweise".format(len(r["zeilen"])) if r["zeilen"] else ""))
        except Exception as e:
            self._log("Pruefung: Fehler {!r}".format(e))
            self._log(traceback.format_exc()[-1000:])

    def _luecken(self):
        self._pruefen(nur_luecken=True)

    def _pruefliste_zeigen(self, nur_luecken=False):
        self.tab_pf.setRowCount(0)
        self._pf_zeilen = []
        if not self.gpkg or not self.nvt:
            return
        try:
            import geopandas as gpd
            import pyogrio
            if "pruefung" not in set(pyogrio.list_layers(self.gpkg)[:, 0]):
                return
            p = gpd.read_file(self.gpkg, layer="pruefung")
            p = p[p["nvt"].astype(str) == str(self.nvt)]
            if nur_luecken:
                p = p[p["art"].isin(["Luecke", "T-Stoss ohne Knoten", "nicht verbunden", "Kreuzung ohne Knoten"])]
        except Exception as e:
            self._log("Befunde nicht lesbar: {!r}".format(e))
            return
        p = p.sort_values(["blockiert", "art"], ascending=[False, True])
        self.tab_pf.setRowCount(len(p))
        for zi, (_, r) in enumerate(p.iterrows()):
            for si, wv in enumerate((str(r["art"]), str(r["text"]), "ja" if int(r["blockiert"] or 0) else "nein")):
                it = QTableWidgetItem(wv)
                if si == 2:
                    it.setForeground(QColor("#C62828" if wv == "ja" else "#E0A800"))
                self.tab_pf.setItem(zi, si, it)
            def _sp(name, vor=""):
                try:
                    w = r[name]
                except Exception:
                    return vor
                w = "" if w is None or (isinstance(w, float) and w != w) else str(w)
                return w if w not in ("", "nan", "None") else vor
            self._pf_zeilen.append({"xy": (r.geometry.x, r.geometry.y) if r.geometry is not None else None,
                                    "uid": _sp("uid"), "uid2": _sp("uid2"), "art": str(r["art"]),
                                    "radius": float(_sp("radius_m", "25") or 25)})
            uids = [u for u in (_sp("uid"), _sp("uid2")) if u]
            self.tab_pf.karte_setzen(zi, xy=self._pf_zeilen[-1]["xy"], bezug=("Planung", {"uid": uids}) if uids else None)
        self.tab_pf.resizeColumnToContents(0)
        self.tab_pf.resizeColumnToContents(2)
        self.tab_pf.fertig()

    def _auswahl_aufheben(self):
        """Markus 27.10.: Befundzeile und Layerauswahl leeren - auch wenn die Karte gerade etwas anderes gewaehlt hat."""
        try:
            self.tab_pf.zeilen_waehlen([], nur=True)
        except Exception:
            pass
        lyr = self._layer("Planung")
        if lyr is not None:
            lyr.removeSelection()
        self._auswahl_zaehlen()

    def _befund_zeigen(self, zoom=False):
        """Markus 17.09.: Befund in der Liste anwaehlen -> die betroffenen Trassen werden im Layer Planung ausgewaehlt (bleiben
        hervorgehoben) und blinken zusammen mit dem Fundpunkt rot auf; Doppelklick oder der Knopf zoomen zusaetzlich hin.
        Die Layerauswahl setzt die Tabelle selbst (Kartenbezug uid); hier nur lesen und blinken - eine zweite Auswahl von hier
        loeste 27.10. die Sprungschleife zwischen Befunden derselben Trasse aus."""
        zeilen = self.tab_pf.auswahl_indizes()
        if not zeilen or zeilen[0] >= len(self._pf_zeilen):
            return
        z = self._pf_zeilen[zeilen[0]]
        crs = QgsCoordinateReferenceSystem("EPSG:25832")
        geome, kasten = [], None
        try:
            uids = [u for u in (z.get("uid"), z.get("uid2")) if u]
            lyr = self._layer("Planung")
            if lyr is not None and uids:
                ausdruck = "\"uid\" IN ({})".format(", ".join("'{}'".format(u.replace("'", "''")) for u in uids))
                for f in lyr.getFeatures(QgsFeatureRequest().setFilterExpression(ausdruck)):
                    g = f.geometry()
                    if g is not None and not g.isEmpty():
                        geome.append(QgsGeometry(g))
                        if kasten is None:
                            kasten = g.boundingBox()
                        else:
                            kasten.combineExtentWith(g.boundingBox())
            if z.get("xy"):
                x, y = z["xy"]
                geome.append(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
                r = float(z.get("radius") or 25.0)
                pk = QgsRectangle(x - r, y - r, x + r, y + r)
                if kasten is None:
                    kasten = pk
                else:
                    kasten.combineExtentWith(pk)
            canvas = self.iface.mapCanvas()
            if zoom and kasten is not None:
                ct = QgsCoordinateTransform(crs, canvas.mapSettings().destinationCrs(), QgsProject.instance())
                kasten.grow(max(5.0, 0.15 * max(kasten.width(), kasten.height())))
                canvas.setExtent(ct.transformBoundingBox(kasten))
                canvas.refresh()
            if geome:
                canvas.flashGeometries(geome, crs, QColor("#C62828"), QColor(198, 40, 40, 0), 3, 600)
        except Exception as e:
            self._log("Befund zeigen: {!r}".format(e))

