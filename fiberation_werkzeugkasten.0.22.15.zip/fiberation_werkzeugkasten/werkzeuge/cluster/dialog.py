# -*- coding: utf-8 -*-
"""Werkzeug 3 - Dialog "NVT-Gebiete clustern": Adressen und Netz waehlen, Regelsatz, schneiden, nachrechnen, Layer laden."""
import os
import traceback

from qgis.core import (QgsCategorizedSymbolRenderer, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsFillSymbol, QgsGeometry,
                       QgsLineSymbol, QgsMarkerSymbol,
                       QgsPalLayerSettings, QgsProject, QgsRendererCategory, QgsSingleSymbolRenderer, QgsTextFormat, QgsVectorLayer,
                       QgsVectorLayerSimpleLabeling)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (QApplication, QComboBox, QDialog, QDialogButtonBox, QFrame, QGridLayout, QHBoxLayout, QInputDialog, QLabel,
                                 QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QProgressBar, QPushButton, QRadioButton, QSpinBox,
                                 QTextEdit, QVBoxLayout)

from ... import ablauf, ci, dateiwahl, layerbaum
from ...dialogbasis import WerkzeugDialog
from ...dateiwahl import DateiFeld
from . import config

FARBEN = {"gruen": "#2E8B57", "gelb": "#E0A800", "rot": "#C62828"}
PALETTE = ["#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4", "#46f0f0", "#f032e6", "#bcf60c", "#fabebe", "#008080", "#e6beff",
           "#9a6324", "#fffac8", "#800000", "#aaffc3", "#808000", "#ffd8b1", "#000075", "#808080", "#ffe119"]


def nvt_label_ausdruck(farbe_von=None, mit_vorgabe=False):
    """Label der NVT-Gebiete (Markus 16.09.2026, drei Bausteine): Kopfzeile fett 10 pt mit Ampelpunkt, Kennzahlen 7,5 pt darunter,
    massstabsabhaengig - ab 1:5000 nur die Kopfzeile, die Kennzahlen erst ab 1:3000. Der Kasten kommt aus ci.label_kasten.
    QGIS-HTML (3.40): jede Zeile ein eigener <div>; <br> direkt nach </span> und \\n gehen verloren, jede Farbe in eigenem Span.
    mit_vorgabe: Layer hat die Spalte vorgabe (ab 0.9.10) - Vorgabe-Gebiete des Planers werden in der Kopfzeile gekennzeichnet."""
    zusatz = "if(coalesce(\"vorgabe\", 0) = 1, ', Vorgabe gesperrt', ''), " if mit_vorgabe else ""
    kopf = ("concat('<div><span style=\"color:', {ampel}, ';font-size:10pt\">&#9679;</span>"
            "<span style=\"color:#1A1A1A;font-size:10pt\"><b> ', \"name\", '</b></span>"
            "<span style=\"color:#1A1A1A;font-size:8pt\"> (', \"ampel\", {zusatz}')</span></div>')").format(ampel=ci.farb_ausdruck("ampel", FARBEN), zusatz=zusatz)
    z = "'</span></div><div><span style=\"color:#1A1A1A\">'"    # Zeilenwechsel
    zahlen = ("concat('<div><span style=\"color:#1A1A1A\">', "
              "\"apl\", ' von ', coalesce(\"max_apl\", 60), '/', coalesce(\"max_apl_hart\", 74), ' Adr | ', "
              "\"snr\", ' von ', coalesce(\"max_snr\", 90), ' SNR', {z}, "
              "\"we\", ' von ', coalesce(\"max_we\", 600), ' WE | ', \"anschluesse\", ' Anschl.', {z}, "
              "round(\"pon_fasern\", 1), ' von ', coalesce(\"max_pon\", 23), ' PON | ', "
              "\"kassetten\", ' von ', coalesce(\"max_kassetten\", 126), ' Kass.', {z}, "
              "'Hk-Fasern ', \"hk_fasern\", ' von ', coalesce(\"max_hk_fasern\", 36), "
              "if(coalesce(\"hk_text\", '') <> '', ' (' || \"hk_text\" || ', ZTV 21 8.6.2.3)', ''), {z}, "
              "'Vzk max ', \"vzk_max_m\", ' von ', coalesce(\"max_vzk_m\", 750), ' m | Baum ', \"vzk_baum_m\", ' m</span></div>')").format(z=z)
    return "if(@map_scale <= 3000, concat({kopf}, {zahlen}), {kopf})".format(kopf=kopf, zahlen=zahlen)


def grenz_layer():
    """Linien- und Flaechenlayer des Projekts, die als Zwangsgrenze taugen (ohne die eigenen Ergebnislayer von Schritt 3)."""
    from qgis.core import QgsWkbTypes
    out = []
    for lyr in QgsProject.instance().mapLayers().values():
        if isinstance(lyr, QgsVectorLayer) and QgsWkbTypes.geometryType(lyr.wkbType()) in (QgsWkbTypes.LineGeometry, QgsWkbTypes.PolygonGeometry):
            if layerbaum.ohne_nummer(lyr.name()).startswith(("NVT-Gebiete", "Netz", "Strassenabschnitte", "Ampel")):
                continue
            out.append(lyr)
    return out


class ZwangsgrenzenDialog(QDialog):
    """Markus 12.10.2026: mehrere Zwangsgrenzen zugleich - alle Linien-/Flaechenlayer des Projekts mit Haken statt einem Kombifeld."""

    def __init__(self, gewaehlt, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Zwangsgrenzen waehlen")
        self.setMinimumWidth(420)
        lay = QVBoxLayout(self)
        hinweis = QLabel("Trassen, die einen angehakten Layer schneiden, werden beim Wachsen der Gebiete nicht ueberschritten (hart). "
                         "Besteht in einem Layer eine Auswahl, zaehlt nur sie. Ohne Haken gelten nur die eingebauten Sperren "
                         "(Hauptstrasse, Bahn, Gewaesser).")
        hinweis.setWordWrap(True)
        hinweis.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        lay.addWidget(hinweis)
        self.liste = QListWidget()
        for lyr in sorted(grenz_layer(), key=lambda l: l.name().lower()):
            it = QListWidgetItem(lyr.name())
            it.setData(Qt.UserRole, lyr.id())
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if lyr.id() in gewaehlt else Qt.Unchecked)
            self.liste.addItem(it)
        lay.addWidget(self.liste, 1)
        kn = QHBoxLayout()
        k_keine = QPushButton("Alle abwaehlen")
        k_keine.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        k_keine.clicked.connect(lambda: [self.liste.item(i).setCheckState(Qt.Unchecked) for i in range(self.liste.count())])
        kn.addWidget(k_keine)
        kn.addStretch(1)
        box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        kn.addWidget(box)
        lay.addLayout(kn)

    def gewaehlt(self):
        return [self.liste.item(i).data(Qt.UserRole) for i in range(self.liste.count()) if self.liste.item(i).checkState() == Qt.Checked]


class ClusterDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self.ergebnis = None
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel("cluster").replace("  ", " ", 1))
        self.setMinimumWidth(820)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel("cluster"), "Adressen entlang des Strassennetzes zu NVT-Gebieten schneiden, Grenzen nach ZTV 21. Der Planer gibt vor und aendert.")
        lay.addWidget(self.kopf)

        # --- Schneiden: Quelle, Regelsatz, Grenzen, Vorgaben, Nummern, Ausgabe -------------------------------------------------------
        lay.addWidget(self._ueberschrift("Schneiden"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(6)
        g.addWidget(QLabel("Adresspruefung (1):"), 0, 0)
        self.f_adr = DateiFeld("adresspruefung", "adresspruefung_....gpkg aus Werkzeug 2 - aufklappen fuer die letzten Ergebnisse, auch per Drag und Drop",
                               "GeoPackage (*.gpkg);;Bedarfsliste (*.csv *.CSV)", "Adresspruefung waehlen", ci.STIL_KNOPF_ZWEIT)
        g.addWidget(self.f_adr, 0, 1, 1, 5)
        g.addWidget(QLabel("Regelsatz:"), 1, 0)
        self.regel = QComboBox()
        self.regel.addItem("automatisch nach Ausbautreiber", "")
        for k, v in config.REGELSAETZE.items():
            self.regel.addItem(v["name"], k)
        self.regel.currentIndexChanged.connect(self._regel_gewechselt)
        self.regel.setToolTip("Grenzen je Gebiet nach ZTV 21; der Ausbautreiber steht in der Bedarfsliste (Eigenausbau 60/74, MBfD 22 L (BF) 51/57, "
                              "MBfD 22 XS (BF) 10/13 nur auf Wahl fuer Strassenzuege).")
        g.addWidget(self.regel, 1, 1, 1, 2)
        self.s_weich = self._spin(1, 200, 60)
        self.s_hart = self._spin(1, 200, 74)
        self.s_we = self._spin(50, 3000, 600)
        self.s_vzk = self._spin(100, 3000, 750)
        self.s_ziel = self._spin(5, 150, 48)
        gr = QHBoxLayout()
        gr.setSpacing(6)
        for text, s, tipp in (("Adr. weich", self.s_weich, "Adressen je NVT, ab hier gelb"), ("hart", self.s_hart, "Adressen je NVT, ab hier rot"),
                              ("WE", self.s_we, "Wohneinheiten je NVT, ab hier gelb"), ("Vzk m", self.s_vzk, "laengster Vzk-Weg im Netz, ab hier rot"),
                              ("Ziel", self.s_ziel, "Zielgroesse: Adressen je NVT, mit der die Automatik startet")):
            lab = QLabel(text + ":")
            lab.setToolTip(tipp)
            s.setToolTip(tipp)
            s.setMaximumWidth(64)
            gr.addWidget(lab)
            gr.addWidget(s)
        gr.addStretch(1)
        self._regel_gewechselt()      # Vorgabe aus myDMS setzen (30.09.2026)
        g.addLayout(gr, 1, 3, 1, 3)
        g.addWidget(QLabel("Zwangsgrenzen:"), 2, 0)
        # Markus 12.10.: Klick auf das Feld oeffnet ein Fenster mit allen Linien-/Flaechenlayern zum Anhaken - mehrere Grenzen zugleich
        self._grenzen_ids = []
        self.k_grenzen = QPushButton("- keine -")
        self.k_grenzen.setStyleSheet(ci.STIL_KNOPF_ZWEIT + " QPushButton { text-align: left; }")
        self.k_grenzen.setCursor(Qt.PointingHandCursor)
        self.k_grenzen.setToolTip("Linien- oder Flaechenlayer aus dem QGIS-Projekt, mehrere zugleich: Trassen, die diese Grenzen schneiden, werden beim "
                                  "Wachsen der Gebiete nicht ueberschritten (hart). Keine = nur die eingebauten Sperren (Hauptstrasse, Bahn, Gewaesser).")
        self.k_grenzen.clicked.connect(self._grenzen_waehlen)
        g.addWidget(self.k_grenzen, 2, 1, 1, 2)
        g.addWidget(QLabel("Vorgabe-Gebiete:"), 2, 3)
        self.l_vorgabe = QComboBox()
        self.l_vorgabe.setToolTip("Polygonlayer mit Gebieten, die der Planer selbst festlegt. Adressen darin sind fest zugeordnet, das Netz darin "
                                  "ist fuer die Automatik gesperrt. Feld 'name' = NVT-Name (leer = Nummer aus dem Nummernkreis). "
                                  "Besteht eine Auswahl im Layer, zaehlt nur sie.")
        g.addWidget(self.l_vorgabe, 2, 4)
        self.k_zeichnen = QPushButton("Zeichnen")
        self.k_zeichnen.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_zeichnen.setToolTip("Legt den Layer 'Vorgabe-Gebiete' an (falls noetig), schaltet ihn in die Bearbeitung und aktiviert das "
                                   "Zeichenwerkzeug. Polygon ziehen, Rechtsklick schliesst, Name eintragen; Bearbeitung speichern, dann Schneiden.")
        self.k_zeichnen.clicked.connect(self._gebiete_zeichnen)
        vz = QHBoxLayout()
        vz.setSpacing(6)
        vz.addWidget(self.k_zeichnen)
        # Markus 12.10.: zweiter Weg - Adressen in der Karte auswaehlen, Polygon darum wird Vorgabe-Gebiet
        self.k_aus_auswahl = QPushButton("Aus Auswahl")
        self.k_aus_auswahl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_aus_auswahl.setToolTip("Adressen in der Karte auswaehlen (Layer 'Adressen' aus Schritt 2 oder 3, QGIS-Auswahlwerkzeug), dann diesen Knopf: "
                                      "ein Polygon um die ausgewaehlten Adressen (eng anliegende Huelle plus 10 m) wird als Vorgabe-Gebiet in den Layer "
                                      "'Vorgabe-Gebiete' geschrieben, Name wird abgefragt (leer = Nummer aus dem Nummernkreis). Der aktive Layer bleibt.")
        self.k_aus_auswahl.clicked.connect(self._gebiet_aus_auswahl)
        vz.addWidget(self.k_aus_auswahl)
        g.addLayout(vz, 2, 5)
        zl = QHBoxLayout()
        zl.setSpacing(8)
        self.k_zaehlen = QPushButton("Adressen zaehlen")
        self.k_zaehlen.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_zaehlen.setToolTip("Alle Polygone des Vorgabe-Layers durchzaehlen (Adressen und WE aus der Adresspruefung oben). Beim Zeichnen "
                                  "geschieht das von selbst; der Knopf hilft, wenn der Layer schon vorher bestand oder nach dem Speichern.")
        self.k_zaehlen.clicked.connect(lambda: self._alle_zaehlen())
        zl.addWidget(self.k_zaehlen)
        self.lab_zaehler = QLabel("")
        self.lab_zaehler.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        self.lab_zaehler.setToolTip("Live-Zaehler beim Zeichnen: Adressen und WE im zuletzt geschlossenen oder geaenderten Polygon und in allen Vorgabe-Gebieten")
        zl.addWidget(self.lab_zaehler, 1)
        g.addLayout(zl, 3, 3, 1, 3)
        g.addWidget(QLabel("Nummernkreis (BVT):"), 3, 0)
        nk = QHBoxLayout()
        nk.setSpacing(6)
        self.nk_praefix = QLineEdit()
        self.nk_praefix.setPlaceholderText("Stamm, leer = aus ASB")
        self.nk_praefix.setMaximumWidth(130)
        self.nk_praefix.setToolTip("Namensstamm vor der Nummer, z. B. 1V. Leer: aus der ASB der Bedarfsliste (ASB 1 -> 1V01).")
        nk.addWidget(self.nk_praefix)
        nk.addWidget(QLabel("von"))
        self.nk_von = self._spin(1, 9999, 1)
        self.nk_von.setToolTip("Erste Nummer, die vergeben wird")
        nk.addWidget(self.nk_von)
        nk.addWidget(QLabel("bis"))
        self.nk_bis = self._spin(1, 9999, 9999)
        self.nk_bis.setToolTip("Nur zur Kontrolle: Namen ausserhalb des Blocks werden nach dem Schneiden gemeldet.")
        nk.addWidget(self.nk_bis)
        nk.addStretch(1)
        g.addLayout(nk, 3, 1, 1, 2)
        # Markus 12.10.: Ausgabeordner in eigener Zeile - vorher lag er mit 'Adressen zaehlen' auf Zeile 3, Spalten 3-5 (Texte ueberlagert)
        g.addWidget(QLabel("Ausgabeordner:"), 4, 0)
        self.out = QLineEdit()
        self.out.setPlaceholderText("leer = neben der Adresspruefung")
        g.addWidget(self.out, 4, 1, 1, 4)
        o = QPushButton("Waehlen")
        o.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        o.clicked.connect(self._out_waehlen)
        g.addWidget(o, 4, 5)
        g.setColumnStretch(1, 3)
        g.setColumnStretch(2, 2)
        g.setColumnStretch(4, 3)
        lay.addLayout(g)

        # --- Aktionen ----------------------------------------------------------------------------------------------------------------
        k = QHBoxLayout()
        self.k_start = QPushButton("Schneiden")
        self.k_start.setStyleSheet(ci.STIL_KNOPF)
        self.k_start.setCursor(Qt.PointingHandCursor)
        self.k_start.clicked.connect(self._start)
        self.k_abbruch = QPushButton("Abbrechen")
        self.k_abbruch.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_abbruch.setEnabled(False)
        self.k_abbruch.setToolTip("Laufenden OpenStreetMap-Abruf (Overpass) abbrechen - der Schritt endet dann ohne Ergebnis.")
        self.k_abbruch.clicked.connect(self._abbrechen)
        self.k_nach = QPushButton("Nachrechnen")
        self.k_nach.setStyleSheet(ci.STIL_KNOPF)
        self.k_nach.setEnabled(False)
        self.k_nach.setToolTip("Den vom Planer geaenderten Stand (Spalte nvt im Layer Adressen) neu bewerten: Polygone, Kennzahlen, Ampel. Schneidet nicht neu.")
        self.k_nach.clicked.connect(self._nachrechnen)
        self.k_laden = dateiwahl.ErgebnisKnopf("nvt_gebiete", self._ergebnis_setzen, "NVT-Gebiete (GeoPackage) waehlen",
                                               stil=ci.STIL_KNOPF_ZWEIT)
        self.k_bericht = QPushButton("Bericht oeffnen")
        self.k_bericht.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_bericht.setEnabled(False)
        self.k_bericht.clicked.connect(self._bericht)
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.setToolTip("Protokoll des Laufs ein- und ausblenden; bei Fehlern klappt es von selbst auf")
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        for b in (self.k_start, self.k_abbruch, self.k_nach, self.k_laden, self.k_bericht, self.k_log):
            k.addWidget(b)
        k.addStretch(1)
        lay.addLayout(k)
        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(120)
        self.log.setMaximumHeight(200)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log)

        # --- Planer-Aenderungen: Polygone, Auswahl, Namen ------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Planer-Aenderungen"))
        pg = QGridLayout()
        pg.setHorizontalSpacing(10)
        pg.setVerticalSpacing(6)
        self.k_poly = QPushButton("Gebiete aus Polygonen uebernehmen")
        self.k_poly.setStyleSheet(ci.STIL_KNOPF)
        self.k_poly.setEnabled(False)
        self.k_poly.setToolTip("Layer 'NVT-Gebiete' mit QGIS bearbeiten (Polygone verschmelzen, Knoten verschieben, Objekte loeschen). "
                               "Jede Adresse bekommt das Gebiet, in dem sie liegt; Polygone werden danach lueckenlos aus den Adressen NEU ABGELEITET - "
                               "von Hand gezeichnete Formen gehen dabei verloren. Sollen die Handpolygone bleiben: in Schritt 5 'Adressen nach Gebieten' nutzen.")
        self.k_poly.clicked.connect(self._aus_polygonen)
        pg.addWidget(self.k_poly, 0, 0)
        pg.addWidget(QLabel("Ausgewaehlte Adressen nach:"), 0, 1, Qt.AlignRight)
        self.ziel = QComboBox()
        self.ziel.setEditable(True)
        self.ziel.setInsertPolicy(QComboBox.NoInsert)
        self.ziel.lineEdit().setPlaceholderText("Gebiet waehlen oder neuen Namen tippen")
        self.ziel.setEnabled(False)
        pg.addWidget(self.ziel, 0, 2)
        self.k_versch = QPushButton("Verschieben")
        self.k_versch.setStyleSheet(ci.STIL_KNOPF)
        self.k_versch.setEnabled(False)
        self.k_versch.setToolTip("Adressen im Layer 'Adressen' mit den QGIS-Auswahlwerkzeugen markieren, Zielgebiet waehlen, Verschieben. "
                                 "Ein neuer Name legt ein neues Gebiet an. Danach Nachrechnen.")
        self.k_versch.clicked.connect(self._auswahl_verschieben)
        pg.addWidget(self.k_versch, 0, 3)
        self.k_ripple = QPushButton("Nummern aufruecken")
        self.k_ripple.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_ripple.setEnabled(False)
        self.k_ripple.setToolTip("Faellt durch Umclustern eine Nummer weg, ruecken die folgenden auf (Luecken schliessen). Zeigt die Liste und fragt vorher nach.")
        self.k_ripple.clicked.connect(self._nummern_aufruecken)
        pg.addWidget(self.k_ripple, 1, 0)
        pg.addWidget(QLabel("Gewaehltes Gebiet umbenennen:"), 1, 1, Qt.AlignRight)
        self.nb_name = QLineEdit()
        self.nb_name.setPlaceholderText("Polygon im Layer 'NVT-Gebiete' waehlen")
        self.nb_name.returnPressed.connect(self._umbenennen)
        pg.addWidget(self.nb_name, 1, 2)
        self.k_umb = QPushButton("Umbenennen")
        self.k_umb.setStyleSheet(ci.STIL_KNOPF)
        self.k_umb.setEnabled(False)
        self.k_umb.setToolTip("Benennt das gewaehlte Gebiet in allen Layern um (Gebiete, NVT-Sitz, Adressen, Strassenabschnitte) und zieht "
                              "die Dateien der Werkzeuge 3 und 4 mit.")
        self.k_umb.clicked.connect(self._umbenennen)
        pg.addWidget(self.k_umb, 1, 3)
        pg.setColumnStretch(2, 1)
        lay.addLayout(pg)
        weiter = QHBoxLayout()
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, "w2"))
        weiter.addWidget(hilfe)
        schl = QPushButton("Schliessen")
        self.k_schliessen = schl
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.close)
        weiter.addWidget(schl)
        weiter.addStretch(1)
        self.k_goo = QPushButton("Weiter mit 9: Uebergabe nach Plan[Goo]")
        self.k_goo.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_goo.setEnabled(False)
        self.k_goo.setToolTip("Oeffnet Werkzeug 10 mit diesem Schnitt: Gebiete, NVT und Adresszuordnung in das offene Plan[Goo]-Projekt schreiben.")
        self.k_goo.clicked.connect(self._weiter_zu_4)
        weiter.addWidget(self.k_goo)
        lay.addLayout(weiter)
        self.setAcceptDrops(True)
        from ... import fenster
        fenster.einrichten(self, "cluster", 820)

    # --- Hilfen ------------------------------------------------------------------------------------------------------------------------
    def _regel_gewechselt(self, *_):
        """Grenzen-Felder mit den myDMS-Werten des gewaehlten Regelsatzes fuellen (30.09.2026). Bei 'automatisch' stehen die
        Eigenausbau-Werte drin, gelten aber nur, wenn der Planer sie aendert (_grenzen liefert nur Abweichungen von der Vorgabe) -
        vorher ueberschrieben die 60/74/600/750 aus dem Dialog auch einen MBfD-Schnitt."""
        k = self.regel.currentData() or "eigen"
        r = config.erzeugen(k)["nvt"]
        self._vorgabe = {"max_apl": r["max_apl"], "max_apl_hart": r["max_apl_hart"], "max_we": r["max_we"],
                         "max_dist_m": r["max_dist_m"], "ziel_apl": r["ziel_apl"]}
        self.s_weich.setValue(r["max_apl"])
        self.s_hart.setValue(r["max_apl_hart"])
        self.s_we.setValue(r["max_we"])
        self.s_vzk.setValue(r["max_dist_m"])
        self.s_ziel.setValue(r["ziel_apl"])
        self.s_weich.setToolTip("Erstausbau je NVT nach myDMS ({}) fuer {}; darueber gelb.".format(r.get("mydms_quelle", "Kopie"), r["typ"]))
        self.s_hart.setToolTip("Maximalausbau je NVT nach myDMS fuer {}; darueber rot. Erweiterung Bestands-NVT: {} / {}.".format(
            r["typ"], r.get("apl_erw_weich", "-"), r.get("apl_erw_hart", "-")))

    def _out_waehlen(self):
        p = dateiwahl.ordner_waehlen(self, "Ausgabeordner waehlen", "ausgabe", self.out.text() or os.path.dirname(self.f_adr.text()))
        if p:
            self.out.setText(p)

    def showEvent(self, ev):
        super().showEvent(ev)
        # Werkzeug 2 kann inzwischen ein neues Ergebnis geschrieben haben
        self.f_adr.vorbelegen()
        self._grenzen_layer_fuellen()

    def _grenzen_waehlen(self):
        dlg = ZwangsgrenzenDialog(self._grenzen_ids, self)
        if dlg.exec_() != QDialog.Accepted:
            return
        self._grenzen_ids = dlg.gewaehlt()
        self._grenzen_anzeigen()
        self._log("Zwangsgrenzen: " + (", ".join(l.name() for l in self._grenzen_layer()) or "keine"))

    def _grenzen_layer(self):
        """Die angehakten Zwangsgrenzen-Layer, die es im Projekt noch gibt (in der Reihenfolge der Wahl)."""
        out = []
        for lid in self._grenzen_ids:
            lyr = QgsProject.instance().mapLayer(lid)
            if isinstance(lyr, QgsVectorLayer):
                out.append(lyr)
        return out

    def _grenzen_anzeigen(self):
        lyrs = self._grenzen_layer()
        self._grenzen_ids = [l.id() for l in lyrs]
        if not lyrs:
            self.k_grenzen.setText("- keine -")
        elif len(lyrs) == 1:
            self.k_grenzen.setText(lyrs[0].name())
        else:
            self.k_grenzen.setText("{} Layer: {}".format(len(lyrs), ", ".join(l.name() for l in lyrs)))
        self.k_grenzen.setToolTip(self.k_grenzen.toolTip().split("\n")[0] + ("\n\nGewaehlt:\n- " + "\n- ".join(l.name() for l in lyrs) if lyrs else ""))

    def _grenzen_layer_fuellen(self):
        from qgis.core import QgsWkbTypes
        self._grenzen_anzeigen()      # verschwundene Layer aus der Wahl nehmen, Text nachziehen
        # Vorgabe-Gebiete: nur Polygonlayer; 'Vorgabe-Gebiete' vorbelegt
        merk_v = self.l_vorgabe.currentData()
        self.l_vorgabe.blockSignals(True)
        self.l_vorgabe.clear()
        self.l_vorgabe.addItem("- keine -", "")
        vorbelegt = 0
        for lyr in QgsProject.instance().mapLayers().values():
            if isinstance(lyr, QgsVectorLayer) and QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PolygonGeometry:
                if layerbaum.ohne_nummer(lyr.name()).startswith(("NVT-Gebiete", "Ampel", "Vorgabe (gesperrt)")):
                    continue
                self.l_vorgabe.addItem(lyr.name(), lyr.id())
                if layerbaum.ohne_nummer(lyr.name()) == "Vorgabe-Gebiete":
                    vorbelegt = self.l_vorgabe.count() - 1
        j = self.l_vorgabe.findData(merk_v) if merk_v else -1
        self.l_vorgabe.setCurrentIndex(j if j >= 0 else vorbelegt)
        self.l_vorgabe.blockSignals(False)
        try:
            self.l_vorgabe.currentIndexChanged.disconnect(self._vorgabe_gewechselt)
        except Exception:
            pass
        self.l_vorgabe.currentIndexChanged.connect(self._vorgabe_gewechselt)
        self._zaehler_anhaengen()

    def _zwangsgrenzen(self):
        """Geometrien aller angehakten Grenzlayer als shapely (EPSG:25832); je Layer nur die Auswahl, wenn eine besteht."""
        lyrs = self._grenzen_layer()
        if not lyrs:
            return None
        from shapely import wkb
        out = []
        for lyr in lyrs:
            ct = QgsCoordinateTransform(lyr.crs(), QgsCoordinateReferenceSystem("EPSG:25832"), QgsProject.instance())
            feats = lyr.selectedFeatures() if lyr.selectedFeatureCount() else lyr.getFeatures()
            n0 = len(out)
            for f in feats:
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ct)
                try:
                    out.append(wkb.loads(bytes(g.asWkb())))
                except Exception:
                    continue
            self._log("Zwangsgrenzen: {} Geometrien aus '{}'{}".format(len(out) - n0, lyr.name(), " (nur Auswahl)" if lyr.selectedFeatureCount() else ""))
        return out or None

    def _vorgabe_gewechselt(self, *_):
        """Anderer Vorgabe-Layer gewaehlt: Zaehler dort anhaengen und den Stand zeigen."""
        if not self._lebt():
            return
        self._alle_zaehlen(still=True)

    def _vorgaben(self):
        """Vorgabe-Gebiete des Planers als Liste dict(name, geometry) in EPSG:25832; nur die Auswahl, wenn eine besteht."""
        lid = self.l_vorgabe.currentData()
        if not lid:
            return None
        lyr = QgsProject.instance().mapLayer(lid)
        if lyr is None:
            return None
        self._speichern_falls_offen(lyr)
        from qgis.core import QgsCoordinateTransform
        from shapely import wkb
        ct = QgsCoordinateTransform(lyr.crs(), QgsCoordinateReferenceSystem("EPSG:25832"), QgsProject.instance())
        feats = lyr.selectedFeatures() if lyr.selectedFeatureCount() else lyr.getFeatures()
        hat_name = lyr.fields().indexOf("name") >= 0
        out = []
        for f in feats:
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            try:
                geom = wkb.loads(bytes(g.asWkb()))
            except Exception:
                continue
            name = str(f["name"]) if hat_name and f["name"] not in (None, "") and str(f["name"]) != "NULL" else ""
            out.append({"name": name.strip(), "geometry": geom})
        self._log("Vorgabe-Gebiete: {} Polygone aus '{}'{}".format(len(out), lyr.name(), " (nur Auswahl)" if lyr.selectedFeatureCount() else ""))
        return out or None

    def _vorgabe_layer(self, anlegen=False):
        """Layer 'Vorgabe-Gebiete' im Projekt; mit anlegen=True wird er als Arbeitsspeicher-Layer angelegt, falls er fehlt."""
        for l in QgsProject.instance().mapLayers().values():
            if isinstance(l, QgsVectorLayer) and layerbaum.ohne_nummer(l.name()) == "Vorgabe-Gebiete":
                return l
        if not anlegen:
            return None
        lyr = QgsVectorLayer("Polygon?crs=EPSG:25832&field=name:string(40)&field=bemerkung:string(200)&field=adressen:integer&field=we:integer",
                             "Vorgabe-Gebiete", "memory")
        lyr.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({"color": "26,26,26,35", "outline_color": "#1A1A1A",
                                                                             "outline_width": "1.4", "outline_style": "dash"})))
        self._label(lyr, "concat(coalesce(\"name\", ''), if(\"adressen\" is null, '', ' | ' || \"adressen\" || ' Adr., ' || coalesce(\"we\", 0) || ' WE'))", 9, True, ausdruck=True)
        layerbaum.benennen(lyr, "cluster")
        QgsProject.instance().addMapLayer(lyr)
        self._log("Layer 'Vorgabe-Gebiete' angelegt (Arbeitsspeicher). Der Schnitt schreibt die Vorgaben in sein GeoPackage (Layer vorgaben); "
                  "wer sie dauerhaft im QGIS-Projekt will, exportiert den Layer als Datei.")
        return lyr

    def _auswahl_punktlayer(self):
        """Punktlayer mit Auswahl: der aktive Layer, sonst der erste Punktlayer mit Auswahl ('Adressen' bevorzugt), sonst None."""
        from qgis.core import QgsWkbTypes
        kand = [l for l in QgsProject.instance().mapLayers().values()
                if isinstance(l, QgsVectorLayer) and QgsWkbTypes.geometryType(l.wkbType()) == QgsWkbTypes.PointGeometry and l.selectedFeatureCount()]
        aktiv = self.iface.activeLayer() if self.iface is not None else None
        if aktiv is not None and aktiv in kand:
            return aktiv
        kand.sort(key=lambda l: (0 if "adress" in l.name().lower() else 1, l.name()))
        return kand[0] if kand else None

    @staticmethod
    def huelle_um_punkte(geoms, rand=10.0):
        """Eng anliegende Huelle (konkav, GEOS >= 3.11; sonst konvex) um Punktgeometrien, um rand m gepuffert. -> QgsGeometry (Polygon)"""
        alle = QgsGeometry.collectGeometry(list(geoms))
        huelle = None
        if len(geoms) >= 4 and hasattr(alle, "concaveHull"):
            try:
                huelle = alle.concaveHull(0.35, False)
            except Exception:
                huelle = None
        if huelle is None or huelle.isNull() or huelle.isEmpty():
            huelle = alle.convexHull()
        return huelle.buffer(float(rand), 8)

    def _gebiet_aus_auswahl(self):
        """Markus 12.10.2026: Vorgabe-Gebiet aus den in der Karte ausgewaehlten Adressen - Polygon um die Auswahl in den Layer 'Vorgabe-Gebiete'.
        Der vorher aktive Layer bleibt aktiv, damit der Planer gleich die naechsten Adressen auswaehlen kann."""
        lyr_p = self._auswahl_punktlayer()
        if lyr_p is None:
            QMessageBox.information(self, "Vorgabe-Gebiet aus Auswahl", "Keine Adressen ausgewaehlt.\n\nIm Layer 'Adressen' (Schritt 2 oder 3) mit den "
                                    "QGIS-Auswahlwerkzeugen (Rechteck, Freihand, Polygon) markieren, dann diesen Knopf.")
            return
        ct = QgsCoordinateTransform(lyr_p.crs(), QgsCoordinateReferenceSystem("EPSG:25832"), QgsProject.instance())
        pts = []
        for f in lyr_p.selectedFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(ct)
            pts.append(g)
        if not pts:
            QMessageBox.information(self, "Vorgabe-Gebiet aus Auswahl", "Die ausgewaehlten Objekte haben keine Geometrie.")
            return
        name, ok = QInputDialog.getText(self, "Vorgabe-Gebiet aus Auswahl", "{} Adressen aus '{}'.\nName des Gebiets (leer = Nummer aus dem Nummernkreis):"
                                        .format(len(pts), lyr_p.name()))
        if not ok:
            return
        try:
            poly = self.huelle_um_punkte(pts, 10.0)
            lyr = self._vorgabe_layer(anlegen=True)
            self._zaehler_anhaengen(lyr)
            war_offen = lyr.isEditable()
            if not war_offen:
                lyr.startEditing()
            f = QgsFeature(lyr.fields())
            f.setGeometry(poly)
            if lyr.fields().indexOf("name") >= 0:
                f["name"] = name.strip() or None
            if lyr.fields().indexOf("bemerkung") >= 0:
                f["bemerkung"] = "aus Auswahl: {} Adressen ({})".format(len(pts), lyr_p.name())[:200]
            if not lyr.addFeature(f):
                raise RuntimeError("Polygon konnte nicht in 'Vorgabe-Gebiete' geschrieben werden")
            if not war_offen and not lyr.commitChanges():
                raise RuntimeError("; ".join(lyr.commitErrors())[:300])
            lyr.triggerRepaint()
            self._grenzen_layer_fuellen()
            i = self.l_vorgabe.findData(lyr.id())
            if i >= 0:
                self.l_vorgabe.setCurrentIndex(i)
            self._alle_zaehlen(lyr, still=True)
            if self.iface is not None:
                self.iface.setActiveLayer(lyr_p)      # aktiver Layer bleibt (Markus 12.10.)
                try:
                    self.iface.mapCanvas().flashGeometries([poly], QgsCoordinateReferenceSystem("EPSG:25832"), QColor("#1A1A1A"), QColor(26, 26, 26, 0), 3, 600)
                except Exception:
                    pass
            self._log("Vorgabe-Gebiet '{}' aus {} ausgewaehlten Adressen angelegt ({:.0f} m2, Huelle + 10 m). Zaehler zeigt, wie viele Adressen "
                      "wirklich darin liegen - weicht die Zahl ab, Polygon im Layer 'Vorgabe-Gebiete' nachziehen.".format(name.strip() or "(Nummer)", len(pts), poly.area()))
        except Exception as e:
            self._log("Vorgabe aus Auswahl: {!r}".format(e))
            QMessageBox.critical(self, "Vorgabe-Gebiet aus Auswahl", "{!r}".format(e)[:500])

    def _gebiete_zeichnen(self):
        """Layer 'Vorgabe-Gebiete' anlegen (Arbeitsspeicher) oder wieder aufnehmen, Bearbeitung an, Zeichenwerkzeug aktiv (Markus 17.09.2026)."""
        lyr = self._vorgabe_layer(anlegen=True)
        self._zaehler_anhaengen(lyr)          # Felder anlegen, bevor die Bearbeitung startet
        if self.iface is not None:
            self.iface.setActiveLayer(lyr)
        if not lyr.isEditable():
            lyr.startEditing()
        self._alle_zaehlen(lyr, still=True)   # Stand sofort in der Zeile zeigen
        try:
            self.iface.actionAddFeature().trigger()
        except Exception:
            pass
        self._grenzen_layer_fuellen()
        i = self.l_vorgabe.findData(lyr.id())
        if i >= 0:
            self.l_vorgabe.setCurrentIndex(i)
        self._log("Zeichnen: Polygon ziehen, Rechtsklick schliesst, im Formular 'name' eintragen (leer = Nummer aus dem Nummernkreis). "
                  "Sobald ein Polygon geschlossen oder geaendert ist, stehen Adressen und WE darin am Polygon und unten in der Zeile. "
                  "Danach Bearbeitung speichern und Schneiden - die Automatik arbeitet dann nur ausserhalb der Vorgaben.")

    # --- Live-Zaehler beim Zeichnen (Markus 22.09.2026: "wenn ich in Tool 3 Gebiete zeichne, brauche ich eine Live-View, wie viele Adressen
    #     ich ins Polygon zeichne") ----------------------------------------------------------------------------------------------------
    def _zaehl_adressen(self):
        """Adresspunkte (shapely) mit WE fuer den Zaehler: aus der gewaehlten Adresspruefung (Schritt 2), sonst aus dem geladenen Schnitt."""
        if not self._lebt():
            return None
        try:
            pfad = self.f_adr.text().strip() if hasattr(self, "f_adr") else ""
        except Exception:
            return None
        if not pfad and self.ergebnis:
            pfad = self.ergebnis.get("gpkg", "")
        if not pfad or not os.path.exists(pfad):
            return None
        if getattr(self, "_zaehl_cache", None) and self._zaehl_cache[0] == pfad:
            return self._zaehl_cache[1]
        try:
            import geopandas as gpd
            import pandas as pd
            from shapely.strtree import STRtree
            layer = "adressen"
            try:
                import pyogrio
                namen = set(pyogrio.list_layers(pfad)[:, 0])
                layer = "adressen" if "adressen" in namen else next(n for n in namen if n.lower().startswith("adress"))
            except Exception:
                pass
            a = gpd.read_file(pfad, layer=layer)
            if a.crs is not None and a.crs.to_epsg() != 25832:
                a = a.to_crs(25832)
            a = a[a.geometry.notna()]
            if "status" in a:
                a = a[a["status"].astype(str) != "ignorieren"]
            we = pd.to_numeric(a.get("we"), errors="coerce").fillna(0).astype(int) if "we" in a else pd.Series([0] * len(a), index=a.index)
            daten = {"punkte": list(a.geometry), "we": we.tolist(), "tree": STRtree(list(a.geometry)), "quelle": os.path.basename(pfad)}
            self._zaehl_cache = (pfad, daten)
            return daten
        except Exception as e:
            self._log("Zaehler: Adressen nicht lesbar ({!r})".format(e))
            return None

    ZAEHL_FELDER = ("adressen", "we")

    def _lebt(self):
        """False, wenn der Dialog (die Seite) schon zerstoert ist - die Signale am Layer ueberleben ihn und wuerden sonst Python-Fehler
        werfen (Markus 22.09.2026: 6 Fehlerberichte aus einer geschlossenen Seite)."""
        try:
            from qgis.PyQt import sip
            return not sip.isdeleted(self)
        except Exception:
            return True

    def _zaehl_melden(self, text):
        """Meldung in Protokoll und Zeile, ohne je eine Ausnahme nach aussen zu lassen."""
        try:
            if not self._lebt():
                return
            self._log(text)
        except Exception:
            try:
                from qgis.core import QgsMessageLog, Qgis
                QgsMessageLog.logMessage(str(text), "Fiberation Werkzeugkasten", Qgis.Info)
            except Exception:
                pass

    def _zaehl_layer(self):
        """Polygonlayer fuer den Zaehler: die Auswahl im Kombifeld 'Vorgabe-Gebiete', sonst der Layer 'Vorgabe-Gebiete' im Projekt."""
        from qgis.core import QgsWkbTypes
        lid = self.l_vorgabe.currentData() if hasattr(self, "l_vorgabe") else ""
        lyr = QgsProject.instance().mapLayer(lid) if lid else None
        if lyr is None:
            for l in QgsProject.instance().mapLayers().values():
                if isinstance(l, QgsVectorLayer) and layerbaum.ohne_nummer(l.name()) == "Vorgabe-Gebiete":
                    lyr = l
                    break
        if isinstance(lyr, QgsVectorLayer) and lyr.isValid() and lyr.geometryType() == QgsWkbTypes.PolygonGeometry:
            return lyr
        return None

    def _zaehler_anhaengen(self, lyr=None):
        """Felder adressen/we anlegen (nur AUSSERHALB der Bearbeitung, sonst sieht der Bearbeitungspuffer sie nicht) und die Signale
        einmal je Layer verbinden. Gezaehlt wird verzoegert (QTimer): das Zeichenwerkzeug fuegt das Polygon innerhalb eines
        Bearbeitungsbefehls ein, Attribute lassen sich erst danach sicher setzen. -> Layer oder None"""
        if not self._lebt():
            return None
        try:
            lyr = lyr or self._zaehl_layer()
            if lyr is None:
                return None
            fehlt = [f for f in self.ZAEHL_FELDER if lyr.fields().indexOf(f) < 0]
            if fehlt:
                from qgis.PyQt.QtCore import QVariant
                from qgis.core import QgsField
                felder = [QgsField(f, QVariant.Int) for f in fehlt]
                if lyr.isEditable():
                    for feld in felder:          # im Bearbeitungspuffer anlegen - die Bearbeitung des Planers bleibt unangetastet
                        lyr.addAttribute(feld)
                else:
                    lyr.dataProvider().addAttributes(felder)
                lyr.updateFields()
                self._zaehl_melden("Zaehler: Felder {} im Layer '{}' angelegt.".format(", ".join(fehlt), lyr.name()))
            verbunden = getattr(self, "_zaehl_verbunden", None)
            if verbunden is None:
                verbunden = self._zaehl_verbunden = set()
            if lyr.id() not in verbunden:
                from qgis.PyQt.QtCore import QTimer
                verbunden.add(lyr.id())
                lyr.featureAdded.connect(lambda fid, l=lyr: QTimer.singleShot(0, lambda: self._vorgabe_zaehlen(l, fid)))
                lyr.geometryChanged.connect(lambda fid, geom, l=lyr: QTimer.singleShot(0, lambda: self._vorgabe_zaehlen(l, fid)))
                lyr.featuresDeleted.connect(lambda *_, l=lyr: QTimer.singleShot(0, lambda: self._zaehler_summe(l)))
                lyr.afterCommitChanges.connect(lambda l=lyr: QTimer.singleShot(0, lambda: self._alle_zaehlen(l, still=True)))
                self._zaehl_melden("Zaehler haengt am Layer '{}' - jedes geschlossene oder geaenderte Polygon wird gezaehlt.".format(lyr.name()))
            return lyr
        except Exception as e:
            self._zaehl_melden("Zaehler nicht angehaengt: {!r}".format(e))
            return None

    def _zaehlen_schreiben(self, lyr, f, daten):
        """Adressen und WE in einem Polygon zaehlen und in die Felder schreiben (im Bearbeitungspuffer oder direkt). -> (n, we) oder None"""
        from shapely import wkb
        g = f.geometry()
        if g is None or g.isEmpty():
            return None
        if lyr.crs().authid() != "EPSG:25832":
            from qgis.core import QgsCoordinateTransform
            g = QgsGeometry(g)
            g.transform(QgsCoordinateTransform(lyr.crs(), QgsCoordinateReferenceSystem("EPSG:25832"), QgsProject.instance()))
        poly = wkb.loads(bytes(g.asWkb()))
        # shapely 2.0: STRtree.query prueft predicate(Eingabegeometrie, Baumgeometrie) - fuer Punkte IM Polygon also "contains"
        drin = [int(i) for i in daten["tree"].query(poly, predicate="contains")]
        n, we = len(drin), int(sum(daten["we"][i] for i in drin))
        ia, iw = lyr.fields().indexOf("adressen"), lyr.fields().indexOf("we")
        if ia >= 0 and iw >= 0:
            if lyr.isEditable():
                lyr.changeAttributeValue(f.id(), ia, n)
                lyr.changeAttributeValue(f.id(), iw, we)
            else:
                lyr.dataProvider().changeAttributeValues({f.id(): {ia: n, iw: we}})
        lyr.triggerRepaint()
        return n, we

    def _vorgabe_zaehlen(self, lyr, fid):
        if not self._lebt():
            return
        try:
            daten = self._zaehl_adressen()
        except Exception as e:
            self._zaehl_melden("Zaehler: Adressen nicht lesbar ({!r})".format(e))
            return
        if daten is None:
            self._zaehl_zeile("Zaehler: keine Adressen - Adresspruefung oben waehlen.")
            self._zaehl_melden("Zaehler: keine Adressen - Adresspruefung (Schritt 2) im Feld oben waehlen.")
            return
        try:
            f = lyr.getFeature(fid)
            erg = self._zaehlen_schreiben(lyr, f, daten)
            if erg is None:
                return
            n, we = erg
            name = f["name"] if lyr.fields().indexOf("name") >= 0 else ""
            name = "" if name in (None, "NULL") else str(name).strip()
            self._zaehl_melden("Polygon {}: {} Adressen, {} WE (aus {})".format(name or fid, n, we, daten["quelle"]))
            self._zaehler_summe(lyr, zuletzt=(name or "Polygon {}".format(fid), n, we))
        except Exception as e:
            self._zaehl_melden("Zaehler: {!r}".format(e))

    def _zaehl_zeile(self, text):
        try:
            if self._lebt() and hasattr(self, "lab_zaehler"):
                self.lab_zaehler.setText(text)
        except Exception:
            pass

    def _alle_zaehlen(self, lyr=None, still=False):
        """Knopf 'Adressen zaehlen': alle Polygone des Vorgabe-Layers zaehlen - auch ohne den Knopf 'Zeichnen' und nach dem Speichern."""
        if not self._lebt():
            return
        try:
            lyr = self._zaehler_anhaengen(lyr if isinstance(lyr, QgsVectorLayer) else None)
            if lyr is None:
                self._zaehl_zeile("Zaehler: kein Polygonlayer 'Vorgabe-Gebiete' - erst 'Zeichnen' druecken oder einen Layer waehlen.")
                if not still:
                    self._zaehl_melden("Zaehler: kein Polygonlayer gewaehlt. 'Zeichnen' legt den Layer 'Vorgabe-Gebiete' an; ein eigener Polygonlayer geht auch (Feld 'Vorgabe-Gebiete').")
                return
            daten = self._zaehl_adressen()
            if daten is None:
                self._zaehl_zeile("Zaehler: keine Adressen - Adresspruefung oben waehlen.")
                if not still:
                    self._zaehl_melden("Zaehler: keine Adressen - Adresspruefung (Schritt 2) im Feld oben waehlen.")
                return
            n = 0
            for f in lyr.getFeatures():
                if self._zaehlen_schreiben(lyr, f, daten) is not None:
                    n += 1
            self._zaehler_summe(lyr)
            if not still:
                self._zaehl_melden("Zaehler: {} Polygone in '{}' gezaehlt (Adressen aus {}).".format(n, lyr.name(), daten["quelle"]))
        except Exception as e:
            self._zaehl_melden("Zaehler: {!r}".format(e))

    def _zaehler_summe(self, lyr, zuletzt=None):
        if not self._lebt():
            return
        try:
            ia, iw = lyr.fields().indexOf("adressen"), lyr.fields().indexOf("we")
            n_p, n_a, n_w = 0, 0, 0
            for f in lyr.getFeatures():
                n_p += 1
                a, w = f[ia] if ia >= 0 else None, f[iw] if iw >= 0 else None
                n_a += int(a) if a not in (None, "NULL") and str(a) != "NULL" else 0
                n_w += int(w) if w not in (None, "NULL") and str(w) != "NULL" else 0
            text = "Vorgabe-Gebiete: {} Polygone, {} Adressen, {} WE".format(n_p, n_a, n_w)
            if zuletzt:
                text = "Zuletzt {}: {} Adressen, {} WE  |  ".format(*zuletzt) + text
            self._zaehl_zeile(text)
        except Exception:
            pass

    def _datei_fallen_gelassen(self, p):
        if not p.lower().endswith((".gpkg", ".csv")):
            return False
        if "nvt_gebiete" in os.path.basename(p).lower():
            self._ergebnis_setzen(p)
        else:
            self.f_adr.setText(p)
        return True

    def _grenzen(self):
        """Nur die Felder, die der Planer gegenueber der myDMS-Vorgabe geaendert hat (sonst gilt der Regelsatz des Ausbautreibers)."""
        ist = {"max_apl": self.s_weich.value(), "max_apl_hart": self.s_hart.value(), "max_we": self.s_we.value(),
               "max_dist_m": self.s_vzk.value(), "ziel_apl": self.s_ziel.value()}
        vor = getattr(self, "_vorgabe", {})
        return {k: v for k, v in ist.items() if vor.get(k) != v}

    def _projekt_gpkg(self):
        return dateiwahl.projekt_gpkg()

    # --- Aktionen ----------------------------------------------------------------------------------------------------------------------
    def _start(self):
        from . import kern
        self.log.clear()
        self.k_start.setEnabled(False)
        from ..cluster import osm
        osm.lauf_beginnen(status=lambda txt: self._fortschritt(self.balken.value(), txt))
        self.k_abbruch.setEnabled(True)
        try:
            quelle = self.f_adr.text()
            if not quelle or not os.path.exists(quelle):
                self._log("Adresspruefung nicht gefunden - erst Werkzeug 2 laufen lassen oder Datei waehlen.")
                self.k_log.setChecked(True)
                return
            dateiwahl.merken("adresspruefung", quelle)
            out_dir = dateiwahl.ausgabeordner(self.out.text())
            art, pfad = "osm", None
            r = kern.schneiden(quelle, netz_art=art, netz_pfad=pfad, regelsatz=self.regel.currentData() or None, out_dir=out_dir,
                               grenzen=self._grenzen(), varianten_vergleichen=False, log=self._log, fortschritt=self._fortschritt,
                               zwangsgrenzen=self._zwangsgrenzen(), verfahren="netz",
                               praefix=self.nk_praefix.text().strip() or None, start=self.nk_von.value(), vorgaben=self._vorgaben())
            dateiwahl.merken("nvt_gebiete", r["gpkg"])
            self._fertig(r, "Gebiete geschnitten")
            self._nummernkreis_pruefen(r["gpkg"])
        except osm.Abgebrochen as e:
            self._fortschritt(0, "Abgebrochen")
            self._log("Abgebrochen: {}".format(e))
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "NVT-Gebiete - Fehler", "Der Schnitt ist abgebrochen:\n{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])
        finally:
            self.k_start.setEnabled(True)
            self.k_abbruch.setEnabled(False)
            osm.lauf_beenden()

    def _nachrechnen(self):
        from . import kern
        if not self.ergebnis:
            return
        self.k_nach.setEnabled(False)
        try:
            self._log("Nachrechnen aus {} (Stand der Datei, Layer vorher speichern) ...".format(os.path.basename(self.ergebnis["gpkg"])))
            r = kern.nachrechnen(self.ergebnis["gpkg"], regelsatz=self.regel.currentData() or None, grenzen=self._grenzen(),
                                 log=self._log, fortschritt=self._fortschritt)
            self._gruppe_entfernen(self.ergebnis["gpkg"])
            self._fertig(r, "Gebiete nachgerechnet")
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "Nachrechnen - Fehler", "{!r}".format(e)[:600])
        finally:
            self.k_nach.setEnabled(True)

    def _ergebnis_setzen(self, gpkg):
        dateiwahl.merken("nvt_gebiete", gpkg)
        self.ergebnis = {"gpkg": gpkg, "bericht": os.path.splitext(gpkg)[0] + "_bericht.md"}
        self.k_nach.setEnabled(True)
        self.k_bericht.setEnabled(os.path.exists(self.ergebnis["bericht"]))
        self._layer_laden(gpkg)
        self._planer_freigeben()
        self._log("Ergebnis geladen: " + gpkg)

    def _fertig(self, r, titel):
        self.ergebnis = r
        self.k_nach.setEnabled(True)
        self.k_bericht.setEnabled(True)
        self._layer_laden(r["gpkg"])
        self._planer_freigeben()
        z = {"gruen": 0, "gelb": 0, "rot": 0}
        for g in r["gebiete"]:
            z[g["ampel"]] = z.get(g["ampel"], 0) + 1
        n = r["cfg"]["nvt"]
        QMessageBox.information(self, titel, "{} Gebiete fuer {} Adressen\n\ngruen {}   gelb {}   rot {}\nRegelsatz: {} ({} weich / {} hart)\n\n"
                                "Layer sind geladen. Zum Aendern: im Layer 'Adressen' die Spalte nvt setzen, speichern, dann 'Nachrechnen'.\n"
                                "Sitz ist ein Vorschlag auf dem Netz; den Standort im oeffentlichen Raum prueft Werkzeug 4."
                                .format(len(r["gebiete"]), len(r["adressen"]), z["gruen"], z["gelb"], z["rot"], n["name"], n["max_apl"],
                                        n.get("max_apl_hart", n["max_apl"])))

    def _bericht(self):
        if self.ergebnis and os.path.exists(self.ergebnis["bericht"]):
            import subprocess
            subprocess.Popen(["cmd", "/c", "start", "", self.ergebnis["bericht"]], shell=False)

    # --- Planer-Aenderungen ------------------------------------------------------------------------------------------------------------
    def _planer_freigeben(self):
        for w in (self.k_poly, self.ziel, self.k_versch, self.k_goo, self.k_ripple):
            w.setEnabled(True)
        self._ziele_fuellen()
        lyr = self._layer("NVT-Gebiete")
        if lyr is not None:
            try:
                lyr.selectionChanged.disconnect(self._gebiet_gewaehlt)
            except Exception:
                pass
            lyr.selectionChanged.connect(self._gebiet_gewaehlt)
        self._gebiet_gewaehlt()

    def _gebiet_gewaehlt(self, *_):
        """Genau ein Polygon gewaehlt: Name ins Feld, Umbenennen frei (Markus 17.09.2026)."""
        lyr = self._layer("NVT-Gebiete")
        namen = [str(f["name"]) for f in lyr.selectedFeatures()] if lyr is not None else []
        self.k_umb.setEnabled(len(namen) == 1)
        if len(namen) == 1:
            self.nb_name.setText(namen[0])
            self.nb_name.setPlaceholderText("")
        else:
            self.nb_name.setPlaceholderText("genau ein Polygon im Layer 'NVT-Gebiete' waehlen"
                                            if not namen else "{} Polygone gewaehlt - genau eines waehlen".format(len(namen)))

    def _umbenennen(self):
        from . import kern
        lyr = self._layer("NVT-Gebiete")
        if lyr is None or not self.ergebnis:
            return
        alt = [str(f["name"]) for f in lyr.selectedFeatures()]
        neu = self.nb_name.text().strip()
        if len(alt) != 1 or not neu:
            QMessageBox.information(self, "Umbenennen", "Genau ein Polygon im Layer 'NVT-Gebiete' waehlen und einen Namen eintragen.")
            return
        if alt[0] == neu:
            return
        try:
            self._speichern_falls_offen(lyr)
            erg = kern.umbenennen(self.ergebnis["gpkg"], {alt[0]: neu}, log=self._log)
            if not erg:
                QMessageBox.information(self, "Umbenennen", "Nichts geaendert.")
                return
            self._layer_laden(self.ergebnis["gpkg"])
            self._planer_freigeben()
            self._log("'{}' heisst jetzt '{}'. Werkzeuge 3 und 4 kennen den alten Namen - dort neu erzeugen.".format(alt[0], neu))
        except Exception as e:
            self._log("Umbenennen: {!r}".format(e))
            QMessageBox.critical(self, "Umbenennen", "{}".format(e)[:400])

    def _nummern_aufruecken(self):
        from . import kern
        if not self.ergebnis:
            return
        try:
            self._speichern_falls_offen(self._layer("NVT-Gebiete"))
            start = self.nk_von.value() if self.nk_praefix.text().strip() or self.nk_von.value() > 1 else None
            paare, luecken = kern.nummern_vorschlag(self.ergebnis["gpkg"], start=start, praefix=self.nk_praefix.text().strip() or None)
            if not paare:
                QMessageBox.information(self, "Nummern aufruecken", "Die Nummern sind lueckenlos - nichts zu tun.")
                return
            liste = "\n".join("{}  ->  {}".format(a, b) for a, b in sorted(paare.items(), key=lambda t: kern._natschluessel(t[0])))
            text = "{}Diese {} Gebiete werden umbenannt:\n\n{}\n\nUebernehmen?".format(
                "Luecke: {}\n\n".format(", ".join(luecken)) if luecken else "", len(paare), liste[:1500])
            if QMessageBox.question(self, "Nummern aufruecken", text, QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                self._log("Nummern aufruecken: vom Planer abgelehnt.")
                return
            kern.umbenennen(self.ergebnis["gpkg"], paare, log=self._log)
            self._layer_laden(self.ergebnis["gpkg"])
            self._planer_freigeben()
            QMessageBox.information(self, "Nummern aufruecken", "{} Gebiete umbenannt. Werkzeuge 3 und 4 kennen die alten Namen - "
                                                                "dort neu erzeugen.".format(len(paare)))
        except Exception as e:
            self._log("Nummern aufruecken: {!r}".format(e))
            QMessageBox.critical(self, "Nummern aufruecken", "{}".format(e)[:400])

    def _nummernkreis_pruefen(self, gpkg):
        """Nach dem Schneiden melden, wenn Namen ausserhalb des BVT-Blocks liegen."""
        from . import kern
        p = self.nk_praefix.text().strip()
        if not p and self.nk_von.value() == 1 and self.nk_bis.value() == 9999:
            return
        try:
            raus = kern.nummernkreis_pruefen(gpkg, p, self.nk_von.value(), self.nk_bis.value())
        except Exception:
            return
        if raus:
            self._log("Nummernkreis: " + "; ".join(raus[:8]))
            QMessageBox.warning(self, "Nummernkreis", "Ausserhalb des vorgegebenen Blocks:\n\n" + "\n".join(raus[:12]))

    def _weiter_zu_4(self):
        """Werkzeug 10 mit dem aktuellen Schnitt oeffnen."""
        try:
            from qgis.utils import plugins
            plugins["fiberation_werkzeugkasten"].uebergabe(self.ergebnis["gpkg"] if self.ergebnis else None)
        except Exception as e:
            self._log("Werkzeug 10 nicht geoeffnet: {!r}".format(e))

    def _ziele_fuellen(self):
        aktuell = self.ziel.currentText()
        self.ziel.blockSignals(True)
        self.ziel.clear()
        lyr = self._layer("NVT-Gebiete")
        if lyr is not None:
            for n in sorted({str(f["name"]) for f in lyr.getFeatures()}):
                self.ziel.addItem(n)
        self.ziel.setCurrentIndex(-1)
        self.ziel.setEditText(aktuell if aktuell and self.ziel.findText(aktuell) < 0 else "")
        self.ziel.blockSignals(False)

    def _layer(self, titel):
        """Layer mit diesem Titel aus der Layergruppe des aktuellen Ergebnisses, sonst None."""
        if not self.ergebnis:
            return None
        # im Baum heissen die Layer "3 NVT-Gebiete", "3 Adressen" (Schrittnummer vorn) - Vergleich ohne Nummer
        return layerbaum.layer_in_gruppe(self._gruppenname(self.ergebnis["gpkg"]), titel)

    def _speichern_falls_offen(self, lyr):
        """Offene Bearbeitung des Layers in die Datei schreiben, sonst rechnet der Kern mit dem alten Stand."""
        if lyr is not None and lyr.isEditable():
            if lyr.isModified():
                if not lyr.commitChanges():
                    raise RuntimeError("Layer '{}' konnte nicht gespeichert werden: {}".format(lyr.name(), "; ".join(lyr.commitErrors())[:300]))
                self._log("Layer '{}' gespeichert.".format(lyr.name()))
            else:
                lyr.rollBack()

    def _aus_polygonen(self):
        from . import kern
        if not self.ergebnis:
            return
        self.k_poly.setEnabled(False)
        try:
            lyr = self._layer("NVT-Gebiete")
            if lyr is None:
                self._log("Layer 'NVT-Gebiete' nicht gefunden - Ergebnis erneut laden.")
                return
            self._speichern_falls_offen(lyr)
            self._speichern_falls_offen(self._layer("Adressen"))
            gpkg = self.ergebnis["gpkg"]
            self._fortschritt(2, "Polygone lesen")
            z = kern.zuordnen_aus_polygonen(gpkg, log=self._log)
            if z["geaendert"] == 0 and not z["entfallen"]:
                self._fortschritt(100, "Keine Aenderung")
                self._log("Keine Adresse hat das Gebiet gewechselt - Polygone unveraendert gelassen?")
                QMessageBox.information(self, "Gebiete aus Polygonen", "Keine Adresse hat das Gebiet gewechselt.\n\nPolygone im Layer "
                                        "'NVT-Gebiete' bearbeiten (verschmelzen, Knoten schieben, loeschen) und erneut uebernehmen.")
                return
            r = kern.nachrechnen(gpkg, regelsatz=self.regel.currentData() or None, grenzen=self._grenzen(), log=self._log,
                                 fortschritt=self._fortschritt)
            self._gruppe_entfernen(gpkg)
            self._fertig(r, "Gebiete aus Polygonen uebernommen ({} Adressen umgehaengt{})".format(
                z["geaendert"], ", {} Gebiete entfallen".format(len(z["entfallen"])) if z["entfallen"] else ""))
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "Gebiete aus Polygonen - Fehler", "{!r}".format(e)[:600])
        finally:
            self.k_poly.setEnabled(True)

    def _auswahl_verschieben(self):
        from . import kern
        if not self.ergebnis:
            return
        self.k_versch.setEnabled(False)
        try:
            lyr = self._layer("Adressen")
            if lyr is None:
                self._log("Layer 'Adressen' nicht gefunden - Ergebnis erneut laden.")
                return
            ids = [str(f["id"]) for f in lyr.selectedFeatures()]
            if not ids:
                QMessageBox.information(self, "Auswahl verschieben", "Keine Adressen ausgewaehlt.\n\nIm Layer 'Adressen' mit den "
                                        "QGIS-Auswahlwerkzeugen (Rechteck, Freihand, Polygon) markieren, dann Zielgebiet waehlen.")
                return
            ziel = self.ziel.currentText().strip()
            if not ziel:
                QMessageBox.information(self, "Auswahl verschieben", "Zielgebiet waehlen oder einen neuen Namen eintippen.")
                return
            self._speichern_falls_offen(lyr)
            self._speichern_falls_offen(self._layer("NVT-Gebiete"))
            gpkg = self.ergebnis["gpkg"]
            n = kern.zuordnen_auswahl(gpkg, ids, ziel, log=self._log)
            if n == 0:
                self._log("Alle ausgewaehlten Adressen lagen schon in '{}'.".format(ziel))
                return
            r = kern.nachrechnen(gpkg, regelsatz=self.regel.currentData() or None, grenzen=self._grenzen(), log=self._log,
                                 fortschritt=self._fortschritt)
            self._gruppe_entfernen(gpkg)
            self._fertig(r, "{} Adressen nach '{}' verschoben".format(n, ziel))
        except Exception as e:
            self._fortschritt(0, "Fehler")
            self.k_log.setChecked(True)
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1500:])
            QMessageBox.critical(self, "Auswahl verschieben - Fehler", "{!r}".format(e)[:600])
        finally:
            self.k_versch.setEnabled(True)

    # --- Layer -------------------------------------------------------------------------------------------------------------------------
    def _gruppenname(self, gpkg):
        return layerbaum.gruppenname("cluster", "NVT-Gebiete {}".format(os.path.basename(gpkg).replace("nvt_gebiete_", "").replace(".gpkg", "")))

    def _aktiv_merken(self):
        """Namen (ohne Schrittnummer) des aktiven Layers merken, bevor die Gruppe neu geladen wird (Markus 12.10.: nach dem Verschieben
        war der Layer 'Adressen' abgewaehlt, weil die Layer neu angelegt werden)."""
        try:
            aktiv = self.iface.activeLayer() if self.iface is not None else None
            # Pruefer B1 12.10.: nur merken, solange nichts gemerkt ist - nach dem Leeren der Gruppe macht Qt den Nachbarknoten aktiv
            if aktiv is not None and not getattr(self, "_aktiv_name", None):
                self._aktiv_name = layerbaum.ohne_nummer(aktiv.name())
        except Exception:
            pass

    def _aktiv_wiederherstellen(self, gruppe):
        name = getattr(self, "_aktiv_name", None)
        if not name or self.iface is None:
            return
        self._aktiv_name = None
        for kn in gruppe.findLayers():
            l = kn.layer()
            if l is not None and layerbaum.ohne_nummer(l.name()) == name:
                self.iface.setActiveLayer(l)
                return

    def _gruppe_entfernen(self, gpkg):
        self._aktiv_merken()
        layerbaum.leeren(self._gruppenname(gpkg))

    def _layer_laden(self, gpkg):
        self._aktiv_merken()
        gruppe = layerbaum.gruppe("cluster", "NVT-Gebiete {}".format(os.path.basename(gpkg).replace("nvt_gebiete_", "").replace(".gpkg", "")))
        # eine Farbe je NVT, in Gebiet und Adressen gleich (wie die Plan[Goo]-Versorgungsbereiche)
        farbe_von = {}
        mit_vorgabe = False
        probe = QgsVectorLayer("{}|layername=nvt_gebiete".format(gpkg), "p", "ogr")
        if probe.isValid():
            for i, n_ in enumerate(sorted(str(f["name"]) for f in probe.getFeatures())):
                farbe_von[n_] = PALETTE[i % len(PALETTE)]
            mit_vorgabe = probe.fields().indexOf("vorgabe") >= 0
        # Markus 22.09.2026: "in dem Tool brauche ich keine NVT als Ausgabe, nur die Polygone" - der Sitzvorschlag bleibt im GeoPackage
        # (Schritt 4 prueft ihn, Schritt 5 und 6 brauchen ihn), wird hier aber nicht mehr als Layer geladen.
        ebenen = [("adressen", "Adressen"), ("strassenabschnitte", "Strassenabschnitte"),
                  ("nvt_gebiete", "NVT-Gebiete"), ("nvt_gebiete", "Ampel (Grenzen)"), ("netz", "Netz")]
        if mit_vorgabe:
            ebenen.insert(3, ("nvt_gebiete", "Vorgabe (gesperrt)"))
        for lname, titel in ebenen:
            lyr = QgsVectorLayer("{}|layername={}".format(gpkg, lname), titel, "ogr")
            if not lyr.isValid():
                continue
            lyr.setCrs(QgsCoordinateReferenceSystem("EPSG:25832"))
            if lname == "nvt_gebiete" and titel.startswith("NVT"):
                # Markus 16.09.: Fuellung zurueckgenommen (12 %), Grenze kraeftiger - die Karte darunter bleibt lesbar
                kats = [QgsRendererCategory(n_, QgsFillSymbol.createSimple({"color": ci.rgba(farbe, 31), "outline_color": farbe, "outline_width": "0.9"}), n_)
                        for n_, farbe in farbe_von.items()]
                lyr.setRenderer(QgsCategorizedSymbolRenderer("name", kats))
                # Kennzahlen des Schnitts direkt am Polygon: Adressen = SNR-Einfuehrungen in die Bodenplatte, WE, PON, Hk-Fasern, Vzk-Weg
                # "Ist von Grenze": Adressen von weich/hart, SNR von Bodenplatte, WE, PON, Hk-Fasern, Kassetten, Vzk-Weg
                ci.label_kasten(lyr, nvt_label_ausdruck(farbe_von, mit_vorgabe), groesse=7.5, rahmen=ci.farb_ausdruck("name", farbe_von),
                                min_massstab=5000, polygon=True)
            elif lname == "nvt_gebiete" and titel.startswith("Vorgabe"):
                # Vorgabe-Gebiete des Planers (Markus 17.09.): dicker schwarzer Strich, ohne Fuellung - gesperrt fuer die Automatik
                lyr.setSubsetString("\"vorgabe\" = 1")
                lyr.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({"color": "255,255,255,0", "outline_color": "#1A1A1A",
                                                                                     "outline_width": "1.8", "outline_style": "dash"})))
            elif lname == "nvt_gebiete":
                # Ampel nur als gestrichelte Grenze fuer gelb und rot, ohne Fuellung; gruen wird nicht gezeichnet
                kats = []
                for wert, farbe in FARBEN.items():
                    if wert == "gruen":
                        continue
                    sym = QgsFillSymbol.createSimple({"color": "255,255,255,0", "outline_color": farbe, "outline_width": "1.6", "outline_style": "dash"})
                    kats.append(QgsRendererCategory(wert, sym, wert))
                lyr.setRenderer(QgsCategorizedSymbolRenderer("ampel", kats))
                self._label(lyr, "hinweis", 7, False)
            elif lname == "adressen":
                kats = [QgsRendererCategory(n_, QgsMarkerSymbol.createSimple({"name": "circle", "color": farbe, "outline_color": "#FFFFFF",
                                                                             "outline_width": "0.2", "size": "2.4"}), n_)
                        for n_, farbe in farbe_von.items()]
                lyr.setRenderer(QgsCategorizedSymbolRenderer("nvt", kats))
                # kein Adresslabel (Markus 16.09.): die Adresse steht in Werkzeug 2, hier zaehlt die Gebietsfarbe
            elif lname == "nvt_sitz":
                # NVT-Symbol wie in Plan[Goo] (Kreis mit Quadrat), in Fiberation-Orange = Vorschlag, abgegrenzt von Rot (Planung)
                lyr.setRenderer(QgsSingleSymbolRenderer(ci.nvt_symbol(ci.ORANGE, 5.0)))
                self._label(lyr, "name", 9, False)
            elif lname == "strassenabschnitte":
                # Bausteine des Schnitts in Gebietsfarbe; geteilte Abschnitte (Adressen in zwei Gebieten) schwarz gestrichelt,
                # Sperren/Querungen (Hauptstrasse, Bahn, Gewaesser, Zwangsgrenze) dunkelgrau gepunktet
                from qgis.core import QgsRuleBasedRenderer
                wurzel_r = QgsRuleBasedRenderer.Rule(None)
                for n_, farbe in farbe_von.items():
                    wurzel_r.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": farbe, "width": "1.1"}), 0, 0,
                                                                   '"nvt" = \'{}\' AND "gemischt" = 0'.format(n_), n_))
                wurzel_r.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": "#1A1A1A", "width": "1.3", "line_style": "dash"}),
                                                               0, 0, '"gemischt" = 1', "geteilt (Kapazitaet)"))
                wurzel_r.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": "#B0B0B0", "width": "0.5"}),
                                                               0, 0, 'coalesce("nvt", \'\') = \'\' AND "gemischt" = 0', "ohne Gebiet"))
                wurzel_r.appendChild(QgsRuleBasedRenderer.Rule(QgsLineSymbol.createSimple({"color": "#555555", "width": "2.2", "line_style": "dot"}),
                                                               0, 0, '"hauptstr" = 1 OR coalesce("querung", \'\') <> \'\' OR "sperre" = 1', "Sperre / Querung"))
                lyr.setRenderer(QgsRuleBasedRenderer(wurzel_r))
            elif lname == "netz":
                lyr.renderer().setSymbol(QgsLineSymbol.createSimple({"color": "#9E9E9E", "width": "0.35"}))
            layerbaum.einhaengen(gruppe, lyr, "cluster", sichtbar=not (lname == "netz" or titel.startswith("Ampel") or lname == "strassenabschnitte"))
        self._aktiv_wiederherstellen(gruppe)
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

