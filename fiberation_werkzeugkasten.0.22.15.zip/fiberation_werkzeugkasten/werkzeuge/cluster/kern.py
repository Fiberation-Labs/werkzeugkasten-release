# -*- coding: utf-8 -*-
"""Werkzeug 3 - Kern ohne Qt: Adressen zu NVT-Gebieten schneiden, Kennzahlen gegen ZTV-Grenzen, Gebiete nachrechnen.

Ablauf `schneiden`: Adressen laden (Werkzeug-2-GeoPackage, Bedarfsliste oder Plan[Goo]-APL) -> Netz (Plan[Goo]-Trassen oder
OSM-Strassen) -> Adressen anbinden -> kapazitiertes Clustering auf Graphkosten (k-1/k/k+1, Regret-Greedy, Medoid; siehe
cluster.py) -> Kennzahlen je Gebiet -> Polygone (Voronoi je Adresse, je Gebiet vereinigt, konkave Huelle) -> GeoPackage + Bericht.
`nachrechnen`: der Planer hat im Adresslayer die Spalte nvt geaendert -> Kennzahlen und Polygone neu, Sitz bleibt.

Grenzen aus config.REGELSAETZE (Eigen 60 weich / 74 hart; MBfD 51 / 57 ANNAHME). Ampel je Gebiet:
  rot   = ueber harter Adressgrenze, ueber SNR-, PON- oder Kassettengrenze, Vzk-Weg ueber max_dist_m
  gelb  = ueber weicher Adressgrenze, ueber WE-Grenze, unter min_apl (klein)
  gruen = alles eingehalten
"""
import math
import os
import pickle
import re
from datetime import datetime

from . import config

CRS = 25832


# --- Adressen --------------------------------------------------------------------------------------------------------------------------
def adressen_laden(quelle, log=print):
    """quelle: Pfad einer Adresspruefung (GeoPackage, Layer adressen), einer Telekom-Bedarfsliste (CSV) oder 'plangoo'.
    -> GeoDataFrame EPSG:25832 mit id, strasse, hnr, we, ge, anschluesse, snr, asb, nvt_alt, geometry"""
    import geopandas as gpd
    import pandas as pd
    from ..adressen import kern as akern, regeln
    q = str(quelle)
    if q.lower() == "plangoo":
        a = akern.lesen_plangoo(log)
        akern.bedarf(a, str(a["sponsor"].iat[0]) if len(a) else "", log=lambda s: None) if "anschluesse" not in a else None
    elif akern.ist_plangoo_gpkg(q):
        a = akern.lesen_plangoo_gpkg(q, log)
        akern.bedarf(a, str(a["sponsor"].iat[0]) if len(a) else "", log=lambda s: None)
    elif q.lower().endswith(".gpkg"):
        a = gpd.read_file(q, layer="adressen")
        if a.crs is None or a.crs.to_epsg() != CRS:
            a = a.set_crs(CRS, allow_override=True) if a.crs is None else a.to_crs(CRS)
        if "status" in a:
            vorher = len(a)
            a = a[a["status"].astype(str) != "ignorieren"].copy()
            if len(a) < vorher:
                log("Adressen: {} mit status 'ignorieren' ausgelassen".format(vorher - len(a)))
    else:
        a = akern.lesen_bedarfsliste(q, log)
        a = a[~a["koord_fehlt"]].copy()
        akern.bedarf(a, "", log=lambda s: None)
    a = a[a.geometry.notna()].copy().reset_index(drop=True)
    ids = a["kls_id"].astype(str).str.strip() if "kls_id" in a else pd.Series([""] * len(a))
    ids = ids.where(~ids.isin(["", "0", "None", "nan"]), None)
    a["id"] = [i if i else "A{}".format(n) for n, i in enumerate(ids)]
    if a["id"].duplicated().any():
        a["id"] = ["{}_{}".format(i, n) if d else i for n, (i, d) in enumerate(zip(a["id"], a["id"].duplicated(keep="first")))]
    for c in ("we", "ge", "anschluesse", "snr", "p2p"):
        a[c] = [regeln._int(v) for v in a[c]] if c in a else 0
    if "anschluesse" not in a.columns or a["anschluesse"].sum() == 0:
        a["anschluesse"] = a["we"] + a["ge"]
    if a["snr"].sum() == 0:
        a["snr"] = 1
    a["we_kap"] = a["anschluesse"].clip(lower=1)      # Last fuer PON/Kassetten: FTTH-Anschluesse nach ZTV 21
    if "asb" not in a:
        a["asb"] = ""
    a["nvt_alt"] = a["nvt"] if "nvt" in a else (a["nvt_plangoo"] if "nvt_plangoo" in a else "")
    log("Adressen: {} mit Koordinate, {} Anschluesse, {} SNR".format(len(a), int(a["anschluesse"].sum()), int(a["snr"].sum())))
    return a


# --- Netz ------------------------------------------------------------------------------------------------------------------------------
def netz_laden(art, cfg, adr, log=print, pfad=None):
    """art: 'plangoo' (pfad = Projekt-GeoPackage) oder 'osm'. -> networkx-Graph (Kanten: length, cost, geometry ...)"""
    from . import graph, osm, plangoo_graph
    if art == "plangoo":
        if not pfad or not os.path.exists(pfad):
            raise ValueError("Plan[Goo]-GeoPackage nicht gefunden: {}".format(pfad))
        edges = plangoo_graph.load(pfad, CRS, cfg)
        edges = edges[~edges["hauszuf"]] if "hauszuf" in edges else edges
        G = graph.build_gds(edges, cfg)
        log("Netz Plan[Goo]: {} Trassen -> {} Kanten, {:.1f} km".format(len(edges), G.number_of_edges(),
                                                                          sum(d["length"] for _, _, d in G.edges(data=True)) / 1000.0))
    elif art == "osm":
        roads, obst = osm.load(cfg, adr)
        G = graph.build_osm(roads, obst, cfg)
        G, raus, meter = graph.beschneiden(G, adr, None, cfg["graph"]["beschnitt_m"])
        log("Netz OSM: {} Wege -> {} Kanten, {:.1f} km (beschnitten um {:.1f} km)".format(
            len(roads), G.number_of_edges(), sum(d["length"] for _, _, d in G.edges(data=True)) / 1000.0, meter / 1000.0))
    else:
        raise ValueError("Netzart unbekannt: " + str(art))
    return G


def anbinden(G, adr, cfg, log=print):
    """-> (addr_nodes Liste je Adresse, weg_m Liste, Anzahl nicht angebunden). Nicht angebundene Adressen werden aus adr entfernt."""
    from . import graph
    res = graph.attach_addresses(G, adr, cfg)
    info = res[0] if isinstance(res, tuple) else res
    nodes, wege, halten = [], [], []
    max_snap = float(cfg["osm"]["max_snap_m"])
    zu_weit = 0
    for i, aid in enumerate(adr["id"]):
        e = info.get(str(aid))
        if e is None or e[0] not in G:
            continue
        w = float(e[1]) if len(e) > 1 and e[1] is not None else 0.0
        if w > max_snap:          # Stich laenger als erlaubt: das Netz fehlt dort - nicht an einen fernen Knoten zwingen
            zu_weit += 1
            continue
        nodes.append(e[0])
        wege.append(w)
        halten.append(i)
    fehl = len(adr) - len(halten)
    if fehl:
        log("Anbindung: {} Adressen ohne Netzanschluss ({} mit Stich ueber {:.0f} m), werden nicht geschnitten - Netz dort pruefen".format(
            fehl, zu_weit, max_snap))
    adr.drop(index=[i for i in range(len(adr)) if i not in set(halten)], inplace=True)
    adr.reset_index(drop=True, inplace=True)
    adr["stich_m"] = [round(w, 1) for w in wege]
    adr["knoten"] = nodes      # Graphknoten der Adresse (A_<id> oder A_<id>_q bei Querung) - fuer das Nachrechnen
    return nodes


# --- Ausreisser ------------------------------------------------------------------------------------------------------------------------
def ausreisser_abtrennen(G, adr, labels, seeds, cfg, addr_nodes, log=print):
    """Adressen, deren Vzk-Weg zum zugewiesenen Sitz laenger als max_dist_m ist (abgesetzte Hoefe, Weiler), werden aus ihrem Gebiet
    geloest und untereinander zu eigenen kleinen Gebieten gruppiert (Weg zwischen ihnen <= max_dist_m). Sitz = Medoid der Gruppe.
    So bleibt kein Gebiet mit 4 km Vzk-Weg stehen; kleine Gruppen erscheinen gelb ('klein') und der Planer entscheidet
    (eigener NVT, XS-Gehaeuse oder Ausnahme). -> (labels, seeds, Anzahl Ausreisser)"""
    import networkx as nx
    from .cluster import _medoid
    maxd = float(cfg["nvt"]["max_dist_m"])
    labels = list(labels)
    weit = []
    for j in sorted(set(labels)):
        dist = nx.single_source_dijkstra_path_length(G, seeds[j], weight="length", cutoff=maxd)
        for i, (l, nd) in enumerate(zip(labels, addr_nodes)):
            if l == j and nd not in dist:
                weit.append(i)
    if not weit:
        return labels, seeds, 0
    adr["hinweis"] = adr["hinweis"] if "hinweis" in adr else ""
    offen = set(weit)
    neue = 0
    while offen:
        start = max(offen, key=lambda i: adr["stich_m"].iat[i])  # irgendein Ausreisser, der weiteste Stich zuerst
        dist = nx.single_source_dijkstra_path_length(G, addr_nodes[start], weight="length", cutoff=maxd)
        gruppe = [i for i in offen if addr_nodes[i] in dist]
        if start not in gruppe:
            gruppe.append(start)
        j = len(seeds)
        members = list(dict.fromkeys(addr_nodes[i] for i in gruppe))
        cutoff = maxd * max(v for row in cfg["kosten"]["eur_m_lv"].values() for v in row.values()) * 2.5
        seeds.append(_medoid(G, members, cutoff) if len(members) > 1 else members[0])
        for i in gruppe:
            labels[i] = j
            offen.discard(i)
            adr.loc[adr.index[i], "hinweis"] = "abgesetzt: Vzk-Weg zum naechsten Gebiet > {:.0f} m, eigenes Gebiet vorgeschlagen".format(maxd)
        neue += 1
    log("Ausreisser: {} Adressen ausserhalb {:.0f} m Vzk-Weg -> {} eigene Gebiete".format(len(weit), maxd, neue))
    return labels, seeds, len(weit)


# --- Kennzahlen ------------------------------------------------------------------------------------------------------------------------
def kennzahlen(G, adr, labels, seeds, cfg, addr_nodes):
    """-> Liste dict je Gebiet (name, apl, we, ge, anschluesse, pon, snr, kassetten, vzk_max_m, vzk_baum_m, sitz_xy, ampel, hinweis)"""
    import networkx as nx
    import numpy as np
    from .cluster import lasten
    n = cfg["nvt"]
    L, caps = lasten(adr["we_kap"].to_numpy(), cfg)
    if cfg["vzk"].get("snr_liste") is not None:
        L["snr"] = np.asarray(cfg["vzk"]["snr_liste"], dtype=float)
    out = []
    for j in sorted(set(int(x) for x in labels)):
        idx = np.where(np.asarray(labels) == j)[0]
        if not len(idx):
            continue
        seed = seeds[j]
        dist = nx.single_source_dijkstra_path_length(G, seed, weight="length")
        members = list(dict.fromkeys(addr_nodes[i] for i in idx))
        wege = [dist.get(m, float("inf")) for m in members]
        vzk_max = max(wege) if wege else 0.0
        # Baumlaenge (Kantenunion der kuerzesten Wege)
        try:
            _, paths = nx.single_source_dijkstra(G, seed, weight="length")
            kanten = set()
            for m in members:
                p = paths.get(m) or []
                for a_, b_ in zip(p[:-1], p[1:]):
                    kanten.add(frozenset((a_, b_)))
            baum = sum(G[a_][b_]["length"] for a_, b_ in (tuple(k) for k in kanten))
        except Exception:
            baum = 0.0
        d = {"cluster": j, "apl": int(len(idx)), "we": int(adr["we"].iloc[idx].sum()), "ge": int(adr["ge"].iloc[idx].sum()),
             "anschluesse": int(adr["anschluesse"].iloc[idx].sum()), "pon": float(L["pon"][idx].sum()),
             "snr": int(round(L["snr"][idx].sum())), "kassetten": float(L["kassetten"][idx].sum()),
             "vzk_max_m": round(vzk_max if math.isfinite(vzk_max) else 9999.0), "vzk_baum_m": round(baum),
             "sitz_xy": (G.nodes[seed]["x"], G.nodes[seed]["y"]), "seed": seed}
        gruende, stufe = [], "gruen"
        if d["apl"] > n.get("max_apl_hart", n["max_apl"]):
            stufe, gruende = "rot", gruende + ["{} Adressen > {} hart".format(d["apl"], n.get("max_apl_hart", n["max_apl"]))]
        elif d["apl"] > n["max_apl"]:
            stufe, gruende = "gelb", gruende + ["{} Adressen > {} weich".format(d["apl"], n["max_apl"])]
        if d["snr"] > caps["snr"]:
            stufe, gruende = "rot", gruende + ["{} SNR > {}".format(d["snr"], int(caps["snr"]))]
        if d["pon"] > caps["pon"]:
            stufe, gruende = "rot", gruende + ["{:.1f} PON-Fasern > {}".format(d["pon"], int(caps["pon"]))]
        if d["kassetten"] > caps["kassetten"]:
            stufe, gruende = "rot", gruende + ["{:.0f} Kassetten > {}".format(d["kassetten"], int(caps["kassetten"]))]
        if d["vzk_max_m"] > n["max_dist_m"]:
            stufe, gruende = "rot", gruende + ["Vzk-Weg {} m > {} m".format(d["vzk_max_m"], n["max_dist_m"])]
        if d["we"] > n["max_we"] and stufe != "rot":
            stufe, gruende = "gelb", gruende + ["{} WE > {} weich".format(d["we"], n["max_we"])]
        # myDMS-Erstausbau (warning) fuer Koppler und Kassetten (30.09.2026): gelb, wenn ueber der Warnschwelle von Plan[Goo]
        if n.get("pon_warn") and d["pon"] > n["pon_warn"] and stufe != "rot":
            stufe, gruende = "gelb", gruende + ["{:.1f} PON > {} Koppler Erstausbau".format(d["pon"], int(n["pon_warn"]))]
        if n.get("kassetten_warn") and d["kassetten"] > n["kassetten_warn"] and stufe != "rot":
            stufe, gruende = "gelb", gruende + ["{:.0f} Kassetten > {} Erstausbau".format(d["kassetten"], int(n["kassetten_warn"]))]
        if d["apl"] < n.get("min_apl", 0) and stufe == "gruen":
            stufe, gruende = "gelb", gruende + ["klein: {} Adressen < {}".format(d["apl"], n["min_apl"])]
        d["ampel"], d["hinweis"] = stufe, "; ".join(gruende)
        d["p2p"] = int(adr["p2p"].iloc[idx].fillna(0).sum()) if "p2p" in adr else 0
        d["hk_fasern"] = _hk_fasern(d["pon"], d["p2p"])
        d["hk_text"] = _hk_text(d["pon"], d["p2p"], d["hk_fasern"])
        d["sitz_xy"] = sitz_seitlich(G, seed, [(p.x, p.y) for p in adr.geometry.iloc[idx]])
        out.append(d)
    return out


def sitz_seitlich(G, knoten, adress_xy, abstand_m=2.5):
    """Sitzvorschlag vom Netzknoten (Strassenachse/Trasse) um abstand_m senkrecht zur Trasse versetzen, auf die Seite, auf der die
    meisten Adressen des Gebiets liegen. Nur ein plausibler Vorschlag; oeffentlicher Raum und Restgehweg prueft Werkzeug 4."""
    x0, y0 = G.nodes[knoten]["x"], G.nodes[knoten]["y"]
    nachbarn = [n for n in G.neighbors(knoten) if not str(n).startswith("A_")]
    if not nachbarn:
        return (x0, y0)
    # Richtung der Trasse am Knoten: laengste anliegende Kante
    best = max(nachbarn, key=lambda n: G[knoten][n].get("length", 0))
    dx, dy = G.nodes[best]["x"] - x0, G.nodes[best]["y"] - y0
    L = math.hypot(dx, dy)
    if L < 0.01:
        return (x0, y0)
    nx_, ny_ = -dy / L, dx / L
    seite = sum(1 if (ax - x0) * nx_ + (ay - y0) * ny_ >= 0 else -1 for ax, ay in adress_xy)
    s = 1.0 if seite >= 0 else -1.0
    return (x0 + s * nx_ * abstand_m, y0 + s * ny_ * abstand_m)


def _hk_fasern(pon, p2p=0):
    """Hk-Fasern je NVT nach ZTV TK-Netz 21 (April 2026) Kap. 8.6.2.3, S. 52:
       - je zugefuehrtem PON-Abschnitt 1 Faser (100 % FTTH-Beschaltung im Endausbau),
       - je weiterem Uebertragungsweg ausserhalb FTTH (P2P) 2 Fasern,
       - > 3 PON: plus 6 Fs allgemeine Netzreserve, Summe in 6er-Schritten aufgerundet (12, 18, 24, 30, 36), mindestens 12,
       - <= 3 PON: mindestens 6 Fs (Gf-NVt XS/Innen), max. 36 (72 bei GWG - hier nicht abgebildet)."""
    p = int(math.ceil(pon - 1e-9))
    bedarf = p + 2 * int(p2p or 0)
    if p <= 3:
        return int(max(6, 6 * math.ceil(bedarf / 6.0)))
    return int(min(36, max(12, 6 * math.ceil((bedarf + 6) / 6.0))))


def _hk_text(pon, p2p, fasern):
    """Kurze Rechnung fuer Label und Bericht, z. B. '4,3 PON + 2x1 P2P + 6 Res. = 12 Fs'."""
    p = int(math.ceil(pon - 1e-9))
    teile = ["{:.1f} PON".format(pon).replace(".", ",")]
    if p2p:
        teile.append("2x{} P2P".format(int(p2p)))
    teile.append("6 Res." if p > 3 else "min. 6")
    return "{} = {} Fs".format(" + ".join(teile), fasern)


def praefix_vorschlag(asb=""):
    """Namensstamm aus der ASB: '1' -> '1V'; ohne ASB 'NVT'."""
    a = re.sub(r"\D", "", str(asb or ""))
    return "{}V".format(a) if a else "NVT"


def namen_vergeben(gebiete, asb="", praefix=None, start=1):
    """Namen nach Lage West -> Ost: <Praefix><nn>, Vorgabe <ASB>V01. Praefix und Startnummer kommen aus dem Nummernkreis, den
    der Auftraggeber (BVT) vorgibt (Markus 17.09.2026). Gebiete mit name_fest (vom Planer benannte Vorgabe-Gebiete) behalten ihren
    Namen; ihre Nummern werden beim Durchzaehlen uebersprungen."""
    p = str(praefix).strip() if praefix else praefix_vorschlag(asb)
    belegt = set()
    for g in gebiete:
        if g.get("name_fest"):
            g["name"] = str(g["name_fest"]).strip()
            pp, z = _teile(g["name"])
            if pp == p and z is not None:
                belegt.add(z)
    n = int(start or 1)
    for g in sorted(gebiete, key=lambda d: (d["sitz_xy"][0], d["sitz_xy"][1])):
        if g.get("name_fest"):
            continue
        while n in belegt:
            n += 1
        g["name"] = "{}{:02d}".format(p, n)
        n += 1
    return gebiete


# --- Vorgabe-Gebiete des Planers (Markus 17.09.2026) --------------------------------------------------------------------------------------
def vorgaben_zuordnen(adr, vorgaben, log=print):
    """vorgaben: Liste dict(name, geometry) mit Polygonen (EPSG:25832), die der Planer vorab festgelegt hat. Jede Adresse in einem
    Polygon ist diesem fest zugeordnet (bei Ueberlappung das kleinste). -> (Vorgabe-Index je Adresse oder -1, Namen, Polygone)"""
    if not vorgaben:
        return [-1] * len(adr), [], []
    from shapely.strtree import STRtree
    polys, namen = [], []
    for v in vorgaben:
        g = v.get("geometry")
        if g is None or g.is_empty or g.geom_type not in ("Polygon", "MultiPolygon"):
            continue
        polys.append(g)
        namen.append(str(v.get("name") or "").strip())
    if not polys:
        return [-1] * len(adr), [], []
    tree = STRtree(polys)
    fest = []
    for p in adr.geometry:
        k = [int(j) for j in tree.query(p, predicate="within")] if p is not None else []
        fest.append(min(k, key=lambda j: polys[j].area) if k else -1)
    n_fest = sum(1 for x in fest if x >= 0)
    log("Vorgabe-Gebiete: {} Polygone, {} Adressen fest zugeordnet, {} frei fuer die Automatik".format(len(polys), n_fest, len(fest) - n_fest))
    return fest, namen, polys


def kanten_in_flaechen(G, polys):
    """Kanten, deren Mitte in einem der Polygone liegt (Netz der Vorgabe-Gebiete: fuer das automatische Wachsen gesperrt). -> Liste (u, v)"""
    if not polys:
        return []
    from shapely.geometry import LineString, Point
    from shapely.prepared import prep
    from shapely.ops import unary_union
    pg = prep(unary_union(polys))
    out = []
    for u, v, d in G.edges(data=True):
        g = d.get("geometry")
        if g is None:
            g = LineString([(G.nodes[u]["x"], G.nodes[u]["y"]), (G.nodes[v]["x"], G.nodes[v]["y"])])
        m = g.interpolate(0.5, normalized=True)
        if pg.contains(m):
            out.append((u, v))
    return out


# --- Namen des Planers: umbenennen und Nummern aufruecken (Markus 17.09.2026) -----------------------------------------------------------
NAME_LAYER = (("adressen", "nvt"), ("nvt_sitz", "name"), ("nvt_gebiete", "name"), ("strassenabschnitte", "nvt"))
# Werkzeug 4 und 4 halten die Namen in eigenen Dateien - beim Umbenennen ziehen sie mit (Markus 17.09.2026).
# Nur diese Layer und Spalten anfassen: 'name' heisst im Layer verkehrsflaechen der Strassenname und darf nicht angetastet werden.
FOLGE_LAYER = {"nvt_standorte": (("name", False),), "korridore": (("name", False),), "sitz_vorher": (("name", False),),
               "vorlage": (("nvt", False), ("uid", True)), "planung": (("nvt", False), ("uid", True)),
               "final": (("nvt", False), ("uid", True)), "adressen": (("nvt", False),), "nvt_status": (("name", False),),
               "pruefung": (("nvt", False), ("uid", True), ("uid2", True))}


def _stamm(gpkg):
    """Namensstamm der Folgedateien - dieselbe Bildung wie in trassen.kern.stamm_von."""
    return re.sub(r"[^A-Za-z0-9_\-]+", "_", re.sub(r"^nvt_gebiete_", "", os.path.splitext(os.path.basename(str(gpkg)))[0])).strip("_")[:40]


def folgedateien(gpkg):
    """GeoPackages der Werkzeuge 3 und 4, die zu diesem Schnitt gehoeren (gleicher Namensstamm im selben Ordner)."""
    import glob
    ordner = os.path.dirname(os.path.abspath(gpkg))
    st = _stamm(gpkg)
    treffer = []
    for vor in ("nvt_standorte_", "trassen_"):
        treffer += sorted(glob.glob(os.path.join(ordner, vor + st + "*.gpkg")))
    return treffer


def _ersetzen(serie, paare, zwischen, ist_uid=False):
    """Werte nach `paare` ersetzen, ueber Zwischennamen (Ringtausch). Bei uid nur den Namensteil vor der letzten Unterstrich-Gruppe.
    -> (neue Serie, Anzahl Treffer)"""
    s = serie.astype(str).str.strip()
    if not ist_uid:
        treffer = int(s.isin(paare).sum())
        if treffer:
            s = s.replace(zwischen).replace({zwischen[a]: b for a, b in paare.items()})
        return s, treffer

    def teil(w, tab):
        if "_" not in w:
            return tab.get(w, w)
        kopf, rest = w.rsplit("_", 1)
        return "{}_{}".format(tab[kopf], rest) if kopf in tab else w
    treffer = int(sum(1 for w in s if (w.rsplit("_", 1)[0] if "_" in w else w) in paare))
    if treffer:
        s = s.map(lambda w: teil(w, zwischen)).map(lambda w: teil(w, {zwischen[a]: b for a, b in paare.items()}))
    return s, treffer


def namen_lesen(gpkg):
    """Vorhandene Gebietsnamen (aus dem Gebietslayer, sonst aus den Adressen), natuerlich sortiert."""
    import geopandas as gpd
    for lname, spalte in (("nvt_gebiete", "name"), ("adressen", "nvt")):
        try:
            df = gpd.read_file(gpkg, layer=lname)
        except Exception:
            continue
        namen = sorted({str(x).strip() for x in df[spalte] if str(x).strip() not in ("", "nan", "None")}, key=_natschluessel)
        if namen:
            return namen
    return []


def _natschluessel(n):
    z = re.match(r"^(.*?)(\d+)$", str(n))
    return (z.group(1), int(z.group(2))) if z else (str(n), -1)


def _teile(n):
    """'1V07' -> ('1V', 7); ohne Zahl -> (name, None)."""
    z = re.match(r"^(.*?)(\d+)$", str(n).strip())
    return (z.group(1), int(z.group(2))) if z else (str(n).strip(), None)


def umbenennen(gpkg, paare, log=print, mitziehen=True):
    """paare: dict alter Name -> neuer Name. Benennt in allen Layern um (Adressen, Sitz, Gebiete, Strassenabschnitte). Ringtausch
    ist erlaubt: es wird ueber Zwischennamen umgesetzt. mitziehen: auch die Dateien der Werkzeuge 3 und 4 zum selben Schnitt
    (Standorte, Trassen samt uid-Vorsatz). -> dict(geaendert je Layer, Schluessel 'Datei:Layer' bei Folgedateien)"""
    import geopandas as gpd
    paare = {str(a).strip(): str(b).strip() for a, b in (paare or {}).items() if str(a).strip() and str(b).strip() and str(a).strip() != str(b).strip()}
    if not paare:
        return {}
    vorhanden = set(namen_lesen(gpkg))
    ziele = list(paare.values())
    if len(set(ziele)) != len(ziele):
        raise RuntimeError("Zwei Gebiete sollen denselben Namen bekommen: {}".format(", ".join(sorted({z for z in ziele if ziele.count(z) > 1}))))
    kollision = [z for z in ziele if z in vorhanden and z not in paare]
    if kollision:
        raise RuntimeError("Name schon vergeben: {}".format(", ".join(sorted(set(kollision)))))
    zwischen = {a: "~~{}~~".format(i) for i, a in enumerate(paare)}
    erg = {}
    for lname, spalte in NAME_LAYER:
        try:
            df = gpd.read_file(gpkg, layer=lname)
        except Exception:
            continue
        if spalte not in df:
            continue
        df[spalte], n = _ersetzen(df[spalte], paare, zwischen)
        if not n:
            continue
        if lname == "adressen":
            _adressen_schreiben(gpkg, df)
        else:
            df.to_file(gpkg, layer=lname, driver="GPKG")
        erg[lname] = n
    log("Umbenannt: {} ({})".format(", ".join("{} -> {}".format(a, b) for a, b in sorted(paare.items())),
                                    ", ".join("{} {}".format(v, k) for k, v in erg.items()) or "nichts gefunden"))
    if mitziehen:
        for datei in folgedateien(gpkg):
            n_datei = _folgedatei_umbenennen(datei, paare, zwischen, erg)
            if n_datei:
                log("  mitgezogen: {} ({} Eintraege)".format(os.path.basename(datei), n_datei))
    return erg


def _folgedatei_umbenennen(datei, paare, zwischen, erg):
    """Namen in einem GeoPackage der Werkzeuge 3/4 ersetzen. -> Anzahl geaenderter Eintraege"""
    import geopandas as gpd
    import pyogrio
    try:
        layer = set(pyogrio.list_layers(datei)[:, 0].tolist())
    except Exception:
        return 0
    gesamt = 0
    for lname, spalten in FOLGE_LAYER.items():
        if lname not in layer:
            continue
        try:
            df = gpd.read_file(datei, layer=lname)
        except Exception:
            continue
        n_layer = 0
        for spalte, ist_uid in spalten:
            if spalte not in df:
                continue
            df[spalte], n = _ersetzen(df[spalte], paare, zwischen, ist_uid=ist_uid)
            n_layer += n
        if not n_layer:
            continue
        try:
            df.to_file(datei, layer=lname, driver="GPKG")
        except Exception:
            continue
        erg["{}:{}".format(os.path.basename(datei), lname)] = n_layer
        gesamt += n_layer
    if gesamt:
        try:
            from ...gemeinsam import wal_schliessen
            wal_schliessen(datei)
        except Exception:
            pass
    return gesamt


def nummern_vorschlag(gpkg, start=None, praefix=None):
    """Lueckenlose Nummern je Namensstamm vorschlagen (Ripple: faellt durch Umclustern eine Nummer weg, ruecken die folgenden auf).
    Die Reihenfolge der vorhandenen Nummern bleibt. -> (dict alt -> neu, Liste der Luecken als Text)"""
    namen = namen_lesen(gpkg)
    gruppen = {}
    for n in namen:
        p, z = _teile(n)
        if z is None:
            continue
        if praefix and p != str(praefix).strip():
            continue
        gruppen.setdefault(p, []).append((z, n))
    paare, luecken = {}, []
    for p, liste in gruppen.items():
        liste.sort()
        ab = int(start) if start is not None else liste[0][0]
        vor = None
        for i, (z, alt) in enumerate(liste):
            if vor is not None and z > vor + 1:
                luecken.append("{}{:02d}".format(p, vor + 1) if z == vor + 2 else "{}{:02d} bis {}{:02d}".format(p, vor + 1, p, z - 1))
            vor = z
            neu = "{}{:02d}".format(p, ab + i)
            if neu != alt:
                paare[alt] = neu
    return paare, luecken


def nummernkreis_pruefen(gpkg, praefix, start, ende=None):
    """-> Liste von Meldungen: Namen ausserhalb des vom Auftraggeber vorgegebenen Blocks."""
    p = str(praefix or "").strip()
    raus = []
    for n in namen_lesen(gpkg):
        pp, z = _teile(n)
        if p and pp != p:
            raus.append("{} passt nicht zum Stamm {}".format(n, p))
        elif z is not None and (z < int(start or 1) or (ende and z > int(ende))):
            raus.append("{} liegt ausserhalb {}{:02d}-{}{:02d}".format(n, p or pp, int(start or 1), p or pp, int(ende or 99)))
    return raus


# --- Polygone --------------------------------------------------------------------------------------------------------------------------
def polygone(adr, spalte="nvt", rand_m=30.0, extra=None):
    """Voronoi je Adresse (+ Stuetzpunkte entlang der Strassenabschnitte, `extra` = Liste (name, Point)), je Gebiet vereinigt,
    beschnitten auf konkave Huelle aller Punkte + rand_m. -> dict name -> Polygon"""
    import shapely
    from shapely.geometry import MultiPoint
    from shapely.ops import unary_union
    from shapely.strtree import STRtree
    namen = [str(n) for n in adr[spalte]]
    pts = list(adr.geometry)
    for name, p in (extra or []):
        namen.append(str(name))
        pts.append(p)
    # doppelte Koordinaten stoeren Voronoi: minimal versetzen
    gesehen, pts2 = set(), []
    for p in pts:
        key = (round(p.x, 2), round(p.y, 2))
        while key in gesehen:
            p = shapely.geometry.Point(p.x + 0.03, p.y + 0.017)
            key = (round(p.x, 2), round(p.y, 2))
        gesehen.add(key)
        pts2.append(p)
    pts = pts2
    if len(pts) < 4:
        return {}
    mp = MultiPoint(pts)
    # Huelle nur aus den Adressen (+ rand_m): die Stuetzpunkte formen die Grenzen zwischen den Gebieten, nicht den Aussenrand.
    # Je zusammenhaengender Siedlung (Adressen naeher als siedlung_m) eine eigene Huelle - sonst zieht die konkave Huelle Korridore
    # ueber die Feldmark zwischen den Ortsteilen (Barntrup 16.09.2026).
    adr_pts = list(adr.geometry)
    siedlung_m = 120.0
    teile = []
    try:
        lappen = unary_union([q.buffer(siedlung_m) for q in adr_pts])
        lappen = list(lappen.geoms) if lappen.geom_type == "MultiPolygon" else [lappen]
        ltree = STRtree(lappen)
        gruppen = {}
        for q in adr_pts:
            h = ltree.query(q, predicate="within")
            gruppen.setdefault(int(h[0]) if len(h) else -1, []).append(q)
        for grp in gruppen.values():
            if len(grp) >= 4:
                try:
                    teile.append(shapely.concave_hull(MultiPoint(grp), ratio=0.25).buffer(rand_m))
                    continue
                except Exception:
                    pass
            teile.append(unary_union([q.buffer(rand_m) for q in grp]))
        gebiet = unary_union(teile)
    except Exception:
        mp_adr = MultiPoint(adr_pts) if len(adr_pts) >= 4 else mp
        gebiet = mp_adr.convex_hull.buffer(rand_m)
    zellen = list(shapely.voronoi_polygons(mp, extend_to=gebiet.buffer(rand_m)).geoms)
    tree = STRtree(zellen)
    je_name = {}
    for name, g in zip(namen, pts):
        hit = tree.query(g, predicate="within")
        if len(hit):
            je_name.setdefault(str(name), []).append(zellen[hit[0]])
    out = {}
    for name, zs in je_name.items():
        geom = unary_union(zs).intersection(gebiet)
        try:
            geom = geom.buffer(0.5).buffer(-0.5)
        except Exception:
            pass
        if not geom.is_empty:
            out[name] = geom
    return polygone_aufraeumen(out)


def polygone_aufraeumen(polys, glaetten_m=4.0, splitter_m2=50.0):
    """Gebietsgrenzen gemeinsam glaetten (Markus 17.09.2026, 'ordentlicher'): die Voronoi-Zickzacklinien zwischen den Gebieten werden je
    Grenzabschnitt zwischen zwei Knoten vereinfacht (Douglas-Peucker, Endpunkte bleiben) - so bleiben die Gebiete lueckenlos und
    ueberlappungsfrei, obwohl jede Grenze nur einmal geglaettet wird. Danach: Flaechen neu bilden und dem Gebiet mit dem groessten
    Anteil zuordnen, Loecher fuellen (wenn kein anderes Gebiet darin liegt), Splitter unter splitter_m2 dem Nachbarn geben.
    Shapely 2.0 hat coverage_simplify noch nicht, deshalb von Hand. Bei jedem Fehler bleibt das Original. -> dict name -> Geometrie"""
    import shapely
    from shapely.geometry import Polygon
    from shapely.ops import linemerge, polygonize, unary_union
    from shapely.strtree import STRtree
    namen = [n for n, g in polys.items() if g is not None and not g.is_empty]
    if len(namen) < 1:
        return polys
    try:
        raender = unary_union([polys[n].boundary for n in namen])
        ketten = linemerge(raender) if raender.geom_type == "MultiLineString" else raender
        ketten = list(ketten.geoms) if ketten.geom_type == "MultiLineString" else [ketten]
        glatt = [k.simplify(glaetten_m, preserve_topology=True) for k in ketten]
        flaechen = [f for f in polygonize(unary_union(glatt)) if f.area > 0.01]
        if not flaechen:
            return polys
        orig = [polys[n] for n in namen]
        tree = STRtree(orig)
        teile = {n: [] for n in namen}
        klein = []
        for f in flaechen:
            kand = [int(j) for j in tree.query(f, predicate="intersects")]
            if not kand:
                continue
            best = max(kand, key=lambda j: orig[j].intersection(f).area)
            (klein if f.area < splitter_m2 else teile[namen[best]]).append((f, namen[best]))
        # Splitter: an das Gebiet mit der laengsten gemeinsamen Grenze, sonst an das Ursprungsgebiet
        for f, herkunft in klein:
            beste, laenge = herkunft, -1.0
            for n in namen:
                if not teile[n]:
                    continue
                l = unary_union([t for t, _ in teile[n]]).boundary.intersection(f.boundary).length
                if l > laenge:
                    beste, laenge = n, l
            teile[beste].append((f, herkunft))
        out = {}
        mitten = {n: polys[n].representative_point() for n in namen}
        for n in namen:
            if not teile[n]:
                out[n] = polys[n]
                continue
            g = unary_union([t for t, _ in teile[n]]).buffer(0)
            polygone_ = list(g.geoms) if g.geom_type == "MultiPolygon" else [g]
            gefuellt = []
            for p in polygone_:
                ringe = []
                for ring in p.interiors:
                    loch = Polygon(ring)
                    if any(loch.contains(mitten[m]) for m in namen if m != n):
                        ringe.append(ring)                  # anderes Gebiet liegt darin: Loch bleibt
                gefuellt.append(Polygon(p.exterior, ringe))
            g = unary_union(gefuellt)
            out[n] = g if not g.is_empty else polys[n]
        if len(out) != len(namen):
            return polys
        return out
    except Exception:
        return polys


# --- Schreiben -------------------------------------------------------------------------------------------------------------------------
def ausgabe_pfad(quelle, out_dir=None):
    stamm = re.sub(r"[^A-Za-z0-9_\-]+", "_", os.path.splitext(os.path.basename(str(quelle)))[0]).strip("_")
    stamm = re.sub(r"^adresspruefung_", "", stamm)[:40] or "Gebiete"
    ordner = out_dir or (os.path.dirname(os.path.abspath(quelle)) if os.path.exists(str(quelle)) else os.path.expanduser("~"))
    return os.path.join(ordner, "nvt_gebiete_{}_{}.gpkg".format(stamm, datetime.now().strftime("%Y%m%d_%H%M")))


def schreiben(adr, gebiete, G, gpkg, cfg, log=print, abschnitte=None, extra=None, vorgaben=None):
    """abschnitte: GeoDataFrame der Strassenabschnitte (Layer strassenabschnitte), extra: Stuetzpunkte fuer die Polygone.
    vorgaben: dict name -> Polygon des Planers; diese Gebiete bekommen genau seine Zeichnung, die automatischen werden darum
    herum beschnitten (Markus 17.09.2026)."""
    import geopandas as gpd
    import pandas as pd
    from shapely.geometry import LineString, Point
    os.makedirs(os.path.dirname(gpkg), exist_ok=True)
    polys = polygone(adr, extra=extra)
    if vorgaben:
        from shapely.ops import unary_union
        block = unary_union([p for p in vorgaben.values() if p is not None and not p.is_empty])
        for name in list(polys):
            if name in vorgaben:
                continue
            geom = polys[name]
            if geom is None or geom.is_empty:
                continue
            try:
                rest = geom.difference(block)
            except Exception:
                continue
            if rest.geom_type == "MultiPolygon":                # groesster Teil bleibt, Splitter hinter der Vorgabe fallen weg
                rest = max(rest.geoms, key=lambda p: p.area)
            if not rest.is_empty and rest.geom_type == "Polygon":
                polys[name] = rest
        for name, p in vorgaben.items():
            polys[name] = p if p.geom_type == "Polygon" else max(p.geoms, key=lambda q: q.area)
    n = cfg["nvt"]
    rows = []
    for g in gebiete:
        geom = polys.get(g["name"])
        rows.append({"name": g["name"], "vorgabe": int(bool(g.get("vorgabe"))), "ampel": g["ampel"], "hinweis": g["hinweis"], "apl": g["apl"], "we": g["we"], "ge": g["ge"],
                     "anschluesse": g["anschluesse"], "pon_fasern": round(g["pon"], 1), "p2p": g.get("p2p", 0),
                     "hk_fasern": g["hk_fasern"], "hk_text": g.get("hk_text", ""), "snr": g["snr"],
                     "kassetten": round(g["kassetten"]), "vzk_max_m": g["vzk_max_m"], "vzk_baum_m": g["vzk_baum_m"],
                     "flaeche_ha": round(geom.area / 1e4, 2) if geom is not None else None,
                     "max_apl": int(n["max_apl"]), "max_apl_hart": int(n.get("max_apl_hart", n["max_apl"])), "max_we": int(n["max_we"]),
                     "max_snr": int(n["max_snr"]), "max_pon": int(n["max_pon_fasern"]), "max_hk_fasern": int(n["max_hk_fasern"]),
                     "max_kassetten": int(n["max_kassetten"] - n["hk_kassetten"]), "max_vzk_m": int(n["max_dist_m"]),
                     "regelsatz": cfg["nvt"]["name"], "status": "offen", "kommentar": "", "geometry": geom})
    gdf_geb = gpd.GeoDataFrame(rows, crs=CRS)
    gdf_geb[gdf_geb.geometry.notna()].to_file(gpkg, layer="nvt_gebiete", driver="GPKG")
    if vorgaben:
        gpd.GeoDataFrame([{"name": k, "geometry": v} for k, v in vorgaben.items()], crs=CRS).to_file(gpkg, layer="vorgaben", driver="GPKG")
    sitz = gpd.GeoDataFrame([{"name": g["name"], "apl": g["apl"], "hk_fasern": g["hk_fasern"], "ampel": g["ampel"],
                              "hinweis": "Sitzvorschlag (Medoid auf dem Netz); Standort im oeffentlichen Raum prueft Werkzeug 4",
                              "geometry": Point(*g["sitz_xy"])} for g in gebiete], crs=CRS)
    sitz.to_file(gpkg, layer="nvt_sitz", driver="GPKG")
    a = adr.copy()
    for c in a.columns:
        if a[c].dtype == object and c != "geometry":
            a[c] = a[c].astype(str).replace({"None": "", "nan": ""})
    for c in ("bedarfspunkt", "koord_fehlt", "bauluecke", "gemischt", "gewerbegebiet", "im_gebaeude"):
        if c in a:
            a[c] = a[c].astype(int)
    a.to_file(gpkg, layer="adressen", driver="GPKG")
    if abschnitte is not None and len(abschnitte):
        abschnitte.to_file(gpkg, layer="strassenabschnitte", driver="GPKG")
    if G is not None:
        kanten = gpd.GeoDataFrame([{"laenge_m": round(d["length"], 1), "eur_m": round(d.get("eur_m", 0), 2), "klasse": d.get("klasse"),
                                    "bauverfahren": d.get("bauverfahren"), "name": d.get("name"), "quelle": d.get("quelle_id"),
                                    "geometry": d.get("geometry") or LineString([(G.nodes[u]["x"], G.nodes[u]["y"]), (G.nodes[v]["x"], G.nodes[v]["y"])])}
                                   for u, v, d in G.edges(data=True) if not str(u).startswith("A_") and not str(v).startswith("A_")], crs=CRS)
        kanten.to_file(gpkg, layer="netz", driver="GPKG")
        with open(os.path.splitext(gpkg)[0] + "_graph.pkl", "wb") as f:
            pickle.dump(G, f)
    log("Geschrieben: {} ({} Gebiete, {} Adressen)".format(gpkg, len(gdf_geb), len(a)))
    return gpkg


def bericht(gebiete, adr, cfg, gpkg, quelle, varianten=None, log=print, netz=None):
    """netz: dict aus dem Netzwachstum (baum_m, gemischt, abschnitte, neue_gebiete, aufgeloest, sperren) oder None (altes Verfahren)."""
    from . import netzwachstum
    p = os.path.splitext(gpkg)[0] + "_bericht.md"
    n = cfg["nvt"]
    z = {"gruen": 0, "gelb": 0, "rot": 0}
    for g in gebiete:
        z[g["ampel"]] = z.get(g["ampel"], 0) + 1
    zeilen = ["# NVT-Gebiete {}".format(os.path.basename(str(quelle))), "",
              "Stand {}, Fiberation Werkzeugkasten, Werkzeug 3. Regelsatz: {} (Adressen {} weich / {} hart, WE {}, SNR {}, PON {}, "
              "Vzk {} m).".format(datetime.now().strftime("%d.%m.%Y %H:%M"), n["name"], n["max_apl"], n.get("max_apl_hart", n["max_apl"]),
                                  n["max_we"], n["max_snr"], n["max_pon_fasern"], n["max_dist_m"]),
              "", "{} Gebiete fuer {} Adressen: {} gruen, {} gelb, {} rot. Adressen je Gebiet im Mittel {:.0f}.".format(
                  len(gebiete), len(adr), z["gruen"], z["gelb"], z["rot"], len(adr) / max(len(gebiete), 1)), ""]
    fest = [g for g in gebiete if g.get("vorgabe")]
    if fest:
        zeilen += ["Vorgabe-Gebiete des Planers, gesperrt und von der Automatik nicht genutzt: {} ({}), zusammen {} Adressen.".format(
            len(fest), ", ".join(g["name"] for g in fest), sum(g["apl"] for g in fest)), ""]
    anzahl_geteilt, geteilt = netzwachstum.geteilte_strassen(adr)
    if netz:
        w = netzwachstum.einstellungen(cfg)
        zeilen += ["## Netzorientierter Schnitt", "",
                   "Bausteine: {} Strassenabschnitte (max. {} Adressen / {:.0f} m je Abschnitt), Gebiete gewachsen entlang des Netzes nach "
                   "Vzk-Weg. Vzk-Baum gesamt {:,.0f} m. {} Abschnitte mussten adressweise geteilt werden (Kapazitaet). {} Gebiete "
                   "nachtraeglich eroeffnet (Adressen ohne Platz oder ausser Reichweite), {} kleine Gebiete aufgeloest.".format(
                       netz.get("abschnitte", 0), w["abschnitt_max_adr"], w["abschnitt_max_m"], netz.get("baum_m", 0),
                       netz.get("gemischt", 0), netz.get("neue_gebiete", 0), netz.get("aufgeloest", 0)),
                   "", "Sperrkanten: Hauptstrasse +{:.0f} m, Bundesstrasse +{:.0f} m, Bahn +{:.0f} m, Gewaesser +{:.0f} m Aufschlag beim "
                   "Wachsen darueber; Planer-Zwangsgrenzen: {} Kanten gesperrt (hart).".format(
                       w["strafe_hauptstrasse_m"], w["strafe_bundesstrasse_m"], w["strafe_bahn_m"], w["strafe_gewaesser_m"],
                       netz.get("sperren", 0)), ""]
    zeilen += ["Geteilte Strassen (Adressen einer Strasse in mehr als einem Gebiet): {}{}".format(
        anzahl_geteilt, " - " + "; ".join("{} ({})".format(s, "/".join(g)) for s, g in geteilt[:25]) + (" ..." if len(geteilt) > 25 else "") if geteilt else ""), ""]
    if varianten:
        zeilen += ["## Varianten", "", "| k | Gebiete | Vzk-Kosten | Gesamt | Ueberlauf |", "|---|---|---|---|---|"]
        for r in varianten:
            zeilen.append("| {} | {} | {:,.0f} | {:,.0f} | {} |".format(r["k"], r["nvt_genutzt"], r["vzk_kosten"], r["kosten"], r["ueberlauf"]))
        zeilen.append("")
    zeilen += ["## Gebiete", "", "| Gebiet | Ampel | Adressen | WE | GE | Anschl. | PON-Fs | Hk-Fs | SNR | Kass. | Vzk max m | Vzk Baum m | Hinweis |",
               "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for g in sorted(gebiete, key=lambda d: d["name"]):
        zeilen.append("| {} | {} | {} | {} | {} | {} | {:.1f} | {} | {} | {:.0f} | {} | {} | {} |".format(
            g["name"], g["ampel"], g["apl"], g["we"], g["ge"], g["anschluesse"], g["pon"], g["hk_fasern"], g["snr"], g["kassetten"],
            g["vzk_max_m"], g["vzk_baum_m"], g["hinweis"]))
    zeilen += ["", "Sitz = Medoid auf dem Netz (Vorschlag). Spalten status/kommentar im Gebietslayer und nvt im Adresslayer gehoeren dem Planer; "
               "'Nachrechnen' uebernimmt die Aenderungen.", ""]
    with open(p, "w", encoding="utf-8") as f:
        f.write("\n".join(zeilen))
    log("Bericht: " + p)
    return p


# --- Gesamtablauf ----------------------------------------------------------------------------------------------------------------------
def sperrkanten(G, zwangsgrenzen):
    """Kanten, die eine Planer-Zwangsgrenze (Linie/Flaeche, EPSG:25832) schneiden. -> Liste (u, v)"""
    if not zwangsgrenzen:
        return []
    from shapely.ops import unary_union
    from shapely.prepared import prep
    from shapely.strtree import STRtree
    geoms = [g for g in zwangsgrenzen if g is not None and not g.is_empty]
    if not geoms:
        return []
    grenze = unary_union([g.boundary if g.geom_type in ("Polygon", "MultiPolygon") else g for g in geoms])
    pg = prep(grenze)
    out = []
    for u, v, d in G.edges(data=True):
        g = d.get("geometry")
        if g is not None and pg.intersects(g):
            out.append((u, v))
    return out


def schneiden(quelle, netz_art="osm", netz_pfad=None, regelsatz=None, out_dir=None, grenzen=None, varianten_vergleichen=False,
              log=print, fortschritt=None, zwangsgrenzen=None, verfahren="netz", praefix=None, start=1, vorgaben=None):
    """verfahren: 'netz' = netzorientiert (Strassenabschnitte, Wachsen entlang des Netzes; Standard seit 16.09.2026),
    'punkte' = altes kapazitiertes k-Medoid-Verfahren. zwangsgrenzen: Liste shapely-Geometrien (Planer-Grenzen, hart).
    praefix/start: Nummernkreis des Auftraggebers (BVT), z. B. '1V' ab 5 -> 1V05, 1V06 ...
    vorgaben: Liste dict(name, geometry) - Gebiete, die der Planer vorab festlegt (Markus 17.09.2026): Adressen darin sind fest
    zugeordnet, das Netz darin ist fuer die Automatik gesperrt, die Automatik schneidet nur den Rest.
    -> dict(gpkg, bericht, gebiete, adressen, varianten, cfg)"""
    import numpy as np
    from . import cluster as cl, netzwachstum
    f = fortschritt or (lambda p, t: None)
    f(2, "Adressen laden")
    adr = adressen_laden(quelle, log)
    treiber = str(adr["sponsor"].iat[0]) if "sponsor" in adr and len(adr) else ""
    rs = regelsatz or config.regelsatz_fuer(treiber)
    cfg = config.erzeugen(rs, out_dir=out_dir or os.path.dirname(os.path.abspath(str(quelle))) if os.path.exists(str(quelle)) else out_dir,
                          treiber=treiber or None, **(grenzen or {}))
    if varianten_vergleichen:
        cfg["nvt"]["k_varianten"] = [-1, 0, 1]
    n_ = cfg["nvt"]
    log("Regelsatz: {} (Ausbautreiber '{}'); Grenzen je NVT aus {}: Adressen {}/{} (Erweiterung {}/{}), Koppler {}/{}, Kassetten {}/{}, WE {}{}".format(
        n_["name"], treiber or "-", n_.get("mydms_quelle", "Regelsatz"), n_["max_apl"], n_["max_apl_hart"], n_.get("apl_erw_weich", "-"),
        n_.get("apl_erw_hart", "-"), n_.get("pon_warn", "-"), n_["max_pon_fasern"], n_.get("kassetten_warn", "-"),
        n_["max_kassetten"] - n_["hk_kassetten"], n_["max_we"], "; vom Planer geaendert: {}".format(grenzen) if grenzen else ""))
    f(8, "Netz laden ({})".format(netz_art))
    G = netz_laden(netz_art, cfg, adr, log, pfad=netz_pfad)
    f(30, "Adressen anbinden")
    nodes = anbinden(G, adr, cfg, log)
    if len(adr) < 2:
        raise RuntimeError("Zu wenige angebundene Adressen.")
    # Vorgabe-Gebiete: fest zugeordnete Adressen raus aus der Automatik, ihr Netz gesperrt
    fest_von_adr, fest_namen, fest_polys = vorgaben_zuordnen(adr, vorgaben, log)
    frei_idx = [i for i in range(len(adr)) if fest_von_adr[i] < 0]
    nodes_frei = [nodes[i] for i in frei_idx]
    we_alle = adr["we_kap"].to_numpy(dtype=float)
    sperr_vorgabe = kanten_in_flaechen(G, fest_polys)
    varianten, netz_info, abschnitte_gdf, extra, nw = None, None, None, None, None
    labels_frei, seeds_frei = [], []
    if frei_idx:
        cfg["vzk"]["snr_liste"] = adr["snr"].astype(float).iloc[frei_idx].tolist()
        if verfahren == "netz":
            sperr = list(sperrkanten(G, zwangsgrenzen)) + sperr_vorgabe
            if sperr:
                log("Gesperrt: {} Kanten ({} an Zwangsgrenzen, {} in Vorgabe-Gebieten)".format(len(sperr), len(sperr) - len(sperr_vorgabe), len(sperr_vorgabe)))
            f(40, "Gebiete wachsen entlang des Netzes")
            nw = netzwachstum.schneiden(G, nodes_frei, we_alle[frei_idx], cfg, sperr_kanten=sperr, log=log, fortschritt=f)
            labels_frei, seeds_frei = list(nw["labels"]), list(nw["seeds"])
            netz_info = {"baum_m": nw["baum_m"], "gemischt": nw["gemischt"], "abschnitte": len(nw["segs"]), "neue_gebiete": nw["neue_gebiete"],
                         "aufgeloest": nw["aufgeloest"], "sperren": len(sperr)}
            for s in nw["segs"]:                                  # Adressindizes zurueck auf die volle Liste
                s["adr"] = [frei_idx[i] for i in s["adr"]]
        else:
            f(40, "Gebiete schneiden" + (" (Varianten k-1, k, k+1)" if len(cfg["nvt"]["k_varianten"]) > 1 else ""))
            adr_frei = adr.iloc[frei_idx].reset_index(drop=True)
            best, varianten = cl.choose(G, nodes_frei, we_alle[frei_idx], cfg, log=log)
            f(72, "Ausreisser pruefen")
            labels_frei, seeds_frei, n_aus = ausreisser_abtrennen(G, adr_frei, list(best["labels"]), list(best["seeds"]), cfg, nodes_frei, log)
    else:
        log("Alle Adressen liegen in Vorgabe-Gebieten - die Automatik hat nichts zu schneiden.")
    cfg["vzk"]["snr_liste"] = adr["snr"].astype(float).tolist()
    # Labels zusammensetzen: automatische Gebiete 0..k-1, dahinter die Vorgabe-Gebiete
    labels = [-1] * len(adr)
    for i, l in zip(frei_idx, labels_frei):
        labels[i] = int(l)
    seeds = list(seeds_frei)
    fest_info = {}
    maxd = float(cfg["nvt"]["max_dist_m"])
    for v, name in enumerate(fest_namen):
        idx = [i for i in range(len(adr)) if fest_von_adr[i] == v]
        if not idx:
            log("Vorgabe-Gebiet {}: keine Adressen darin - kein Gebiet, Netz bleibt gesperrt".format(name or "Nr. {}".format(v + 1)))
            continue
        j = len(seeds)
        seeds.append(netzwachstum._medoid(G, [nodes[i] for i in idx], maxd))
        for i in idx:
            labels[i] = j
        fest_info[j] = (name, fest_polys[v])
    labels = np.array(labels)
    f(80, "Kennzahlen")
    gebiete = kennzahlen(G, adr, labels, seeds, cfg, nodes)
    for g in gebiete:
        if g["cluster"] in fest_info:
            g["vorgabe"], g["name_fest"] = True, fest_info[g["cluster"]][0]
            g["hinweis"] = "; ".join(x for x in ("Vorgabe des Planers (gesperrt)", g["hinweis"]) if x)
    asb = adr["asb"].astype(str).replace("nan", "").iloc[0] if "asb" in adr and len(adr) else ""
    namen_vergeben(gebiete, asb, praefix=praefix, start=start)
    name_von_cluster = {g["cluster"]: g["name"] for g in gebiete}
    adr["nvt"] = [name_von_cluster.get(int(l), "") for l in labels]
    vorgabe_polys = {g["name"]: fest_info[g["cluster"]][1] for g in gebiete if g.get("vorgabe")}
    if verfahren == "netz" and nw is not None:
        abschnitte_gdf = netzwachstum.abschnitte_frame(G, nw["segs"], name_von_cluster, CRS)
        extra = netzwachstum.stuetzpunkte(G, nw["segs"], name_von_cluster, netzwachstum.einstellungen(cfg)["polygon_punkte_m"])
        seg_von_adr = {i: s["id"] for s in nw["segs"] for i in s["adr"]}
        adr["abschnitt"] = [int(seg_von_adr.get(i, -1)) for i in range(len(adr))]   # fuer das Nachrechnen (Mehrheit je Abschnitt)
    f(90, "Schreiben")
    gpkg = ausgabe_pfad(quelle, out_dir)
    schreiben(adr, gebiete, G, gpkg, cfg, log, abschnitte=abschnitte_gdf, extra=extra, vorgaben=vorgabe_polys)
    md = bericht(gebiete, adr, cfg, gpkg, quelle, varianten, log, netz=netz_info)
    f(100, "Fertig")
    z = {"gruen": 0, "gelb": 0, "rot": 0}
    for g in gebiete:
        z[g["ampel"]] += 1
    log("Ergebnis: {} Gebiete ({} gruen, {} gelb, {} rot), Mittel {:.0f} Adressen".format(len(gebiete), z["gruen"], z["gelb"], z["rot"], len(adr) / len(gebiete)))
    return {"gpkg": gpkg, "bericht": md, "gebiete": gebiete, "adressen": adr, "varianten": varianten, "cfg": cfg}


def nachrechnen(gpkg, regelsatz=None, grenzen=None, log=print, fortschritt=None):
    """Adresslayer (Spalte nvt, vom Planer geaendert) und Sitzlayer lesen, Kennzahlen + Polygone neu schreiben. -> dict"""
    import geopandas as gpd
    import numpy as np
    from . import graph
    f = fortschritt or (lambda p, t: None)
    f(5, "Layer lesen")
    adr = gpd.read_file(gpkg, layer="adressen")
    sitz = gpd.read_file(gpkg, layer="nvt_sitz")
    alt = gpd.read_file(gpkg, layer="nvt_gebiete")
    if adr.crs is None or adr.crs.to_epsg() != CRS:
        adr = adr.set_crs(CRS, allow_override=True)
    rs = regelsatz or config.regelwerk.regelsatz_aus_gebieten(alt)
    treiber = str(adr["sponsor"].iat[0]) if "sponsor" in adr and len(adr) else None
    cfg = config.erzeugen(rs, out_dir=os.path.dirname(gpkg), treiber=treiber or None, **(grenzen or {}))
    pkl = os.path.splitext(gpkg)[0] + "_graph.pkl"
    if not os.path.exists(pkl):
        raise RuntimeError("Netzgraph fehlt ({}), Nachrechnen nicht moeglich - neu schneiden.".format(os.path.basename(pkl)))
    with open(pkl, "rb") as fh:
        G = pickle.load(fh)
    for c in ("we", "ge", "anschluesse", "snr", "p2p"):
        adr[c] = adr[c].fillna(0).astype(int) if c in adr else 0
    adr["we_kap"] = adr["anschluesse"].clip(lower=1)
    adr["nvt"] = adr["nvt"].astype(str).str.strip()
    adr = adr[adr["nvt"] != ""].reset_index(drop=True)
    f(25, "Adressen zuordnen")
    # Adressknoten stehen schon im gespeicherten Graphen (A_<id>); nicht erneut anbinden, sonst werden Kanten doppelt geteilt
    adr["id"] = adr["id"].astype(str)
    if "knoten" in adr:
        knoten = [str(k) if str(k) not in ("", "None", "nan") else "A_" + i for k, i in zip(adr["knoten"], adr["id"])]
    else:
        knoten = ["A_" + i for i in adr["id"]]
    im_graph = [k in G for k in knoten]
    if not all(im_graph):
        log("Nachrechnen: {} Adressen ohne Knoten im gespeicherten Netz, werden ausgelassen".format(im_graph.count(False)))
        adr = adr[im_graph].reset_index(drop=True)
        knoten = [k for k, ok in zip(knoten, im_graph) if ok]
    nodes = knoten
    cfg["vzk"]["snr_liste"] = adr["snr"].astype(float).tolist()
    namen = sorted(adr["nvt"].unique().tolist())
    labels = np.array([namen.index(n) for n in adr["nvt"]])
    seeds = []
    sitz_xy = {str(r["name"]): (r.geometry.x, r.geometry.y) for _, r in sitz.iterrows()}
    for n in namen:
        if n in sitz_xy:
            seeds.append(graph.nearest_node(G, sitz_xy[n][0], sitz_xy[n][1], exclude_addr=True)[0])
        else:   # neues Gebiet ohne Sitz: Knoten nahe dem Schwerpunkt der Adressen
            sub = adr[adr["nvt"] == n]
            cx, cy = sub.geometry.x.mean(), sub.geometry.y.mean()
            seeds.append(graph.nearest_node(G, cx, cy, exclude_addr=True)[0])
    f(55, "Kennzahlen")
    gebiete = kennzahlen(G, adr, labels, seeds, cfg, nodes)
    for g in gebiete:
        g["name"] = namen[g["cluster"]]
        if g["name"] in sitz_xy:
            g["sitz_xy"] = sitz_xy[g["name"]]     # vom Planer ggf. verschobener Sitz bleibt
    # status/kommentar des Planers behalten
    alt_status = {str(r["name"]): (r.get("status", "offen"), r.get("kommentar", "")) for _, r in alt.iterrows()}
    # Vorgabe-Gebiete bleiben gesperrt und behalten ihre Zeichnung (Markus 17.09.2026)
    vorgaben = {}
    if "vorgabe" in alt:
        for _, r in alt.iterrows():
            if int(r.get("vorgabe") or 0) == 1 and r.geometry is not None and not r.geometry.is_empty:
                vorgaben[str(r["name"]).strip()] = r.geometry
    for g in gebiete:
        if g["name"] in vorgaben:
            g["vorgabe"] = True
            g["hinweis"] = "; ".join(x for x in ("Vorgabe des Planers (gesperrt)", g["hinweis"]) if x)
    # Strassenabschnitte nachziehen: Gebiet = Mehrheit seiner Adressen, Stuetzpunkte fuer die Polygone
    absch, extra = abschnitte_nachziehen(gpkg, adr, cfg, log)
    f(80, "Schreiben")
    schreiben(adr, gebiete, G, gpkg, cfg, log, abschnitte=absch, extra=extra, vorgaben=vorgaben or None)
    try:
        geb = gpd.read_file(gpkg, layer="nvt_gebiete")
        geb["status"] = [alt_status.get(str(n), ("offen", ""))[0] for n in geb["name"]]
        geb["kommentar"] = [alt_status.get(str(n), ("offen", ""))[1] for n in geb["name"]]
        geb.to_file(gpkg, layer="nvt_gebiete", driver="GPKG")
    except Exception:
        pass
    md = bericht(gebiete, adr, cfg, gpkg, gpkg, None, log)
    f(100, "Fertig")
    return {"gpkg": gpkg, "bericht": md, "gebiete": gebiete, "adressen": adr, "varianten": None, "cfg": cfg}


def layer_namen(gpkg):
    """Ebenen eines GeoPackages (ohne fiona: gpkg_contents lesen)."""
    import sqlite3
    try:
        con = sqlite3.connect(gpkg)
        try:
            return [r[0] for r in con.execute("SELECT table_name FROM gpkg_contents")]
        finally:
            con.close()
    except Exception:
        return []


def abschnitte_nachziehen(gpkg, adr, cfg, log=print):
    """Layer strassenabschnitte (falls vorhanden) an die aktuelle Adresszuordnung anpassen: Gebiet = Mehrheit der Adressen des
    Abschnitts (Spalte abschnitt im Adresslayer), gemischt = Adressen in mehreren Gebieten; Abschnitte ohne Adressen behalten ihr
    Gebiet, solange es noch existiert. -> (GeoDataFrame | None, Stuetzpunkte Liste (name, Point) | None)"""
    import geopandas as gpd
    from shapely.geometry import Point
    from . import netzwachstum
    try:
        if "strassenabschnitte" not in layer_namen(gpkg):
            return None, None
        absch = gpd.read_file(gpkg, layer="strassenabschnitte")
    except Exception:
        return None, None
    if not len(absch) or "abschnitt" not in adr:
        return None, None
    namen = set(adr["nvt"].astype(str))
    mehrheit, gemischt = {}, {}
    a = adr[adr["abschnitt"].fillna(-1).astype(int) >= 0]
    for sid, grp in a.groupby(a["abschnitt"].astype(int)):
        vc = grp["nvt"].astype(str).value_counts()
        mehrheit[int(sid)] = str(vc.idxmax())
        gemischt[int(sid)] = len(vc) > 1
    neu_nvt, neu_gem = [], []
    for _, r in absch.iterrows():
        sid = int(r["id"])
        if sid in mehrheit:
            neu_nvt.append(mehrheit[sid])
            neu_gem.append(int(gemischt[sid]))
        else:
            neu_nvt.append(str(r["nvt"]) if str(r["nvt"]) in namen else "")
            neu_gem.append(0)
    absch["nvt"] = neu_nvt
    absch["gemischt"] = neu_gem
    abstand = float(netzwachstum.einstellungen(cfg)["polygon_punkte_m"])
    extra = []
    for _, r in absch.iterrows():
        if not r["nvt"] or r["gemischt"] or r.geometry is None or r.geometry.length < 1.0:
            continue
        if int(r.get("apl", 0) or 0) == 0 and float(r.get("laenge_m", 0) or 0) > 150.0:
            continue
        g = r.geometry
        lines = list(g.geoms) if g.geom_type == "MultiLineString" else [g]
        for ln in lines:
            n_p = max(1, int(ln.length // abstand))
            for q in range(n_p + 1):
                p = ln.interpolate(min(1.0, (q + 0.5) / (n_p + 1)), normalized=True)
                extra.append((r["nvt"], Point(p.x, p.y)))
    return absch, extra


# --- Planer-Aenderungen uebernehmen ---------------------------------------------------------------------------------------------------
def _adressen_schreiben(gpkg, adr):
    a = adr.copy()
    for c in a.columns:
        if a[c].dtype == object and c != "geometry":
            a[c] = a[c].astype(str).replace({"None": "", "nan": ""})
    a.to_file(gpkg, layer="adressen", driver="GPKG")


def kennwerte_nachziehen(gpkg, log=print):
    """Pruefer 29.10.2026 (B1): nach einem Umhaengen von Adressen OHNE Nachrechnen (Polygone bleiben) die Kennwerte je Gebiet aus den
    Adressen neu bestimmen - alles, was kein Netz braucht: apl, we, ge, anschluesse, pon_fasern, p2p, snr, kassetten, hk_fasern, hk_text,
    flaeche_ha, Ampel mit Hinweis (Kapazitaetsregeln wie kennzahlen(); der Vzk-Weg bleibt der gespeicherte Wert vom letzten Schnitt).
    Schreibt nvt_gebiete (Geometrie, status, kommentar, vorgabe, max_* unveraendert) und nvt_sitz (apl, hk_fasern, ampel). Schritt 6 liest
    hk_fasern von hier. -> Anzahl Gebiete"""
    import geopandas as gpd
    import numpy as np
    from .cluster import lasten
    adr = gpd.read_file(gpkg, layer="adressen")
    geb = gpd.read_file(gpkg, layer="nvt_gebiete")
    adr["nvt"] = adr["nvt"].astype(str).str.strip()
    geb["name"] = geb["name"].astype(str).str.strip()
    for c in ("we", "ge", "anschluesse", "snr", "p2p"):
        adr[c] = adr[c].fillna(0).astype(int) if c in adr else 0
    adr["we_kap"] = adr["anschluesse"].clip(lower=1)
    rs = config.regelwerk.regelsatz_aus_gebieten(geb)
    treiber = str(adr["sponsor"].iat[0]) if "sponsor" in adr and len(adr) else None
    cfg = config.erzeugen(rs, out_dir=os.path.dirname(gpkg), treiber=treiber or None)
    cfg["vzk"]["snr_liste"] = adr["snr"].astype(float).tolist()
    L, caps = lasten(adr["we_kap"].to_numpy(), cfg)
    n = cfg["nvt"]
    nvt = adr["nvt"].to_numpy()
    werte = {}
    for name in geb["name"]:
        idx = np.where(nvt == name)[0]
        d = {"apl": int(len(idx)), "we": int(adr["we"].iloc[idx].sum()), "ge": int(adr["ge"].iloc[idx].sum()),
             "anschluesse": int(adr["anschluesse"].iloc[idx].sum()), "pon": float(L["pon"][idx].sum()) if len(idx) else 0.0,
             "snr": int(round(L["snr"][idx].sum())) if len(idx) else 0, "kassetten": float(L["kassetten"][idx].sum()) if len(idx) else 0.0,
             "p2p": int(adr["p2p"].iloc[idx].sum())}
        d["hk_fasern"] = _hk_fasern(d["pon"], d["p2p"])
        d["hk_text"] = _hk_text(d["pon"], d["p2p"], d["hk_fasern"])
        werte[name] = d
    aus = {c: [] for c in ("apl", "we", "ge", "anschluesse", "pon_fasern", "p2p", "snr", "kassetten", "hk_fasern", "hk_text", "ampel", "hinweis", "flaeche_ha")}
    for _, r in geb.iterrows():
        d = werte[str(r["name"])]
        gruende, stufe = [], "gruen"
        if d["apl"] > n.get("max_apl_hart", n["max_apl"]):
            stufe, gruende = "rot", gruende + ["{} Adressen > {} hart".format(d["apl"], n.get("max_apl_hart", n["max_apl"]))]
        elif d["apl"] > n["max_apl"]:
            stufe, gruende = "gelb", gruende + ["{} Adressen > {} weich".format(d["apl"], n["max_apl"])]
        if d["snr"] > caps["snr"]:
            stufe, gruende = "rot", gruende + ["{} SNR > {}".format(d["snr"], int(caps["snr"]))]
        if d["pon"] > caps["pon"]:
            stufe, gruende = "rot", gruende + ["{:.1f} PON-Fasern > {}".format(d["pon"], int(caps["pon"]))]
        if d["kassetten"] > caps["kassetten"]:
            stufe, gruende = "rot", gruende + ["{:.0f} Kassetten > {}".format(d["kassetten"], int(caps["kassetten"]))]
        vzk = float(r.get("vzk_max_m") or 0) if "vzk_max_m" in geb else 0.0
        if vzk > n["max_dist_m"]:
            stufe, gruende = "rot", gruende + ["Vzk-Weg {:.0f} m > {} m (Stand des letzten Schnitts)".format(vzk, n["max_dist_m"])]
        if d["we"] > n["max_we"] and stufe != "rot":
            stufe, gruende = "gelb", gruende + ["{} WE > {} weich".format(d["we"], n["max_we"])]
        if n.get("pon_warn") and d["pon"] > n["pon_warn"] and stufe != "rot":
            stufe, gruende = "gelb", gruende + ["{:.1f} PON > {} Koppler Erstausbau".format(d["pon"], int(n["pon_warn"]))]
        if n.get("kassetten_warn") and d["kassetten"] > n["kassetten_warn"] and stufe != "rot":
            stufe, gruende = "gelb", gruende + ["{:.0f} Kassetten > {} Erstausbau".format(d["kassetten"], int(n["kassetten_warn"]))]
        if d["apl"] < n.get("min_apl", 0) and stufe == "gruen":
            stufe, gruende = "gelb", gruende + ["klein: {} Adressen < {}".format(d["apl"], n["min_apl"])]
        if int(r.get("vorgabe") or 0) == 1 if "vorgabe" in geb else False:
            gruende = ["Vorgabe des Planers (gesperrt)"] + gruende
        for c, v in (("apl", d["apl"]), ("we", d["we"]), ("ge", d["ge"]), ("anschluesse", d["anschluesse"]), ("pon_fasern", round(d["pon"], 1)),
                     ("p2p", d["p2p"]), ("snr", d["snr"]), ("kassetten", round(d["kassetten"])), ("hk_fasern", d["hk_fasern"]), ("hk_text", d["hk_text"]),
                     ("ampel", stufe), ("hinweis", "; ".join(gruende)),
                     ("flaeche_ha", round(r.geometry.area / 1e4, 2) if r.geometry is not None and not r.geometry.is_empty else None)):
            aus[c].append(v)
    for c, v in aus.items():
        if c in geb:
            geb[c] = v
    geb.to_file(gpkg, layer="nvt_gebiete", driver="GPKG")
    try:
        sitz = gpd.read_file(gpkg, layer="nvt_sitz")
        sitz["name"] = sitz["name"].astype(str).str.strip()
        ampel_je = dict(zip(geb["name"], aus["ampel"]))
        for c in ("apl", "hk_fasern"):
            if c in sitz:
                sitz[c] = [werte[nm][c] if nm in werte else sitz[c].iat[i] for i, nm in enumerate(sitz["name"])]
        if "ampel" in sitz:
            sitz["ampel"] = [ampel_je.get(nm, sitz["ampel"].iat[i]) for i, nm in enumerate(sitz["name"])]
        sitz.to_file(gpkg, layer="nvt_sitz", driver="GPKG")
    except Exception as e:
        log("nvt_sitz nicht nachgezogen: {}".format(str(e)[:80]))
    log("Kennwerte je Gebiet nachgezogen (ohne Netz): {} Gebiete, Ampel {}".format(len(geb), ", ".join("{} {}".format(aus["ampel"].count(s_), s_) for s_ in ("gruen", "gelb", "rot") if aus["ampel"].count(s_))))
    return int(len(geb))


def zuordnen_aus_polygonen(gpkg, log=print):
    """Planer hat den Layer nvt_gebiete umgezeichnet oder verschmolzen: jede Adresse bekommt das Gebiet, in dem sie liegt.
    Adressen ausserhalb aller Polygone behalten ihr Gebiet. Bei Ueberlappung gilt das kleinste Polygon. -> dict(geaendert, ausserhalb,
    entfallen). Danach nachrechnen(); die Polygone werden dabei aus den Adressen neu abgeleitet (lueckenlos, ueberlappungsfrei)."""
    import geopandas as gpd
    adr = gpd.read_file(gpkg, layer="adressen")
    geb = gpd.read_file(gpkg, layer="nvt_gebiete")
    if adr.crs is None or adr.crs.to_epsg() != CRS:
        adr = adr.set_crs(CRS, allow_override=True)
    if geb.crs is None or geb.crs.to_epsg() != CRS:
        geb = geb.set_crs(CRS, allow_override=True)
    geb = geb[geb.geometry.notna() & ~geb.geometry.is_empty].copy()
    geb["name"] = geb["name"].astype(str).str.strip()
    geb = geb[geb["name"] != ""]
    if not len(geb):
        raise RuntimeError("Layer nvt_gebiete ist leer.")
    geb["_flaeche"] = geb.geometry.area
    alt = adr["nvt"].astype(str).str.strip()
    treffer = gpd.sjoin(adr[["geometry"]].reset_index().rename(columns={"index": "_i"}), geb[["name", "_flaeche", "geometry"]],
                        how="inner", predicate="within")
    treffer = treffer.sort_values("_flaeche").drop_duplicates("_i", keep="first")
    neu = alt.copy()
    for i, n in zip(treffer["_i"], treffer["name"]):
        neu.iat[int(i)] = n
    geaendert = int((neu != alt).sum())
    ausserhalb = int(len(adr) - len(treffer))
    entfallen = sorted(set(alt.unique()) - set(neu.unique()) - {""})
    adr["nvt"] = neu
    _adressen_schreiben(gpkg, adr)
    log("Aus Polygonen uebernommen: {} Adressen umgehaengt, {} ausserhalb aller Polygone (behalten ihr Gebiet){}".format(
        geaendert, ausserhalb, ", entfallen: " + ", ".join(entfallen) if entfallen else ""))
    return {"geaendert": geaendert, "ausserhalb": ausserhalb, "entfallen": entfallen}


def zuordnen_auswahl(gpkg, ids, ziel, log=print):
    """Ausgewaehlte Adressen (Spalte id) in das Gebiet ziel haengen; ziel darf neu sein. -> Anzahl geaendert. Danach nachrechnen()."""
    import geopandas as gpd
    ziel = str(ziel).strip()
    if not ziel:
        raise RuntimeError("Kein Zielgebiet angegeben.")
    adr = gpd.read_file(gpkg, layer="adressen")
    ids = {str(i) for i in ids}
    maske = adr["id"].astype(str).isin(ids)
    alt = adr.loc[maske, "nvt"].astype(str)
    n = int((alt != ziel).sum())
    adr.loc[maske, "nvt"] = ziel
    _adressen_schreiben(gpkg, adr)
    log("Auswahl verschoben: {} von {} Adressen nach '{}'".format(n, int(maske.sum()), ziel))
    return n
