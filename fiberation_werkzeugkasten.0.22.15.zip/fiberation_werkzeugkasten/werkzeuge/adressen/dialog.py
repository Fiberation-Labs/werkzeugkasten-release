# -*- coding: utf-8 -*-
"""Werkzeug 2 - Dialog "Adressen pruefen": Quelle waehlen, pruefen, Layer laden."""
import os
import traceback

from qgis.core import (QgsCategorizedSymbolRenderer, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFillSymbol, QgsGeometry, QgsLineSymbol,
                       QgsMarkerSymbol, QgsPalLayerSettings, QgsPointXY, QgsProject, QgsRectangle, QgsRendererCategory, QgsTextBufferSettings,
                       QgsTextFormat, QgsVectorLayer, QgsVectorLayerSimpleLabeling)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QHeaderView,
                                 QLabel, QLineEdit, QMessageBox, QProgressBar, QPushButton, QRadioButton, QTableWidget, QTableWidgetItem,
                                 QTextEdit, QVBoxLayout)

from ... import ablauf, ci, dateiwahl, layerbaum, tabelle
from ...dialogbasis import WerkzeugDialog
from . import alkis

FARBEN = {"gruen": "#2E8B57", "gelb": "#E0A800", "rot": "#C62828"}
# Status des Planers schlaegt die Ampel in der Karte: geprueft = erledigt (hellgruen), ignoriert = grau
ERLEDIGT = (("geprueft", "#8FC9A4", "geprueft (erledigt)"), ("ignorieren", "#B0B0B0", "ignoriert"))
NUR_OFFEN = "coalesce(\"status\", '') NOT IN ('geprueft', 'ignorieren')"
AMPEL_ODER_ERLEDIGT = "if(" + NUR_OFFEN + ", \"ampel\", \"status\")"


class AdressenDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self.ergebnis = None
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel("adressen").replace("  ", " ", 1))
        self.setMinimumWidth(760)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel("adressen"), "Bedarfsliste gegen ALKIS, Bedarf nach ZTV 21, Bauluecken und fehlende Gebaeude. Nach Plan[Goo] geht es in Schritt 9.")
        lay.addWidget(self.kopf)

        # --- Quelle und Optionen in einem Block -------------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Quelle"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(6)
        g.addWidget(QLabel("Bedarfsliste (CSV) oder Angebotslayer:"), 0, 0)
        self.feld = QLineEdit()
        self.feld.setPlaceholderText("Telekom-Bedarfsliste (CSV) oder MBfD-Angebotslayer (Plan[Goo] .gpkg) hineinziehen oder waehlen ...")
        g.addWidget(self.feld, 0, 1, 1, 3)
        w = QPushButton("Waehlen")
        w.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        w.clicked.connect(self._waehlen)
        g.addWidget(w, 0, 4)
        g.addWidget(QLabel("Ausgabeordner:"), 1, 0)
        self.out = QLineEdit()
        self.out.setPlaceholderText("leer = neben der Eingangsdatei")
        g.addWidget(self.out, 1, 1, 1, 3)
        o = QPushButton("Waehlen")
        o.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        o.clicked.connect(self._out_waehlen)
        g.addWidget(o, 1, 4)
        self.h_alkis = QCheckBox("ALKIS-Gebaeude und Flurstuecke abrufen (WFS Landesvermessung)")
        self.h_alkis.setChecked(True)
        g.addWidget(self.h_alkis, 2, 1, 1, 2)
        lz = QHBoxLayout()
        lz.addStretch(1)
        lz.addWidget(QLabel("Land:"))
        self.land = QComboBox()
        self.land.addItem("automatisch", "")
        for k in sorted(alkis.LAENDER, key=lambda x: alkis.LAENDER[x]):
            self.land.addItem("{} ({})".format(alkis.LAENDER[k], k), k)
        self.land.setMinimumWidth(200)
        lz.addWidget(self.land)
        g.addLayout(lz, 2, 3, 1, 2)
        g.setColumnStretch(1, 2)
        g.setColumnStretch(3, 1)
        lay.addLayout(g)

        # --- Aktionen: Pruefen, Ergebnis laden, Bericht, Protokoll ----------------------------------------------------------------------
        knoepfe = QHBoxLayout()
        self.k_start = QPushButton("Pruefen")
        self.k_start.setStyleSheet(ci.STIL_KNOPF)
        self.k_start.setCursor(Qt.PointingHandCursor)
        self.k_start.clicked.connect(self._start)
        knoepfe.addWidget(self.k_start)
        self.k_abbruch = QPushButton("Abbrechen")
        self.k_abbruch.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_abbruch.setEnabled(False)
        self.k_abbruch.setToolTip("Laufende Pruefung (ALKIS-Abruf) beenden - halb geschriebene Ergebnisdateien werden geloescht")
        self.k_abbruch.clicked.connect(self._abbrechen)
        knoepfe.addWidget(self.k_abbruch)
        self.k_laden = dateiwahl.ErgebnisKnopf("adresspruefung", self._ergebnis_setzen, "Adresspruefung (GeoPackage) waehlen",
                                               stil=ci.STIL_KNOPF_ZWEIT)
        knoepfe.addWidget(self.k_laden)
        self.k_bericht = QPushButton("Bericht oeffnen")
        self.k_bericht.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_bericht.setEnabled(False)
        self.k_bericht.clicked.connect(self._bericht)
        knoepfe.addWidget(self.k_bericht)
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.setToolTip("Protokoll des Laufs ein- und ausblenden; bei Fehlern klappt es von selbst auf")
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        knoepfe.addWidget(self.k_log)
        knoepfe.addStretch(1)
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, "w1"))
        knoepfe.addWidget(hilfe)
        schl = QPushButton("Schliessen")
        self.k_schliessen = schl
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.close)
        knoepfe.addWidget(schl)
        lay.addLayout(knoepfe)
        self.setAcceptDrops(True)

        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setValue(0)
        self.balken.setTextVisible(True)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(120)
        self.log.setMaximumHeight(180)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log)

        # --- Pruefliste: das eigentliche Arbeitsfeld, bekommt den Platz ------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Pruefliste - gelbe und rote Adressen, Bauluecken, fehlender Bedarf"))
        pf = QHBoxLayout()
        pf.addWidget(QLabel("Zeigen:"))
        self.pf_filter = QComboBox()
        for text, wert in (("rot und gelb, offen", "offen"), ("neu hinzugefuegt, offen (Plan[Goo]-Begruendung)", "neu"), ("nur rot, offen", "rot"),
                           ("nur gelb, offen", "gelb"), ("nur mit Vorschlag", "vorschlag"),
                           ("nur Bauluecken und fehlender Bedarf, offen", "kandidaten"), ("alle rot/gelb (auch erledigt)", "alle"),
                           ("aufgenommene Bauluecken und fehlender Bedarf", "aufgenommen"), ("anders verortete Adressen (Vorschlag uebernommen)", "verortet"),
                           ("geaenderte Adressen (Plan[Goo]-Begruendung)", "geaendert")):
            self.pf_filter.addItem(text, wert)
        self.pf_filter.currentIndexChanged.connect(lambda *_: self._pruefliste_fuellen())
        pf.addWidget(self.pf_filter)
        self.pf_zahl = QLabel("")
        self.pf_zahl.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        pf.addWidget(self.pf_zahl, 1)
        self.k_xls = QPushButton("Nach Excel")
        self.k_xls.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_xls.setToolTip("Die Zeilen des gewaehlten Filters als Excel-Liste (Adresse, Ampel, Hinweise, Status, Kommentar, alte und neue Lage, Quelle) "
                              "neben dem Ergebnis ablegen und oeffnen - z. B. aufgenommene Bauluecken oder anders verortete Adressen fuer die Telekom")
        self.k_xls.setEnabled(False)
        self.k_xls.clicked.connect(self._pruefliste_excel)
        pf.addWidget(self.k_xls)
        self.k_ign = QPushButton("Ignorieren")
        self.k_ign.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_ign.setToolTip("Markierte Zeilen ausblenden: status ignorieren (Adressen wie Kandidaten)")
        self.k_ign.clicked.connect(lambda: self._pruefliste_aktion("ignorieren"))
        self.k_off = QPushButton("Wieder offen")
        self.k_off.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_off.clicked.connect(lambda: self._pruefliste_aktion("offen"))
        pf.addWidget(self.k_ign)
        pf.addWidget(self.k_off)
        lay.addLayout(pf)
        # Markus 12.10.: gemeinsame Tabelle (Sortieren, Filter, Spalten, Kartenauswahl in beide Richtungen, Zoom/Blinken, Kopieren, Zaehler)
        self.tabelle = tabelle.Tabelle("adressen_pruefliste", ["Ampel", "Adresse", "Hinweise", "Lagevorschlag", "m", "Status"], self.iface)
        self.tabelle.layer_finder(self._pf_layer)
        for si, b in enumerate((56, 190, 260, 220, 40, 70)):
            self.tabelle.setColumnWidth(si, b)
        self.tabelle.setMinimumHeight(260)
        self.tabelle.itemDoubleClicked.connect(lambda *_: self.tabelle.zoom())
        # Markus 12.10.: Zeile anwaehlen zoomt hin und laesst den Punkt blinken (abschaltbar mit dem Haken "automatisch")
        self.tabelle.itemSelectionChanged.connect(self._pf_auswahl_geaendert)
        lay.addWidget(self.tabelle, 1)
        # Aktionen in zwei Gruppen: Lage (links) und Entscheidung (rechts)
        pk = QHBoxLayout()
        self.cb_auto = QCheckBox("beim Anwaehlen hinzoomen")
        self.cb_auto.setChecked(True)
        self.cb_auto.setToolTip("Beim Anwaehlen einer Zeile sofort hinzoomen und blinken lassen")
        self.k_vor = QPushButton("Vorschlag uebernehmen")
        self.k_vor.setStyleSheet(ci.STIL_KNOPF)
        self.k_vor.setToolTip("Lage auf den orangen Vorschlagspunkt setzen, status geprueft, alte Lage im Kommentar")
        self.k_vor.clicked.connect(lambda: self._pruefliste_aktion("vorschlag"))
        self.k_gep = QPushButton("Lage stimmt")
        self.k_gep.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_gep.setToolTip("Adresse bleibt, wo sie ist: status geprueft")
        self.k_gep.clicked.connect(lambda: self._pruefliste_aktion("geprueft"))
        self.k_auf = QPushButton("In Adressen aufnehmen")
        self.k_auf.setStyleSheet(ci.STIL_KNOPF)
        self.k_auf.setToolTip("Rote Zeilen 'Bauluecke:' und 'Fehlt:' als neue Adresse anlegen - mit allem, was Plan[Goo] braucht "
                              "(Adresse, PLZ/Ort, ONKZ/ASB, WE, Gebaeudenutzung, Begruendung); nach Plan[Goo] erst in Kachel 9")
        self.k_auf.clicked.connect(lambda: self._pruefliste_aktion("aufnehmen"))
        for b in (self.cb_auto, self.k_vor, self.k_gep, self.k_auf):
            b.setEnabled(False)
            pk.addWidget(b)
        pk.addStretch(1)
        for b in (self.k_ign, self.k_off):
            b.setEnabled(False)
        lay.addLayout(pk)
        hinweis = QLabel("Zeile anwaehlen zoomt zur Adresse und ihrem Vorschlag und laesst den Punkt blinken (Haken; sonst Doppelklick, Hinzoomen oder "
                         "Blinken ueber der Tabelle). Auswahl in Karte und Liste laeuft synchron. Spalten sortieren, filtern, ziehen, ausblenden. "
                         "Mehrere Zeilen mit Strg und Umschalt. Jede Aktion schreibt in das GeoPackage und laedt die Layer neu.")
        hinweis.setWordWrap(True)
        hinweis.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        lay.addWidget(hinweis)
        from ... import fenster
        fenster.einrichten(self, "adressen", 760)

    # --- Drag und Drop -------------------------------------------------------------------------------------------------------------------
    def _datei_fallen_gelassen(self, p):
        if p.lower().endswith((".csv", ".txt", ".gpkg")):
            self.feld.setText(p)
            return True
        return False

    # --- Bedienung ---------------------------------------------------------------------------------------------------------------------
    def _waehlen(self):
        p = dateiwahl.datei_waehlen(self, "Bedarfsliste oder Angebotslayer waehlen", "Bedarfsliste oder Angebotslayer (*.csv *.CSV *.gpkg);;Bedarfsliste (*.csv *.CSV);;Angebotslayer Plan[Goo] (*.gpkg);;Alle Dateien (*.*)", "bedarfsliste",
                                    self.feld.text())
        if p:
            self.feld.setText(p)

    def _out_waehlen(self):
        p = dateiwahl.ordner_waehlen(self, "Ausgabeordner waehlen", "ausgabe", self.out.text())
        if p:
            self.out.setText(p)

    def _start(self):
        """Pruefung im Kindprozess (ALKIS-Abruf dauert Minuten; QGIS bleibt bedienbar, Markus 12.10. Punkt 5)."""
        from ... import hintergrund
        p = self.feld.text().strip().strip('"')
        if not p or not os.path.exists(p):
            self._log("Eingangsdatei (Bedarfsliste oder Angebotslayer) nicht gefunden.")
            self.k_log.setChecked(True)
            return
        self.log.clear()
        self.k_start.setEnabled(False)
        self.k_abbruch.setEnabled(True)
        out_dir = dateiwahl.ausgabeordner(self.out.text())
        hintergrund.starten(self, "Adressen pruefen", "werkzeuge.adressen.kern", "lauf", [p],
                            {"out_dir": out_dir, "land": self.land.currentData() or None, "mit_alkis": self.h_alkis.isChecked()},
                            self._start_fertig, aufraeumen=(out_dir, "adresspruefung_*.gpkg"))

    def _start_fertig(self, r, fehler, rv):
        self.k_start.setEnabled(True)
        self.k_abbruch.setEnabled(False)
        if fehler is not None:
            return self._lauf_fehler("Adressen pruefen - Fehler", fehler, rv)
        self.ergebnis = r
        dateiwahl.merken("adresspruefung", r["gpkg"])  # Werkzeug 3 findet die Datei dann sofort
        self._layer_laden(r)
        self._pruefliste_fuellen()
        self.k_bericht.setEnabled(True)
        self._log("Fertig. Ampel im Layer 'Adressen' bearbeiten (Spalten status, kommentar), Bericht ueber den Knopf, "
                  "danach 'Nach Plan[Goo] uebernehmen'.")
        z = r["zahlen"]
        neu = ("Neu laut Plan[Goo]-Begruendung: {} (gelb, Hinweis 'neu', Filter 'neu hinzugefuegt', Layer 'Neu in Plan[Goo]')\n".format(z["neu"])
               if z.get("neu") else "")
        QMessageBox.information(self, "Adressen pruefen - fertig",
                                "{} Adressen geprueft.\n\ngruen {}   gelb {}   rot {}   (davon {} mit Lagevorschlag)\n{}"
                                "Adressen ohne Gebaeude: {}\n"
                                "Fehlender Bedarf (ALKIS-Adresse nicht in der Liste): {}  -  {} Luecke in der Nummernfolge, {} Strasse in der Liste, {} am Rand\n"
                                "Moegliche Bauluecken (unbebaute Bauflaechen-Flurstuecke): {}  -  {} zwischen bebauten Nachbarn, {} Eck/Rand\n"
                                "FTTH-Anschluesse nach ZTV 21: {}   SNR: {}\n\nLayer sind geladen: {}\n\n"
                                "Naechster Schritt: Pruefliste unten - gelbe/rote Adressen und die roten Kandidaten 'Bauluecke:' / 'Fehlt:' "
                                "(In Adressen aufnehmen oder Ignorieren). Nach Plan[Goo] geht alles in Kachel 9.".format(
                                    z["adressen"], z["gruen"], z["gelb"], z["rot"], z["vorschlag"], neu, z["bauluecke"], z["fehlend"], z["fehlend_hoch"],
                                    z["fehlend_mittel"], z["fehlend_niedrig"], z["bauluecken"], z["bl_hoch"], z["bl_mittel"], z["anschluesse"], z["snr"],
                                    os.path.basename(r["gpkg"])))

    def _bericht(self):
        if self.ergebnis and os.path.exists(self.ergebnis["bericht"]):
            import subprocess
            subprocess.Popen(["cmd", "/c", "start", "", self.ergebnis["bericht"]], shell=False)

    # --- Pruefliste --------------------------------------------------------------------------------------------------------------------
    def _callout_label(self, lyr):
        """Label am Vorschlagspunkt: Adresse, Vorschlagstext - der Callout des Planers."""
        st = QgsPalLayerSettings()
        st.fieldName = "concat(\"adresse\", '\\n', 'Vorschlag: ', \"vorschlag_text\")"
        st.isExpression = True
        st.enabled = True
        st.scaleVisibility = True
        st.minimumScale = 4000
        st.maximumScale = 0
        st.multilineAlign = QgsPalLayerSettings.MultiLeft if hasattr(QgsPalLayerSettings, "MultiLeft") else 0
        try:
            st.placement = QgsPalLayerSettings.OrderedPositionsAroundPoint
            st.dist = 2.0
        except Exception:
            pass
        fmt = QgsTextFormat()
        fmt.setSize(7.5)
        fmt.setColor(QColor(ci.ORANGE_DUNKEL))
        f = fmt.font()
        f.setBold(True)
        fmt.setFont(f)
        puffer = QgsTextBufferSettings()
        puffer.setEnabled(True)
        puffer.setSize(0.9)
        puffer.setColor(QColor("#FFFFFF"))
        fmt.setBuffer(puffer)
        st.setFormat(fmt)
        lyr.setLabelsEnabled(True)
        lyr.setLabeling(QgsVectorLayerSimpleLabeling(st))

    def _ergebnis_setzen(self, p):
        """Vorhandene Adresspruefung (GeoPackage) uebernehmen: Layer, Pruefliste, Knoepfe."""
        dateiwahl.merken("adresspruefung", p)
        try:
            import pyogrio
            namen = pyogrio.list_layers(p)[:, 0].tolist()
        except Exception:
            namen = ["adressen"]
        self.ergebnis = {"gpkg": p, "bericht": os.path.splitext(p)[0] + "_bericht.md", "layer": [(n, 0) for n in namen]}
        self.k_bericht.setEnabled(os.path.exists(self.ergebnis["bericht"]))
        self._log("Ergebnis geladen: " + p)
        self._pruefliste_fuellen()
        self._layer_laden(self.ergebnis)

    def _pf_layer(self, schl):
        """Kartenbezug der Pruefliste: Layer 'Adressen' der aktuellen Adresspruefung (wird bei jeder Aktion neu angelegt)."""
        if not self.ergebnis:
            return None
        for l in QgsProject.instance().mapLayers().values():
            try:
                if l.source().split("|")[0].lower() == self.ergebnis["gpkg"].lower() and layerbaum.ohne_nummer(l.name()) == "Adressen":
                    return l
            except Exception:
                continue
        return None

    def _pruefliste_fuellen(self):
        from . import kern
        self.tabelle.leeren()
        self._pf_zeilen = []
        if not self.ergebnis or not os.path.exists(self.ergebnis["gpkg"]):
            self.pf_zahl.setText("")
            return
        try:
            adr, _ = kern.pruefliste_lesen(self.ergebnis["gpkg"])
        except Exception as e:
            self._log("Pruefliste nicht lesbar: {!r}".format(e))
            return
        f = self.pf_filter.currentData()
        if f in kern.AUSWAHL_FILTER:
            sel = kern.pruefliste_auswahl(adr, f)
        else:
            sel = adr[adr["ampel"].isin(["gelb", "rot"])]
        if f in ("offen", "rot", "gelb", "vorschlag", "neu"):
            sel = sel[sel["status"] == "offen"]
        if f in ("rot", "gelb"):
            sel = sel[sel["ampel"] == f]
        if f == "vorschlag":
            sel = sel[sel["vorschlag_x"].notna()]
        if f == "kandidaten":
            sel = sel.iloc[0:0]
        sel = sel.sort_values(["ampel", "strasse", "hnr"], key=lambda c: c.map({"rot": 0, "gelb": 1, "gruen": 2}) if c.name == "ampel" else c)
        # Kandidaten (Bauluecken, fehlender Bedarf) als rote Zeilen davor (Markus 17.09.)
        kand = None
        if f in ("offen", "rot", "kandidaten", "alle"):
            try:
                kand = kern.kandidaten_lesen(self.ergebnis["gpkg"])
            except Exception as e:
                self._log("Kandidaten nicht lesbar: {!r}".format(e))
            if kand is not None and len(kand):
                if f != "alle":
                    kand = kand[kand["status"] == "offen"]
                kand = kand.sort_values(["art", "prioritaet", "strasse", "hnr"], key=lambda c: c.map({"hoch": 0, "mittel": 1, "niedrig": 2}) if c.name == "prioritaet" else c)
        n_k = 0 if kand is None else len(kand)
        self.tabelle.setRowCount(len(sel) + n_k)
        for zi, (_, k) in enumerate(kand.iterrows() if n_k else []):
            werte = ["rot", str(k["adresse"]), str(k["hinweise"]), "-", "", str(k["status"])]
            for si, w in enumerate(werte):
                it = QTableWidgetItem(w)
                if si == 0:
                    it.setForeground(QColor(FARBEN["rot"]))
                    it.setText("ROT")
                self.tabelle.setItem(zi, si, it)
            x, y = k.get("x"), k.get("y")
            xy = (float(x), float(y)) if x is not None and x == x and y is not None and y == y else None
            self._pf_zeilen.append({"uid": None, "kid": str(k["kid"]), "xy": xy, "vxy": None, "hnr": str(k.get("hnr") or "")})
            self.tabelle.karte_setzen(zi, xy=xy)
        for zi, (_, r) in enumerate(sel.iterrows(), start=n_k):
            vm = r.get("lage_verschoben_m") if f == "verortet" else r.get("vorschlag_m")
            vm = "" if vm is None or (isinstance(vm, float) and vm != vm) else "{:.0f}".format(float(vm))
            lage = str(r.get("kommentar") or "-") if f in ("verortet", "aufgenommen") else str(r.get("vorschlag_text") or "-")
            werte = [str(r["ampel"]), kern._adresse(r), str(r.get("hinweise") or ""), lage, vm, str(r.get("status") or "offen")]
            for si, w in enumerate(werte):
                it = QTableWidgetItem(w)
                if si == 0:
                    it.setForeground(QColor(FARBEN.get(w, "#333333")))
                    it.setText({"rot": "ROT", "gelb": "gelb"}.get(w, w))
                self.tabelle.setItem(zi, si, it)
            x, y = r.get("vorschlag_x"), r.get("vorschlag_y")
            g = r.geometry if r.geometry is not None and not isinstance(r.geometry, float) else None
            self._pf_zeilen.append({"uid": str(r["uid"]), "kid": None, "xy": (g.x, g.y) if g is not None else None,
                                    "vxy": (float(x), float(y)) if x is not None and x == x else None})
            self.tabelle.karte_setzen(zi, xy=[self._pf_zeilen[-1]["xy"], self._pf_zeilen[-1]["vxy"]], bezug=("adressen", {"uid": str(r["uid"])}))
        self.tabelle.fertig()
        z = adr[adr["ampel"].isin(["gelb", "rot"])]
        n_neu = len(kern.pruefliste_auswahl(adr, "neu"))
        self.pf_zahl.setText("{} Zeilen | Adressen: {} rot, {} gelb, davon {} offen, {} mit Vorschlag | Kandidaten (Bauluecke/fehlt) offen: {} | aufgenommen {} | anders verortet {}{}".format(
            len(sel) + n_k, int((z["ampel"] == "rot").sum()), int((z["ampel"] == "gelb").sum()), int((z["status"] == "offen").sum()),
            int(z["vorschlag_x"].notna().sum()), n_k if f != "alle" else int((kand["status"] == "offen").sum()) if n_k else 0,
            len(kern.pruefliste_auswahl(adr, "aufgenommen")), len(kern.pruefliste_auswahl(adr, "verortet")),
            " | neu (Plan[Goo]) {}".format(n_neu) if n_neu else ""))
        for b in (self.cb_auto, self.k_vor, self.k_gep, self.k_auf, self.k_ign, self.k_off, self.k_xls):
            b.setEnabled(True)

    def _pruefliste_excel(self):
        from . import kern
        if not self.ergebnis:
            return
        try:
            f = self.pf_filter.currentData()
            p = kern.pruefliste_export(self.ergebnis["gpkg"], f, out_dir=dateiwahl.ausgabeordner(self.out.text()), log=self._log)
            self._log("Excel geschrieben: " + p)
            import subprocess
            subprocess.Popen(["cmd", "/c", "start", "", p], shell=False)
        except Exception as e:
            self._log("Excel-Export: {!r}".format(e))
            QMessageBox.critical(self, "Nach Excel", "{!r}".format(e)[:500])

    def _pf_auswahl(self):
        return [self._pf_zeilen[i] for i in self.tabelle.auswahl_indizes() if i < len(self._pf_zeilen)]

    def _pf_auswahl_geaendert(self):
        # Markus 12.10.: Anwaehlen in der Liste = hinzoomen + blinken (Haken); Zoom und Blinken liefert die gemeinsame Tabelle
        if not self.cb_auto.isChecked() or not self.tabelle.auswahl_indizes():
            return
        self.tabelle.zoom()

    def _pruefliste_aktion(self, aktion):
        from . import kern
        aus = self._pf_auswahl()
        if not aus or not self.ergebnis:
            QMessageBox.information(self, "Pruefliste", "Erst Zeilen in der Pruefliste markieren.")
            return
        kids = [z["kid"] for z in aus if z.get("kid")]
        aus_adr = [z for z in aus if z.get("uid")]
        uids = [z["uid"] for z in aus_adr]
        if aktion == "vorschlag":
            ohne = [z for z in aus_adr if not z["vxy"]]
            if ohne:
                QMessageBox.information(self, "Pruefliste", "{} markierte Adressen haben keinen Vorschlag - sie bleiben unveraendert.".format(len(ohne)))
            uids = [z["uid"] for z in aus_adr if z["vxy"]]
        if aktion in ("vorschlag", "geprueft") and kids:
            QMessageBox.information(self, "Pruefliste", "Bauluecken und fehlender Bedarf haben keine Lage zu bestaetigen - fuer sie gilt "
                                    "'In Adressen aufnehmen' oder 'Ignorieren'. {} Kandidaten bleiben unveraendert.".format(len(kids)))
            kids = []
        if aktion == "aufnehmen":
            if uids:
                QMessageBox.information(self, "Pruefliste", "'In Adressen aufnehmen' gilt nur fuer die roten Zeilen 'Bauluecke:' und 'Fehlt:'. "
                                        "{} Adresszeilen bleiben unveraendert.".format(len(uids)))
            uids = []
            if not kids:
                return
            hnr, we = None, None
            if len(kids) == 1:
                from qgis.PyQt.QtWidgets import QInputDialog
                vor = aus[0].get("hnr") or ""
                h, ok = QInputDialog.getText(self, "In Adressen aufnehmen", "Hausnummer (leer lassen, wenn unbekannt):", text=vor)
                if not ok:
                    return
                hnr = h.strip() or None
                w, ok = QInputDialog.getInt(self, "In Adressen aufnehmen", "Wohneinheiten (Annahme fuer die Planung):", 1, 0, 500)
                if not ok:
                    return
                we = w or 1
            else:
                if QMessageBox.question(self, "In Adressen aufnehmen", "{} Kandidaten mit vorgeschlagener Hausnummer (sonst leer) und 1 WE aufnehmen? "
                                        "Hausnummer und WE lassen sich danach im Layer Adressen aendern.".format(len(kids))) != QMessageBox.Yes:
                    return
        if not uids and not kids:
            return
        try:
            lyr_adr = None
            for l in QgsProject.instance().mapLayers().values():
                if l.source().split("|")[0].lower() == self.ergebnis["gpkg"].lower() and layerbaum.ohne_nummer(l.name()) == "Adressen":
                    lyr_adr = l
            if lyr_adr is not None and lyr_adr.isEditable():
                if lyr_adr.isModified():
                    lyr_adr.commitChanges()
                    self._log("Layer 'Adressen' gespeichert.")
                else:
                    lyr_adr.rollBack()
            n = kern.pruefliste_aendern(self.ergebnis["gpkg"], uids, aktion, log=self._log) if uids else 0
            n_k = 0
            if kids:
                if aktion == "aufnehmen":
                    n_k = kern.kandidaten_aufnehmen(self.ergebnis["gpkg"], kids, hnr=hnr, we=we, log=self._log)
                else:
                    n_k = kern.kandidaten_status(self.ergebnis["gpkg"], kids, aktion, log=self._log)
            self._layer_laden(self.ergebnis)
            self._pruefliste_fuellen()
            if uids:
                self._log("{} Adressen: {}".format(n, {"vorschlag": "Lage vom Vorschlag uebernommen, geprueft", "geprueft": "als geprueft markiert",
                                                      "ignorieren": "ignoriert", "offen": "wieder offen"}.get(aktion, aktion)))
            if kids:
                self._log("{} Kandidaten: {}".format(n_k, {"aufnehmen": "in den Layer Adressen aufgenommen (gelb, geprueft, Begruendung fuer Plan[Goo] gesetzt)",
                                                          "ignorieren": "ignoriert", "offen": "wieder offen"}.get(aktion, aktion)))
        except Exception as e:
            self._log("Fehler: {!r}".format(e))
            self._log(traceback.format_exc()[-1200:])
            QMessageBox.critical(self, "Pruefliste - Fehler", "{!r}".format(e)[:500])

    # --- Layer -------------------------------------------------------------------------------------------------------------------------
    def _layer_laden(self, r):
        gpkg = r["gpkg"]
        gruppe = layerbaum.gruppe("adressen", "Adresspruefung {}".format(os.path.basename(gpkg).replace("adresspruefung_", "").replace(".gpkg", "")))
        for lname, _ in r["layer"]:
            if "CSV" in lname:
                continue
            lyr = QgsVectorLayer("{}|layername={}".format(gpkg, lname), {"adressen": "Adressen", "bauluecken": "Adressen ohne Gebaeude",
                                                                          "fehlender_bedarf": "Fehlender Bedarf (ALKIS-Adresse nicht in der Liste)",
                                                                          "bauluecken_moeglich": "Bauluecke moeglich (unbebautes Bauflaechen-Flurstueck)",
                                                                          "gebaeude_ohne_adresse": "Gebaeude ohne Adresse (auch in ALKIS)",
                                                                          "alkis_gebaeude": "ALKIS-Gebaeude", "vorschlaege": "Lagevorschlag (Callout)",
                                                                          "neue_adressen": "Neu in Plan[Goo] (Begruendung)",
                                                                          "vorschlag_linien": "Lagevorschlag Linie"}.get(lname, lname), "ogr")
            if not lyr.isValid():
                self._log("Layer nicht ladbar: " + lname)
                continue
            lyr.setCrs(QgsCoordinateReferenceSystem("EPSG:25832"))
            if lname == "adressen":
                self._ampel_stil(lyr)
            elif lname == "neue_adressen":
                # Phillip 26.10.: neu hinzugefuegte APL getrennt sehen - gelber Ring um den Ampelpunkt, Callout "NEU" mit der Begruendung
                # erledigte (Lage stimmt, Ignorieren) ohne Ring und Label - ueber den Renderer, nicht per Subset: ein Subset haelt die gpkg offen,
                # und das Neuschreiben nach jeder Prueflisten-Aktion bricht dann ab ("unable to open database file")
                ring = QgsMarkerSymbol.createSimple({"name": "circle", "color": "255,255,255,0", "outline_color": FARBEN["gelb"],
                                                     "outline_width": "1.0", "size": "5.5"})
                lyr.setRenderer(QgsCategorizedSymbolRenderer("if(" + NUR_OFFEN + ", 'offen', 'erledigt')",
                                                             [QgsRendererCategory("offen", ring, "neu, offen")]))
                ci.label_kasten(lyr, ("if(" + NUR_OFFEN + ", concat('<div><span style=\"color:#1A1A1A\"><b>NEU ', coalesce(\"strasse\", ''), ' ', "
                                      "coalesce(\"hnr\", ''), coalesce(\"hnr_zs\", ''), '</b></span></div>', "
                                      "'<div><span style=\"color:#333333\">', coalesce(\"begruendung\", ''), ', ', coalesce(\"we\", 0), ' WE</span></div>'), NULL)"),
                                groesse=7, rahmen=FARBEN["gelb"], farbe_text="#333333", min_massstab=3000, abstand_mm=1.5)
            elif lname == "bauluecken":
                lyr.setRenderer(lyr.renderer())
                sym = QgsMarkerSymbol.createSimple({"name": "square", "color": "255,255,255,0", "outline_color": "#7B1FA2", "outline_width": "0.8", "size": "4.5"})
                lyr.renderer().setSymbol(sym)
            elif lname == "fehlender_bedarf":
                # Markus 17.09.: Wannen 102 - Gebaeude mit ALKIS-Adresse, das in der Liste fehlt. Rot = Luecke in der Nummernfolge,
                # orange = Strasse in der Liste, grau = am Rand. Callout wie beim Lagevorschlag, damit der Planer es beim Durchsehen sieht.
                kats = [QgsRendererCategory("hoch", QgsFillSymbol.createSimple({"color": "198,40,40,140", "outline_color": "#C62828", "outline_width": "0.7"}),
                                            "hoch: Luecke in der Nummernfolge"),
                        QgsRendererCategory("mittel", QgsFillSymbol.createSimple({"color": "245,167,62,110", "outline_color": ci.ORANGE_DUNKEL, "outline_width": "0.5"}),
                                            "mittel: Strasse in der Liste, Nachbarn fehlen auch"),
                        QgsRendererCategory("niedrig", QgsFillSymbol.createSimple({"color": "158,158,158,60", "outline_color": "#9E9E9E", "outline_width": "0.4"}),
                                            "niedrig: am Rand, meist anderes Gebiet")]
                lyr.setRenderer(QgsCategorizedSymbolRenderer("prioritaet", kats))
                lyr.setSubsetString("\"status\" = 'offen' OR \"status\" IS NULL OR \"status\" = ''")
                ci.label_kasten(lyr, ("concat('<div><span style=\"color:#1A1A1A\"><b>', coalesce(\"adresse\", ''), '</b></span></div>', "
                                      "'<div><span style=\"color:#333333\">fehlt in der Bedarfsliste (', coalesce(\"funktion\", ''), ', ', "
                                      "coalesce(\"flaeche_m2\", 0), ' m2)</span></div>')"),
                                groesse=7, rahmen=ci.farb_ausdruck("prioritaet", {"hoch": "#C62828", "mittel": ci.ORANGE_DUNKEL, "niedrig": "#9E9E9E"}),
                                farbe_text="#333333", min_massstab=3000, polygon=True)
            elif lname == "bauluecken_moeglich":
                # Markus 17.09.: unbebaute Bauflaechen-Flurstuecke; violett wie die Adressen ohne Gebaeude, Callout mit Strasse/Nummer/Nachbarn
                kats = [QgsRendererCategory("hoch", QgsFillSymbol.createSimple({"color": "123,31,162,130", "outline_color": "#7B1FA2", "outline_width": "0.8"}),
                                            "hoch: zwischen bebauten Nachbarn"),
                        QgsRendererCategory("mittel", QgsFillSymbol.createSimple({"color": "123,31,162,95", "outline_color": "#7B1FA2", "outline_width": "0.8",
                                                                                  "outline_style": "dash"}), "mittel: Eck- oder Randgrundstueck")]
                lyr.setRenderer(QgsCategorizedSymbolRenderer("prioritaet", kats))
                lyr.setSubsetString("\"status\" = 'offen' OR \"status\" IS NULL OR \"status\" = ''")
                ci.label_kasten(lyr, ("concat('<div><span style=\"color:#1A1A1A\"><b>Bauluecke moeglich: ', coalesce(\"strasse\", ''), ' ', "
                                      "coalesce(\"hnr\", ''), '</b></span></div>', "
                                      "'<div><span style=\"color:#333333\">', coalesce(\"nutzung\", ''), ', ', coalesce(\"flaeche_m2\", 0), ' m2, Nachbarn ', "
                                      "coalesce(\"nachbarn\", ''), '</span></div>')"),
                                groesse=7, rahmen="#7B1FA2", farbe_text="#333333", min_massstab=3000, polygon=True)
            elif lname == "gebaeude_ohne_adresse":
                kats = [QgsRendererCategory("hoch", QgsFillSymbol.createSimple({"color": "198,40,40,70", "outline_color": "#C62828", "outline_width": "0.4", "outline_style": "dash"}), "hoch (Wohnen)"),
                        QgsRendererCategory("mittel", QgsFillSymbol.createSimple({"color": "224,168,0,50", "outline_color": "#E0A800", "outline_width": "0.4", "outline_style": "dash"}), "mittel (Gewerbe u. a.)")]
                lyr.setRenderer(QgsCategorizedSymbolRenderer("prioritaet", kats))
            elif lname == "alkis_gebaeude":
                lyr.renderer().setSymbol(QgsFillSymbol.createSimple({"color": "158,158,158,51", "outline_color": "#9E9E9E", "outline_width": "0.2"}))
            elif lname == "vorschlaege":
                lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({"name": "circle", "color": "255,255,255,0", "outline_color": ci.ORANGE,
                                                                       "outline_width": "0.9", "size": "4.5"}))
                self._callout_label(lyr)
            elif lname == "vorschlag_linien":
                lyr.renderer().setSymbol(QgsLineSymbol.createSimple({"color": ci.ORANGE, "width": "0.6", "line_style": "dash"}))
            layerbaum.einhaengen(gruppe, lyr, "adressen", sichtbar=lname not in ("alkis_gebaeude", "gebaeude_ohne_adresse"))
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def _ampel_stil(self, lyr):
        # Phillip 26.10.: erledigte Zeilen (Lage stimmt / Vorschlag uebernommen = geprueft, Ignorieren) nicht mehr in Ampelfarbe und ohne
        # Label - die Ampel-Spalte bleibt der Pruefbefund, die Karte zeigt, was noch offen ist
        kats = []
        for wert, farbe in FARBEN.items():
            sym = QgsMarkerSymbol.createSimple({"name": "circle", "color": farbe, "outline_color": "#FFFFFF", "outline_width": "0.3", "size": "3.2"})
            kats.append(QgsRendererCategory(wert, sym, wert))
        for wert, farbe, text in ERLEDIGT:
            sym = QgsMarkerSymbol.createSimple({"name": "circle", "color": farbe, "outline_color": "#FFFFFF", "outline_width": "0.3", "size": "2.6"})
            kats.append(QgsRendererCategory(wert, sym, text))
        lyr.setRenderer(QgsCategorizedSymbolRenderer(AMPEL_ODER_ERLEDIGT, kats))
        # Label: Adresse fett, darunter die Hinweise, im weissen Kasten mit Ampelrahmen (Markus 16.09.), ab 1:3000 sichtbar; nur offene Zeilen
        ci.label_kasten(lyr, ("if(" + NUR_OFFEN + ", concat('<div><span style=\"color:#1A1A1A\"><b>', coalesce(\"strasse\", ''), ' ', "
                              "coalesce(\"hnr\", ''), coalesce(\"hnr_zs\", ''), '</b></span></div>', "
                              "if(coalesce(\"hinweise\", '') <> '', '<div><span style=\"color:#333333\">' || \"hinweise\" || '</span></div>', '')), NULL)"),
                        groesse=7, rahmen=ci.farb_ausdruck("ampel", FARBEN), farbe_text="#333333", min_massstab=3000, abstand_mm=1.5)
