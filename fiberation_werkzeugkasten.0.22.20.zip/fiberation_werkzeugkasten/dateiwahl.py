# -*- coding: utf-8 -*-
"""Dateiwahl: die GeoPackages der Werkzeuge wiederfinden, ohne im Dateidialog zu suchen.

Jedes Werkzeug merkt sich seine Ausgabe und seine Eingaben (merken). Das Feld DateiFeld ist beim Oeffnen mit der juengsten
passenden Datei vorbelegt und klappt eine Liste auf: zuletzt benutzte Dateien, im QGIS-Projekt geladene GeoPackages und die
neuesten Treffer in den bekannten Ordnern (Plan[Goo]-Projektordner, Ordner der letzten Ergebnisse). Der Dateidialog startet im
zuletzt benutzten Ordner der jeweiligen Art.

Arten: adresspruefung (Werkzeug 1), nvt_gebiete (Werkzeug 2), nvt_standorte (Werkzeug 3), plangoo (Projekt-GeoPackage mit .db).
"""
import fnmatch
import os
from datetime import datetime

from qgis.PyQt.QtCore import QSettings, Qt
from qgis.PyQt.QtWidgets import QComboBox, QFileDialog, QHBoxLayout, QMenu, QPushButton, QWidget

SCHLUESSEL = "fiberation_werkzeugkasten/zuletzt/"
MAX_MERKEN = 12
MAX_LISTE = 15
MUSTER = {"adresspruefung": "adresspruefung_*.gpkg", "nvt_gebiete": "nvt_gebiete_*.gpkg", "nvt_standorte": "nvt_standorte_*.gpkg",
          "wesi": "wesi_spezialfaelle_*.gpkg", "umfeld": "umfeld_osm_*.gpkg", "trassen": "trassen_*.gpkg", "comsof": "*extern*.gpkg",
          "bestand": "bestand_*.gpkg", "hk": "hk_*.gpkg", "kollo": "kollo_*.gpkg", "zfp": "zfp222_*.xlsm",
          "megaplan": "*rohranlage*.gpkg", "comsof_in": "*existingpipes*.shp",
          "plangoo": "*.gpkg"}
EIGENE_PRAEFIXE = ("adresspruefung_", "nvt_gebiete_", "nvt_standorte_", "wesi_spezialfaelle_", "umfeld_osm_", "trassen_", "bestand_", "hk_")


# --- Merken -----------------------------------------------------------------------------------------------------------------------------
def _norm(p):
    return os.path.normpath(str(p).strip().strip('"'))


def zuletzt(art):
    """Gemerkte Pfade einer Art, juengste zuerst, nur noch vorhandene und nur solche, deren Name zur Art passt (Barntrup 31.10.2026: ein
    Trassen-Ergebnis stand in der Liste 'nvt_gebiete', war als juengste Datei immer vorbelegt und wurde als Gebiete-Datei verwendet)."""
    roh = QSettings().value(SCHLUESSEL + art, "", type=str) or ""
    return [p for p in (z.strip() for z in roh.split("\n")) if p and os.path.exists(p) and passt(art, p)]


def merken(art, pfad):
    """Pfad an den Anfang der Liste der Art setzen und den Ordner als Startordner merken. Passt der Name nicht zur Art (z. B. trassen_*.gpkg
    als nvt_gebiete), wird nichts gemerkt und nichts in die Standdatei geschrieben."""
    if not pfad or not os.path.exists(str(pfad)):
        return
    p = _norm(pfad)
    if not passt(art, p):
        return
    liste = [p] + [q for q in zuletzt(art) if os.path.normcase(q) != os.path.normcase(p)]
    QSettings().setValue(SCHLUESSEL + art, "\n".join(liste[:MAX_MERKEN]))
    QSettings().setValue(SCHLUESSEL + "ordner/" + art, os.path.dirname(p))
    try:                                   # Markus 12.10.: Standdatei neben den Ergebnissen fuehrt die Schritte eines Gebiets zusammen
        from . import stand
        stand.schreiben(os.path.dirname(p), art, p)
    except Exception:
        pass


PFAD_GRENZE = 240          # Windows: 259 Zeichen fuer Datei + Pfad; SQLite/GDAL brechen darueber ab ("unable to open database file")
AUSWEICH_ORDNER = os.path.join(os.path.expanduser("~"), "PlanGoo", "Werkzeugkasten")


def ausgabe_pfad(out_dir, dateiname, log=None):
    """Vollstaendiger Ausgabepfad; ist er laenger als PFAD_GRENZE, wandert die Datei in den kurzen lokalen Ordner AUSWEICH_ORDNER
    (Markus 18.09.2026, Mannheim-Rheinau: Pfad mit 278 Zeichen -> sqlite3_open failed)."""
    voll = os.path.join(out_dir, dateiname)
    if len(voll) <= PFAD_GRENZE:
        return voll
    os.makedirs(AUSWEICH_ORDNER, exist_ok=True)
    kurz = os.path.join(AUSWEICH_ORDNER, dateiname)
    if log:
        log("ACHTUNG: Ausgabepfad zu lang ({} Zeichen, Windows-Grenze 259) - Ausgabe stattdessen unter {}".format(len(voll), kurz))
    return kurz


def projekt_gpkg():
    """GeoPackage des offenen Plan[Goo]-Projekts oder None."""
    try:
        from . import plangoo_api
        inst = plangoo_api.instanz()
        if inst is None:
            return None
        p = inst.gpkg_path if hasattr(inst, "gpkg_path") else inst.get_gpkg_path()
        return p if p and os.path.exists(p) else None
    except Exception:
        return None


# --- Suchen -----------------------------------------------------------------------------------------------------------------------------
def passt(art, pfad):
    name = os.path.basename(str(pfad)).lower()
    if not fnmatch.fnmatch(name, MUSTER.get(art, "*.gpkg")):
        return False
    if art == "plangoo":
        # Projekt-GeoPackage: hat eine .db daneben und ist keine Werkzeug-Ausgabe
        return not name.startswith(EIGENE_PRAEFIXE) and os.path.exists(os.path.splitext(str(pfad))[0] + ".db")
    return True


def geladene(art):
    """GeoPackages der im QGIS-Projekt geladenen Layer, die zur Art passen."""
    treffer = []
    try:
        from qgis.core import QgsProject
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                src = lyr.source().split("|")[0]
            except Exception:
                continue
            if src.lower().endswith(".gpkg") and os.path.exists(src) and passt(art, src):
                treffer.append(_norm(src))
    except Exception:
        pass
    return treffer


def _ordner(art):
    """Ordner, in denen gesucht wird: Startordner der Art, Plan[Goo]-Projektordner, Ordner aller gemerkten Dateien."""
    o = []
    start = QSettings().value(SCHLUESSEL + "ordner/" + art, "", type=str)
    if start:
        o.append(start)
    pg = projekt_gpkg()
    if pg:
        o.append(os.path.dirname(pg))
    for a in MUSTER:
        o.extend(os.path.dirname(p) for p in zuletzt(a))
    # Ordner aller im QGIS-Projekt geladenen GeoPackages (z. B. die Adresspruefung liegt neben den NVT-Gebieten)
    try:
        from qgis.core import QgsProject
        for lyr in QgsProject.instance().mapLayers().values():
            src = lyr.source().split("|")[0]
            if src.lower().endswith(".gpkg"):
                o.append(os.path.dirname(src))
    except Exception:
        pass
    gesehen, erg = set(), []
    for d in o:
        k = os.path.normcase(os.path.normpath(d))
        if k not in gesehen and os.path.isdir(d):
            gesehen.add(k)
            erg.append(d)
    return erg


def kandidaten(art):
    """Alle passenden Dateien: gemerkt, geladen, in bekannten Ordnern gefunden - juengste zuerst, ohne Dubletten."""
    alle = list(zuletzt(art)) + geladene(art)
    if art == "plangoo":
        pg = projekt_gpkg()
        if pg:
            alle.insert(0, _norm(pg))
    muster = MUSTER.get(art, "*.gpkg")
    for d in _ordner(art):
        try:
            for name in os.listdir(d):
                if fnmatch.fnmatch(name.lower(), muster):
                    p = os.path.join(d, name)
                    if passt(art, p):
                        alle.append(_norm(p))
        except Exception:
            continue
    gesehen, erg = set(), []
    for p in alle:
        k = os.path.normcase(p)
        if k not in gesehen and os.path.isfile(p):
            gesehen.add(k)
            erg.append(p)
    erg.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return erg[:MAX_LISTE]


def juengstes(art):
    """Juengstes vorhandenes Ergebnis der Art (gemerkt, geladen oder in bekannten Ordnern gefunden) oder ''."""
    k = kandidaten(art)
    return k[0] if k else ""


def startordner(art, aktuell=""):
    a = _norm(aktuell) if aktuell else ""
    if a and os.path.exists(a):
        return a if os.path.isdir(a) else os.path.dirname(a)
    o = QSettings().value(SCHLUESSEL + "ordner/" + art, "", type=str)
    if o and os.path.isdir(o):
        return o
    pg = projekt_gpkg()
    if pg:
        return os.path.dirname(pg)
    return os.path.expanduser("~")


def datei_waehlen(parent, titel, filter_, art, aktuell=""):
    """Dateidialog, der im zuletzt benutzten Ordner der Art startet. -> Pfad oder ''"""
    p, _ = QFileDialog.getOpenFileName(parent, titel, startordner(art, aktuell), filter_)
    if p:
        merken(art, p)
    return p or ""


class OrdnerFehler(RuntimeError):
    """Feld 'Ausgabeordner' unbrauchbar (siehe ausgabeordner)."""


def ausgabeordner(text):
    """Text des Felds 'Ausgabeordner' pruefen. Leer -> None (das Werkzeug legt neben seine Eingabe). Sonst ein vollstaendiger,
    beschreibbarer Ordner (wird angelegt) -> normierter Pfad. Ein relativer Pfad (z. B. ein vertipptes '3') wuerde gegen das
    Arbeitsverzeichnis von QGIS aufgeloest - das ist der Programmordner, dort ist Anlegen verboten, und der Fehler kam erst tief im
    OSM-Cache als PermissionError (Markus 06.10.2026). Jetzt eine klare Meldung vor dem Start."""
    p = (text or "").strip().strip('"')
    if not p:
        return None
    if not os.path.isabs(p) or not os.path.splitdrive(p)[0]:
        raise OrdnerFehler("Ausgabeordner '{}' ist kein vollstaendiger Pfad (z. B. C:\\Projekte\\...). "
                           "Feld leeren oder den Ordner mit 'Waehlen' setzen.".format(p))
    p = os.path.normpath(p)
    try:
        os.makedirs(p, exist_ok=True)
    except OSError as e:
        raise OrdnerFehler("Ausgabeordner '{}' laesst sich nicht anlegen: {}".format(p, e.strerror or e))
    if not os.path.isdir(p) or not os.access(p, os.W_OK):
        raise OrdnerFehler("Ausgabeordner '{}' ist nicht beschreibbar.".format(p))
    return p


def ordner_waehlen(parent, titel, art, aktuell=""):
    """Ordnerdialog fuer Ausgabeordner, startet im zuletzt benutzten Ordner. -> Pfad oder ''"""
    p = QFileDialog.getExistingDirectory(parent, titel, startordner(art, aktuell))
    if p:
        QSettings().setValue(SCHLUESSEL + "ordner/" + art, p)
    return p or ""


def _anzeige(p):
    try:
        t = datetime.fromtimestamp(os.path.getmtime(p)).strftime("%d.%m. %H:%M")
    except Exception:
        t = "?"
    return "{}    {}    [{}]".format(os.path.basename(p), t, os.path.basename(os.path.dirname(p)) or os.path.dirname(p))


# --- Widget -----------------------------------------------------------------------------------------------------------------------------
class _Box(QComboBox):
    def __init__(self, feld):
        super().__init__()
        self._feld = feld

    def showPopup(self):
        self._feld.auffuellen()
        super().showPopup()


class DateiFeld(QWidget):
    """Eingabefeld mit Aufklappliste der passenden GeoPackages und 'Waehlen'-Knopf. text()/setText() wie QLineEdit."""

    def __init__(self, art, platzhalter="", filter_="GeoPackage (*.gpkg)", titel="Datei waehlen", knopf_stil=None, parent=None,
                 vorbelegen=True):
        super().__init__(parent)
        self.art = art
        self.filter_ = filter_
        self.titel = titel
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        self.box = _Box(self)
        self.box.setEditable(True)
        self.box.setInsertPolicy(QComboBox.NoInsert)
        self.box.setMaxVisibleItems(MAX_LISTE)
        self.box.lineEdit().setPlaceholderText(platzhalter)
        self.box.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.box.setMinimumContentsLength(30)
        self.box.activated.connect(self._gewaehlt)
        self.box.lineEdit().textChanged.connect(self._tipp)
        self.knopf = QPushButton("Waehlen")
        if knopf_stil:
            self.knopf.setStyleSheet(knopf_stil)
        self.knopf.clicked.connect(self._dialog)
        lay.addWidget(self.box, 1)
        lay.addWidget(self.knopf)
        self.setFocusProxy(self.box)
        if vorbelegen:
            self.vorbelegen()

    # QLineEdit-artige Schnittstelle
    def text(self):
        return self.box.lineEdit().text().strip().strip('"')

    def setText(self, p):
        self.box.setEditText(_norm(p) if p else "")

    def setPlaceholderText(self, t):
        self.box.lineEdit().setPlaceholderText(t)

    def setEnabled(self, an):
        super().setEnabled(an)
        self.box.setEnabled(an)
        self.knopf.setEnabled(an)

    # Verhalten
    def auffuellen(self):
        aktuell = self.text()
        self.box.blockSignals(True)
        self.box.clear()
        for p in kandidaten(self.art):
            self.box.addItem(_anzeige(p), p)
            self.box.setItemData(self.box.count() - 1, p, Qt.ToolTipRole)
        self.box.setCurrentIndex(-1)
        self.box.setEditText(aktuell)
        self.box.blockSignals(False)

    def vorbelegen(self):
        """Leeres Feld mit der juengsten passenden Datei fuellen."""
        if self.text():
            return
        k = kandidaten(self.art)
        if k:
            self.setText(k[0])

    def _gewaehlt(self, index):
        p = self.box.itemData(index)
        if p:
            self.box.setEditText(p)

    def _tipp(self, t):
        p = t.strip().strip('"')
        self.box.setToolTip(p if p else "")

    def _dialog(self):
        p = datei_waehlen(self, self.titel, self.filter_, self.art, self.text())
        if p:
            self.setText(p)


class ErgebnisKnopf(QWidget):
    """'Vorhandenes Ergebnis laden' ohne Suchen (Markus 16.09.): der Klick laedt sofort das juengste Ergebnis der Art, der Pfeil
    daneben klappt die letzten Ergebnisse auf und bietet 'Andere Datei waehlen...'. laden(pfad) wird mit dem Pfad aufgerufen.
    Gibt es noch kein Ergebnis, oeffnet der Klick den Dateidialog."""

    def __init__(self, art, laden, titel="Ergebnis (GeoPackage) waehlen", filter_="GeoPackage (*.gpkg)", stil=None,
                 text="Vorhandenes Ergebnis laden", parent=None):
        super().__init__(parent)
        self.art = art
        self.laden = laden
        self.titel = titel
        self.filter_ = filter_
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        self.knopf = QPushButton(text)
        self.knopf.clicked.connect(self._juengstes)
        self.pfeil = QPushButton("\u25be")
        self.pfeil.setFixedWidth(26)
        self.pfeil.setToolTip("Letzte Ergebnisse oder andere Datei waehlen")
        self.pfeil.clicked.connect(self._menue)
        if stil:
            self.knopf.setStyleSheet(stil)
            self.pfeil.setStyleSheet(stil.replace("padding:7px 14px", "padding:7px 4px"))
        lay.addWidget(self.knopf)
        lay.addWidget(self.pfeil)

    def enterEvent(self, ev):
        p = juengstes(self.art)
        self.knopf.setToolTip(("Laedt sofort: " + _anzeige(p) + "\n" + p) if p else "Noch kein Ergebnis bekannt - oeffnet die Dateiwahl")
        super().enterEvent(ev)

    def setEnabled(self, an):
        super().setEnabled(an)
        self.knopf.setEnabled(an)
        self.pfeil.setEnabled(an)

    def _juengstes(self):
        p = juengstes(self.art)
        if p:
            self.laden(p)
        else:
            self._dialog()

    def _menue(self):
        m = QMenu(self)
        for p in kandidaten(self.art):
            a = m.addAction(_anzeige(p))
            a.setToolTip(p)
            a.triggered.connect(lambda _=False, pfad=p: self.laden(pfad))
        if m.actions():
            m.addSeparator()
        m.addAction("Andere Datei waehlen...").triggered.connect(self._dialog)
        m.setToolTipsVisible(True)
        m.exec_(self.pfeil.mapToGlobal(self.pfeil.rect().bottomLeft()))

    def _dialog(self):
        p = datei_waehlen(self, self.titel, self.filter_, self.art)
        if p:
            self.laden(p)
