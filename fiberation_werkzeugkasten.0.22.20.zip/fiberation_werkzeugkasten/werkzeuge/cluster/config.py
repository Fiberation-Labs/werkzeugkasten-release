# -*- coding: utf-8 -*-
"""Werkzeug 2 - Regelsaetze und Rechenparameter fuer den NVT-Gebietsschnitt.

SEIT 30.09.2026 (Markus: "uebernehme mydms regelwerk in unsere tools"): Adressen weich/hart, Koppler, Kassetten und WE je NVT kommen aus
dem myDMS-Regelwerk der Telekom, so wie Plan[Goo] es prueft (fiberation_werkzeugkasten/mydms.py: installiertes Plan[Goo], sonst Kopie).
  Eigen NVt22 L (myDMS 23499 V34 S. 61/52): Adressen 40 Erstausbau / 90 max, Koppler 15/23, Kassetten 40/90 - ersetzt 60/74 vom 14.09.
  Eigen NVt22 L Gewerbe (pushgk*, S. 128): 50/60, Koppler 8/12, Kassetten 72/90.
  MBfD NVt22 L (BF) (S. 156): 45/51 (Erweiterung 51/60), Koppler 8/12, Kassetten 40/72 - ersetzt 51/57.
  MBfD NVt22 XS (BF): 10/13 (Erweiterung 13/15), Koppler 0/2, Kassetten 13/15.
Die Zahlen in REGELSAETZE unten sind Rueckfall und Quelle fuer Typ, SNR, Hk-Fasern, Vzk-Laenge und Kosten.

Grenzen je NVT (ZTV TK-Netz 21, Nov. 2025, Rueckfall):
  Eigenausbau Gf-NVt 22 L: max. 60 Adressen im Erstausbau (Kap. 8.8.3 Phasen; Markus 04.09.2026), 90 SNR 7 mm (8.6.5.3),
      23 PON-Fasern (8.6.2.3), 144 UNI-Kassetten minus 18 fuer 36 Hk-Fasern (8.6.5.1), 600 WE weich (Gold Mannheim 549).
      Markus 14.09.2026: 60 weich / 74 hart (Gold: Saarbruecken bis 74 APL je NVT).
  MBfD Gf-NVt 22 L (BF) (Kap. 13, Langmatz 47149235 / Raycap 47147178): max. 60 SNR 12 Vzk, Erstausbau max. 51 Adressen,
      9 Kabel Telekom + 3 Kollokation -> 57 SNR fuer Vzk, Hk 36 Fs (18 UNI), 12 Koppler, 72 Vzk-Kassetten, 24 Kollo-Kassetten
      (die Kollo-Kassetten zaehlen hier nicht mit: max_kassetten 90 minus 18 Hk = 72 Vzk-Kassetten).
      51 weich / 57 hart (14.09.2026 Annahme, 30.09.2026 durch den ZTV-Extrakt Kap. 13 gedeckt).
      Kassetten je Haus bei MBfD: 4 Fs je WE + 2 je Gebaeude, 12 Fs Vzk je UNI -> ceil(Fs/12) (ANNAHME 30.09.2026, cluster.lasten).
  MBfD Gf-NVt 22 XS (BF) (Langmatz 47149237, Strassenzug/Luecke): 15 SNR 12, Erstausbau max. 13 Adressen (an anderer Stelle 10 -
      hier 10 weich / 13 hart), Hk 12 Fs, 2 Koppler, 15 Vzk-, 8 Kollo-Kassetten. Nur auf Wunsch des Planers (Auswahl im Dialog).
  Vzk-Laenge NVT -> APL: 750 m (Eigen, Roboter-Vorgabe); MBfD Kap. 13: mehrere Versorgungsrichtungen max. 1.200 m.
  Gewerbe-NVT (0.22.17, ZTV 21 04/2026 Kap. 8.10; Markus 29.10.2026, Barntrup 1V7032/1V7039): ein NVT, in dem mehr als die Haelfte der
      Adressen im Gewerbegebiet liegt, bekommt je Gebiet (kern.gwg_grenzen, Spalte gwg = 1) die Gewerbe-Grenzen 50/60 Adressen, 8/12 Koppler,
      72/90 Kassetten (myDMS NVt22 L Gewerbe), 16 Anschluesse je Teil-PON (cluster.lasten pon_gwg), Hk 36 Fs im Erstausbau (24 bis 20
      Adressen, max. 72; kern._hk_fasern_gwg). Der Regelsatz der Datei bleibt Eigenausbau; MBfD unveraendert (dort Kap. 9.6.7).
Kosten: LV KNA Angebot 4 (wie HLD Roboter), nur fuer die Kostenbewertung der Varianten, nicht fuer Mengen.
Regelsatz-Erkennung (Ausbautreiber, Materialkonzept): fiberation_werkzeugkasten/regelwerk.py (seit 30.09.2026 zentral).
"""
import copy

from ... import regelwerk

REGELSAETZE = {
    "eigen": {
        "name": "Eigenausbau ZTV 21 (Gf-NVt 22 L)",
        "typ": "Gf-NVt 22 L", "max_apl": 60, "max_apl_hart": 74, "min_apl": 30, "ziel_apl": 48, "max_we": 600,
        "max_hk_fasern": 36, "max_pon_fasern": 23, "max_snr": 90, "max_kassetten": 144, "hk_kassetten": 18,
        "max_dist_m": 750, "k_varianten": [0], "iterationen": 6, "kosten_stueck": 4500.0, "parallel": False, "mbfd": False,
    },
    "mbfd": {
        "name": "MBfD ZTV 21 (Gf-NVt 22 L BF)",
        "typ": "Gf-NVt 22 L (BF)", "max_apl": 51, "max_apl_hart": 57, "min_apl": 20, "ziel_apl": 42, "max_we": 384,
        "max_hk_fasern": 36, "max_pon_fasern": 12, "max_snr": 57, "max_kassetten": 90, "hk_kassetten": 18,
        "max_dist_m": 1200, "k_varianten": [0], "iterationen": 6, "kosten_stueck": 6500.0, "parallel": False, "mbfd": True,
    },
    "mbfd_xs": {
        "name": "MBfD ZTV 21 (Gf-NVt 22 XS BF, Strassenzug)",
        "typ": "Gf-NVt 22 XS (BF)", "max_apl": 10, "max_apl_hart": 13, "min_apl": 3, "ziel_apl": 8, "max_we": 64,
        "max_hk_fasern": 12, "max_pon_fasern": 2, "max_snr": 12, "max_kassetten": 21, "hk_kassetten": 6,
        "max_dist_m": 1200, "k_varianten": [0], "iterationen": 6, "kosten_stueck": 3500.0, "parallel": False, "mbfd": True,
    },
}

BASIS = {
    "crs": 25832,
    "out_dir": None,
    "ausbautreiber": "eigen_ab_2023",
    "graph": {"quelle": "osm", "beschnitt_m": 300, "bst_anbindung_max_m": 60.0},
    "nvt": dict(REGELSAETZE["eigen"]),
    "vzk": {"snr_je_apl": 1, "snr_je_apl_ab_we": {}, "reserve_anteil": 0.15},
    "kosten": {
        "oberflaechenklasse": {"Asphalt": 1, "Beton": 1, "geb_Oberbau": 1, "Pflaster": 2, "Platten": 2, "ungebundener Oberbau": 2,
                               "Ungebundener Oberbau": 2, "ohne Oberbau": 3, "Ohne Oberbau": 3, "_default": 1},
        "eur_m_lv": {
            "Offene Bauweise": {"1": 148.0, "2": 89.19, "3": 34.75},
            "Mindertiefe_15x30": {"1": 105.18, "2": 79.42, "3": 26.45},
            "Fahrbahn": {"1": 180.0, "2": 128.9, "3": 59.5},
            "Spülbohrung": {"1": 156.44, "2": 156.44, "3": 156.44},
            "Bodenrakete": {"1": 121.5, "2": 121.5, "3": 121.5},
            "Trenching": {"1": 75.0, "2": 60.0, "3": 30.0},
            "Kabelpflug": {"1": 40.0, "2": 30.0, "3": 20.0},
            "Einzug": {"0": 5.83, "1": 5.83, "2": 5.83, "3": 5.83},
        },
        "annahme_bauverfahren": ["Trenching", "Kabelpflug"],
        "bauverfahren_default": "Offene Bauweise",
        "rohr_einbau_eur_m": 4.9,
        "querung": {"bundesstrasse": 6000.0, "bahn": 25000.0, "gewaesser": 15000.0, "hauptstrasse": 2500.0},
    },
    # Werkzeugkasten 16.09.2026: netzorientierter Schnitt (netzwachstum.py) - Bausteine und Sperrkanten-Aufschlaege in Metern
    "wachstum": {"aktiv": True, "abschnitt_max_adr": 8, "abschnitt_max_m": 250.0, "strafe_hauptstrasse_m": 300.0,
                 "strafe_bundesstrasse_m": 600.0, "strafe_bahn_m": 800.0, "strafe_gewaesser_m": 500.0, "iterationen": 8,
                 "polygon_punkte_m": 15.0},
    "osm": {
        "seiten": {"aktiv": False},
        "puffer_m": 1000, "cache": None,   # Markus 18.09.2026: Rand gross genug, dass die Landstrassen zwischen den Ortsteilen im Abruf sind
        "ausschluss_highway": ["motorway", "motorway_link", "trunk", "trunk_link", "raceway", "bus_guideway", "corridor", "elevator",
                               "proposed", "construction", "abandoned", "platform"],
        "klasse_je_highway": {
            "primary": "geb_Oberbau", "primary_link": "geb_Oberbau", "secondary": "geb_Oberbau", "secondary_link": "geb_Oberbau",
            "tertiary": "geb_Oberbau", "tertiary_link": "geb_Oberbau", "residential": "geb_Oberbau", "living_street": "geb_Oberbau",
            "unclassified": "geb_Oberbau", "service": "geb_Oberbau", "pedestrian": "geb_Oberbau", "footway": "geb_Oberbau",
            "cycleway": "geb_Oberbau", "path": "Ohne Oberbau", "track": "Ohne Oberbau", "steps": "geb_Oberbau", "bridleway": "Ohne Oberbau",
            "road": "geb_Oberbau"},
        "klasse_je_surface": {
            "asphalt": "geb_Oberbau", "concrete": "geb_Oberbau", "paving_stones": "Ungebundener Oberbau", "sett": "Ungebundener Oberbau",
            "cobblestone": "Ungebundener Oberbau", "compacted": "Ungebundener Oberbau", "gravel": "Ungebundener Oberbau",
            "fine_gravel": "Ungebundener Oberbau", "unpaved": "Ohne Oberbau", "ground": "Ohne Oberbau", "grass": "Ohne Oberbau",
            "dirt": "Ohne Oberbau", "earth": "Ohne Oberbau", "sand": "Ohne Oberbau"},
        "faktor_hauptstrasse": 1.25,
        "hauptstrasse_highway": ["primary", "primary_link", "secondary", "secondary_link"],
        "max_snap_m": 120.0,
    },
}


def regelsatz_fuer(treiber):
    """Ausbautreiber -> Regelsatz-Schluessel (zentral in regelwerk.py)."""
    return regelwerk.regelsatz_fuer(treiber)


def erzeugen(regelsatz="eigen", out_dir=None, treiber=None, **nvt_override):
    """Vollstaendige Konfiguration fuer Graph, Anbindung und Clustering.
    Seit 30.09.2026 (Markus: "uebernehme mydms regelwerk in unsere tools") kommen Adressen, Koppler, Kassetten und WE je NVT aus dem
    myDMS-Regelwerk (mydms.nvt_grenzen: installiertes Plan[Goo], sonst Kopie) fuer das Gehaeuse des Regelsatzes und den Ausbautreiber
    (z. B. pushgk_2023 -> Gewerbe-Zeile). REGELSAETZE liefert Typ, SNR, Hk-Fasern, Vzk-Laenge und die Rueckfallwerte.
    nvt_override (Grenzen-Felder im Dialog) ueberschreibt zuletzt."""
    from ... import mydms
    cfg = copy.deepcopy(BASIS)
    cfg["nvt"] = dict(REGELSAETZE.get(regelsatz, REGELSAETZE["eigen"]))
    cfg["nvt"].update(mydms.nvt_grenzen(regelsatz, treiber))
    cfg["nvt"].update({k: v for k, v in nvt_override.items() if v is not None})
    # Zielgroesse der Automatik nie ueber dem Erstausbau (myDMS Eigen: 40 warn / 90 max; Regelsatz-Rueckfall 48)
    cfg["nvt"]["ziel_apl"] = min(int(cfg["nvt"]["ziel_apl"]), int(cfg["nvt"]["max_apl"]))
    cfg["nvt"]["min_apl"] = min(int(cfg["nvt"]["min_apl"]), int(cfg["nvt"]["ziel_apl"]))
    cfg["out_dir"] = out_dir
    cfg["regelsatz"] = regelsatz
    cfg["ausbautreiber"] = treiber or cfg["nvt"].get("mydms_treiber") or cfg["ausbautreiber"]
    return cfg
