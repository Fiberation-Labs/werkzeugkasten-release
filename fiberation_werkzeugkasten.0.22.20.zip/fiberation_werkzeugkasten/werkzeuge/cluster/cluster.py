# -*- coding: utf-8 -*-
"""Kapazitiertes NVT-Clustering auf Graphdistanzen (Kosten-gewichtet).

Verfahren je k: k-means++-Start auf Koordinaten -> Zuweisung mit Kapazitaet (Regret-Greedy)
-> Medoid je Cluster neu (Knoten mit minimaler Summe der Graphkosten zu den Mitgliedern) -> wiederholen.
Bewertung: Vzk-Baumkosten + k * NVT-Stueckkosten. k-1, k, k+1 werden verglichen.
"""
import math

import networkx as nx
import numpy as np

INF = float("inf")


def _kmeanspp(xy, k, rng):
    n = len(xy)
    idx = [int(rng.integers(n))]
    d2 = np.sum((xy - xy[idx[0]]) ** 2, axis=1)
    for _ in range(1, k):
        p = d2 / d2.sum() if d2.sum() > 0 else np.full(n, 1.0 / n)
        nxt = int(rng.choice(n, p=p))
        idx.append(nxt)
        d2 = np.minimum(d2, np.sum((xy - xy[nxt]) ** 2, axis=1))
    return idx


def lasten(we, cfg):
    """Je Adresse die Lasten, die ein NVT tragen muss, und die Grenzen je NVT (ZTV TK-Netz 21, April 2026, Gf-NVt 22 L):
       apl        1 je Adresse                      Grenze nvt.max_apl (Markus: 60 als Grundlage, Planer entscheidet)
       we         Wohneinheiten                     Grenze nvt.max_we (weich, 600)
       pon        PON-Faseranteil nach Kap. 8.6.2.3/8.6.5.1 (eigen ab 2023): <= 3 WE -> WE/32 (1:32 im NVT),
                  4-8 WE -> 1/8 (1:8 im NVT + 1:4 im Haus), > 8 WE -> ceil(WE/32) (12-Fs-Kabel, Koppler im Haus)
                                                    Grenze nvt.max_pon_fasern 23 ("max. belegte Gf mit PON-Nutzung")
                  -> Hk-Fasern = PON + 6 Reserve in 6er-Schritten <= 36 ist damit automatisch eingehalten
       snr        SNR-Einfuehrungen (snr_je_adresse) Grenze nvt.max_snr 90 (Bodenplatte: 90 SNR + 6 Havarie + 12 Hk/Vzk)
       Gewerbegebiet (0.22.17, Kap. 8.10.4.4): 16 Anschluesse je Teil-PON -> <= 3: WE/16, 4-8: 1/4, > 8: ceil(WE/32); Schluessel
                  pon_std/pon_gwg (und kass_*) liegen beide im Ergebnis, pon/kassetten folgen cfg["vzk"]["gwg_liste"] je Adresse
       kassetten  1 UNI je Haus + Koppler-Kassetten  Grenze nvt.max_kassetten 144 - nvt.hk_kassetten 18 (36 Hk-Fs / 2)
    -> (dict name -> np.array(n), dict name -> cap)"""
    from .fibers import snr_je_adresse
    ncfg = cfg["nvt"]
    we = np.asarray(we, dtype=float)
    if ncfg.get("mbfd"):
        # ZTV 21 Kap. 13 (30.09.2026): alle Gebaeude <= 68 WE ueber den zentralen 1:32 im NVT (HUEP ohne Koppler), > 68 WE OneBox wie
        # Eigenausbau; Kassetten je Haus = 4 Fs je WE + 2 je Gebaeude in UNI a 12 Fs Vzk (ANNAHME), > 68 WE eine UNI + Koppler
        pon = np.where(we <= 68, we / 32.0, np.ceil(we / 32.0))
        kassetten = np.where(we <= 68, np.ceil((4.0 * we + 2.0) / 12.0), 1.0 + pon)
    else:
        pon = np.where(we <= 3, we / 32.0, np.where(we <= 8, 1.0 / 8.0, np.ceil(we / 32.0)))
        kassetten = 1.0 + pon
    # 0.22.17 (ZTV 21 04/2026 Kap. 8.10.4.4, S. 147): im Industrie-/Gewerbegebiet max. 16 FTTH-Anschluesse je Teil-PON - am 1:32 im NVT
    # nur 16 Ausgaenge (<= 3 Anschluesse -> WE/16), am 1:8 im NVT nur 4 Ausgaenge + 1:4 im Haus (4-8 -> 1/4), > 8: 1:32 im Haus bleibt 32.
    # Je Adresse ueber cfg["vzk"]["gwg_liste"] (0/1 wie snr_liste); pon_std/pon_gwg bleiben beide im Ergebnis, damit kennzahlen() je
    # Gebiet entscheiden kann (Wohnobjekte in einem Gewerbe-NVT laufen auf dem 16er-PON mit). MBfD: eigene Rechnung, unveraendert.
    pon_std, kass_std = pon, kassetten
    if ncfg.get("mbfd"):
        pon_gwg, kass_gwg = pon, kassetten
    else:
        pon_gwg = np.where(we <= 3, we / 16.0, np.where(we <= 8, 0.25, np.ceil(we / 32.0)))
        kass_gwg = 1.0 + pon_gwg
        gwg_liste = cfg["vzk"].get("gwg_liste")
        if gwg_liste is not None and len(gwg_liste) == len(we):
            gwg = np.asarray(gwg_liste, dtype=float) > 0
            pon, kassetten = np.where(gwg, pon_gwg, pon), np.where(gwg, kass_gwg, kassetten)
    # Werkzeugkasten 14.09.2026: SNR je Adresse kommt aus Werkzeug 1 (Bedarf nach ZTV 21), wenn vorhanden
    snr_liste = cfg["vzk"].get("snr_liste")
    if snr_liste is not None and len(snr_liste) == len(we):
        snr = np.asarray(snr_liste, dtype=float)
    else:
        snr = np.array([snr_je_adresse(int(w), cfg) for w in we], dtype=float)
    L = {"apl": np.ones(len(we)), "we": we, "pon": pon, "snr": snr, "kassetten": kassetten,
         "pon_std": pon_std, "kass_std": kass_std, "pon_gwg": pon_gwg, "kass_gwg": kass_gwg}
    caps = {"apl": float(ncfg["max_apl"]), "we": float(ncfg["max_we"]),
            "pon": float(ncfg.get("max_pon_fasern", 23)), "snr": float(ncfg.get("max_snr", 90)),
            "kassetten": float(ncfg.get("max_kassetten", 144) - ncfg.get("hk_kassetten", 18))}
    return L, caps


def _passt(state, L, caps, i, j):
    for name, cap in caps.items():
        if state[name][j] + L[name][i] > cap + 1e-9:
            return False
    return True


def _belegen(state, L, i, j):
    for name in state:
        state[name][j] += L[name][i]


def _assign(D, L, caps, we=None, max_apl=None, max_we=None):
    """D: (n, k) Kosten. Regret-Greedy mit Kapazitaeten (Lastvektoren aus `lasten`). -> labels (n,), ueberlauf (int)"""
    n, k = D.shape
    state = {name: np.zeros(k) for name in caps}
    order = np.argsort(D, axis=1)
    best = D[np.arange(n), order[:, 0]]
    second = D[np.arange(n), order[:, 1]] if k > 1 else best
    regret = second - best
    labels = np.full(n, -1)
    ueberlauf = 0
    for i in np.argsort(-regret):
        placed = False
        for j in order[i]:
            if D[i, j] == INF:
                break
            if _passt(state, L, caps, i, j):
                labels[i] = j
                _belegen(state, L, i, j)
                placed = True
                break
        if not placed:  # alles voll oder unerreichbar: bester Sitz trotzdem, wird gezaehlt
            j = order[i][0]
            labels[i] = j
            _belegen(state, L, i, j)
            ueberlauf += 1
    return labels, ueberlauf


def _medoid(G, members, cutoff, kandidaten=12):
    """Knoten unter den Mitgliedern mit minimaler Kosten-Summe zu allen anderen Mitgliedern.
    Gerechnet werden nur die `kandidaten` Mitglieder, die dem Koordinaten-Schwerpunkt am naechsten liegen."""
    if len(members) > kandidaten:
        xy = np.array([[G.nodes[m]["x"], G.nodes[m]["y"]] for m in members])
        c = xy.mean(axis=0)
        order = np.argsort(np.sum((xy - c) ** 2, axis=1))
        cands = [members[i] for i in order[:kandidaten]]
    else:
        cands = members
    best, bs = cands[0], INF
    for m in cands:
        dist = nx.single_source_dijkstra_path_length(G, m, cutoff=cutoff, weight="cost")
        s = 0.0
        for o in members:
            s += dist.get(o, cutoff * 2)
        if s < bs:
            best, bs = m, s
    return best


def _tree_cost(G, seed, members):
    """Kosten des Kuerzeste-Wege-Baums vom Sitz zu den Mitgliedern (Kantenunion)."""
    _, paths = nx.single_source_dijkstra(G, seed, weight="cost")
    edges = {}
    for m in members:
        p = paths.get(m)
        if not p:
            continue
        for a, b in zip(p[:-1], p[1:]):
            edges[frozenset((a, b))] = G[a][b]["cost"]
    return sum(edges.values())


def run_k(G, addr_nodes, we, k, cfg, rng):
    """addr_nodes: Liste Graphknoten je Adresse; we: np.array WE. -> dict(labels, seeds, kosten, ueberlauf, iter)"""
    ncfg = cfg["nvt"]
    n = len(addr_nodes)
    xy = np.array([[G.nodes[a]["x"], G.nodes[a]["y"]] for a in addr_nodes])
    seeds = [addr_nodes[i] for i in _kmeanspp(xy, k, rng)]
    cutoff = ncfg["max_dist_m"] * max(v for row in cfg["kosten"]["eur_m_lv"].values() for v in row.values()) * 2.5
    L, caps = lasten(we, cfg)
    labels = None
    for it in range(ncfg["iterationen"]):
        D = np.full((n, k), INF)
        node_index = {}
        for i, a in enumerate(addr_nodes):
            node_index.setdefault(a, []).append(i)
        for j, s in enumerate(seeds):
            dist = nx.single_source_dijkstra_path_length(G, s, weight="cost")
            # 14.09.2026 (Werkzeugkasten): Vzk-Laenge NVT -> APL ist eine harte Grenze (max_dist_m, Meter), nicht nur Suchradius
            erreichbar = nx.single_source_dijkstra_path_length(G, s, weight="length", cutoff=float(ncfg["max_dist_m"]))
            for node, dd in dist.items():
                if node not in erreichbar:
                    continue
                for i in node_index.get(node, ()):
                    D[i, j] = dd
        new_labels, ueberlauf = _assign(D, L, caps)
        new_seeds = []
        for j in range(k):
            members = [addr_nodes[i] for i in np.where(new_labels == j)[0]]
            if not members:
                new_seeds.append(seeds[j])
                continue
            uniq = list(dict.fromkeys(members))
            new_seeds.append(_medoid(G, uniq, cutoff))
        converged = labels is not None and np.array_equal(new_labels, labels) and new_seeds == seeds
        labels, seeds = new_labels, new_seeds
        if converged:
            break
    labels, seeds, aufgeloest = _dissolve_small(G, addr_nodes, we, labels, seeds, cfg)
    vzk = 0.0
    for j in range(k):
        members = list(dict.fromkeys(addr_nodes[i] for i in np.where(labels == j)[0]))
        if members:
            vzk += _tree_cost(G, seeds[j], members)
    used = len(set(labels.tolist()))
    kosten = vzk + used * ncfg["kosten_stueck"]
    return {"k": k, "labels": labels, "seeds": seeds, "vzk_kosten": vzk, "kosten": kosten, "ueberlauf": ueberlauf,
            "iterationen": it + 1, "nvt_genutzt": used, "aufgeloest": aufgeloest}


def _dissolve_small(G, addr_nodes, we, labels, seeds, cfg):
    """Cluster unter min_apl aufloesen: Mitglieder zum naechsten anderen Sitz mit freier Kapazitaet.
    Nur wenn alle Mitglieder unterkommen (max_dist eingehalten, Kapazitaet frei). Kleinste zuerst."""
    ncfg = cfg["nvt"]
    min_apl = ncfg.get("min_apl", 0)
    if not min_apl:
        return labels, seeds, 0
    L, caps = lasten(we, cfg)
    labels = labels.copy()
    aufgeloest = 0
    while True:
        counts = {j: int((labels == j).sum()) for j in set(labels.tolist())}
        small = sorted((c, j) for j, c in counts.items() if 0 < c < min_apl)
        if not small:
            break
        moved_any = False
        for _, j in small:
            idx = np.where(labels == j)[0]
            andere = [jj for jj in counts if jj != j]
            state = {name: {jj: float(L[name][labels == jj].sum()) for jj in andere} for name in caps}
            plan = {}
            ok = True
            for i in idx:
                dist = nx.single_source_dijkstra_path_length(G, addr_nodes[i], weight="length", cutoff=ncfg["max_dist_m"])
                cands = sorted((dist[seeds[jj]], jj) for jj in andere if seeds[jj] in dist)
                placed = False
                for _, jj in cands:
                    if all(state[name][jj] + L[name][i] <= caps[name] + 1e-9 for name in caps):
                        plan[i] = jj
                        for name in caps:
                            state[name][jj] += L[name][i]
                        placed = True
                        break
                if not placed:
                    ok = False
                    break
            if ok:
                for i, jj in plan.items():
                    labels[i] = jj
                aufgeloest += 1
                moved_any = True
                break  # Zaehler neu aufbauen
        if not moved_any:
            break
    # Sitze der veraenderten Cluster nachziehen
    cutoff = ncfg["max_dist_m"] * max(v for row in cfg["kosten"]["eur_m_lv"].values() for v in row.values()) * 2.5
    seeds = list(seeds)
    for j in set(labels.tolist()):
        members = list(dict.fromkeys(addr_nodes[i] for i in np.where(labels == j)[0]))
        seeds[j] = _medoid(G, members, cutoff)
    return labels, seeds, aufgeloest


def _run_k_seed(args):
    """Wrapper fuer Prozess-Pool: eigener Zufallsgenerator je Variante (deterministisch je k)."""
    G, addr_nodes, we, k, cfg = args
    return run_k(G, addr_nodes, we, k, cfg, np.random.default_rng(42 + k))


def _parallel_moeglich(cfg):
    """Prozess-Pool nur in einem echten Python-Prozess (Konsole/Hintergrundprozess), nicht innerhalb von QGIS."""
    import os
    import sys
    if not cfg["nvt"].get("parallel", True):
        return False
    exe = os.path.basename(sys.executable or "").lower()
    return exe.startswith("python")


def choose(G, addr_nodes, we, cfg, log=print):
    ncfg = cfg["nvt"]
    n = len(addr_nodes)
    k0 = max(1, math.ceil(n / ncfg["ziel_apl"]))
    ks = [k0 + dk for dk in ncfg["k_varianten"] if 1 <= k0 + dk <= n]
    results = []
    if len(ks) > 1 and _parallel_moeglich(cfg):
        import os
        from concurrent.futures import ProcessPoolExecutor
        workers = min(len(ks), max(1, (os.cpu_count() or 2) - 1))
        log("  {} Varianten parallel auf {} Kernen".format(len(ks), workers))
        try:
            with ProcessPoolExecutor(max_workers=workers) as ex:
                results = list(ex.map(_run_k_seed, [(G, addr_nodes, we, k, cfg) for k in ks]))
        except Exception as e:  # z. B. kein Spawn moeglich -> seriell
            log("  parallel nicht moeglich ({}), rechne seriell".format(str(e)[:80]))
            results = []
    if not results:
        for k in ks:
            results.append(_run_k_seed((G, addr_nodes, we, k, cfg)))
    for r in results:
        log("  k={:3d}: {} NVT genutzt ({} kleine aufgeloest), Vzk {:>12,.0f} EUR + NVT {:>10,.0f} EUR = {:>12,.0f} EUR, Ueberlauf {}, Iter {}".format(
            r["k"], r["nvt_genutzt"], r["aufgeloest"], r["vzk_kosten"], r["nvt_genutzt"] * ncfg["kosten_stueck"], r["kosten"], r["ueberlauf"], r["iterationen"]))
    # Varianten mit Ueberlauf (Kapazitaet oder Vzk-Laenge gerissen) nur nehmen, wenn es keine saubere gibt;
    # unter den unsauberen zaehlt zuerst der kleinste Ueberlauf, dann die Kosten (Werkzeugkasten 14.09.2026)
    clean = [r for r in results if r["ueberlauf"] == 0]
    if clean:
        best = min(clean, key=lambda r: r["kosten"])
    else:
        best = min(results, key=lambda r: (r["ueberlauf"], r["kosten"]))
    return best, results
