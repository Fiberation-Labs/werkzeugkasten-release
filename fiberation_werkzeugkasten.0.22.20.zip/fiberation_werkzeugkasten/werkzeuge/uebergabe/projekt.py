# -*- coding: utf-8 -*-
"""Werkzeug 10 "Ab nach Plan[Goo]" - Kern (Markus 16.09.2026: letzte Kachel, neues leeres Plan[Goo]-Projekt anlegen und dann Kachel
fuer Kachel importieren).

Bausteine:
  neues_projekt        - leere Projektdateien aus den Plan[Goo]-Vorlagen (core/templates/goo_template_v1.{db,gpkg}) mit gemeinsamem
                         Referenzschluessel, Ausbautreiber als GooSettings AUSBAUTREIBER - wie das Plan[Goo]-Menue
                         "Leeres Plan[Goo] V2-Projekt speichern unter" (utilities/ui_actions.create_empty_files).
  in_bearbeitung_nehmen - Offline-Reiter von Plan[Goo] mit den beiden Dateien fuellen und dessen "In Bearbeitung nehmen" ausloesen
                         (GooEditOffline.start), danach ist das Projekt die aktive Instanz mit geladenen Layern.
  projekt_stand        - Pfad, Ausbautreiber, Anzahl APL / NVT / Trassen der aktiven Instanz.
  adressen_importieren - Kachel 2: Adressen der Adresspruefung als APL (Attribute an vorhandene, fehlende neu anlegen).
  kondensat_vorschau / kondensat_importieren - Kachel 5+7: Kondensat aus NVT-Trassen und Hk-Trasse (uebergabe/kondensat.py), nur wenn beide
                         final und geprueft sind; einziger Weg der Trassen nach Plan[Goo] (Markus 12.10.2026).
  Kachel 3 (Gebiete, NVT, Zuordnung) bleibt uebergabe.plangoo.uebernehmen.

Pfadfalle: Plan[Goo] bricht bei Projektpfaden ueber 259 Zeichen ab (Backup-Zip) - Vorgabe ist ein kurzer Ordner unter
C:\\Users\\<Nutzer>\\PlanGoo\\<Stamm>. OneDrive-Ordner meidet Plan[Goo] selbst mit einer Warnung.
"""
import importlib
import os
import re

from ... import plangoo_api


M = "technik_plangoo_v2_vds_main"


def _m(name):
    return plangoo_api.modul(name)


def plangoo_plugin():
    """Das geladene Plan[Goo]-Plugin (qgis.utils.plugins) oder None."""
    try:
        from qgis.utils import plugins
        return plugins.get(M)
    except Exception:
        return None


def aktive_instanz():
    try:
        return _m("core.project.instance").GooInstances.get_active_instance()
    except Exception:
        return None


def saubere_bezeichnung(text, max_len=40):
    t = re.sub(r"[^A-Za-z0-9_-]+", "_", str(text or "").strip()).strip("_")
    return (t or "Projekt")[:max_len]


def kurzer_ordner(stamm):
    """Vorgabe-Ordner fuer ein neues Projekt: C:\\Users\\<Nutzer>\\PlanGoo\\<Stamm> (kurz, nicht synchronisiert)."""
    return os.path.join(os.path.expanduser("~"), "PlanGoo", saubere_bezeichnung(stamm))


def name_aus_stamm(stamm):
    return "PlGoo_" + saubere_bezeichnung(stamm, 32)


def neues_projekt(ordner, name, sponsor, log=print):
    """Leere Projektdateien anlegen. sponsor: Plan[Goo]-Ausbautreiber (Enum aus dem Sponsor-Dialog) oder dessen Wert. -> (db, gpkg)"""
    from pathlib import Path
    name = saubere_bezeichnung(name, 60)
    os.makedirs(ordner, exist_ok=True)
    db, gp = os.path.join(ordner, name + ".db"), os.path.join(ordner, name + ".gpkg")
    for p in (db, gp):
        if os.path.exists(p):
            raise FileExistsError("Datei gibt es schon: {} - anderen Namen oder Ordner waehlen.".format(p))
    if len(gp) > 200:
        log("Warnung: Projektpfad hat {} Zeichen - Plan[Goo] bricht ueber 259 Zeichen ab (Backup-Zip). Kuerzeren Ordner waehlen.".format(len(gp)))
    create_new_project = _m("core.templates.dummy_project").create_new_project
    temp_instance = _m("core.project.instance").temp_instance
    GooSettings = _m("core.components").GooSettings
    DbT = _m("core.utilities.constants").DbMetaDataTypes
    db2, gp2 = create_new_project(ordner, name + ".db", name + ".gpkg")
    wert = getattr(sponsor, "value", sponsor)
    with temp_instance(Path(db2), Path(gp2)):
        GooSettings.create("AUSBAUTREIBER", wert, DbT.STR)
    log("Leeres Plan[Goo]-Projekt angelegt: {} (Ausbautreiber {})".format(gp2, wert))
    return str(db2), str(gp2)


def in_bearbeitung_nehmen(db, gpkg, log=print):
    """Offline-Reiter von Plan[Goo] fuellen und 'In Bearbeitung nehmen' ausloesen. -> aktive Instanz"""
    pl = plangoo_plugin()
    if pl is None:
        raise RuntimeError("Plan[Goo] V2 ist nicht geladen (Erweiterungen > Plan[Goo] V2 aktivieren).")
    off = pl.get_edit_offline() if hasattr(pl, "get_edit_offline") else None
    if off is None:
        raise RuntimeError("Der Plan[Goo]-Bearbeitungsreiter ist nicht geladen - Plan[Goo] einmal oeffnen (Werkzeugleiste), dann erneut.")
    try:
        dock = pl.get_dockwidget()
        if dock is not None:
            dock.show()
            dock.raise_()
    except Exception:
        pass
    off.get_offline_gis_widget().setFilePath(gpkg)
    off.get_offline_meta_db_widget().setFilePath(db)
    off.start()
    inst = aktive_instanz()
    if inst is None:
        raise RuntimeError("Plan[Goo] hat das Projekt nicht in Bearbeitung genommen - Meldung im Plan[Goo]-Fenster pruefen.")
    try:
        if os.path.normcase(os.path.abspath(str(inst.gpkg_path))) != os.path.normcase(os.path.abspath(gpkg)):
            raise RuntimeError("Plan[Goo] hat ein anderes Projekt aktiv: {}".format(inst.gpkg_path))
    except AttributeError:
        pass
    log("In Bearbeitung genommen: {}".format(gpkg))
    return inst


def ausbautreiber_wert():
    """Ausbautreiber (GooSettings AUSBAUTREIBER) der aktiven Instanz als Text, sonst None."""
    try:
        s = _m("core.components").GooSettings.from_uid("AUSBAUTREIBER")
        v = s.get_value() if s is not None else None
        return str(getattr(v, "value", v)) if v is not None else None
    except Exception:
        return None


def ausbautreiber():
    """Ausbautreiber als Plan[Goo]-Enum (constants.Ausbautreiber) oder None."""
    w = ausbautreiber_wert()
    if not w:
        return None
    try:
        return _m("core.utilities.constants").Ausbautreiber(w)
    except Exception:
        return None


def projekt_stand(inst=None):
    """-> dict(pfad, ordner, sponsor, apl, nvt, trassen) oder None, wenn kein Projekt aktiv ist."""
    inst = inst or aktive_instanz()
    if inst is None:
        return None
    C = _m("core.utilities.constants")
    GooPoint = _m("core.components").GooPoint
    st = {"pfad": str(getattr(inst, "gpkg_path", "") or ""), "sponsor": "", "apl": 0, "nvt": 0, "trassen": 0}
    st["ordner"] = os.path.dirname(st["pfad"])
    st["sponsor"] = ausbautreiber_wert() or ""
    try:
        st["apl"] = len(GooPoint.from_type(C.GooPointTypes.APL))
        st["nvt"] = len(GooPoint.from_type(C.GooPointTypes.NVT))
    except Exception:
        pass
    try:
        st["trassen"] = int(inst.get_tranch_layer().featureCount())
    except Exception:
        pass
    return st


def stand_text(st):
    if not st:
        return "Kein Plan[Goo]-Projekt in Bearbeitung."
    return "Projekt: {}   |   Ausbautreiber {}   |   {} APL, {} NVT, {} Trassen".format(
        os.path.basename(st["pfad"]) or "-", st["sponsor"] or "-", st["apl"], st["nvt"], st["trassen"])


# --- Kachel 2: Adressen -> APL ------------------------------------------------------------------------------------------------------------
def adressen_lesen(gpkg):
    import geopandas as gpd
    adr = gpd.read_file(gpkg, layer="adressen")
    if adr.crs is None or adr.crs.to_epsg() != 25832:
        adr = adr.set_crs(25832, allow_override=True)
    if "koord_fehlt" not in adr:
        adr["koord_fehlt"] = False
    adr["koord_fehlt"] = adr["koord_fehlt"].fillna(False).astype(bool) | adr.geometry.isna()
    return adr


def adressen_vorschau(gpkg):
    adr = adressen_lesen(gpkg)
    status = adr["status"].astype(str) if "status" in adr else None
    ampel = adr["ampel"].astype(str) if "ampel" in adr else None
    return {"gesamt": int(len(adr)),
            "ignorieren": int((status == "ignorieren").sum()) if status is not None else 0,
            "rot": int((ampel == "rot").sum()) if ampel is not None else 0,
            "ohne_koordinate": int(adr["koord_fehlt"].sum()),
            "onkz_asb": bool("onkz" in adr and "asb" in adr and adr["onkz"].notna().any() and adr["asb"].notna().any())}


def adressen_importieren(gpkg, rote_auslassen=True, mit_backup=True, lage=False, log=print, fortschritt=None):
    """Adressen der Adresspruefung (Kachel 2) als APL in das aktive Projekt: vorhandene bekommen Attribute, fehlende werden angelegt
    (ASB aus dem ersten APL, sonst ONKZ/ASB der Liste). lage=True: vorhandene APL auf die Lage der Adresspruefung setzen (Markus 31.10.2026,
    nach 'Adresslage abgleichen' in Schritt 5). -> dict wie adressen.plangoo.uebernehmen"""
    from ..adressen import plangoo as aplangoo
    adr = adressen_lesen(gpkg)
    log("Adressen: {} aus {}".format(len(adr), os.path.basename(gpkg)))
    return aplangoo.uebernehmen(adr, attribute=True, neue_anlegen=True, nur_gruen_gelb=rote_auslassen, mit_backup=mit_backup, lage=lage,
                                log=log, fortschritt=fortschritt)


def lage_vorschau(gpkg):
    """Kachel 2 mit 'Lage nachziehen': wie viele vorhandene APL liegen abseits der Adresspruefung? -> dict(abweichend, gleich, ohne_apl, max_m)"""
    from ..adressen import plangoo as aplangoo
    return aplangoo.lage_vorschau(adressen_lesen(gpkg))


# --- Kachel 5: Trassen -------------------------------------------------------------------------------------------------------------------
# --- Kondensat aus Schritt 5 und 7 (Markus 12.10.2026) ---------------------------------------------------------------------------------
def kondensat_vorschau(trassen_gpkg, hk_gpkg, log=print):
    """Vorbedingungen pruefen und das Kondensat bilden (Ebene 'uebergabe' im Trassen-GeoPackage), ohne nach Plan[Goo] zu schreiben.
    -> dict(ok, fehlt, stats, text)"""
    from . import kondensat
    from ..trassen import kern as tkern
    tkern.migrieren(trassen_gpkg, log=lambda s: None)
    vb = kondensat.vorbedingungen(trassen_gpkg, hk_gpkg)
    if not vb["ok"]:
        return {"ok": False, "fehlt": vb["fehlt"], "stats": None, "text": "Noch nicht final: {} von {} NVT (Schritt 5) und {} von {} Straengen (Schritt 7) geprueft.".format(
            vb["nvt_fertig"], vb["nvt_gesamt"], vb["hk_fertig"], vb["hk_gesamt"])}
    erg = kondensat.dissolve(trassen_gpkg, hk_gpkg, log=log, schreiben=True)
    return {"ok": True, "fehlt": [], "stats": erg["stats"], "text": kondensat.stats_text(erg["stats"]), "konflikte": erg["konflikte"]}


def kondensat_importieren(trassen_gpkg, hk_gpkg, mit_backup=True, inst=None, log=print, fortschritt=None):
    """Ebene 'uebergabe' (Kondensat) als Plan[Goo]-Trassen anlegen; Status in der Ebene, Endstand, NVT-Status uebertragen.
    -> dict(angelegt, uebersprungen, fehler, backup, meldungen, stats)"""
    import importlib
    import re
    from datetime import datetime
    from . import kondensat
    from ..adressen import plangoo as aplangoo
    from ..trassen import kern as tkern
    f = fortschritt or (lambda p, t: None)
    v = kondensat_vorschau(trassen_gpkg, hk_gpkg, log=log)
    if not v["ok"]:
        raise RuntimeError("Uebergabe blockiert - noch nicht final:\n" + "\n".join(v["fehlt"][:25]))
    inst = inst or aplangoo.instanz()
    erg = {"angelegt": 0, "uebersprungen": 0, "fehler": 0, "backup": None, "meldungen": [], "endstand": 0, "stats": v["stats"]}
    if mit_backup:
        f(2, "Backup")
        M = "technik_plangoo_v2_vds_main"
        db, gp = inst.db_path, inst.gpkg_path
        Backup = plangoo_api.klasse("core.project.backup", "Backup")
        ziel = os.path.join(os.path.dirname(db), "{}_trassen_kondensat_{}.zip".format(os.path.splitext(os.path.basename(gp))[0], datetime.now().strftime("%Y-%m-%d_%H-%M")))
        Backup.create_zip_backup(db, gp, ziel)
        erg["backup"] = ziel
        log("Backup: " + ziel)
    u = tkern.ebene_lesen(trassen_gpkg, kondensat.EBENE)
    if not len(u):
        raise RuntimeError("Kondensat ist leer.")
    tkern.tranchen_anlegen(u, u, inst, erg, log=log, fortschritt=f)
    tkern.ebene_schreiben(trassen_gpkg, u, kondensat.EBENE, extra=("herkunft", "hk"))
    # Endstand: das Kondensat als eingefrorener Stand
    import geopandas as gpd
    import pandas as pd
    fin = u.copy()
    fin["stand"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    try:
        alt = tkern.ebene_lesen(trassen_gpkg, "final")
        if len(alt):
            fin = gpd.GeoDataFrame(pd.concat([alt, fin], ignore_index=True), crs=tkern.CRS)
    except Exception:
        pass
    tkern.ebene_schreiben(trassen_gpkg, fin, "final", extra=("stand", "herkunft", "hk"))
    erg["endstand"] = len(u)
    if erg["fehler"] == 0:
        n = tkern.nvt_lesen(trassen_gpkg)
        n.loc[n["status"].astype(str) == "geprueft", "status"] = "uebertragen"
        n.to_file(trassen_gpkg, layer="nvt_status", driver="GPKG")
        tkern.wal_schliessen(trassen_gpkg)
        try:                                        # Schritt-7-Straenge auch auf uebertragen (ein Statussatz, schema.STATUS)
            geb = gpd.read_file(hk_gpkg, layer="hk_gebiete")
            geb.loc[geb["status"].astype(str) == "geprueft", "status"] = "uebertragen"
            geb.to_file(hk_gpkg, layer="hk_gebiete", driver="GPKG")
            tkern.wal_schliessen(hk_gpkg)
        except Exception as e:
            log("Hk-Status nicht auf uebertragen gesetzt: {!r}".format(e))
    log("Kondensat nach Plan[Goo]: {} Trassen angelegt, {} uebersprungen, {} Fehler".format(erg["angelegt"], erg["uebersprungen"], erg["fehler"]))
    f(100, "Fertig")
    return erg
