# -*- coding: utf-8 -*-
"""Attributformular fuer die Planungslayer (Markus 27.10.2026): zeichnet der Planer eine Trasse von Hand, zeigt QGIS danach das
Attributformular. Dort sollen die Plan[Goo]-Felder dieselben Auswahllisten haben wie die Leiste "Trassenattribute" im Dialog
(Bestand, Bauverfahren, Oberflaeche, Zulage, Lagehinweis, WeSi, Hauszufuehrung) - keine freien Textfelder, nichts erfinden.

einrichten(lyr, listen, fest=(), alias=None) -> Zahl der Felder mit Auswahlliste.
  listen: dict Feldname -> Liste von (Anzeige, Wert). Nur Felder, die der Layer hat, werden eingerichtet.
  fest:   Felder, die das Werkzeug selbst setzt (uid, nvt, laenge_m, quelle, kante, status) - im Formular nur lesbar.
  alias:  dict Feldname -> Beschriftung im Formular und in der Attributtabelle.
Das Formular wird fuer den Layer ausdruecklich eingeschaltet (SuppressOff), sonst greift die globale QGIS-Einstellung
"Attributformular beim Erstellen unterdruecken" und der Planer sieht die Listen nie.

Falle: QgsEditFormConfig kommt als Kopie - Aenderungen daran erst mit setEditFormConfig zurueckgeben. ValueMap-Konfiguration ist seit
QGIS 3.x eine Liste einelementiger dicts {Anzeige: Wert} (die Reihenfolge bleibt so erhalten; ein dict wuerde Werte alphabetisch sortieren)."""
from qgis.core import QgsEditFormConfig, QgsEditorWidgetSetup

LEER = "- leer -"


def liste(werte, leer=True):
    """Werteliste (Text) -> Liste (Anzeige, Wert); leerer Wert wird als '- leer -' gezeigt und steht vorn."""
    paare = []
    if leer and "" not in werte:
        paare.append((LEER, ""))
    for w in werte:
        paare.append((LEER if w == "" else str(w), w))
    return paare


def einrichten(lyr, listen, fest=(), alias=None):
    fl = lyr.fields()
    n = 0
    for feld, paare in listen.items():
        i = fl.indexOf(feld)
        if i < 0:
            continue
        lyr.setEditorWidgetSetup(i, QgsEditorWidgetSetup("ValueMap", {"map": [{str(a): w} for a, w in paare]}))
        n += 1
    cfg = lyr.editFormConfig()
    for feld in fest:
        i = fl.indexOf(feld)
        if i >= 0:
            cfg.setReadOnly(i, True)
    aus = getattr(QgsEditFormConfig, "SuppressOff", None)
    if aus is None:
        aus = QgsEditFormConfig.FeatureFormSuppress.SuppressOff
    cfg.setSuppress(aus)
    lyr.setEditFormConfig(cfg)
    for feld, text in (alias or {}).items():
        i = fl.indexOf(feld)
        if i >= 0:
            lyr.setFieldAlias(i, text)
    return n


def hat_liste(lyr, feld):
    """-> True, wenn das Feld eine Auswahlliste (ValueMap) traegt."""
    i = lyr.fields().indexOf(feld)
    return i >= 0 and lyr.editorWidgetSetup(i).type() == "ValueMap"
