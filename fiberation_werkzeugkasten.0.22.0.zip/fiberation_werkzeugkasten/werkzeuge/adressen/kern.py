# -*- coding: utf-8 -*-
"""Werkzeug 2 - Kern ohne Qt: Adressen laden, pruefen, Bedarf bestimmen, GeoPackage und Bericht schreiben.

Schema des Adress-GeoDataFrame (EPSG:25832):
  kls_id, strasse, hnr, hnr_zs, plz, ort, ortsteil, we, ge, p2p, gebietstyp, sponsor, gebaeude (Telekom-Gebaeudefunktion),
  kenner, bewertung_hh, bewertung_adr, quelle ('bedarfsliste' | 'plangoo'), geometry
Pruefspalten: ampel (gruen/gelb/rot), hinweise, dublette, alkis_abstand_m, alkis_funktion, bauluecke
Bedarfsspalten: we_gesamt, zusatz, anschluesse, snr, fasern_haus, fasern_direkt, gebaeudetyp, gemischt, sonderfall, regel, gewerbegebiet
Planerspalten: status ('offen' | 'geprueft' | 'ignorieren'), kommentar
"""
import os
import re
from datetime import datetime

from ... import regelwerk, plangoo_api
from . import regeln

CRS = 25832
# MBfD-Angebotslayer (Plan[Goo]): die Telekom legt den APL auf die Hauswand, weil sie im Angebot keine Inhouse-Trasse rechnet (Markus
# 29.09.2026). Dornberg: Abstaende 0-1,4 m an der Wand, dann erst ab 3,1 m - Grenze 1,5 m.
WAND_M = 1.5
SPALTEN_LISTE = {"KLS_ID": "kls_id", "Strasse": "strasse", "HsNr": "hnr", "HsNrzs": "hnr_zs", "PLZ": "plz", "Ort": "ort",
                 "Ortsteil": "ortsteil", "WE": "we", "GE": "ge", "P2P": "p2p", "Gebietstyp": "gebietstyp", "Ausbau_Sponsor": "sponsor",
                 "Gebaeudefunktion": "gebaeude", "adress_qualitaet_kenner": "kenner", "bewertung_hh": "bewertung_hh",
                 "adress_bewertung": "bewertung_adr", "Zusatzbedarfe_Sonderleitungen": "zusatzbedarf_txt", "Bemerkung_Zusatzinfo": "bemerkung",
                 "ONKZ": "onkz", "ASB": "asb"}


# --- Laden -----------------------------------------------------------------------------------------------------------------------------
def lesen_bedarfsliste(pfad, log=print):
    """Telekom-Bedarfsliste (CSV, Semikolon, Windows-1252). -> GeoDataFrame EPSG:25832"""
    import geopandas as gpd
    import pandas as pd
    from shapely.geometry import Point
    df = None
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            df = pd.read_csv(pfad, sep=";", dtype=str, encoding=enc, keep_default_na=False)
            break
        except UnicodeDecodeError:
            continue
    if df is None:
        raise ValueError("Bedarfsliste nicht lesbar: " + pfad)
    df.columns = [c.strip() for c in df.columns]
    fehlt = [c for c in ("KLS_ID", "Koord_X", "Koord_Y", "WE") if c not in df.columns]
    if fehlt:
        raise ValueError("Bedarfsliste ohne Pflichtspalten {}: {}".format(fehlt, os.path.basename(pfad)))
    out = pd.DataFrame({neu: df[alt].str.strip() if alt in df else "" for alt, neu in SPALTEN_LISTE.items()})
    x = pd.to_numeric(df["Koord_X"].str.replace(",", "."), errors="coerce")
    y = pd.to_numeric(df["Koord_Y"].str.replace(",", "."), errors="coerce")
    if "Koordinate_Bedarfspunkt_UTM32_X" in df:
        bx = pd.to_numeric(df["Koordinate_Bedarfspunkt_UTM32_X"].str.replace(",", "."), errors="coerce")
        by = pd.to_numeric(df["Koordinate_Bedarfspunkt_UTM32_Y"].str.replace(",", "."), errors="coerce")
        out["bedarfspunkt"] = bx.notna() & (bx > 0)
        x = bx.where(out["bedarfspunkt"], x)
        y = by.where(out["bedarfspunkt"], y)
    else:
        out["bedarfspunkt"] = False
    out["koord_fehlt"] = x.isna() | y.isna() | (x <= 0) | (y <= 0)
    out["quelle"] = "bedarfsliste"
    geom = [Point(a, b) if not f else None for a, b, f in zip(x.fillna(0), y.fillna(0), out["koord_fehlt"])]
    g = gpd.GeoDataFrame(out, geometry=geom, crs=CRS)
    log("Bedarfsliste: {} Zeilen, {} ohne Koordinate, Sponsor {}".format(len(g), int(g["koord_fehlt"].sum()),
                                                                          ", ".join(sorted(set(g["sponsor"]) - {""})) or "-"))
    return g


def lesen_plangoo(log=print):
    """APL/NAP des aktiven Plan[Goo]-Projekts (nur in QGIS mit geladenem Plan[Goo]). -> GeoDataFrame EPSG:25832"""
    import importlib
    import geopandas as gpd
    import pandas as pd
    from shapely.geometry import Point
    from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject
    M = "technik_plangoo_v2_vds_main"
    inst = plangoo_api.instanz()
    if inst is None:
        raise RuntimeError("Kein Plan[Goo]-Projekt geoeffnet.")
    comps = plangoo_api.komponenten()
    GooPoint = comps.GooPoint
    treiber = ""
    try:
        treiber = str(comps.GooSettings.from_uid("AUSBAUTREIBER").get_value() or "")
    except Exception:
        pass
    layer = inst.get_point_layer()
    ct = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:{}".format(CRS)), QgsProject.instance())
    zeilen, geoms = [], []
    for f in layer.getFeatures():
        if str(f["TYPE"] or "") not in ("apl", "nap") or f.geometry() is None or f.geometry().isEmpty():
            continue
        p = ct.transform(f.geometry().asPoint())
        pt = None
        try:
            pt = GooPoint.from_feature(f)
        except Exception:
            pass
        z = {"kls_id": _s(f["KLS_ID"]), "strasse": _s(f["STRASSE"]), "hnr": _s(f["HS_NR"]), "hnr_zs": _s(f["HS_NR_ZS"]),
             "plz": _s(f["PLZ"]), "ort": _s(f["ORT"]), "ortsteil": _s(f["ORTSTEIL"]), "uid": _s(f["UID"]),
             "we": _meta(pt, f, ("get_hh", "get_homes"), "HH"), "ge": _meta(pt, f, ("get_usto",), "USTO"),
             "p2p": _meta(pt, f, ("get_p2p",), "P2P"), "gebietstyp": "", "sponsor": treiber,
             "gebaeude": _meta_wert(pt, "BUILDING") or _meta(pt, f, ("get_building_type",), "GEBAUDE_NUTZUNG"), "kenner": "", "bewertung_hh": "",
             "bewertung_adr": "", "zusatzbedarf_txt": "", "bemerkung": "", "onkz": "", "asb": "", "bedarfspunkt": False,
             "koord_fehlt": False, "quelle": "plangoo"}
        zeilen.append(z)
        geoms.append(Point(p.x(), p.y()))
    if not zeilen:
        raise RuntimeError("Das Projekt enthaelt keine APL.")
    g = gpd.GeoDataFrame(pd.DataFrame(zeilen), geometry=geoms, crs=CRS)
    log("Plan[Goo]: {} APL/NAP aus dem aktiven Projekt, Ausbautreiber {}".format(len(g), treiber or "-"))
    return g


def ist_plangoo_gpkg(pfad):
    """True, wenn pfad ein Plan[Goo]-V2-GeoPackage ist (Layer GEOMETRY_POINT mit APL-Feldern)."""
    import sqlite3
    if not str(pfad).lower().endswith(".gpkg") or not os.path.exists(pfad):
        return False
    try:
        con = sqlite3.connect("file:{}?mode=ro".format(os.path.abspath(pfad).replace("\\", "/")), uri=True)
        try:
            spalten = [r[1] for r in con.execute('pragma table_info("GEOMETRY_POINT")')]
        finally:
            con.close()
    except Exception:
        return False
    return "APL_HH" in spalten and "KLS_ID" in spalten


def lesen_plangoo_gpkg(pfad, log=print):
    """APL/NAP aus einer Plan[Goo]-V2-Projektdatei (GeoPackage, EPSG:3857), ohne dass Plan[Goo] geoeffnet sein muss. Markus 29.09.2026
    zu Dornberg (521_10_BLFD.gpkg): "es kann sein, dass wir nur diesen Input haben". WE = APL_HH, GE = APL_USTO, Gebaeude = APL_BUILDING;
    Ausbautreiber aus SETTINGS.AUSBAUTREIBER der .db daneben (fehlt die .db, bleibt er leer). -> GeoDataFrame EPSG:25832"""
    import sqlite3
    import geopandas as gpd
    import pandas as pd
    g = gpd.read_file(pfad, layer="GEOMETRY_POINT")
    g = g[g["TYPE"].astype(str).isin(("apl", "nap")) & g.geometry.notna() & ~g.geometry.is_empty]
    if not len(g):
        raise RuntimeError("Die Plan[Goo]-Datei enthaelt keine APL: " + os.path.basename(pfad))
    if g.crs is None:
        g = g.set_crs(3857)
    g = g.to_crs(CRS)
    treiber = ""
    db = os.path.splitext(pfad)[0] + ".db"
    if os.path.exists(db):
        try:
            con = sqlite3.connect("file:{}?mode=ro".format(os.path.abspath(db).replace("\\", "/")), uri=True)
            try:
                r = con.execute("select VALUE from SETTINGS where UID='AUSBAUTREIBER'").fetchone()
                treiber = _s(r[0]) if r else ""
            finally:
                con.close()
        except Exception:
            pass

    def zahl(v):
        s = _s(v)
        if s in ("", "nan"):
            return ""
        try:
            return str(int(float(s)))
        except ValueError:
            return s

    def spalte(name, fn=_s):
        return [fn(v) for v in g[name]] if name in g else [""] * len(g)

    luft = spalte("APL_BUILDING_CONNECTION_TYPE")
    out = pd.DataFrame({
        "kls_id": spalte("KLS_ID", zahl), "strasse": spalte("STRASSE"), "hnr": spalte("HS_NR"), "hnr_zs": spalte("HS_NR_ZS"),
        "plz": spalte("PLZ"), "ort": spalte("ORT"), "ortsteil": spalte("ORTSTEIL"), "uid": spalte("UID"),
        "we": spalte("APL_HH", zahl), "ge": spalte("APL_USTO", zahl), "p2p": spalte("APL_P2P", zahl), "gebietstyp": "", "sponsor": treiber,
        "gebaeude": spalte("APL_BUILDING"), "kenner": "", "bewertung_hh": "", "bewertung_adr": "", "zusatzbedarf_txt": "",
        "bemerkung": ["Hauszufuehrung oberirdisch (Plan[Goo])" if t == "aerial" else "" for t in luft],
        "onkz": "", "asb": "", "bedarfspunkt": False, "koord_fehlt": False, "quelle": "angebot",
        "nvt_plangoo": spalte("PARENT_NAME")})     # bisherige NVT-Zuordnung, Schritt 3 zeigt sie als nvt_alt
    out = gpd.GeoDataFrame(out, geometry=list(g.geometry), crs=CRS)
    log("Angebotslayer {}: {} APL/NAP, {} WE, Ausbautreiber {} (APL an der Hauswand bis {} m gelten als im Gebaeude)".format(
        os.path.basename(pfad), len(out), int(pd.to_numeric(out["we"], errors="coerce").fillna(0).sum()), treiber or "-", WAND_M))
    return out


def lesen_quelle(pfad, log=print):
    """Bedarfsliste (CSV) oder Plan[Goo]-GeoPackage - je nach Datei."""
    if str(pfad).lower().endswith(".gpkg"):
        if not ist_plangoo_gpkg(pfad):
            raise ValueError("Kein Plan[Goo]-GeoPackage (Layer GEOMETRY_POINT mit APL fehlt): " + os.path.basename(pfad))
        return lesen_plangoo_gpkg(pfad, log)
    return lesen_bedarfsliste(pfad, log)


def ist_mbfd(adr):
    """MBfD-Projekt: Ausbautreiber/Sponsor MBfD (wie cluster.config.regelsatz_fuer) oder Angebotslayer. Dann steht die Adressliste fest
    (Markus 29.09.2026: "es duerfen bei MBfD keine Bauluecken und fehlenden Adressen dazu kommen"); Lage verschieben bleibt erlaubt, wird aber
    als Abweichung vom Angebot gekennzeichnet."""
    if adr is None or not len(adr):
        return False
    t = " ".join(sorted(set(adr["sponsor"].astype(str)))) if "sponsor" in adr else ""
    if regelwerk.ist_mbfd_text(t):
        return True
    return "quelle" in adr and (adr["quelle"].astype(str) == "angebot").all()


from ... import gemeinsam
_s = gemeinsam.s


def _meta_wert(pt, key):
    """Meta-Wert (z. B. BUILDING = Gebaeudenutzung, BEGRUENDUNG) eines GooPoint oder ''."""
    if pt is None:
        return ""
    try:
        v = pt.get_meta().get_value(key)
        if v is None:
            return ""
        v = v.get_value() if hasattr(v, "get_value") else v
        return "" if v is None else str(v)
    except Exception:
        return ""


def _meta(pt, f, methoden, feld):
    for m in methoden:
        try:
            v = getattr(pt, m)()
            if v is not None:
                v = getattr(v, "value", v)
                return str(v)
        except Exception:
            continue
    try:
        return _s(f[feld])
    except Exception:
        return ""


# --- Pruefen ---------------------------------------------------------------------------------------------------------------------------
def pruefen(adr, gebaeude=None, radius_m=12.0, weit_m=25.0, log=print, wand_m=WAND_M, mbfd=False, flur=None):
    """Ampel, Hinweise, Dubletten, ALKIS-Abgleich, Bauluecken. Aendert `adr` und gibt es zurueck.
    Angebotslayer (quelle angebot) und Plan[Goo]-APL: APL bis wand_m neben dem Gebaeude sitzen an der Hauswand und gelten als im Gebaeude.
    MBfD (mbfd=True, Markus 29.09.2026 "die Adressen muessen nur valide sein"): gelb/rot nur fuer Gueltigkeit - keine Koordinate, Dublette,
    0 WE, Adresse amtlich nicht vorhanden oder weit weg (ALKIS-Lagebezeichnung von Gebaeuden und Flurstuecken, siehe _gueltigkeit). Lage neben
    dem Gebaeude, Nutzung, Sammelpunkt, Platzhalter bleiben als Hinweis stehen, faerben die Ampel aber nicht."""
    import numpy as np
    import pandas as pd
    n = len(adr)
    if "uid" not in adr:
        adr["uid"] = ["A{:05d}".format(i) for i in range(n)]
    hinweise = [[] for _ in range(n)]
    ampel = ["gruen"] * n
    gueltig_befund = True          # im MBfD-Modus faerben nur Gueltigkeitsbefunde (siehe setze)

    def setze(i, stufe, text):
        if text:
            hinweise[i].append(text)
        if mbfd and stufe == "gelb" and not gueltig_befund:
            return
        if stufe == "rot" or (stufe == "gelb" and ampel[i] != "rot"):
            ampel[i] = stufe

    # 1. Kenner
    for i, k in enumerate(adr["kenner"].tolist()):
        if adr["quelle"].iat[i] == "bedarfsliste":
            st, txt = regeln.kenner_ampel(k)
            if st != "gruen":
                setze(i, st, txt)
    # 2. Koordinate
    for i, fehlt in enumerate(adr["koord_fehlt"].tolist()):
        if fehlt:
            setze(i, "rot", "keine Koordinate")
    # 3. Dubletten
    adresse = (adr["strasse"].str.lower().str.strip() + "|" + adr["hnr"].astype(str).str.strip() + "|"
               + adr["hnr_zs"].astype(str).str.lower().str.strip() + "|" + adr["plz"].astype(str).str.strip())
    dupl_adr = adresse.duplicated(keep=False) & (adr["strasse"].str.strip() != "")
    kls = adr["kls_id"].astype(str).str.strip()
    dupl_kls = kls.duplicated(keep=False) & (kls != "")
    adr["dublette"] = ""
    for i in range(n):
        if dupl_kls.iat[i]:
            adr.loc[adr.index[i], "dublette"] = "KLS-ID mehrfach"
            setze(i, "rot", "KLS-ID {} mehrfach".format(kls.iat[i]))
        elif dupl_adr.iat[i]:
            adr.loc[adr.index[i], "dublette"] = "Adresse mehrfach"
            setze(i, "rot", "Adresse mehrfach in der Liste")
    # 4. Bewertung / Inhalt
    for i in range(n):
        if adr["quelle"].iat[i] == "bedarfsliste":
            b = str(adr["bewertung_adr"].iat[i] or "")
            if b in ("-", "--"):
                setze(i, "gelb", "Telekom-Adressbewertung {}".format(b))
            if str(adr["bewertung_hh"].iat[i] or "") == "--":
                setze(i, "gelb", "Telekom-Haushaltsbewertung --")
        gueltig_befund = False
        if not str(adr["gebaeude"].iat[i] or "").strip():
            setze(i, "gelb", "Gebaeudefunktion leer")
        gueltig_befund = True
        if regeln._int(adr["we"].iat[i]) == 0 and regeln._int(adr["ge"].iat[i]) == 0:
            setze(i, "gelb", "0 WE und 0 GE")
    # 5. Bauluecke ueber Hausnummer
    platz = [regeln.hnr_platzhalter(h) for h in adr["hnr"].tolist()]
    gueltig_befund = False
    # 5b. gleiche Koordinate fuer verschiedene Adressen (Hof, Sammelpunkt oder Fehler)
    schl = ["{:.0f}|{:.0f}".format(p.x, p.y) if p is not None and not f else "" for p, f in zip(adr.geometry, adr["koord_fehlt"])]
    mehrfach = pd.Series(schl).duplicated(keep=False) & (pd.Series(schl) != "")
    anz = pd.Series(schl).map(pd.Series(schl).value_counts())
    adr["koord_mehrfach"] = [int(a) if m else 0 for a, m in zip(anz, mehrfach)]
    for i in range(n):
        if mehrfach.iat[i]:
            setze(i, "gelb", "gleiche Koordinate fuer {} Adressen (Hof oder Sammelpunkt pruefen)".format(int(anz.iat[i])))
    # 6. ALKIS-Abgleich
    adr["alkis_abstand_m"] = np.nan
    adr["alkis_funktion"] = ""
    adr["im_gebaeude"] = False
    ohne_geb = [False] * n
    if gebaeude is not None and len(gebaeude):
        from shapely.strtree import STRtree
        rel = gebaeude[gebaeude["relevant"]].reset_index(drop=True)
        geoms = list(rel.geometry)
        tree = STRtree(geoms)
        funk = rel["funktion"].fillna("").tolist()
        for i, p in enumerate(adr.geometry):
            if p is None or adr["koord_fehlt"].iat[i]:
                continue
            kand = tree.query(p.buffer(weit_m))
            if len(kand) == 0:
                ohne_geb[i] = True
                adr.loc[adr.index[i], "alkis_abstand_m"] = 999.0
                continue
            d = [(geoms[j].distance(p), j) for j in kand]
            dist, j = min(d)
            adr.loc[adr.index[i], "alkis_abstand_m"] = round(dist, 1)
            adr.loc[adr.index[i], "alkis_funktion"] = funk[j]
            if dist > radius_m:
                ohne_geb[i] = True
            else:
                if dist <= 0.01 or (dist <= wand_m and adr["quelle"].iat[i] in ("plangoo", "angebot")):
                    adr.loc[adr.index[i], "im_gebaeude"] = True
                else:
                    setze(i, "gelb", "Koordinate liegt {:.1f} m neben dem Gebaeude, nicht darin".format(dist))
                tk = str(adr["gebaeude"].iat[i] or "").lower()
                al = funk[j].lower()
                if tk and al:
                    wohn_tk, wohn_al = "wohn" in tk, "wohn" in al
                    if wohn_tk != wohn_al and "gemischt" not in tk and "gemischt" not in al:
                        setze(i, "gelb", "Nutzung weicht ab: Telekom '{}', ALKIS '{}'".format(adr["gebaeude"].iat[i], funk[j]))
        for i in range(n):
            if ohne_geb[i]:
                a = adr["alkis_abstand_m"].iat[i]
                if a >= weit_m:
                    stufe = "rot" if "A" not in str(adr["kenner"].iat[i] or "").upper() and adr["quelle"].iat[i] == "bedarfsliste" else "gelb"
                    setze(i, stufe, "kein ALKIS-Gebaeude in {:.0f} m".format(weit_m))
                else:
                    setze(i, "gelb", "naechstes ALKIS-Gebaeude {:.0f} m entfernt".format(a))
    if mbfd and gebaeude is not None:
        gueltig_befund = True
        _gueltigkeit(adr, gebaeude, flur, setze, log)
    adr["bauluecke"] = [bool(p or o) for p, o in zip(platz, ohne_geb)]
    for i in range(n):
        if platz[i]:
            setze(i, "gelb", "Platzhalter-Hausnummer (Bauluecke)")
        elif ohne_geb[i] and gebaeude is not None:
            hinweise[i].append("Bauluecke?")
    adr["ampel"] = ampel
    adr["hinweise"] = ["; ".join(h) for h in hinweise]
    z = pd.Series(ampel).value_counts()
    log("Pruefung: {} gruen, {} gelb, {} rot; {} Dubletten, {} Bauluecken-Kandidaten".format(
        int(z.get("gruen", 0)), int(z.get("gelb", 0)), int(z.get("rot", 0)), int((adr["dublette"] != "").sum()), int(adr["bauluecke"].sum())))
    return adr


def _gueltigkeit(adr, gebaeude, flur, setze, log=print, max_m=50.0):
    """MBfD: gibt es die Adresse amtlich? Index aus den ALKIS-Lagebezeichnungen aller Gebaeude (und der Flurstuecke, falls geladen).
    Spalte alkis_adresse: 'bestaetigt' | 'bestaetigt (unbebautes Flurstueck)' | Befundtext. Gelb bei: Strasse unbekannt, Hausnummer fehlt,
    amtliche Adresse > max_m von der Koordinate."""
    idx, strassen = {}, set()
    for quelle, df in (("gebaeude", gebaeude), ("flurstueck", flur)):
        if df is None or not len(df) or "lagebeztxt" not in df:
            continue
        for lb, g in zip(df["lagebeztxt"], df.geometry):
            if g is None or g.is_empty:
                continue
            for sn, h, zs, _ in alkis_adressen(lb):
                idx.setdefault((sn, h, zs), []).append((quelle, g))
                strassen.add(sn)
    je_nr = {}
    for (sn, h, zs), v in idx.items():
        je_nr.setdefault((sn, h), []).extend(v)
    status = [""] * len(adr)
    for i, (s, hn, zs0, p, fehlt) in enumerate(zip(adr["strasse"], adr["hnr"], adr["hnr_zs"], adr.geometry, adr["koord_fehlt"])):
        sn = _norm_strasse(s)
        h, zs_h = _hnr_teile(hn)
        zs = (_s(zs0).strip() or zs_h).lower()
        if not sn or not h:
            status[i] = "Strasse oder Hausnummer leer"
            setze(i, "gelb", "Adresse unvollstaendig")
            continue
        kand = idx.get((sn, h, zs))
        zusatz_frei = False
        if not kand and zs:
            kand = idx.get((sn, h, ""))
            zusatz_frei = bool(kand)
        if not kand and not zs:
            kand = je_nr.get((sn, h))
        if not kand:
            if sn in strassen:
                status[i] = "Hausnummer amtlich nicht gefunden"
                setze(i, "gelb", "Hausnummer {}{} in ALKIS nicht gefunden (Strasse vorhanden)".format(h, zs))
            else:
                status[i] = "Strasse amtlich nicht gefunden"
                setze(i, "gelb", "Strasse '{}' in ALKIS nicht gefunden (Schreibweise pruefen)".format(_s(s)))
            continue
        if p is None or isinstance(p, float) or fehlt:
            status[i] = "bestaetigt, ohne Koordinate"
            continue
        d, q = min((g.distance(p), qu != "gebaeude", qu) for qu, g in kand)[::2]     # Gebaeude vor Flurstueck
        geb_d = [g.distance(p) for qu, g in kand if qu == "gebaeude"]
        if geb_d and min(geb_d) <= max_m:
            d, q = min(geb_d), "gebaeude"
        if d > max_m:
            status[i] = "amtliche Adresse {:.0f} m entfernt".format(d)
            setze(i, "gelb", "amtliche Adresse liegt {:.0f} m entfernt (ALKIS)".format(d))
            continue
        status[i] = "bestaetigt" + (" (unbebautes Flurstueck)" if q == "flurstueck" else "") + (" (Zusatz nur in der Liste)" if zusatz_frei else "")
        if q == "flurstueck" or zusatz_frei:
            setze(i, "", "ALKIS: " + status[i])
    adr["alkis_adresse"] = status
    ok = sum(1 for t in status if t.startswith("bestaetigt"))
    log("Gueltigkeit (MBfD): {} von {} Adressen amtlich bestaetigt, {} Befunde".format(ok, len(status), len(status) - ok))


# --- Fehlender Bedarf: ALKIS-Adresse (lagebeztxt) gegen die Liste (Markus 17.09.2026, Beispiel Wannen 102) ------------------------------
def _norm_strasse(s):
    """'Hüttenstr.' und 'Hüttenstraße' -> 'huettenstr'; Leerzeichen, Punkte, Bindestriche raus."""
    s = _s(s).lower().strip()
    s = s.replace("ß", "ss").replace("ä", "ae").replace("ö", "oe").replace("ü", "ue")
    s = re.sub(r"stra(ss|s)e\b|str\.", "str", s)
    return re.sub(r"[\s\.\-]+", "", s)


def _hnr_teile(t):
    """'60a' -> (60, 'a'); '' -> (0, '')."""
    z = re.match(r"\s*(\d+)\s*([a-zA-Z]?)", _s(t))
    return (int(z.group(1)), z.group(2).lower()) if z else (0, "")


def alkis_adressen(lagebeztxt):
    """ALKIS-Lagebezeichnung -> Liste (strasse_norm, hnr, zusatz, text). 'Wannen 60, 60a, 60b' -> drei Eintraege, 'A 1; B 2' -> zwei Strassen."""
    out = []
    for teil in re.split(r"\s*;\s*", _s(lagebeztxt)):
        z = re.match(r"^(.*?[^\d\s])\s+(\d+.*)$", teil.strip())
        if not z:
            continue
        strasse, rest = z.group(1).strip(), z.group(2)
        for nr in re.split(r"\s*,\s*", rest):
            h, zs = _hnr_teile(nr)
            if h:
                out.append((_norm_strasse(strasse), h, zs, "{} {}{}".format(strasse, h, zs)))
    return out


def _listen_index(adr):
    """-> (Menge (strasse_norm, hnr, zs), Menge (strasse_norm, hnr), Hausnummern je strasse_norm)."""
    voll, kurz, je = set(), set(), {}
    for s, h, zs in zip(adr["strasse"], adr["hnr"], adr["hnr_zs"]):
        sn = _norm_strasse(s)
        hi, _ = _hnr_teile(h)
        if not sn or not hi:
            continue
        z = _s(zs).lower().strip()
        voll.add((sn, hi, z))
        kurz.add((sn, hi))
        je.setdefault(sn, set()).add(hi)
    return voll, kurz, je


def _in_liste(sn, h, zs, voll, kurz):
    """Adresse in der Liste? Zusatz nur streng, wenn beide Seiten einen haben."""
    if (sn, h, zs) in voll:
        return True
    if zs == "" or (sn, h, "") in voll:
        return (sn, h) in kurz
    return False


def _prioritaet_fehlend(adressen, je):
    """hoch = Luecke in der Nummernfolge (Nachbarn derselben Strassenseite, Nr. -2..-6 und +2..+6, stehen in der Liste; bei gemischter
    Nummerierung -1..-3 und +1..+3), mittel = Strasse in der Liste und Nummer zwischen kleinster und groesster Listennummer
    (z. B. ganze Strassenseite fehlt: anderes Gebiet oder wirklich vergessen), niedrig = Strasse nicht in der Liste oder ausserhalb."""
    stufe = "niedrig"
    for sn, h, _, _ in adressen:
        if sn not in je:
            continue
        nrn = je[sn]
        gemischt = any(x % 2 for x in nrn) and any(not x % 2 for x in nrn)
        schritte = [(2, 4, 6)] + ([(1, 2, 3)] if gemischt else [])
        for s in schritte:
            if any(h - d in nrn for d in s) and any(h + d in nrn for d in s):
                return "hoch"
        if min(nrn) <= h <= max(nrn):
            stufe = "mittel"
    return stufe


def fehlender_bedarf(adr, gebaeude, umfeld_m=60.0):
    """Relevante ALKIS-Gebaeude mit Adresse (lagebeztxt), deren Adressen alle NICHT in der Liste stehen und in denen kein Listenpunkt liegt,
    im Umfeld der Liste (naechste Listenadresse <= umfeld_m). Prioritaet hoch/mittel/niedrig siehe _prioritaet_fehlend.
    -> GeoDataFrame (Polygone) oder None"""
    if gebaeude is None or not len(gebaeude) or "lagebeztxt" not in gebaeude:
        return None
    import geopandas as gpd
    from shapely.strtree import STRtree
    pts = [(i, p) for i, (p, f) in enumerate(zip(adr.geometry, adr["koord_fehlt"])) if p is not None and not isinstance(p, float) and not f]
    if not pts:
        return None
    tree = STRtree([p for _, p in pts])
    voll, kurz, je = _listen_index(adr)
    rel = gebaeude[gebaeude["relevant"].astype(bool)].reset_index(drop=True)
    zeilen, geoms = [], []
    for i, g in enumerate(rel.geometry):
        if g is None or g.is_empty or g.area < 30.0:
            continue
        adressen = alkis_adressen(rel["lagebeztxt"].iat[i])
        if not adressen:
            continue
        if any(_in_liste(sn, h, zs, voll, kurz) for sn, h, zs, _ in adressen):
            continue                                    # Adresse ist in der Liste, nur die Koordinate liegt woanders
        if len(tree.query(g, predicate="intersects")):
            continue                                    # ein Listenpunkt liegt im Gebaeude
        nah = [j for j in tree.query(g.buffer(umfeld_m)) if g.distance(pts[j][1]) <= umfeld_m]   # query liefert Bbox-Kandidaten
        if not nah:
            continue                                    # ausserhalb des Umfelds der Liste (Rand des ALKIS-Abrufs)
        j_min = min(nah, key=lambda j: g.distance(pts[j][1]))
        d = g.distance(pts[j_min][1])
        r_n = adr.iloc[pts[j_min][0]]
        prio = _prioritaet_fehlend(adressen, je)
        funktion = _s(rel["funktion"].iat[i])
        sn0, h0, zs0, txt0 = adressen[0]
        strasse0 = re.sub(r"\s+\d.*$", "", txt0).strip()
        for s in adr["strasse"].unique():                     # Schreibweise der Liste bevorzugen (Hüttenstr. statt Hüttenstraße)
            if _norm_strasse(s) == sn0:
                strasse0 = _s(s).strip()
                break
        q = g.representative_point()
        zeilen.append({"oid": _s(rel["oid"].iat[i]) if "oid" in rel else "", "adresse": ", ".join(t for _, _, _, t in adressen),
                       "strasse": strasse0, "hnr": str(h0), "hnr_zs": zs0.upper(), "plz": _s(r_n.get("plz")), "ort": _s(r_n.get("ort")),
                       "ortsteil": _s(r_n.get("ortsteil")), "we": max(1, len(adressen)), "gebaeudetyp": _gebaeudetyp_alkis(funktion),
                       "apl_x": round(q.x, 2), "apl_y": round(q.y, 2),
                       "lagebeztxt": _s(rel["lagebeztxt"].iat[i]), "funktion": funktion, "flaeche_m2": round(g.area),
                       "naechste_adresse": _adresse(r_n), "abstand_m": round(d, 1), "prioritaet": prio,
                       "hinweis": {"hoch": "Luecke in der Nummernfolge: Nachbarn stehen in der Liste, dieses Gebaeude nicht (fehlender Bedarf?)",
                                   "mittel": "Strasse in der Liste, Nummer im Bereich, aber Nachbarn fehlen auch (andere Strassenseite/anderes Gebiet oder vergessen?)",
                                   "niedrig": "Am Rand: Strasse nicht in der Liste oder Nummer ausserhalb (meist anderes Gebiet)"}[prio],
                       "status": "offen", "kommentar": ""})
        geoms.append(g)
    if not zeilen:
        return None
    out = gpd.GeoDataFrame(zeilen, geometry=geoms, crs=CRS)
    out["_rang"] = out["prioritaet"].map({"hoch": 0, "mittel": 1, "niedrig": 2})
    return out.sort_values(["_rang", "flaeche_m2"], ascending=[True, False]).drop(columns="_rang").reset_index(drop=True)


def _gebaeudetyp_alkis(funktion):
    f = _s(funktion).lower()
    if "wohn" in f:
        return regeln.WOHNHAUS
    if "wirtschaft" in f or "gewerbe" in f or "industrie" in f or "handel" in f:
        return regeln.GEWERBE
    if "öffentlich" in f or "oeffentlich" in f or "verwaltung" in f:
        return regeln.OEFFENTLICH
    return ""


# --- Moegliche Bauluecken: unbebaute Bauflaechen-Flurstuecke zwischen bebauten (Markus 17.09.2026, Weg 2 + 3) --------------------------------
def _hnr_vorschlag(nummern, belegt):
    """Freie Hausnummer zwischen zwei Nachbarnummern derselben Strassenseite (Abstand 4, z. B. 100 und 104 -> 102), wenn sie weder in der
    Liste noch in ALKIS vergeben ist; sonst ''. Kein Vorschlag bei Abstand 2 (Gegenseite) - lieber leer als falsch."""
    n = sorted(set(nummern))
    for a, b in zip(n, n[1:]):
        if b - a == 4 and (a + 2) not in belegt:
            return str(a + 2)
    return ""


def bauluecken_moeglich(adr, gebaeude, flur, min_m2=250.0, max_m2=3000.0, umfeld_m=60.0):
    """Unbebaute Flurstuecke mit Bauflaechen-Nutzung (Wohnbau, gemischt), ohne relevantes ALKIS-Gebaeude und ohne Listenpunkt, min_m2..max_m2,
    die an mindestens ein Flurstueck mit Listenadresse grenzen und hoechstens umfeld_m von der Liste entfernt liegen.
    hoch = zwischen zwei bebauten Nachbarflurstuecken (gleiche Strasse), mittel = ein bebauter Nachbar (Eck- oder Randgrundstueck).
    Nebengebaeude (Garage, Schuppen) auf dem Flurstueck sind erlaubt und werden vermerkt. Hausnummer-Vorschlag aus der ALKIS-Lagebezeichnung
    (reservierte Nummer) oder aus der Luecke zwischen den Nachbarnummern. Spalten apl_x/apl_y = Punkt fuer den spaeteren APL (25832).
    -> GeoDataFrame (Polygone) oder None"""
    if flur is None or not len(flur):
        return None
    import geopandas as gpd
    from collections import Counter
    from shapely.strtree import STRtree
    pts = [(i, p) for i, (p, f) in enumerate(zip(adr.geometry, adr["koord_fehlt"])) if p is not None and not isinstance(p, float) and not f]
    if not pts:
        return None
    t_pts = STRtree([p for _, p in pts])
    voll, kurz, je = _listen_index(adr)
    listen_strassen = {_norm_strasse(s): _s(s).strip() for s in adr["strasse"].unique() if _s(s).strip()}
    belegt = {sn: set(nrn) for sn, nrn in je.items()}                 # Hausnummern je Strasse: Liste + ALKIS-Gebaeude
    geb_geoms, geb_rel = [], []
    if gebaeude is not None and len(gebaeude):
        gb = gebaeude[gebaeude.geometry.notna()].reset_index(drop=True)
        geb_geoms = list(gb.geometry)
        geb_rel = gb["relevant"].astype(bool).tolist() if "relevant" in gb else [True] * len(gb)
        if "lagebeztxt" in gb:
            for t in gb["lagebeztxt"]:
                for sn, h, _, _ in alkis_adressen(t):
                    belegt.setdefault(sn, set()).add(h)
    t_geb = STRtree(geb_geoms) if geb_geoms else None
    fl = flur[flur.geometry.notna() & ~flur.geometry.is_empty].reset_index(drop=True)
    fl_geoms = list(fl.geometry)
    t_fl = STRtree(fl_geoms)
    # Listenadressen je Flurstueck (fuer bebaute Nachbarn)
    adr_je_fl = {}
    for i, p in pts:
        for j in t_fl.query(p, predicate="within"):
            adr_je_fl.setdefault(int(j), []).append(i)
    zeilen, geoms = [], []
    for k, g in enumerate(fl_geoms):
        fl_area = g.area
        if fl_area < min_m2 or fl_area > max_m2:
            continue
        nutz = _s(fl["nutzung"].iat[k]) if "nutzung" in fl else ""
        anteil = float(fl["bau_anteil"].iat[k]) if "bau_anteil" in fl and fl["bau_anteil"].iat[k] is not None else (1.0 if not nutz else 0.0)
        if nutz and anteil < 0.5:
            continue                                     # Acker, Gruenland, Wald, Verkehr, Garten ohne Bauflaeche
        if k in adr_je_fl:
            continue                                     # Listenadresse liegt drauf: bebaut
        neben = False
        if t_geb is not None:
            bebaut = False
            for j in t_geb.query(g, predicate="intersects"):
                j = int(j)
                try:
                    schnitt = geb_geoms[j].intersection(g).area
                except Exception:
                    schnitt = 0.0
                if schnitt < 15.0:
                    continue
                if geb_rel[j]:
                    bebaut = True
                    break
                neben = True
            if bebaut:
                continue
        nah = [j for j in t_pts.query(g.buffer(umfeld_m)) if g.distance(pts[j][1]) <= umfeld_m]
        if not nah:
            continue
        # bebaute Nachbarflurstuecke (gemeinsame Grenze) und deren Adressen
        nachbar_adr = []
        n_bebaut = 0
        for j in t_fl.query(g.buffer(3.0), predicate="intersects"):     # 3 m: schmale Graben-/Wegflurstuecke dazwischen zaehlen nicht als Trennung
            j = int(j)
            if j == k or j not in adr_je_fl:
                continue
            n_bebaut += 1
            nachbar_adr += adr_je_fl[j]
        if n_bebaut == 0:
            continue
        # Strasse: Lagebezeichnung des Flurstuecks ('Dorfstraße; Windenstraße', 'Kleff 155a'), erste die in der Liste vorkommt, in der
        # Schreibweise der Liste; sonst haeufigste Strasse der bebauten Nachbarn
        lage = _s(fl["lagebeztxt"].iat[k]) if "lagebeztxt" in fl else ""
        strassen = Counter(_s(adr["strasse"].iat[i]).strip() for i in nachbar_adr)
        strasse = ""
        for teil in re.split(r"\s*;\s*", lage):
            sn_t = _norm_strasse(re.sub(r"\s+\d.*$", "", teil.split(",")[0]).strip())
            if sn_t in listen_strassen:
                strasse = listen_strassen[sn_t]
                break
        if not strasse:
            strasse = strassen.most_common(1)[0][0] if strassen else re.sub(r"\s+\d.*$", "", lage.split(";")[0].split(",")[0]).strip()
        sn = _norm_strasse(strasse)
        hnr, hnr_quelle = "", ""
        for sn_l, h, zs, _ in alkis_adressen(lage):
            if sn_l == sn and not _in_liste(sn_l, h, zs, voll, kurz):
                hnr, hnr_quelle = "{}{}".format(h, zs), "ALKIS-Lagebezeichnung"
                break
        gleiche = [regeln._int(adr["hnr"].iat[i]) for i in nachbar_adr if _norm_strasse(adr["strasse"].iat[i]) == sn and regeln._int(adr["hnr"].iat[i])]
        if not hnr and len(set(gleiche)) >= 2:
            hnr = _hnr_vorschlag(gleiche, belegt.get(sn, set()))
            hnr_quelle = "Luecke zwischen den Nachbarn" if hnr else ""
        nachbarn_txt = ", ".join(sorted({_adresse(adr.iloc[i]) for i in nachbar_adr}))
        prio = "hoch" if len(set(gleiche)) >= 2 else "mittel"
        j_min = min(nah, key=lambda j: g.distance(pts[j][1]))
        r_n = adr.iloc[pts[j_min][0]]
        q = g.representative_point()
        zeilen.append({"flstkennz": _s(fl["flstkennz"].iat[k]) if "flstkennz" in fl else "", "gemarkung": _s(fl["gemarkung"].iat[k]) if "gemarkung" in fl else "",
                       "flur": _s(fl["flur"].iat[k]) if "flur" in fl else "", "flurstnr": _s(fl["flurstnr"].iat[k]) if "flurstnr" in fl else "",
                       "flaeche_m2": round(fl_area), "nutzung": nutz or "unbekannt", "bau_anteil": anteil, "lagebeztxt": lage,
                       "strasse": strasse, "hnr": hnr, "hnr_zs": "", "hnr_quelle": hnr_quelle, "nachbarn": nachbarn_txt,
                       "nebengebaeude": int(neben), "plz": _s(r_n.get("plz")), "ort": _s(r_n.get("ort")), "ortsteil": _s(r_n.get("ortsteil")),
                       "we": 1, "gebaeudetyp": regeln.WOHNHAUS, "prioritaet": prio,
                       "hinweis": ("Unbebautes Bauflaechen-Flurstueck zwischen bebauten Nachbarn" if prio == "hoch" else
                                   "Unbebautes Bauflaechen-Flurstueck mit einem bebauten Nachbarn (Eck- oder Randgrundstueck)")
                                  + (", Nebengebaeude vorhanden" if neben else ""),
                       "status": "offen", "kommentar": "", "apl_x": round(q.x, 2), "apl_y": round(q.y, 2)})
        geoms.append(g)
    if not zeilen:
        return None
    out = gpd.GeoDataFrame(zeilen, geometry=geoms, crs=CRS)
    out["_rang"] = out["prioritaet"].map({"hoch": 0, "mittel": 1})
    return out.sort_values(["_rang", "flaeche_m2"], ascending=[True, False]).drop(columns="_rang").reset_index(drop=True)


def gebaeude_ohne_adresse(adr, gebaeude, radius_m=12.0, umfeld_m=60.0):
    """Relevante ALKIS-Gebaeude OHNE Lagebezeichnung im Umfeld der Adressen (umfeld_m), die keine Adresse in radius_m haben
    (Nebengebaeude, Neubau ohne Adresse). Gebaeude mit ALKIS-Adresse laufen ueber fehlender_bedarf(). -> GeoDataFrame"""
    if gebaeude is None or not len(gebaeude):
        return None
    from shapely.strtree import STRtree
    pts = [p for p, f in zip(adr.geometry, adr["koord_fehlt"]) if p is not None and not f]
    if not pts:
        return None
    tree = STRtree(pts)
    rel = gebaeude[gebaeude["relevant"]].reset_index(drop=True)
    treffer = []
    for i, g in enumerate(rel.geometry):
        if g is None or g.is_empty or g.area < 30.0:
            continue
        if "lagebeztxt" in rel and alkis_adressen(rel["lagebeztxt"].iat[i]):
            continue
        nah = tree.query(g.buffer(radius_m))
        if len(nah):
            continue
        if len(tree.query(g.buffer(umfeld_m))) == 0:
            continue
        treffer.append(i)
    out = rel.iloc[treffer].copy()
    out["prioritaet"] = ["hoch" if "wohn" in str(f).lower() else "mittel" for f in out["funktion"]]
    out["hinweis"] = "Gebaeude ohne Adresse in ALKIS und ohne Adresse in der Liste (Pruefen: Nebengebaeude, Neubau)"
    out["status"] = "offen"
    out["flaeche_m2"] = out.geometry.area.round(0)
    return out.sort_values(["prioritaet", "flaeche_m2"], ascending=[True, False]).reset_index(drop=True)


# --- Bedarf ----------------------------------------------------------------------------------------------------------------------------
def we_umgebung(adr, radius_m=150.0, n_min=5, n_max=12):
    """ZTV 21 Kap. 13: Bauluecken (0 WE) zaehlen mit der mittleren WE-Zahl der Umgebung, nie 0 (Markus 30.09.2026: "ja, Umgebungs-WE").
    Je Adresse mit 0 WE und 0 GE: Mittel der WE der naechsten Adressen mit WE - bevorzugt dieselbe Strasse im Umkreis radius_m
    (mindestens n_min, hoechstens n_max Nachbarn), sonst die naechsten n_min Adressen, sonst Median des Gebiets. -> dict index -> WE"""
    import numpy as np
    we = np.array([regeln._int(v) for v in adr["we"]], dtype=float)
    ge = np.array([regeln._int(v) for v in adr["ge"]], dtype=float) if "ge" in adr else np.zeros(len(adr))
    typ = [regeln.gebaeudetyp(f, g)[0] for f, g in zip(adr["gebaeude"], ge)] if "gebaeude" in adr else [""] * len(adr)
    null = [(w == 0 and g == 0 and t in (regeln.WOHNHAUS, regeln.UNBEKANNT)) for w, g, t in zip(we, ge, typ)]
    if not any(null):
        return {}
    xy = np.array([(p.x, p.y) if p is not None and not p.is_empty else (np.nan, np.nan) for p in adr.geometry], dtype=float)
    mit = np.where((we > 0) & ~np.isnan(xy[:, 0]))[0]
    strassen = adr["strasse"].astype(str).str.strip().str.lower().to_numpy() if "strasse" in adr else np.array([""] * len(adr))
    median = float(np.median(we[mit])) if len(mit) else 1.0
    out = {}
    for i in np.where(null)[0]:
        if not len(mit) or np.isnan(xy[i, 0]):
            out[adr.index[i]] = max(1.0, median)
            continue
        d = np.hypot(xy[mit, 0] - xy[i, 0], xy[mit, 1] - xy[i, 1])
        reihe = np.argsort(d)
        nah = reihe[d[reihe] <= radius_m]
        gleiche = [k for k in nah if strassen[mit[k]] and strassen[mit[k]] == strassen[i]]
        wahl = gleiche[:n_max] if len(gleiche) >= n_min else list(nah[:n_max])
        if len(wahl) < n_min:
            wahl = list(reihe[:n_min])
        out[adr.index[i]] = max(1.0, float(np.mean(we[mit[np.array(wahl, dtype=int)]])))
    return out


def bedarf(adr, treiber="", log=print, mbfd=None):
    import pandas as pd
    if mbfd is None:
        mbfd = ist_mbfd(adr) or regelwerk.ist_mbfd_text(treiber)
    umf = we_umgebung(adr) if mbfd else {}
    rows = [regeln.bedarf(we, ge, p2p, gt, gf, treiber or sp, mbfd=mbfd, we_umfeld=umf.get(i)) for i, we, ge, p2p, gt, gf, sp in
            zip(adr.index, adr["we"], adr["ge"], adr["p2p"], adr["gebietstyp"], adr["gebaeude"], adr["sponsor"])]
    b = pd.DataFrame(rows, index=adr.index)
    for c in b.columns:
        if c == "treiber":
            continue
        adr[c] = b[c]
    if "ampel" not in adr:          # Bedarf ohne vorherige Pruefung (z. B. Werkzeug 3 direkt aus der Bedarfsliste)
        adr["ampel"] = "gruen"
    if "hinweise" not in adr:
        adr["hinweise"] = ""
    if umf:
        idx = list(umf.keys())
        adr.loc[idx, "hinweise"] = [((h + "; ") if h else "") + "Bedarf mit mittlerer WE der Umgebung ({:.0f}) angesetzt (ZTV 21 Kap. 13)".format(umf[i])
                                    for i, h in zip(idx, adr.loc[idx, "hinweise"].fillna("").astype(str))]
        log("MBfD Kap. 13: {} Adressen mit 0 WE bekommen die mittlere WE der Umgebung (Mittel {:.1f}, {} bis {} WE)".format(
            len(umf), sum(umf.values()) / len(umf), int(round(min(umf.values()))), int(round(max(umf.values())))))
    if mbfd:
        log("Bedarf nach ZTV 21 Kap. 13 (MBfD): 4 Fs je WE + 2 je Gebaeude, {} Fs Hauszufuehrung gesamt, kein pauschaler Zusatzbedarf".format(
            int(pd.to_numeric(adr["fasern_bedarf"], errors="coerce").fillna(0).sum())))
    frag = adr["sonderfall"].str.contains("fragt nach", na=False)
    adr.loc[frag & (adr["ampel"] == "gruen"), "ampel"] = "gelb"
    adr.loc[frag, "hinweise"] = adr.loc[frag, "hinweise"].where(adr.loc[frag, "hinweise"] != "", "") + \
        adr.loc[frag, "hinweise"].apply(lambda h: "; " if h else "") + "Bedarf beim Planer nachfragen"
    adr["status"] = "offen"
    adr["kommentar"] = ""
    log("Bedarf: {} Anschluesse, {} SNR, {} Adressen mit Sonderfall, {} im Gewerbegebiet, Gebaeudetypen {}".format(
        int(adr["anschluesse"].sum()), int(adr["snr"].sum()), int((adr["sonderfall"] != "").sum()), int(adr["gewerbegebiet"].sum()),
        dict(adr["gebaeudetyp"].replace("", "unbekannt").value_counts())))
    return adr


# --- Schreiben -------------------------------------------------------------------------------------------------------------------------
def ausgabe_pfad(quelle, out_dir=None, name=None):
    stamm = name or re.sub(r"[^A-Za-z0-9_\-]+", "_", os.path.splitext(os.path.basename(quelle))[0]).strip("_")[:40] or "Adressen"
    ordner = out_dir or os.path.dirname(os.path.abspath(quelle))
    return os.path.join(ordner, "adresspruefung_{}_{}.gpkg".format(stamm, datetime.now().strftime("%Y%m%d_%H%M")))


def schreiben(adr, gebaeude, gpkg, log=print, fehlend=None, bauluecken=None):
    """Layer adressen, bauluecken (Adressen ohne Gebaeude), fehlender_bedarf, bauluecken_moeglich, gebaeude_ohne_adresse (wenn vorhanden),
    alkis_gebaeude (relevant). -> Liste (layername, anzahl)"""
    import geopandas as gpd
    import pandas as pd
    os.makedirs(os.path.dirname(gpkg), exist_ok=True)
    a = adr.copy()
    for c in a.columns:
        if a[c].dtype == object and c != "geometry":
            a[c] = a[c].astype(str).replace({"None": "", "nan": ""})
    for c in ("we", "ge", "p2p"):
        a[c] = [regeln._int(v) for v in a[c]]
    for c in ("bedarfspunkt", "koord_fehlt", "bauluecke", "gemischt", "gewerbegebiet", "im_gebaeude"):
        if c in a:
            a[c] = a[c].astype(int)
    mit = a[a.geometry.notna()]
    ohne = a[a.geometry.isna()].drop(columns="geometry")
    layer = []
    mit.to_file(gpkg, layer="adressen", driver="GPKG")
    layer.append(("adressen", len(mit)))
    if len(ohne):
        ohne.to_csv(os.path.splitext(gpkg)[0] + "_ohne_koordinate.csv", sep=";", index=False, encoding="utf-8-sig")
        layer.append(("ohne Koordinate (CSV)", len(ohne)))
    bl = mit[mit["bauluecke"] == 1]
    if len(bl):
        bl.to_file(gpkg, layer="bauluecken", driver="GPKG")
        layer.append(("bauluecken", len(bl)))
    vp, vl = vorschlag_layer(adr)
    if vp is not None and len(vp):
        vp.to_file(gpkg, layer="vorschlaege", driver="GPKG")
        layer.append(("vorschlaege", len(vp)))
        if vl is not None and len(vl):
            vl.to_file(gpkg, layer="vorschlag_linien", driver="GPKG")
            layer.append(("vorschlag_linien", len(vl)))
    mbfd = ist_mbfd(adr)            # MBfD: keine neuen Adressen - weder fehlender Bedarf noch Gebaeude ohne Adresse
    if gebaeude is not None and len(gebaeude):
        if fehlend is None and not mbfd:
            fehlend = fehlender_bedarf(adr, gebaeude)
        if fehlend is not None and len(fehlend):
            fehlend.to_file(gpkg, layer="fehlender_bedarf", driver="GPKG")
            layer.append(("fehlender_bedarf", len(fehlend)))
        if bauluecken is not None and len(bauluecken):
            bauluecken.to_file(gpkg, layer="bauluecken_moeglich", driver="GPKG")
            layer.append(("bauluecken_moeglich", len(bauluecken)))
        goa = gebaeude_ohne_adresse(adr, gebaeude) if not mbfd else None
        if goa is not None and len(goa):
            goa.to_file(gpkg, layer="gebaeude_ohne_adresse", driver="GPKG")
            layer.append(("gebaeude_ohne_adresse", len(goa)))
        rel = gebaeude[gebaeude["relevant"]].copy()
        rel["relevant"] = rel["relevant"].astype(int)
        rel.to_file(gpkg, layer="alkis_gebaeude", driver="GPKG")
        layer.append(("alkis_gebaeude", len(rel)))
    log("Geschrieben: {} ({})".format(gpkg, ", ".join("{} {}".format(n, l) for l, n in layer)))
    return layer


def bericht(adr, gebaeude, gpkg, quelle, land, log=print, fehlend=None, bauluecken=None, flur_geladen=False):
    """Markdown-Bericht neben dem GeoPackage. -> Pfad"""
    import pandas as pd
    p = os.path.splitext(gpkg)[0] + "_bericht.md"
    n_bl = 0 if bauluecken is None else len(bauluecken)
    n_bl_hoch = 0 if not n_bl else int((bauluecken["prioritaet"] == "hoch").sum())
    if fehlend is None and gebaeude is not None and len(gebaeude):
        fehlend = fehlender_bedarf(adr, gebaeude)
    n_fehlend = 0 if fehlend is None else len(fehlend)
    zf = fehlend["prioritaet"].value_counts() if n_fehlend else {}
    n_fehlend_hoch, n_fehlend_mittel, n_fehlend_niedrig = int(zf.get("hoch", 0)), int(zf.get("mittel", 0)), int(zf.get("niedrig", 0))
    z = adr["ampel"].value_counts()
    zeilen = ["# Adresspruefung {}".format(os.path.basename(quelle)),
              "", "Stand {}, Fiberation Werkzeugkasten, Werkzeug 2. Quelle: {}`{}`. ALKIS: {}.".format(
                  datetime.now().strftime("%d.%m.%Y %H:%M"), "MBfD-Angebotslayer (Plan[Goo]) " if str(quelle).lower().endswith(".gpkg") else "", quelle, "{} ({} Gebaeude)".format(land, len(gebaeude)) if gebaeude is not None else "nicht abgerufen"),
              "", "## Ampel", "",
              "| Ampel | Adressen |", "|---|---|",
              "| gruen | {} |".format(int(z.get("gruen", 0))), "| gelb | {} |".format(int(z.get("gelb", 0))), "| rot | {} |".format(int(z.get("rot", 0))),
              "", "## Pruefungen", ""]
    hin = pd.Series([h for hs in adr["hinweise"] for h in hs.split("; ") if h]).str.replace(r"\d+(\.\d+)?", "n", regex=True)
    for txt, n in hin.value_counts().items():
        zeilen.append("- {}: {}".format(txt, n))
    zeilen += ["", "## Bedarf", "",
               "| Groesse | Summe |", "|---|---|",
               "| Adressen | {} |".format(len(adr)),
               "| WE laut Liste | {} |".format(int(sum(regeln._int(v) for v in adr["we"]))),
               "| Gewerbeeinheiten | {} |".format(int(sum(regeln._int(v) for v in adr["ge"]))),
               "| FTTH-Anschluesse (WE + Gewerbe + Zusatzbedarf) | {} |".format(int(adr["anschluesse"].sum())),
               "| SNR am NVT | {} |".format(int(adr["snr"].sum())),
               "| Direktfasern | {} |".format(int(adr["fasern_direkt"].sum())),
               "| Adressen mit 12-Fs-Hauszufuehrung | {} |".format(int((adr["fasern_haus"] >= 12).sum())),
               "| Sonderfaelle | {} |".format(int((adr["sonderfall"] != "").sum())),
               "| im Gewerbegebiet | {} |".format(int(adr["gewerbegebiet"].sum())),
               "| Adressen ohne Gebaeude (Platzhalter-Nr. oder kein ALKIS-Gebaeude) | {} |".format(int(adr["bauluecke"].sum())),
               "| Fehlender Bedarf: ALKIS-Gebaeude mit Adresse, nicht in der Liste (Luecke in der Nummernfolge / Strasse in der Liste / am Rand) | {} ({} / {} / {}) |".format(
                   n_fehlend, n_fehlend_hoch, n_fehlend_mittel, n_fehlend_niedrig),
               "| Moegliche Bauluecken: unbebaute Bauflaechen-Flurstuecke (zwischen bebauten / Eck- oder Rand) | {} |".format(
                   "{} ({} / {})".format(n_bl, n_bl_hoch, n_bl - n_bl_hoch) if flur_geladen else "nicht geprueft (keine Flurstuecke)"),
               "| Koordinate im Gebaeude / daneben / kein Gebaeude | {} / {} / {} |".format(
                   int(adr["im_gebaeude"].sum()) if "im_gebaeude" in adr else 0,
                   int(((~adr["im_gebaeude"]) & (adr["alkis_abstand_m"] <= 12)).sum()) if "im_gebaeude" in adr else 0,
                   int((adr["alkis_abstand_m"] > 12).sum())),
               "", "Gebaeudetypen (Plan[Goo]): " + ", ".join("{} {}".format(k or "unbekannt", v) for k, v in adr["gebaeudetyp"].value_counts().items()),
               "", "## Rote Faelle", ""]
    rot = adr[adr["ampel"] == "rot"]
    for _, r in rot.head(60).iterrows():
        zeilen.append("- {} {}{} ({}): {}".format(r["strasse"], r["hnr"], r["hnr_zs"] or "", r["kls_id"], r["hinweise"]))
    if len(rot) > 60:
        zeilen.append("- ... {} weitere im Layer".format(len(rot) - 60))
    zeilen += ["", "## Sonderfaelle", ""]
    for _, r in adr[adr["sonderfall"] != ""].head(60).iterrows():
        zeilen.append("- {} {}{}: {} -> {}".format(r["strasse"], r["hnr"], r["hnr_zs"] or "", r["gebaeude"], r["sonderfall"]))
    zeilen += ["", "## Fehlender Bedarf (ALKIS-Gebaeude mit Adresse, die nicht in der Liste steht)", ""]
    if n_fehlend:
        zeilen.append("Kein Listenpunkt im Gebaeude, keine der ALKIS-Adressen in der Liste, naechste Listenadresse hoechstens 60 m entfernt. "
                      "Layer `fehlender_bedarf` (Spalten status, kommentar fuer den Planer).")
        for prio, titel in (("hoch", "Luecke in der Nummernfolge - Nachbarn derselben Strassenseite stehen in der Liste (klarer Kandidat)"),
                            ("mittel", "Strasse in der Liste, Nummer im Bereich, Nachbarn fehlen ebenfalls (ganze Strassenseite: anderes Gebiet oder vergessen?)")):
            teil = fehlend[fehlend["prioritaet"] == prio]
            if not len(teil):
                continue
            zeilen += ["", "### {} ({})".format(titel, len(teil)), ""]
            for _, r in teil.head(60).iterrows():
                zeilen.append("- {} ({}, {:.0f} m2): naechste Listenadresse {} in {} m".format(
                    r["adresse"], r["funktion"] or "Funktion unbekannt", r["flaeche_m2"], r["naechste_adresse"], r["abstand_m"]))
            if len(teil) > 60:
                zeilen.append("- ... {} weitere im Layer".format(len(teil) - 60))
        if n_fehlend_niedrig:
            zeilen += ["", "Am Rand (Strasse nicht in der Liste oder Nummer ausserhalb, meist anderes Gebiet): {} Gebaeude, nur im Layer.".format(n_fehlend_niedrig)]
    else:
        zeilen.append("keine" if gebaeude is not None else "nicht geprueft (ALKIS nicht abgerufen)")
    zeilen += ["", "## Moegliche Bauluecken (unbebaute Bauflaechen-Flurstuecke)", ""]
    if n_bl:
        zeilen.append("ALKIS-Flurstueck mit Nutzung Wohnbau/gemischt, 250-3000 m2, ohne Wohn-/Gewerbegebaeude und ohne Listenadresse, mit gemeinsamer "
                      "Grenze zu mindestens einem Flurstueck mit Listenadresse. Layer `bauluecken_moeglich`; status geprueft = geht bei der "
                      "Uebernahme als APL mit Begruendung Bauluecke nach Plan[Goo] (1 WE, Annahme).")
        for prio, titel in (("hoch", "Zwischen bebauten Nachbarn derselben Strasse"), ("mittel", "Ein bebauter Nachbar (Eck- oder Randgrundstueck)")):
            teil = bauluecken[bauluecken["prioritaet"] == prio]
            if not len(teil):
                continue
            zeilen += ["", "### {} ({})".format(titel, len(teil)), ""]
            for _, r in teil.head(60).iterrows():
                zeilen.append("- {}{} ({}, {:.0f} m2, Flurstueck {} Flur {} Gemarkung {}){}: Nachbarn {}".format(
                    r["strasse"] or "Strasse unbekannt", " " + r["hnr"] + " (" + r["hnr_quelle"] + ")" if r["hnr"] else "",
                    r["nutzung"], r["flaeche_m2"], r["flurstnr"], r["flur"], r["gemarkung"],
                    ", Nebengebaeude" if r["nebengebaeude"] else "", r["nachbarn"]))
            if len(teil) > 60:
                zeilen.append("- ... {} weitere im Layer".format(len(teil) - 60))
    elif flur_geladen:
        zeilen.append("keine")
    else:
        zeilen.append("nicht geprueft (keine ALKIS-Flurstuecke geladen)")
    zeilen += ["", "Regeln: ZTV TK-Netz 21 (Nov. 2025) Kap. 8.5.1.1-8.5.1.7, 8.8.1-8.8.2. Kenner: A = amtliche Adresse mit Gebaeude "
               "(aus Daten abgeleitet, Telekom-Dokumentation offen). Spalten status und kommentar gehoeren dem Planer.", ""]
    with open(p, "w", encoding="utf-8") as f:
        f.write("\n".join(zeilen))
    log("Bericht: " + p)
    return p


# --- Gesamtablauf ------------------------------------------------------------------------------------------------------------------------
def lauf(quelle, out_dir=None, land=None, mit_alkis=True, treiber="", adr=None, log=print, fortschritt=None, mit_flur=True):
    """Alles in einem: laden (oder `adr` uebergeben), ALKIS (Gebaeude, Flurstuecke), pruefen, Bedarf, fehlender Bedarf, moegliche Bauluecken,
    schreiben, Bericht. -> dict. fortschritt(prozent, text) wird je Phase gerufen (ALKIS-Abruf je Kachel)."""
    from . import alkis
    f = fortschritt or (lambda p, t: None)
    f(2, "Adressen laden")
    if adr is None:
        adr = lesen_quelle(quelle, log)
    mbfd = ist_mbfd(adr)
    if mbfd:
        log("MBfD: die Adressliste steht fest (Angebot) - keine Suche nach fehlenden Adressen und Bauluecken, Verschieben wird als Abweichung gefuehrt; geprueft wird die Gueltigkeit der Adressen")
    geb, flur = None, None
    mit = adr[~adr["koord_fehlt"]]
    if mit_alkis and len(mit):
        minx, miny, maxx, maxy = mit.total_bounds
        if not land:
            kand = alkis.laender_fuer_bbox(minx, miny, maxx, maxy)
            land = kand[0] if kand else None
            log("Bundesland aus Umgriff: {}".format(", ".join(kand) or "unbekannt"))
        if land:
            f(8, "ALKIS-Gebaeude abrufen")
            geb = alkis.laden(minx, miny, maxx, maxy, land, log=log,
                              fortschritt=lambda a, b: f(8 + 34 * a / max(b, 1), "ALKIS-Gebaeude abrufen ({}/{})".format(a, b)))
            if mit_flur and geb is not None:
                f(42, "ALKIS-Flurstuecke abrufen")
                flur = alkis.laden_flurstuecke(minx, miny, maxx, maxy, land, log=log,
                                               fortschritt=lambda a, b: f(42 + 18 * a / max(b, 1), "ALKIS-Flurstuecke abrufen ({}/{})".format(a, b)))
    f(62, "Adressen pruefen")
    pruefen(adr, geb, log=log, mbfd=mbfd, flur=flur)
    f(72, "Lagevorschlaege")
    vorschlaege(adr, geb, log=log)
    f(78, "Bedarf bestimmen")
    bedarf(adr, treiber, log=log)
    f(84, "Fehlenden Bedarf suchen")
    fehlend = fehlender_bedarf(adr, geb) if geb is not None and not mbfd else None
    if fehlend is not None and len(fehlend):
        zf = fehlend["prioritaet"].value_counts()
        log("Fehlender Bedarf: {} ALKIS-Gebaeude mit Adresse, die nicht in der Liste steht ({} Luecke in der Nummernfolge, {} Strasse in der Liste, {} am Rand)".format(
            len(fehlend), int(zf.get("hoch", 0)), int(zf.get("mittel", 0)), int(zf.get("niedrig", 0))))
    f(85, "Moegliche Bauluecken suchen")
    bl = bauluecken_moeglich(adr, geb, flur) if flur is not None and not mbfd else None
    if bl is not None and len(bl):
        log("Moegliche Bauluecken: {} unbebaute Bauflaechen-Flurstuecke ({} zwischen bebauten Nachbarn, {} Eck/Rand)".format(
            len(bl), int((bl["prioritaet"] == "hoch").sum()), int((bl["prioritaet"] == "mittel").sum())))
    elif flur is not None and not mbfd:
        log("Moegliche Bauluecken: keine")
    f(86, "GeoPackage schreiben")
    gpkg = ausgabe_pfad(quelle, out_dir)
    layer = schreiben(adr, geb, gpkg, log, fehlend=fehlend, bauluecken=bl)
    f(96, "Bericht schreiben")
    md = bericht(adr, geb, gpkg, quelle, land, log, fehlend=fehlend, bauluecken=bl, flur_geladen=flur is not None)
    f(100, "Fertig")
    return {"gpkg": gpkg, "bericht": md, "layer": layer, "adressen": adr, "gebaeude": geb, "land": land, "fehlend": fehlend, "bauluecken": bl}


# --- Pruefliste: Lagevorschlaege fuer gelbe und rote Adressen (Markus 16.09.2026) --------------------------------------------------------
RICHTUNGEN = ["N", "NO", "O", "SO", "S", "SW", "W", "NW"]
VORSCHLAG_SPALTEN = ("vorschlag_x", "vorschlag_y", "vorschlag_m", "vorschlag_text", "vorschlag_quelle")


def _richtung(dx, dy):
    import math
    return RICHTUNGEN[int(((math.degrees(math.atan2(dx, dy)) % 360) + 22.5) // 45) % 8]


def _adresse(r):
    return "{} {}{}".format(_s(r.get("strasse")), _s(r.get("hnr")), _s(r.get("hnr_zs"))).strip()


def _offen(adr):
    import pandas as pd
    if "status" in adr:
        return adr["status"].astype(str).replace({"": "offen", "None": "offen", "nan": "offen"}).reset_index(drop=True)
    return pd.Series(["offen"] * len(adr))


LAGE_HINWEISE = re.compile(r"keine Koordinate|neben dem Gebaeude|kein ALKIS-Gebaeude|naechstes ALKIS-Gebaeude|Platzhalter-Hausnummer|"
                           r"Bauluecke\?|gleiche Koordinate", re.I)


def _lageproblem(adr, i, koord_fehlt, im_geb):
    """Nur Adressen, deren Koordinate fraglich ist, bekommen einen Lagevorschlag (Markus 17.09.): fehlende Koordinate, Punkt neben oder
    ohne Gebaeude, Platzhalter-Nummer, Sammelpunkt. Kenner, Telekom-Bewertung, leere Gebaeudefunktion, Nutzung, Dubletten sind
    Attributfragen - die Lage stimmt, ein Verschieben kostet den Planer nur Zeit."""
    if koord_fehlt:
        return True
    if LAGE_HINWEISE.search(_s(adr["hinweise"].iat[i]) if "hinweise" in adr else ""):
        return True
    return not im_geb


def _nachbarn(nach_liste, h, p):
    """Nachbarn derselben Strasse fuer die Mitte: erst gleiche Strassenseite (Nr. -2/-4 und +2/+4), sonst -1/-2 und +1/+2
    (Strassen ohne gerade/ungerade Teilung). -> (unten, oben) als Listen (hnr, Punkt)"""
    for schritte in ((2, 4), (1, 2)):
        unten = [(hh, q) for hh, q in nach_liste if (h - hh) in schritte and q is not p]
        oben = [(hh, q) for hh, q in nach_liste if (hh - h) in schritte and q is not p]
        if unten and oben:
            return unten, oben
    return [], []


def vorschlaege(adr, gebaeude=None, max_m=40.0, nachbar_m=150.0, log=print):
    """Je gelber/roter Adresse mit status offen UND Lageproblem (_lageproblem) ein Lagevorschlag (Callout im Werkzeug):
       1. naechstes relevantes ALKIS-Gebaeude in max_m, in dem noch keine Adresse liegt (Koordinate neben dem Haus, Hof/Sammelpunkt),
       2. sonst Mitte zwischen den Nachbarn derselben Strasse und Strassenseite (Nr. -2/-4 und +2/+4, sonst -1/-2 und +1/+2; auch ohne
          Koordinate), auf ein freies Gebaeude in 25 m gezogen, wenn vorhanden.
       Spalten vorschlag_x/y (25832), vorschlag_m (Abstand zur alten Lage), vorschlag_text, vorschlag_quelle. -> Anzahl Vorschlaege"""
    import numpy as np
    from collections import Counter
    from shapely.geometry import Point
    from shapely.strtree import STRtree
    for c in VORSCHLAG_SPALTEN:
        adr[c] = np.nan if c in ("vorschlag_x", "vorschlag_y", "vorschlag_m") else ""
    n = len(adr)
    status = _offen(adr)
    geoms, funk, tree = [], [], None
    if gebaeude is not None and len(gebaeude):
        rel = gebaeude[gebaeude["relevant"].astype(bool)].reset_index(drop=True) if "relevant" in gebaeude else gebaeude.reset_index(drop=True)
        rel = rel[rel.geometry.notna() & (rel.geometry.area >= 25.0)].reset_index(drop=True)
        geoms = list(rel.geometry)
        funk = rel["funktion"].fillna("").astype(str).tolist() if "funktion" in rel else [""] * len(geoms)
        tree = STRtree(geoms) if geoms else None
    koord_fehlt = adr["koord_fehlt"].astype(bool).tolist() if "koord_fehlt" in adr else [g is None for g in adr.geometry]
    pts = [(i, p) for i, p in enumerate(adr.geometry) if p is not None and not isinstance(p, float) and not koord_fehlt[i]]
    belegt = Counter()
    if tree is not None:
        for i, p in pts:
            for j in tree.query(p, predicate="within"):
                belegt[int(j)] += 1
    nach = {}
    for i, p in pts:
        h = regeln._int(adr["hnr"].iat[i])
        if h:
            nach.setdefault((_s(adr["strasse"].iat[i]).lower().strip(), _s(adr["plz"].iat[i]) if "plz" in adr else ""), []).append((h, p))
    im_geb = adr["im_gebaeude"].astype(bool).tolist() if "im_gebaeude" in adr else [False] * n
    anz, ohne_lageproblem = 0, 0
    for i in range(n):
        if adr["ampel"].iat[i] not in ("gelb", "rot") or status.iat[i] != "offen":
            continue
        if not _lageproblem(adr, i, koord_fehlt[i], im_geb[i]):
            ohne_lageproblem += 1
            continue
        p = adr.geometry.iat[i] if not koord_fehlt[i] else None
        if isinstance(p, float):
            p = None
        ziel, text, quelle = None, "", ""
        if p is not None and tree is not None and not im_geb[i]:
            kand = sorted(((geoms[j].distance(p), int(j)) for j in tree.query(p.buffer(max_m))), key=lambda t: t[0])
            for d, j in kand:
                if belegt.get(j, 0) == 0:
                    q = geoms[j].representative_point()
                    ziel, quelle = q, "gebaeude"
                    text = "ALKIS-Gebaeude ohne Adresse{} {:.0f} m {}".format(" (" + funk[j] + ")" if funk[j] else "", d, _richtung(q.x - p.x, q.y - p.y))
                    break
        if ziel is None:
            h = regeln._int(adr["hnr"].iat[i])
            k = (_s(adr["strasse"].iat[i]).lower().strip(), _s(adr["plz"].iat[i]) if "plz" in adr else "")
            if h and k in nach:
                unten, oben = _nachbarn(nach[k], h, p)
                if unten and oben:
                    hu, qu = max(unten, key=lambda t: t[0])
                    ho, qo = min(oben, key=lambda t: t[0])
                    if qu.distance(qo) <= nachbar_m:
                        m = Point((qu.x + qo.x) / 2.0, (qu.y + qo.y) / 2.0)
                        ziel, quelle, text = m, "nachbarn", "zwischen Nr. {} und Nr. {}".format(hu, ho)
                        if tree is not None:
                            kand = sorted(((geoms[j].distance(m), int(j)) for j in tree.query(m.buffer(25.0))), key=lambda t: t[0])
                            for d, j in kand:
                                if belegt.get(j, 0) == 0:
                                    ziel = geoms[j].representative_point()
                                    text += ", freies ALKIS-Gebaeude {:.0f} m daneben".format(d)
                                    break
        if ziel is None:
            continue
        adr.loc[adr.index[i], "vorschlag_x"] = round(ziel.x, 2)
        adr.loc[adr.index[i], "vorschlag_y"] = round(ziel.y, 2)
        adr.loc[adr.index[i], "vorschlag_m"] = round(p.distance(ziel), 1) if p is not None else np.nan
        adr.loc[adr.index[i], "vorschlag_text"] = text
        adr.loc[adr.index[i], "vorschlag_quelle"] = quelle
        anz += 1
    offen = int(((adr["ampel"].isin(["gelb", "rot"])).values & (status.values == "offen")).sum())
    log("Lagevorschlaege: {} fuer {} offene gelbe/rote Adressen ({} davon nur Attributfragen, Lage im Gebaeude - kein Vorschlag)".format(
        anz, offen, ohne_lageproblem))
    return anz


def vorschlag_layer(adr):
    """-> (Punkte am Vorschlag mit Adresse/Hinweis/Text, Linien alte Lage -> Vorschlag) fuer offene Adressen mit Vorschlag."""
    import geopandas as gpd
    from shapely.geometry import LineString, Point
    if "vorschlag_x" not in adr:
        return None, None
    status = _offen(adr)
    sel = adr[adr["vorschlag_x"].notna().values & (status.values == "offen")]
    if not len(sel):
        return None, None
    rows, lines = [], []
    for _, r in sel.iterrows():
        q = Point(float(r["vorschlag_x"]), float(r["vorschlag_y"]))
        vm = r.get("vorschlag_m")
        vm = None if vm is None or (isinstance(vm, float) and vm != vm) else float(vm)
        rows.append({"uid": _s(r.get("uid")), "adresse": _adresse(r), "kls_id": _s(r.get("kls_id")), "ampel": _s(r.get("ampel")),
                     "hinweise": _s(r.get("hinweise")), "vorschlag_text": _s(r.get("vorschlag_text")), "vorschlag_quelle": _s(r.get("vorschlag_quelle")),
                     "vorschlag_m": vm, "geometry": q})
        p = r.geometry
        if p is not None and not isinstance(p, float) and not bool(r.get("koord_fehlt", False)) and p.distance(q) > 0.5:
            lines.append({"uid": _s(r.get("uid")), "adresse": _adresse(r), "ampel": _s(r.get("ampel")), "geometry": LineString([p, q])})
    vp = gpd.GeoDataFrame(rows, crs=25832)
    vl = gpd.GeoDataFrame(lines, crs=25832) if lines else None
    return vp, vl


def pruefliste_lesen(gpkg):
    """Adressen (Layer) + Adressen ohne Koordinate (CSV) als ein GeoDataFrame; Vorschlagsspalten werden bei Bedarf nachgerechnet
    (aeltere Ergebnisse) und zurueckgeschrieben. -> (adr, gebaeude oder None)"""
    import geopandas as gpd
    import pandas as pd
    adr = gpd.read_file(gpkg, layer="adressen")
    if adr.crs is None or adr.crs.to_epsg() != 25832:
        adr = adr.set_crs(25832, allow_override=True)
    csv = os.path.splitext(gpkg)[0] + "_ohne_koordinate.csv"
    if os.path.exists(csv):
        try:
            ohne = pd.read_csv(csv, sep=";", dtype=str, encoding="utf-8-sig").fillna("")
            if len(ohne):
                ohne = gpd.GeoDataFrame(ohne, geometry=[None] * len(ohne), crs=25832)
                ohne["koord_fehlt"] = True
                adr = gpd.GeoDataFrame(pd.concat([adr, ohne], ignore_index=True), crs=25832)
        except Exception:
            pass
    for c, v in (("status", "offen"), ("kommentar", ""), ("hinweise", ""), ("ampel", "gruen")):
        if c not in adr:
            adr[c] = v
    adr["status"] = adr["status"].astype(str).replace({"": "offen", "None": "offen", "nan": "offen"})
    adr["koord_fehlt"] = adr["koord_fehlt"].astype(str).isin(["1", "True", "true"]) if "koord_fehlt" in adr else adr.geometry.isna()
    if "im_gebaeude" in adr:
        adr["im_gebaeude"] = adr["im_gebaeude"].astype(str).isin(["1", "True", "true"])
    geb = None
    try:
        geb = gpd.read_file(gpkg, layer="alkis_gebaeude")
        if "relevant" not in geb:
            geb["relevant"] = True
    except Exception:
        geb = None
    if "uid" not in adr or "vorschlag_x" not in adr:
        if "uid" not in adr:
            adr["uid"] = ["A{:05d}".format(i) for i in range(len(adr))]
        vorschlaege(adr, geb, log=lambda s: None)
        pruefliste_schreiben(gpkg, adr)
    return adr, geb


def _layer_loeschen(gpkg, name):
    import sqlite3
    try:
        con = sqlite3.connect(gpkg)
        con.execute('DROP TABLE IF EXISTS "{}"'.format(name))
        con.execute("DELETE FROM gpkg_contents WHERE table_name = ?", (name,))
        con.execute("DELETE FROM gpkg_geometry_columns WHERE table_name = ?", (name,))
        con.commit()
        con.close()
    except Exception:
        pass


def pruefliste_schreiben(gpkg, adr):
    """Adresslayer, CSV ohne Koordinate und Vorschlagslayer aus dem Stand `adr` neu schreiben."""
    import pyogrio
    a = adr.copy()
    for c in a.columns:
        if a[c].dtype == object and c != "geometry":
            a[c] = a[c].astype(str).replace({"None": "", "nan": ""})
    for c in ("bedarfspunkt", "koord_fehlt", "bauluecke", "gemischt", "gewerbegebiet", "im_gebaeude"):
        if c in a:
            a[c] = a[c].astype(str).isin(["1", "True", "true"]).astype(int)
    mit = a[a.geometry.notna()]
    ohne = a[a.geometry.isna()].drop(columns="geometry")
    mit.to_file(gpkg, layer="adressen", driver="GPKG")
    csv = os.path.splitext(gpkg)[0] + "_ohne_koordinate.csv"
    if len(ohne):
        ohne.to_csv(csv, sep=";", index=False, encoding="utf-8-sig")
    elif os.path.exists(csv):
        try:
            os.remove(csv)
        except Exception:
            pass
    vp, vl = vorschlag_layer(adr)
    vorhandene = set(pyogrio.list_layers(gpkg)[:, 0].tolist())
    for name, df in (("vorschlaege", vp), ("vorschlag_linien", vl)):
        if df is not None and len(df):
            df.to_file(gpkg, layer=name, driver="GPKG")
        elif name in vorhandene:
            _layer_loeschen(gpkg, name)
    try:
        from ...gemeinsam import wal_schliessen
        wal_schliessen(gpkg)
    except Exception:
        pass


# --- Kandidaten in der Pruefliste: moegliche Bauluecken und fehlender Bedarf (Markus 17.09.2026) ------------------------------------------
KANDIDAT_LAYER = (("bauluecke", "bauluecken_moeglich", "flstkennz"), ("fehlt", "fehlender_bedarf", "oid"))


def _kandidat_key(art, r, i, schluessel):
    k = _s(r.get(schluessel)) if schluessel in r else ""
    return "{}|{}".format(art, k or i)


def kandidaten_lesen(gpkg):
    """Moegliche Bauluecken und fehlender Bedarf als Pruefzeilen. -> DataFrame(kid, art, layer, adresse, hinweise, status, x, y, prioritaet,
    strasse, hnr) oder leerer DataFrame. Rot in der Pruefliste; Entscheidung des Planers: in die Adressen aufnehmen oder ignorieren."""
    import geopandas as gpd
    import pandas as pd
    import pyogrio
    try:
        vorhanden = set(pyogrio.list_layers(gpkg)[:, 0].tolist())
    except Exception:
        vorhanden = set()
    zeilen = []
    for art, lname, schl in KANDIDAT_LAYER:
        if lname not in vorhanden:
            continue
        df = gpd.read_file(gpkg, layer=lname)
        for i, r in df.iterrows():
            if art == "bauluecke":
                adresse = "Bauluecke: {}{} [Flurstueck {}]".format(_s(r.get("strasse")) or "Strasse unbekannt", " " + _s(r.get("hnr")) if _s(r.get("hnr")) else "",
                                                                  _s(r.get("flurstnr")))
                hinweise = "{}, {:.0f} m2{}; Nachbarn {}{}".format(_s(r.get("nutzung")), float(r.get("flaeche_m2") or 0),
                                                                  ", Nebengebaeude" if regeln._int(r.get("nebengebaeude")) else "", _s(r.get("nachbarn")),
                                                                  "; Nummer aus " + _s(r.get("hnr_quelle")) if _s(r.get("hnr_quelle")) else "")
            else:
                adresse = "Fehlt: {}".format(_s(r.get("adresse")))
                hinweise = "ALKIS-Gebaeude ({}, {:.0f} m2) mit Adresse, nicht in der Liste; {}; naechste Listenadresse {} in {} m".format(
                    _s(r.get("funktion")) or "Funktion unbekannt", float(r.get("flaeche_m2") or 0),
                    {"hoch": "Luecke in der Nummernfolge", "mittel": "Strasse in der Liste, Nachbarn fehlen auch", "niedrig": "am Rand"}.get(_s(r.get("prioritaet")), ""),
                    _s(r.get("naechste_adresse")), _s(r.get("abstand_m")))
            st = _s(r.get("status")).strip() or "offen"
            zeilen.append({"kid": _kandidat_key(art, r, i, schl), "art": art, "layer": lname, "adresse": adresse, "hinweise": hinweise,
                           "status": st, "x": r.get("apl_x"), "y": r.get("apl_y"), "prioritaet": _s(r.get("prioritaet")),
                           "strasse": _s(r.get("strasse")), "hnr": _s(r.get("hnr"))})
    return pd.DataFrame(zeilen, columns=["kid", "art", "layer", "adresse", "hinweise", "status", "x", "y", "prioritaet", "strasse", "hnr"])


def _kandidaten_schreiben(gpkg, lname, df):
    df.to_file(gpkg, layer=lname, driver="GPKG")
    try:
        from ...gemeinsam import wal_schliessen
        wal_schliessen(gpkg)
    except Exception:
        pass


def kandidaten_status(gpkg, kids, status, log=print):
    """status 'ignorieren' | 'offen' | 'aufgenommen' fuer Kandidaten (kid = art|schluessel). -> Anzahl"""
    import geopandas as gpd
    kids = {str(k) for k in kids}
    n = 0
    for art, lname, schl in KANDIDAT_LAYER:
        meine = {k.split("|", 1)[1] for k in kids if k.startswith(art + "|")}
        if not meine:
            continue
        try:
            df = gpd.read_file(gpkg, layer=lname)
        except Exception:
            continue
        maske = [(_kandidat_key(art, r, i, schl).split("|", 1)[1] in meine) for i, r in df.iterrows()]
        if any(maske):
            df.loc[maske, "status"] = status
            _kandidaten_schreiben(gpkg, lname, df)
            n += int(sum(maske))
    log("Pruefliste: {} Kandidaten -> {}".format(n, status))
    return n


def kandidaten_aufnehmen(gpkg, kids, hnr=None, we=None, log=print):
    """Kandidaten in den Layer adressen aufnehmen (Markus 17.09.): neue Adresszeile mit allem, was Plan[Goo] fuer den APL braucht
    (Strasse, Hausnummer, PLZ, Ort, Ortsteil, ONKZ/ASB und Gebietstyp/Sponsor vom naechsten Listenpunkt, WE, Gebaeudenutzung, Bedarf nach
    ZTV 21, bauluecke-Kennzeichen -> Begruendung in Plan[Goo]). Ampel gelb, status geprueft, quelle 'bauluecke' | 'alkis' - der Import
    nach Plan[Goo] passiert erst in Kachel 9. Der Kandidat bekommt status aufgenommen. hnr/we gelten fuer alle uebergebenen Kandidaten
    (sinnvoll bei einem). -> Anzahl"""
    import geopandas as gpd
    import numpy as np
    import pandas as pd
    from shapely.geometry import Point
    from shapely.strtree import STRtree
    adr, geb = pruefliste_lesen(gpkg)
    if ist_mbfd(adr):
        raise ValueError("MBfD: die Adressliste steht fest - Bauluecken und fehlende Adressen duerfen nicht dazukommen.")
    kids = {str(k) for k in kids}
    pts = [(i, p) for i, p in enumerate(adr.geometry) if p is not None and not isinstance(p, float)]
    tree = STRtree([p for _, p in pts]) if pts else None
    vorhanden = adr["uid"].astype(str).tolist()
    nr = 1 + max([int(u[1:]) for u in vorhanden if u.startswith("B") and u[1:].isdigit()] or [0])
    neue = []
    for art, lname, schl in KANDIDAT_LAYER:
        meine = {k.split("|", 1)[1] for k in kids if k.startswith(art + "|")}
        if not meine:
            continue
        df = gpd.read_file(gpkg, layer=lname)
        maske = []
        for i, r in df.iterrows():
            treffer = _kandidat_key(art, r, i, schl).split("|", 1)[1] in meine
            maske.append(treffer)
            if not treffer:
                continue
            x, y = float(r["apl_x"]), float(r["apl_y"])
            p = Point(x, y)
            n_ = None
            if tree is not None:
                j = tree.nearest(p)
                n_ = adr.iloc[pts[int(j)][0]] if j is not None else None
            h_roh = _s(hnr) if hnr else _s(r.get("hnr"))
            h_num, h_zs = _hnr_teile(h_roh)                       # '2A' -> hnr 2, hnr_zs A (Plan[Goo] fuehrt HS_NR und HS_NR_ZS getrennt)
            h = str(h_num) if h_num else ""
            zs = h_zs.upper() or _s(r.get("hnr_zs")).upper()
            w = regeln._int(we) if we else (regeln._int(r.get("we")) or 1)
            gebaeude = _s(r.get("gebaeudetyp")) or regeln.WOHNHAUS
            gebietstyp = _s(n_.get("gebietstyp")) if n_ is not None else ""
            sponsor = _s(n_.get("sponsor")) if n_ is not None else ""
            b = regeln.bedarf(w, 0, 0, gebietstyp, gebaeude, sponsor)
            if art == "bauluecke":
                hinweis = "Bauluecke: Flurstueck {} ({}, {:.0f} m2), Nachbarn {}; vom Planer aufgenommen".format(
                    _s(r.get("flurstnr")), _s(r.get("nutzung")), float(r.get("flaeche_m2") or 0), _s(r.get("nachbarn")))
            else:
                hinweis = "Fehlender Bedarf: ALKIS-Adresse {} ({}), nicht in der Bedarfsliste; vom Planer aufgenommen".format(
                    _s(r.get("adresse")), _s(r.get("funktion")))
            z = {"uid": "B{:05d}".format(nr), "kls_id": "", "strasse": _s(r.get("strasse")), "hnr": h, "hnr_zs": zs,
                 "plz": _s(r.get("plz")) or (_s(n_.get("plz")) if n_ is not None else ""),
                 "ort": _s(r.get("ort")) or (_s(n_.get("ort")) if n_ is not None else ""),
                 "ortsteil": _s(r.get("ortsteil")) or (_s(n_.get("ortsteil")) if n_ is not None else ""),
                 "we": w, "ge": 0, "p2p": 0, "gebietstyp": gebietstyp, "sponsor": sponsor, "gebaeude": gebaeude, "kenner": "",
                 "bewertung_hh": "", "bewertung_adr": "", "zusatzbedarf_txt": "", "bemerkung": "",
                 "onkz": _s(n_.get("onkz")) if n_ is not None else "", "asb": _s(n_.get("asb")) if n_ is not None else "",
                 "bedarfspunkt": False, "koord_fehlt": False, "quelle": art if art == "bauluecke" else "alkis",
                 "ampel": "gelb", "hinweise": hinweis, "dublette": "", "koord_mehrfach": 0,
                 "alkis_abstand_m": 0.0 if art == "fehlt" else np.nan, "alkis_funktion": _s(r.get("funktion")) if art == "fehlt" else "",
                 "im_gebaeude": art == "fehlt", "bauluecke": art == "bauluecke",
                 "status": "geprueft", "kommentar": "aus der Pruefliste aufgenommen ({})".format("Bauluecke" if art == "bauluecke" else "fehlender Bedarf"),
                 "vorschlag_x": np.nan, "vorschlag_y": np.nan, "vorschlag_m": np.nan, "vorschlag_text": "", "vorschlag_quelle": "",
                 "geometry": p}
            for c, v in b.items():
                if c != "treiber":
                    z[c] = v
            neue.append(z)
            nr += 1
        if any(maske):
            df.loc[maske, "status"] = "aufgenommen"
            _kandidaten_schreiben(gpkg, lname, df)
    if not neue:
        log("Pruefliste: kein Kandidat aufgenommen.")
        return 0
    neu = gpd.GeoDataFrame(pd.DataFrame(neue), geometry="geometry", crs=CRS)
    for c in adr.columns:
        if c not in neu.columns:
            neu[c] = "" if adr[c].dtype == object else np.nan
    alle = gpd.GeoDataFrame(pd.concat([adr, neu[adr.columns.tolist() + [c for c in neu.columns if c not in adr.columns]]], ignore_index=True), crs=CRS)
    pruefliste_schreiben(gpkg, alle)
    log("Pruefliste: {} Kandidaten in die Adressen aufgenommen (gelb, geprueft): {}".format(
        len(neue), "; ".join("{} {}".format(z["strasse"], z["hnr"]).strip() for z in neue[:8])))
    return len(neue)


LAGE_SPALTEN = ("lage_alt_x", "lage_alt_y", "lage_verschoben_m", "lage_quelle")   # alte Lage, wenn der Planer den Vorschlag uebernommen hat


def pruefliste_auswahl(adr, filter_):
    """Zeilen der Pruefliste fuer die Filter 'aufgenommen' (Bauluecken und fehlender Bedarf, die der Planer in die Adressen aufgenommen hat)
    und 'verortet' (Adressen, deren Lage vom Vorschlag uebernommen wurde) - Markus 22.09.2026."""
    import pandas as pd
    if filter_ == "aufgenommen":
        q = adr["quelle"].astype(str) if "quelle" in adr else pd.Series([""] * len(adr), index=adr.index)
        return adr[q.isin(["bauluecke", "alkis"])]
    if filter_ == "verortet":
        m = pd.Series([False] * len(adr), index=adr.index)
        if "lage_verschoben_m" in adr:
            m |= pd.to_numeric(adr["lage_verschoben_m"], errors="coerce").fillna(0) > 0
        if "kommentar" in adr:      # aeltere Ergebnisse ohne Lage-Spalten: am Kommentar erkennen
            m |= adr["kommentar"].astype(str).str.startswith("Lage vom Vorschlag uebernommen")
        return adr[m]
    return adr.iloc[0:0]


def pruefliste_export(gpkg, filter_, out_dir=None, log=print):
    """Zeilen eines Filters als Excel (.xlsx) neben das Ergebnis schreiben -> Pfad. Spalten: Adresse, Ampel, Status, Kommentar, Hinweise,
    Quelle, WE, alte/neue Lage (UTM 32), Verschiebung m, KLS-ID, PLZ/Ort/Ortsteil, Plan[Goo]-Bedarf."""
    import os as _os
    from datetime import datetime as _dt
    import pandas as pd
    _os.environ.setdefault("OPENPYXL_LXML", "False")
    adr, _ = pruefliste_lesen(gpkg)
    f = str(filter_ or "offen")
    if f in ("aufgenommen", "verortet"):
        sel = pruefliste_auswahl(adr, f)
    else:
        sel = adr[adr["ampel"].isin(["gelb", "rot"])]
        if f in ("offen", "rot", "gelb", "vorschlag"):
            sel = sel[sel["status"] == "offen"]
        if f in ("rot", "gelb"):
            sel = sel[sel["ampel"] == f]
        if f == "vorschlag":
            sel = sel[sel["vorschlag_x"].notna()]
    titel = {"aufgenommen": "Aufgenommene Bauluecken und fehlender Bedarf", "verortet": "Anders verortete Adressen (Vorschlag uebernommen)" if not ist_mbfd(adr) else "Abweichungen vom Angebot (Lage)",
             "offen": "Pruefliste rot und gelb, offen", "rot": "Pruefliste rot, offen", "gelb": "Pruefliste gelb, offen", "vorschlag": "Adressen mit Lagevorschlag",
             "alle": "Pruefliste rot und gelb, alle", "kandidaten": "Kandidaten"}.get(f, f)
    zeilen = []
    for _, r in sel.iterrows():
        g = r.geometry if r.geometry is not None and not isinstance(r.geometry, float) else None
        zeilen.append({"Adresse": _adresse(r), "Strasse": _s(r.get("strasse")), "HsNr": _s(r.get("hnr")), "Zusatz": _s(r.get("hnr_zs")), "PLZ": _s(r.get("plz")),
                       "Ort": _s(r.get("ort")), "Ortsteil": _s(r.get("ortsteil")), "KLS-ID": _s(r.get("kls_id")), "Ampel": _s(r.get("ampel")), "Status": _s(r.get("status")),
                       "Quelle": {"bauluecke": "Bauluecke (ALKIS-Flurstueck)", "alkis": "fehlender Bedarf (ALKIS-Gebaeude)", "bedarfsliste": "Bedarfsliste", "plangoo": "Plan[Goo]", "angebot": "Angebotslayer (Plan[Goo])"}.get(_s(r.get("quelle")), _s(r.get("quelle"))),
                       "WE": r.get("we"), "GE": r.get("ge"), "Gebaeude": _s(r.get("gebaeude")), "Hinweise": _s(r.get("hinweise")), "Kommentar": _s(r.get("kommentar")),
                       "Lagevorschlag": _s(r.get("vorschlag_text")), "Vorschlag Quelle": _s(r.get("vorschlag_quelle")),
                       "Abweichung vom Angebot": _s(r.get("abweichung_angebot")), "alte Lage X": r.get("lage_alt_x"), "alte Lage Y": r.get("lage_alt_y"), "Verschiebung m": r.get("lage_verschoben_m"),
                       "Lage X": round(g.x, 2) if g is not None else None, "Lage Y": round(g.y, 2) if g is not None else None,
                       "ONKZ": _s(r.get("onkz")), "ASB": _s(r.get("asb")), "Anschluesse": r.get("anschluesse"), "SNR": r.get("snr"), "Fasern Haus": r.get("fasern_haus")})
    df = pd.DataFrame(zeilen)
    out_dir = out_dir or _os.path.dirname(str(gpkg))
    stamm = _os.path.splitext(_os.path.basename(str(gpkg)))[0]
    p = _os.path.join(out_dir, "{}_{}_{}.xlsx".format(stamm, f, _dt.now().strftime("%Y%m%d_%H%M")))
    with pd.ExcelWriter(p, engine="openpyxl") as w:
        (df if len(df) else pd.DataFrame({"Hinweis": ["keine Zeilen fuer diesen Filter"]})).to_excel(w, sheet_name=titel[:31], index=False)
        ws = w.sheets[titel[:31]]
        for i, c in enumerate(df.columns if len(df) else ["Hinweis"], 1):
            breite = max(10, min(60, int(max([len(str(c))] + [len(str(v)) for v in (df[c].tolist() if len(df) else [])]) * 1.1) + 2))
            ws.column_dimensions[ws.cell(1, i).column_letter].width = breite
        ws.freeze_panes = "A2"
    log("Excel: {} Zeilen ({}) -> {}".format(len(df), titel, _os.path.basename(p)))
    return p


def pruefliste_aendern(gpkg, uids, aktion, kommentar="", log=print):
    """aktion: 'vorschlag' (Lage auf den Vorschlag setzen, status geprueft), 'geprueft', 'ignorieren', 'offen'. -> Anzahl geaendert"""
    from shapely.geometry import Point
    adr, geb = pruefliste_lesen(gpkg)
    mbfd = ist_mbfd(adr)
    if mbfd and "abweichung_angebot" not in adr:
        adr["abweichung_angebot"] = ""
    uids = {str(u) for u in uids}
    maske = adr["uid"].astype(str).isin(uids)
    n = 0
    for i in adr.index[maske]:
        if aktion == "vorschlag":
            x, y = adr.at[i, "vorschlag_x"], adr.at[i, "vorschlag_y"]
            if x is None or x != x:
                continue
            alt = adr.geometry.loc[i]
            alt = None if alt is None or isinstance(alt, float) else alt
            for c in LAGE_SPALTEN:
                if c not in adr:
                    adr[c] = float("nan") if c != "lage_quelle" else ""
            if alt is not None:
                adr.loc[i, "lage_alt_x"] = round(alt.x, 2)
                adr.loc[i, "lage_alt_y"] = round(alt.y, 2)
                adr.loc[i, "lage_verschoben_m"] = round(alt.distance(Point(float(x), float(y))), 1)
            adr.loc[i, "lage_quelle"] = _s(adr.at[i, "vorschlag_quelle"]) or "Vorschlag"
            if mbfd:
                adr.loc[i, "abweichung_angebot"] = "Lage verschoben {:.1f} m".format(adr.at[i, "lage_verschoben_m"]) if alt is not None else "Lage gesetzt"
            adr.loc[i, "geometry"] = Point(float(x), float(y))
            adr.loc[i, "koord_fehlt"] = False
            adr.loc[i, "status"] = "geprueft"
            adr.loc[i, "kommentar"] = ("Lage vom Vorschlag uebernommen ({}){}".format(_s(adr.at[i, "vorschlag_text"]),
                                                                                       "; alt {:.0f}/{:.0f}".format(alt.x, alt.y) if alt is not None else "")
                                       + (("; " + kommentar) if kommentar else ""))
        else:
            adr.loc[i, "status"] = aktion
            if kommentar:
                adr.loc[i, "kommentar"] = kommentar
        n += 1
    if n:
        pruefliste_schreiben(gpkg, adr)
    log("Pruefliste: {} Adressen -> {}".format(n, aktion))
    return n


def lauf_zusammenfassung(r):
    """Ergebnis von lauf() fuer den Dialog (JSON-faehig, hintergrund_lauf.py): Pfade, Layerliste und Zahlen statt DataFrames."""
    a = r.get("adressen")
    z = a["ampel"].value_counts() if a is not None and len(a) else {}
    fe, bl = r.get("fehlend"), r.get("bauluecken")
    zf = fe["prioritaet"].value_counts() if fe is not None and len(fe) else {}
    zb = bl["prioritaet"].value_counts() if bl is not None and len(bl) else {}
    return {"gpkg": r.get("gpkg"), "bericht": r.get("bericht"), "layer": [list(x) for x in r.get("layer", [])], "land": r.get("land"),
            "zahlen": {"adressen": 0 if a is None else int(len(a)), "gruen": int(z.get("gruen", 0)), "gelb": int(z.get("gelb", 0)), "rot": int(z.get("rot", 0)),
                       "vorschlag": int(a["vorschlag_x"].notna().sum()) if a is not None and "vorschlag_x" in a else 0,
                       "bauluecke": int(a["bauluecke"].sum()) if a is not None and "bauluecke" in a else 0,
                       "fehlend": 0 if fe is None else int(len(fe)), "fehlend_hoch": int(zf.get("hoch", 0)), "fehlend_mittel": int(zf.get("mittel", 0)),
                       "fehlend_niedrig": int(zf.get("niedrig", 0)), "bauluecken": 0 if bl is None else int(len(bl)), "bl_hoch": int(zb.get("hoch", 0)),
                       "bl_mittel": int(zb.get("mittel", 0)), "anschluesse": int(a["anschluesse"].sum()) if a is not None and "anschluesse" in a else 0,
                       "snr": int(a["snr"].sum()) if a is not None and "snr" in a else 0}}
