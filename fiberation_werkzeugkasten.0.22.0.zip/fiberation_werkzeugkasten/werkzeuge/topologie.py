# -*- coding: utf-8 -*-
"""Eine Topologie fuer alle Schritte (Markus 12.10.2026, Punkt 2: "Enden einrasten, Abzweige teilen und Kreuzungen vernoden gab es in
Schritt 5, in Schritt 7 und im Kondensat jeweils anders gebaut").

Arbeitseinheit ist das Stueck: dict(attr=dict der Spalten, geom=LineString, quelle=Index des Originals). _in_stuecke() macht aus einem
GeoDataFrame Stuecke (Mehrfachlinien zerlegt), stuecke_als_gdf() den Weg zurueck.

  enden_cluster(stuecke, tol)            Enden bis tol m -> gemeinsamer Knoten (echter Abstand, Union-Find; nie Anfang und Ende desselben Stuecks)
  enden_einrasten(stuecke, tol)          Enden eines Knotens auf den Mittelpunkt setzen
  abzweige_teilen(stuecke, tol)          Ende eines Stuecks liegt auf dem Inneren eines anderen -> das andere dort teilen, Ende dorthin (Schritt 7)
  enden_an_linien(stuecke, tol)          dasselbe, aber ohne Teilen: Stuetzpunkt in die andere Linie setzen (T-Stoss mit Knoten, Schritt 5)
  kreuzungen_teilen(stuecke, tol)        zwei Stuecke schneiden sich ohne Knoten -> beide am Schnittpunkt teilen
  stuetzpunkte_einrasten(geoms, raster)  alle Stuetzpunkte bis raster aufeinander, Linien auf Nachbarlinien einrasten (vor unary_union, Kondensat)

Toleranzen bleiben je Schritt verschieden (Hk 3 m, NVT-Trassen 0,1 m, Kondensat 0,05 m) - die Regeln sind dieselben."""
from shapely.geometry import LineString, Point
from shapely.ops import nearest_points, substring, unary_union
from shapely.strtree import STRtree


# --- Grundlagen ---------------------------------------------------------------------------------------------------------------------------
class UnionFind(object):
    def __init__(self, n):
        self.p = list(range(n))

    def find(self, i):
        while self.p[i] != i:
            self.p[i] = self.p[self.p[i]]
            i = self.p[i]
        return i

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.p[rb] = ra


def _enden(stuecke):
    """-> Liste (stueck_index, 0|1, Point) aller Anfangs- und Endpunkte."""
    out = []
    for i, s in enumerate(stuecke):
        c = list(s["geom"].coords)
        out.append((i, 0, Point(c[0][:2])))
        out.append((i, 1, Point(c[-1][:2])))
    return out


def _ende_setzen(geom, welches, pt):
    c = [tuple(p[:2]) for p in geom.coords]
    if welches == 0:
        c[0] = (pt.x, pt.y)
    else:
        c[-1] = (pt.x, pt.y)
    return LineString(c)


def _name(s):
    a = s["attr"]
    return "{}{}".format(a.get("hk", a.get("nvt", "")), " " + str(a.get("uid")) if a.get("uid") else "")


def _in_stuecke(a):
    """GeoDataFrame -> Liste Stuecke (Mehrfachlinien zerlegt, leere ausgelassen)."""
    out = []
    for idx, r in a.iterrows():
        g = r.geometry
        if g is None or g.is_empty:
            continue
        attr = {c: r[c] for c in a.columns if c != "geometry"}
        geoms = [g] if g.geom_type == "LineString" else [p for p in getattr(g, "geoms", []) if p.geom_type == "LineString"]
        for k, p in enumerate(geoms):
            if p.length <= 0:
                continue
            out.append({"attr": dict(attr), "geom": LineString([q[:2] for q in p.coords]), "quelle": idx, "teil": k})
    return out


def stuecke_als_gdf(stuecke, spalten, crs):
    import geopandas as gpd
    zeilen = [dict(s["attr"]) for s in stuecke]
    for z in zeilen:
        for c in spalten:
            z.setdefault(c, "")
    return gpd.GeoDataFrame(zeilen, geometry=[s["geom"] for s in stuecke], crs=crs)


# --- Knoten ---------------------------------------------------------------------------------------------------------------------------------
def enden_cluster(stuecke, toleranz):
    """Enden innerhalb der Toleranz (echter Abstand, nicht Raster) zu Knoten zusammenfassen.
    -> (knoten_von[(stueck_index, 0|1)] = knoten_id, mittel[knoten_id] = Point)"""
    enden = _enden(stuecke)
    if not enden:
        return {}, {}
    pts = [e[2] for e in enden]
    tree = STRtree(pts)
    uf = UnionFind(len(enden))
    for i, p in enumerate(pts):
        for j in tree.query(p.buffer(toleranz)):
            j = int(j)
            if j != i and enden[j][0] != enden[i][0] and pts[j].distance(p) <= toleranz:
                uf.union(i, j)          # nie Anfang und Ende desselben Stuecks: ein kurzes Stueck wuerde sonst auf einen Punkt schrumpfen
    gruppen = {}
    for i, e in enumerate(enden):
        gruppen.setdefault(uf.find(i), []).append(i)
    knoten_von, mittel = {}, {}
    for kid, (wurzel, mitglieder) in enumerate(gruppen.items()):
        xs = [pts[m].x for m in mitglieder]
        ys = [pts[m].y for m in mitglieder]
        mittel[kid] = Point(sum(xs) / len(xs), sum(ys) / len(ys))
        for m in mitglieder:
            knoten_von[(enden[m][0], enden[m][1])] = kid
    return knoten_von, mittel


def enden_einrasten(stuecke, toleranz, log=None, kontext=None, kleinst_m=0.5):
    """Enden innerhalb der Toleranz auf den gemeinsamen Mittelpunkt setzen. -> (stuecke, meldungen, zahl)"""
    knoten_von, mittel = enden_cluster(stuecke, toleranz)
    n = 0
    meld = []
    for (i, w), kid in knoten_von.items():
        if knoten_von.get((i, 1 - w)) == kid and stuecke[i]["geom"].length > kleinst_m:
            continue                # beide Enden im selben Knoten (ueber Dritte verkettet): Stueck nicht auf einen Punkt ziehen
        c = list(stuecke[i]["geom"].coords)
        alt = Point(c[0][:2] if w == 0 else c[-1][:2])
        ziel = mittel[kid]
        d = alt.distance(ziel)
        if d > 0.005:
            stuecke[i]["geom"] = _ende_setzen(stuecke[i]["geom"], w, ziel)
            n += 1
            meld.append("Ende von Stueck {} ({}) um {:.2f} m auf den gemeinsamen Knoten gesetzt".format(_name(stuecke[i]), "Anfang" if w == 0 else "Ende", d))
    return stuecke, meld, {"enden_zusammen": n}


# --- Abzweige und Kreuzungen -------------------------------------------------------------------------------------------------------------------
def _teilen(stuecke, schnitte, grund):
    """stuecke an den Distanzen schnitte[i] = [d1, d2, ...] (entlang der Linie) teilen. -> (neue stuecke, meldungen, Anzahl geteilter Linien)"""
    neu, meld, n_lin = [], [], 0
    for i, s in enumerate(stuecke):
        ds = []
        for d in sorted(d for d in schnitte.get(i, []) if 0.02 < d < s["geom"].length - 0.02):
            if not ds or d - ds[-1] > 0.01:          # exakte Distanzen behalten (Teilungspunkt = Abzweig-Ende), Doppelte zusammenlegen
                ds.append(d)
        if not ds:
            neu.append(s)
            continue
        grenzen = [0.0] + ds + [s["geom"].length]
        teile = []
        for a, b in zip(grenzen[:-1], grenzen[1:]):
            g = substring(s["geom"], a, b)
            if g is not None and not g.is_empty and g.geom_type == "LineString" and g.length > 0.01:
                teile.append(g)
        if len(teile) < 2:
            neu.append(s)
            continue
        n_lin += 1
        for k, g in enumerate(teile):
            attr = dict(s["attr"])
            if k > 0 and attr.get("uid"):
                attr["uid"] = "{}_t{}".format(attr["uid"], k)
            neu.append({"attr": attr, "geom": g, "quelle": s["quelle"], "teil": s.get("teil", 0) * 100 + k})
        meld.append("Stueck {} an {} Stelle(n) geteilt ({}): {} Teile".format(_name(s), len(ds), grund, len(teile)))
    return neu, meld, n_lin


def _abzweig_treffer(stuecke, toleranz):
    """-> (schnitte {j: [d]}, versetzt [(i, w, Punkt auf Linie j)]) fuer Enden, die auf dem Inneren eines anderen Stuecks liegen."""
    geoms = [s["geom"] for s in stuecke]
    tree = STRtree(geoms)
    schnitte, versetzt = {}, []
    for i, w, p in _enden(stuecke):
        for j in tree.query(p.buffer(toleranz)):
            j = int(j)
            if j == i:
                continue
            g = geoms[j]
            if g.distance(p) > toleranz:
                continue
            d = g.project(p)
            if d <= toleranz or d >= g.length - toleranz:
                continue                      # nahe an einem Ende des anderen Stuecks: das ist ein Knotenfall (Enden einrasten)
            schnitte.setdefault(j, []).append(d)
            versetzt.append((i, w, j, g.interpolate(d)))
    return schnitte, versetzt


def abzweige_teilen(stuecke, toleranz, log=None, kontext=None):
    """Ende eines Stuecks liegt im Umkreis der Toleranz auf dem Inneren eines anderen: dort teilen, Ende dorthin setzen (Schritt 7)."""
    schnitte, versetzt = _abzweig_treffer(stuecke, toleranz)
    meld = []
    for i, w, j, q in versetzt:
        c = list(stuecke[i]["geom"].coords)
        alt = Point(c[0][:2] if w == 0 else c[-1][:2])
        if alt.distance(q) > 0.005:
            stuecke[i]["geom"] = _ende_setzen(stuecke[i]["geom"], w, q)
            meld.append("Abzweig: Ende von Stueck {} um {:.2f} m auf die Linie gesetzt".format(_name(stuecke[i]), alt.distance(q)))
    neu, meld2, n_lin = _teilen(stuecke, schnitte, "Abzweig")
    return neu, meld + meld2, {"abzweige": len(versetzt), "linien_abzweig": n_lin}


def _stuetzpunkt(line, q):
    """Stuetzpunkt q in die Linie setzen (auf dem Segment, das q traegt), falls noch nicht vorhanden."""
    c = [tuple(p[:2]) for p in line.coords]
    if any(abs(x - q.x) < 1e-6 and abs(y - q.y) < 1e-6 for x, y in c):
        return line
    for k in range(len(c) - 1):
        if LineString([c[k], c[k + 1]]).distance(q) < 1e-3:
            c.insert(k + 1, (q.x, q.y))
            return LineString(c)
    return line


def enden_an_linien(stuecke, toleranz, log=None, kontext=None, nur=None):
    """Schritt 5: Ende bis toleranz neben einer anderen Linie dorthin ziehen (Endpunkt der anderen bevorzugt) und der anderen dort einen
    Stuetzpunkt geben - T-Stoss mit Knoten, ohne zu teilen (Plan[Goo] versteht das). -> (stuecke, meldungen, {"enden_bewegt": n})"""
    geoms = [s["geom"] for s in stuecke]
    tree = STRtree(geoms)
    bewegt, meld = 0, []
    for i, s in enumerate(stuecke):
        if nur is not None and i not in nur:
            continue                        # nur diese Stuecke bewegen; alle anderen koennen Stuetzpunkte bekommen
        c = [tuple(p[:2]) for p in s["geom"].coords]
        geaendert = False
        for pos in (0, -1):
            p = Point(c[pos])
            best, bd = None, toleranz + 1e-9
            for j in tree.query(p.buffer(toleranz)):
                j = int(j)
                if j == i:
                    continue
                d = geoms[j].distance(p)
                if 1e-6 < d < bd:
                    best, bd = j, d
            if best is None:
                continue
            og = geoms[best]
            enden = [Point(og.coords[0]), Point(og.coords[-1])]
            ep = min(enden, key=lambda e: e.distance(p))
            q = ep if ep.distance(p) <= toleranz else nearest_points(og, p)[0]
            c[pos] = (q.x, q.y)
            geaendert = True
            bewegt += 1
            if q is not ep:
                geoms[best] = _stuetzpunkt(og, q)
                stuecke[best]["geom"] = geoms[best]
        if geaendert:
            stuecke[i]["geom"] = LineString(c)
            geoms[i] = stuecke[i]["geom"]
            meld.append("Ende von Stueck {} eingerastet".format(_name(s)))
    return stuecke, meld, {"enden_bewegt": bewegt}


def kreuzungen_teilen(stuecke, toleranz, log=None, kontext=None):
    """Zwei Stuecke schneiden sich, ohne dass dort ein Ende liegt: beide am Schnittpunkt teilen."""
    geoms = [s["geom"] for s in stuecke]
    tree = STRtree(geoms)
    schnitte, punkte = {}, []
    for i, g in enumerate(geoms):
        for j in tree.query(g):
            j = int(j)
            if j <= i:
                continue
            h = geoms[j]
            if not g.crosses(h):
                continue
            x = g.intersection(h)
            pts = [x] if x.geom_type == "Point" else [p for p in getattr(x, "geoms", []) if p.geom_type == "Point"]
            for p in pts:
                di, dj = g.project(p), h.project(p)
                if di <= toleranz or di >= g.length - toleranz or dj <= toleranz or dj >= h.length - toleranz:
                    continue              # am Ende eines der beiden: kein Kreuzungsfall
                schnitte.setdefault(i, []).append(di)
                schnitte.setdefault(j, []).append(dj)
                punkte.append(p)
    neu, meld, n_lin = _teilen(stuecke, schnitte, "Kreuzung")
    return neu, meld, {"kreuzungen": len(punkte), "linien_kreuzung": n_lin}


# --- Stuetzpunkte (vor einem Dissolve) ------------------------------------------------------------------------------------------------------------
def stuetzpunkte_einrasten(geoms, raster):
    """Mini-Versaetze aus der Digitalisierung (bis raster) beseitigen, damit unary_union sie nicht als zwei Linien fuehrt: (1) alle Stuetzpunkte,
    die bis raster beieinanderliegen, auf einen gemeinsamen Punkt; (2) jede Linie auf die Nachbarlinien einrasten (shapely.snap), damit
    auch ein Stuetzpunkt neben einer Linie ohne Stuetzpunkt dort landet. -> Liste (None fuer leere Eingaben)"""
    import shapely
    pts, wo = [], []
    for i, g in enumerate(geoms):
        if g is None or g.is_empty:
            continue
        for k, c in enumerate(g.coords):
            pts.append(Point(c[:2]))
            wo.append((i, k))
    if not pts:
        return list(geoms)
    tree = STRtree(pts)
    uf = UnionFind(len(pts))
    for i, p in enumerate(pts):
        for j in tree.query(p.buffer(raster)):
            j = int(j)
            if j != i and pts[j].distance(p) <= raster:
                uf.union(i, j)
    gruppen = {}
    for i in range(len(pts)):
        gruppen.setdefault(uf.find(i), []).append(i)
    ziel = {}
    for mitglieder in gruppen.values():
        x = sum(pts[m].x for m in mitglieder) / len(mitglieder)
        y = sum(pts[m].y for m in mitglieder) / len(mitglieder)
        for m in mitglieder:
            ziel[m] = (x, y)
    neu_coords = {}
    for n, (i, k) in enumerate(wo):
        neu_coords.setdefault(i, {})[k] = ziel[n]
    out = []
    for i, g in enumerate(geoms):
        if g is None or g.is_empty:
            out.append(None)
            continue
        c = [neu_coords[i][k] for k in range(len(g.coords))]
        c2 = [c[0]] + [p for a_, p in zip(c[:-1], c[1:]) if p != a_]
        out.append(LineString(c2) if len(c2) >= 2 else None)
    gueltig = [g for g in out if g is not None]
    if len(gueltig) > 1:
        t2 = STRtree(gueltig)
        for i, g in enumerate(out):
            if g is None:
                continue
            nachbarn = [gueltig[int(j)] for j in t2.query(g.buffer(raster)) if gueltig[int(j)] is not g]
            if nachbarn:
                try:
                    out[i] = shapely.snap(g, unary_union(nachbarn), raster)
                except Exception:
                    pass
    return out
