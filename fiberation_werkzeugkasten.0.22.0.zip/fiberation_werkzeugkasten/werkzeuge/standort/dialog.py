# -*- coding: utf-8 -*-
"""Werkzeug 4 - Dialog "Standortsicherung": NVT-Standorte vorschlagen (Gehweg/Bankett/neben Bestand), Korridor, Excel, Lageplaene,
und die Standortsicherung fuehren: Pruef-Checkliste je Standort, Rechtliche Sicherung, Alternativstandort, Gesamtstatus, Uebersicht mit Filter."""
import os
import traceback

from qgis.core import (QgsCategorizedSymbolRenderer, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsFillSymbol,
                       QgsGeometry, QgsMapRendererCustomPainterJob, QgsMapSettings, QgsMarkerSymbol, QgsPalLayerSettings, QgsPointXY, QgsProject,
                       QgsRasterLayer, QgsRectangle, QgsRendererCategory, QgsTextBufferSettings, QgsTextFormat, QgsVectorLayer,
                       QgsVectorLayerSimpleLabeling, QgsWkbTypes)
from qgis.PyQt.QtCore import QSize, Qt
from qgis.PyQt.QtGui import QColor, QImage, QPainter
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFrame, QGridLayout, QHBoxLayout,
                                 QHeaderView, QLabel, QLineEdit, QMessageBox, QProgressBar, QPushButton, QRadioButton, QTableWidget,
                                 QTableWidgetItem, QTextEdit, QVBoxLayout)

from ... import ablauf, ci, dateiwahl, layerbaum, tabelle, plangoo_api
from ...dialogbasis import WerkzeugDialog
from ...dateiwahl import DateiFeld, ErgebnisKnopf

# Hintergrund fuer Lageplaene: ALKIS-WMS NRW (Open Data); andere Laender ueber den GeoBasis Loader in QGIS laden
WMS_NW = "contextualWMSLegend=0&crs=EPSG:25832&dpiMode=7&featureCount=10&format=image/png&layers=adv_alkis_flurstuecke&layers=adv_alkis_gebaeude&styles=&styles=&url=https://www.wms.nrw.de/geobasis/wms_nw_alkis"
FARBE_STATUS = {"Gesichert": "#2E7D32", "Offen": ci.ORANGE, "Abgelehnt": "#C62828"}
STATUS_AUSDRUCK = "\"gesamt\" || if(\"variante\" = 'Alternativ', ' (Alt.)', '')"


from ... import gemeinsam
_s = gemeinsam.s


class StandortDialog(WerkzeugDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface, parent)
        self.ergebnis = None
        self.gpkg = None
        self._zeilen = []
        self.setWindowTitle("Fiberation Werkzeugkasten - " + ablauf.titel("standort").replace("  ", " ", 1))
        self.setMinimumWidth(860)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 14, 20, 10)
        lay.setSpacing(8)
        self.kopf = ci.kopf_widget(ablauf.titel("standort"), "NVT auf Gehweg, Bankett oder neben Bestand-NVT setzen (ALKIS + OSM), dann je Standort Checkliste, Sicherung und Alternative fuehren.")
        lay.addWidget(self.kopf)

        # --- Standorte vorschlagen ----------------------------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Standorte vorschlagen"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(6)
        g.addWidget(QLabel("NVT-Gebiete (2):"), 0, 0)
        self.f_nvt = DateiFeld("nvt_gebiete", "nvt_gebiete_....gpkg aus Werkzeug 3 - aufklappen fuer die letzten Ergebnisse, auch per Drag und Drop",
                               "GeoPackage (*.gpkg);;Shape (*.shp)", "NVT-Datei waehlen", ci.STIL_KNOPF_ZWEIT)
        self.f_nvt.setToolTip("Sitzvorschlaege, Gebiete, Adressen und Netz aus dem Schnitt. Kandidaten werden am Rand der ALKIS-Strassenflaechen, auf "
                              "Gehwegen und neben Bestand-NVT (OSM, Plan[Goo]) gesucht.")
        g.addWidget(self.f_nvt, 0, 1, 1, 5)
        self.s_rest = self._spin(0.5, 5.0, 1.5)
        self.s_rand = self._spin(0.0, 3.0, 0.6)
        self.s_geb = self._spin(0.0, 5.0, 1.0)
        self.s_kreuz = self._spin(0.0, 30.0, 8.0)
        self.s_radius = self._spin(10.0, 200.0, 60.0)
        g.addWidget(QLabel("Regeln (m):"), 1, 0)
        rg = QHBoxLayout()
        rg.setSpacing(6)
        for txt, s, tipp in (("Gehwegrest", self.s_rest, "Gehwegrestbreite neben dem NVT (Checkliste: mindestens 1,50 m)"),
                             ("Grenze", self.s_rand, "Mindestabstand zur Grenze des oeffentlichen Grundes (Wunsch 0,8 m)"),
                             ("Gebaeude", self.s_geb, "Mindestabstand zum Gebaeude (Arbeitsraum, Tuer)"),
                             ("Kreuzung", self.s_kreuz, "Mindestabstand zur Kreuzung oder Einmuendung (Sichtdreieck)"),
                             ("Suchradius", self.s_radius, "Umkreis um den Sitzvorschlag fuer die Kandidatensuche; findet sich nichts, wird er verdoppelt")):
            lab = QLabel(txt + ":")
            lab.setToolTip(tipp)
            s.setToolTip(tipp)
            s.setMaximumWidth(64)
            rg.addWidget(lab)
            rg.addWidget(s)
        rg.addStretch(1)
        g.addLayout(rg, 1, 1, 1, 5)
        g.addWidget(QLabel("Gehaeusetyp:"), 2, 0)
        self.f_typ = QLineEdit("Gf-NVt 22 L")
        self.f_typ.setMaximumWidth(140)
        self.f_typ.setToolTip("Steht so in der Excel-Liste fuer die Standortsicherung")
        g.addWidget(self.f_typ, 2, 1)
        g.addWidget(QLabel("Ausgabeordner:"), 2, 2)
        self.out = QLineEdit()
        self.out.setPlaceholderText("leer = neben der Quelle")
        g.addWidget(self.out, 2, 3, 1, 2)
        o = QPushButton("Waehlen")
        o.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        o.clicked.connect(self._out_waehlen)
        g.addWidget(o, 2, 5)
        # Markus 12.10.: "Standorte vorschlagen" ist kein Pflichtschritt - drei gleichwertige Wege zum selben Ergebnislayer
        g.addWidget(QLabel("Methode:"), 3, 0)
        mz = QHBoxLayout()
        mz.setSpacing(10)
        self.m_vorschlag = QRadioButton("Vorschlag (ALKIS/OSM)")
        self.m_vorschlag.setToolTip("Das Werkzeug sucht je NVT den besten Platz im Umkreis des Sitzvorschlags (Gehweg, Bankett, neben Bestand-NVT)")
        self.m_zeichnen = QRadioButton("Zeichnen")
        self.m_zeichnen.setToolTip("Die Sitzvorschlaege aus Schritt 3 kommen als Arbeitslayer in die Karte; Punkte an die richtige Stelle schieben, "
                                   "bei Bedarf Punkte hinzufuegen oder loeschen, dann 'Zeichnung uebernehmen'")
        self.m_uebernahme = QRadioButton("Aus Layer uebernehmen")
        self.m_uebernahme.setToolTip("Vorhandene NVT-Standorte aus einem Punktlayer des QGIS-Projekts oder aus dem offenen Plan[Goo]-Projekt uebernehmen "
                                     "(besteht im Layer eine Auswahl, nur sie)")
        self.m_vorschlag.setChecked(True)
        for r_ in (self.m_vorschlag, self.m_zeichnen, self.m_uebernahme):
            r_.toggled.connect(self._methode_gewechselt)
            mz.addWidget(r_)
        self.cb_lage = QCheckBox("Lage mit ALKIS/OSM pruefen")
        self.cb_lage.setChecked(True)
        self.cb_lage.setToolTip("Beim Zeichnen und Uebernehmen: ALKIS-Flaechen und OSM-Strassen abrufen und je Punkt Lage (Gehweg/Bankett/privat), Flurstueck, "
                                "Strasse und Abstaende bestimmen - der Punkt bleibt, wo der Planer ihn gesetzt hat; Beanstandungen stehen im Hinweis. "
                                "Ohne Haken geht es schnell und ohne Netz, Flurstueck und Lage bleiben leer.")
        mz.addSpacing(12)
        mz.addWidget(self.cb_lage)
        mz.addStretch(1)
        g.addLayout(mz, 3, 1, 1, 5)
        self.lab_quelle = QLabel("Quelllayer:")
        g.addWidget(self.lab_quelle, 4, 0)
        self.l_quelle = QComboBox()
        self.l_quelle.setToolTip("Punktlayer des QGIS-Projekts mit NVT-Standorten, oder die NVT des offenen Plan[Goo]-Projekts")
        self.l_quelle.currentIndexChanged.connect(lambda *_: self._namensfeld_fuellen())
        g.addWidget(self.l_quelle, 4, 1, 1, 2)
        self.lab_namensfeld = QLabel("Namensfeld:")
        g.addWidget(self.lab_namensfeld, 4, 3, Qt.AlignRight)
        self.l_namensfeld = QComboBox()
        self.l_namensfeld.setToolTip("Spalte mit dem NVT-Namen (NAME, name, bezeichner, nvt ...); ohne Spalte werden die Punkte durchnummeriert")
        g.addWidget(self.l_namensfeld, 4, 4)
        self.k_quelle_neu = QPushButton("Aktualisieren")
        self.k_quelle_neu.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_quelle_neu.setToolTip("Layerliste neu einlesen")
        self.k_quelle_neu.clicked.connect(self._quelllayer_fuellen)
        g.addWidget(self.k_quelle_neu, 4, 5)
        g.setColumnStretch(3, 1)
        lay.addLayout(g)

        k = QHBoxLayout()
        self.k_start = QPushButton("Standorte vorschlagen")
        self.k_start.setStyleSheet(ci.STIL_KNOPF)
        self.k_start.setCursor(Qt.PointingHandCursor)
        self.k_start.setToolTip("ALKIS und OSM abrufen, je NVT den besten Standort im Umkreis waehlen, Korridor, Excel und Pruefblatt schreiben")
        self.k_start.clicked.connect(self._start)
        self.k_zeichnung = QPushButton("Zeichnung uebernehmen")
        self.k_zeichnung.setStyleSheet(ci.STIL_KNOPF)
        self.k_zeichnung.setEnabled(False)
        self.k_zeichnung.setToolTip("Die Punkte des Arbeitslayers 'Standorte zeichnen' als Standortdatei schreiben (Bearbeitung wird gespeichert)")
        self.k_zeichnung.clicked.connect(self._zeichnung_uebernehmen)
        self.k_abbruch = QPushButton("Abbrechen")
        self.k_abbruch.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_abbruch.setEnabled(False)
        self.k_abbruch.setToolTip("Laufenden OpenStreetMap-Abruf (Overpass) abbrechen - der Schritt endet dann ohne Ergebnis.")
        self.k_abbruch.clicked.connect(self._abbrechen)
        self.k_ergebnis = ErgebnisKnopf("nvt_standorte", self._ergebnis_laden, "Standortdatei (GeoPackage) waehlen", stil=ci.STIL_KNOPF_ZWEIT,
                                        text="Ergebnis laden")
        self.k_ergebnis.setToolTip("Fruehere Standortdatei laden und die Standortsicherung weiterfuehren")
        self.k_plaene = QPushButton("Lageplaene 1:1000")
        self.k_plaene.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_plaene.setEnabled(False)
        self.k_plaene.setToolTip("Je Standort ein PNG-Lageplan 1:1000 mit Standort, Korridor, ALKIS und Flurstuecken in den Ausgabeordner")
        self.k_plaene.clicked.connect(self._lageplaene)
        self.k_excel = QPushButton("Excel")
        self.k_excel.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_excel.setEnabled(False)
        self.k_excel.setToolTip("Excel 'Netzverteiler-Standorte [Projekt].xlsx' aus dem aktuellen Stand neu schreiben und oeffnen")
        self.k_excel.clicked.connect(self._excel)
        self.k_blatt = QPushButton("Pruefblatt")
        self.k_blatt.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_blatt.setEnabled(False)
        self.k_blatt.clicked.connect(lambda: self._oeffnen(self.ergebnis and self.ergebnis.get("bericht")))
        # Markus 12.10.: StoSi-Shape wie Plan[Goo] "Export StoSi-Shape fuer GDI" (Reiter Allgemein, Bereich Export)
        self.k_shape = QPushButton("StoSi-Shape exportieren")
        self.k_shape.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_shape.setEnabled(False)
        self.k_shape.setToolTip("NVT-Standorte als Zip mit ESRI-Shape (UTF-8, EPSG:25832) im Plan[Goo]-Punktschema - wie 'Export StoSi-Shape fuer GDI' "
                                "in Plan[Goo]; je NVT der Hauptstandort, bei abgelehntem Hauptstandort der Alternativstandort")
        self.k_shape.clicked.connect(self._shape_export)
        self.k_log = QPushButton("Protokoll")
        self.k_log.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_log.setCheckable(True)
        self.k_log.setToolTip("Protokoll ein- und ausblenden; bei Fehlern klappt es von selbst auf")
        self.k_log.toggled.connect(lambda an: self.log.setVisible(an))
        for b in (self.k_start, self.k_zeichnung, self.k_abbruch, self.k_ergebnis, self.k_plaene, self.k_excel, self.k_blatt, self.k_shape, self.k_log):
            k.addWidget(b)
        k.addStretch(1)
        lay.addLayout(k)
        self._methode_gewechselt()
        self.balken = QProgressBar()
        self.balken.setRange(0, 100)
        self.balken.setFormat("bereit")
        self.balken.setFixedHeight(16)
        self.balken.setStyleSheet("QProgressBar {{ border:1px solid {g}; border-radius:4px; text-align:center; font-size:11px; }}"
                                  "QProgressBar::chunk {{ background:{o}; border-radius:3px; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        lay.addWidget(self.balken)

        # --- Standortsicherung --------------------------------------------------------------------------------------------------------
        lay.addWidget(self._ueberschrift("Standortsicherung"))
        f = QHBoxLayout()
        f.addWidget(QLabel("Status:"))
        self.filter = QComboBox()
        self.filter.addItems(["alle", "Offen", "Abgelehnt", "Gesichert"])
        self.filter.setToolTip("Uebersicht auf einen Gesamtstatus eingrenzen")
        self.filter.currentIndexChanged.connect(lambda *_: self._tabelle_fuellen())
        f.addWidget(self.filter)
        self.l_zahl = QLabel("")
        self.l_zahl.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        f.addWidget(self.l_zahl, 1)
        self.k_zoom = QPushButton("Hinzoomen")
        self.k_zoom.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_zoom.setToolTip("Gewaehlten Standort im Layer auswaehlen, aufblinken lassen und hinzoomen")
        self.k_zoom.clicked.connect(lambda: self._zeigen(True))
        self.k_check = QPushButton("Checkliste")
        self.k_check.setStyleSheet(ci.STIL_KNOPF)
        self.k_check.setToolTip("Pruef-Checkliste (8 Punkte mit Status und Bemerkung), Rechtliche Sicherung und Kommentar des gewaehlten Standorts bearbeiten "
                                "- auch per Doppelklick auf die Zeile")
        self.k_check.clicked.connect(self._checkliste)
        self.k_alt = QPushButton("Alternativstandort")
        self.k_alt.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_alt.setToolTip("Zweiten Standort fuer diesen NVT anlegen (Kopie 3 m oestlich, Checkliste leer) - danach den Punkt im Layer an die richtige Stelle schieben")
        self.k_alt.clicked.connect(self._alternative)
        for b in (self.k_zoom, self.k_check, self.k_alt):
            b.setEnabled(False)
            f.addWidget(b)
        lay.addLayout(f)
        self.tab = tabelle.Tabelle("standort_sicherung", ["NVT", "Variante", "Lage", "zulaessig", "Gesamtstatus", "Offene Punkte"], self.iface, mehrfach=False)
        self.tab.layer_finder(lambda schl: self._layer())
        self.tab.setMinimumHeight(170)
        self.tab.setMaximumHeight(250)
        self.k_zoom.setVisible(False)      # Hinzoomen/Blinken sitzen jetzt ueber der Tabelle (gemeinsame Tabelle, Markus 12.10.)
        self.tab.setToolTip("Alle erfassten Standorte. OFFEN = Punkte ungeprueft oder Sicherung nicht erteilt; Abgelehnt = ein Punkt Nicht OK oder "
                            "Sicherung abgelehnt; Gesichert = alles OK und Zustimmung/Gestattung erteilt.")
        self.tab.itemSelectionChanged.connect(lambda: self._zeigen(False))
        self.tab.itemDoubleClicked.connect(lambda *_: self._checkliste())
        lay.addWidget(self.tab)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(140)
        self.log.setStyleSheet("font-family:Consolas,monospace; font-size:11px;")
        self.log.setVisible(False)
        lay.addWidget(self.log, 1)
        fuss = QHBoxLayout()
        weiter = QLabel("Weiter mit 5 Trassen (Standorte werden dort als NVT-Punkte angeboten) oder 9 Plan[Goo].")
        weiter.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        fuss.addWidget(weiter)
        fuss.addStretch(1)
        hilfe = QPushButton("Anleitung")
        hilfe.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        hilfe.clicked.connect(lambda: __import__("fiberation_werkzeugkasten.hilfe", fromlist=["zeige_anleitung"]).zeige_anleitung(self, "w3"))
        fuss.addWidget(hilfe)
        schl = QPushButton("Schliessen")
        self.k_schliessen = schl
        schl.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        schl.clicked.connect(self.close)
        fuss.addWidget(schl)
        lay.addLayout(fuss)
        self.setAcceptDrops(True)
        from ... import fenster
        fenster.einrichten(self, "standort", 860)

    # --- Hilfen ------------------------------------------------------------------------------------------------------------------------
    def _out_waehlen(self):
        p = dateiwahl.ordner_waehlen(self, "Ausgabeordner waehlen", "ausgabe", self.out.text() or os.path.dirname(self.f_nvt.text()))
        if p:
            self.out.setText(p)

    def showEvent(self, ev):
        super().showEvent(ev)
        # Werkzeug 3 kann inzwischen ein neues Ergebnis geschrieben haben
        self.f_nvt.vorbelegen()
        self._quelllayer_fuellen()

    # --- Methode: Vorschlag / Zeichnen / Uebernahme (Markus 12.10.2026) ----------------------------------------------------------------
    ZEICHENLAYER = "Standorte zeichnen"

    def _methode(self):
        return "zeichnen" if self.m_zeichnen.isChecked() else "uebernahme" if self.m_uebernahme.isChecked() else "vorschlag"

    def _methode_gewechselt(self, *_):
        m = self._methode()
        self.k_start.setText({"vorschlag": "Standorte vorschlagen", "zeichnen": "Zeichnen starten", "uebernahme": "Aus Layer uebernehmen"}[m])
        self.k_start.setToolTip({"vorschlag": "ALKIS und OSM abrufen, je NVT den besten Standort im Umkreis waehlen, Korridor, Excel und Pruefblatt schreiben",
                                 "zeichnen": "Arbeitslayer 'Standorte zeichnen' mit den Sitzvorschlaegen aus Schritt 3 anlegen, Bearbeitung an, Verschieben-Werkzeug aktiv",
                                 "uebernahme": "Punkte des Quelllayers (bei Auswahl nur diese) als Standortdatei schreiben"}[m])
        self.k_zeichnung.setVisible(m == "zeichnen")
        self.cb_lage.setVisible(m != "vorschlag")
        for w in (self.lab_quelle, self.l_quelle, self.lab_namensfeld, self.l_namensfeld, self.k_quelle_neu):
            w.setVisible(m == "uebernahme")
        if m == "uebernahme":
            self._quelllayer_fuellen()
        if m == "zeichnen":
            self.k_zeichnung.setEnabled(self._zeichenlayer() is not None)

    def _plangoo_offen(self):
        try:
            import importlib
            inst = plangoo_api.instanz()
            return inst is not None
        except Exception:
            return False

    def _quelllayer_fuellen(self):
        if not hasattr(self, "l_quelle"):
            return
        merk = self.l_quelle.currentData()
        self.l_quelle.blockSignals(True)
        self.l_quelle.clear()
        if self._plangoo_offen():
            self.l_quelle.addItem("Plan[Goo]: NVT des offenen Projekts", "plangoo")
        for lyr in QgsProject.instance().mapLayers().values():
            if isinstance(lyr, QgsVectorLayer) and QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PointGeometry:
                if layerbaum.ohne_nummer(lyr.name()) in ("Standort (Vorschlag)", "Sitz vorher"):
                    continue
                self.l_quelle.addItem(lyr.name() + ("  ({} ausgewaehlt)".format(lyr.selectedFeatureCount()) if lyr.selectedFeatureCount() else ""), lyr.id())
        i = self.l_quelle.findData(merk) if merk else -1
        self.l_quelle.setCurrentIndex(max(i, 0))
        self.l_quelle.blockSignals(False)
        self._namensfeld_fuellen()

    NAMENSFELDER = ("NAME", "name", "Name", "bezeichner", "Bezeichner", "BEZEICHNER", "nvt", "NVT", "nvt_name", "id", "ID")

    def _namensfeld_fuellen(self):
        self.l_namensfeld.clear()
        lid = self.l_quelle.currentData()
        if not lid or lid == "plangoo":
            self.l_namensfeld.addItem("NAME", "NAME")
            self.l_namensfeld.setEnabled(False)
            return
        self.l_namensfeld.setEnabled(True)
        lyr = QgsProject.instance().mapLayer(lid)
        if lyr is None:
            return
        namen = [f.name() for f in lyr.fields()]
        self.l_namensfeld.addItem("- durchnummerieren -", "")
        for n in namen:
            self.l_namensfeld.addItem(n, n)
        for kand in self.NAMENSFELDER:
            if kand in namen:
                self.l_namensfeld.setCurrentIndex(self.l_namensfeld.findData(kand))
                break

    def _zeichenlayer(self):
        for l in QgsProject.instance().mapLayers().values():
            if isinstance(l, QgsVectorLayer) and layerbaum.ohne_nummer(l.name()) == self.ZEICHENLAYER:
                return l
        return None

    def _zeichnen_starten(self):
        """Arbeitslayer mit den Sitzvorschlaegen aus Schritt 3 anlegen (oder wieder aufnehmen), Bearbeitung an, Verschieben-Werkzeug."""
        from . import kern
        lyr = self._zeichenlayer()
        if lyr is None:
            lyr = QgsVectorLayer("Point?crs=EPSG:25832&field=name:string(40)&field=gehaeusetyp:string(40)", self.ZEICHENLAYER, "memory")
            lyr.setRenderer(lyr.renderer())
            lyr.renderer().setSymbol(ci.nvt_symbol(ci.ORANGE, 5.0))
            self._label(lyr, "name", 9, True)
            quelle = self.f_nvt.text()
            n = 0
            if quelle and os.path.exists(quelle):
                try:
                    sitze, _, _, _ = kern.nvt_laden(quelle, self._log)
                    feats = []
                    for _, r in sitze.iterrows():
                        f = QgsFeature(lyr.fields())
                        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(r.geometry.x, r.geometry.y)))
                        f["name"] = str(r["name"])
                        f["gehaeusetyp"] = self.f_typ.text().strip() or "Gf-NVt 22 L"
                        feats.append(f)
                    lyr.dataProvider().addFeatures(feats)
                    lyr.updateExtents()
                    n = len(feats)
                except Exception as e:
                    self._log("Sitzvorschlaege nicht geladen ({!r}) - Layer bleibt leer, Punkte von Hand setzen".format(e))
            else:
                self._log("Keine NVT-Datei - Layer bleibt leer, Punkte von Hand setzen (Name im Formular).")
            layerbaum.benennen(lyr, "standort")
            QgsProject.instance().addMapLayer(lyr)
            self._log("Arbeitslayer '{}' angelegt mit {} Sitzvorschlaegen (Arbeitsspeicher).".format(lyr.name(), n))
        if self.iface is not None:
            self.iface.setActiveLayer(lyr)
        if not lyr.isEditable():
            lyr.startEditing()
        try:
            self.iface.actionMoveFeature().trigger()
        except Exception:
            pass
        self.k_zeichnung.setEnabled(True)
        self._log("Zeichnen: Punkte mit dem Verschieben-Werkzeug an die richtige Stelle ziehen; neue Punkte mit 'Punktobjekt hinzufuegen' (Name im "
                  "Formular), ueberzaehlige loeschen. Dann 'Zeichnung uebernehmen'.")

    def _zeichnung_uebernehmen(self):
        lyr = self._zeichenlayer()
        if lyr is None:
            QMessageBox.information(self, "Zeichnung uebernehmen", "Kein Arbeitslayer '{}' - erst 'Zeichnen starten'.".format(self.ZEICHENLAYER))
            return
        if lyr.isEditable():
            if lyr.isModified() and not lyr.commitChanges():
                self._log("Arbeitslayer nicht gespeichert: " + "; ".join(lyr.commitErrors())[:300])
                return
            elif not lyr.isModified():
                lyr.rollBack()
        punkte = []
        for f in lyr.getFeatures():
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            q = g.asPoint()
            punkte.append({"name": _s(f["name"]), "x": q.x(), "y": q.y(), "gehaeusetyp": _s(f["gehaeusetyp"])})
        if not punkte:
            QMessageBox.information(self, "Zeichnung uebernehmen", "Der Arbeitslayer enthaelt keine Punkte.")
            return
        self._punkte_uebernehmen(punkte, "gezeichnet")

    def _aus_layer(self):
        lid = self.l_quelle.currentData()
        if not lid:
            QMessageBox.information(self, "Aus Layer uebernehmen", "Kein Punktlayer im Projekt. Layer laden oder Plan[Goo]-Projekt oeffnen, dann 'Aktualisieren'.")
            return
        punkte = []
        if lid == "plangoo":
            from . import kern
            try:
                g = kern._nvt_aus_plangoo(self._log)
            except Exception as e:
                QMessageBox.information(self, "Aus Layer uebernehmen", "Plan[Goo]: {}".format(e))
                return
            for _, r in g.iterrows():
                punkte.append({"name": str(r["name"]), "x": r.geometry.x, "y": r.geometry.y})
            herkunft = "uebernommen: Plan[Goo]"
        else:
            lyr = QgsProject.instance().mapLayer(lid)
            if lyr is None:
                self._quelllayer_fuellen()
                return
            feld = self.l_namensfeld.currentData() or ""
            ct = QgsCoordinateTransform(lyr.crs(), QgsCoordinateReferenceSystem("EPSG:25832"), QgsProject.instance())
            feats = lyr.selectedFeatures() if lyr.selectedFeatureCount() else lyr.getFeatures()
            for i, f in enumerate(feats):
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(ct)
                if g.isMultipart():
                    g.convertToSingleType()
                q = g.asPoint()
                name = _s(f[feld]) if feld and lyr.fields().indexOf(feld) >= 0 else ""
                punkte.append({"name": name or "NVT{:02d}".format(i + 1), "x": q.x(), "y": q.y()})
            herkunft = "uebernommen: " + layerbaum.ohne_nummer(lyr.name())
        if not punkte:
            QMessageBox.information(self, "Aus Layer uebernehmen", "Keine Punkte im Quelllayer.")
            return
        self._punkte_uebernehmen(punkte, herkunft)

    def _lauf_vorbereiten(self):
        """Gemeinsame Eingaben fuer Vorschlag und Uebernahme; -> (quelle|None, out_dir, regeln, gehaeusetyp)"""
        quelle = self.f_nvt.text()
        quelle = quelle if quelle and os.path.exists(quelle) else None
        if quelle:
            dateiwahl.merken("nvt_gebiete", quelle)
        out_dir = dateiwahl.ausgabeordner(self.out.text()) if (self.out.text().strip() or quelle) else dateiwahl.ausgabeordner(os.path.expanduser("~"))
        regeln = {"restgehweg_m": self.s_rest.value(), "rand_min_m": self.s_rand.value(), "gebaeude_min_m": self.s_geb.value(),
                  "kreuzung_min_m": self.s_kreuz.value(), "suchradius_m": self.s_radius.value()}
        return quelle, out_dir, regeln, (self.f_typ.text().strip() or "Gf-NVt 22 L")

    def _lauf_starten(self, beschreibung, funktion, args, kwargs, fertig):
        """Kernlauf im Kindprozess (ALKIS/OSM blockieren QGIS sonst minutenlang; Thread stuerzt in pyproj ab - Markus 12.10. Punkt 5)."""
        from ... import hintergrund
        self.log.clear()
        self.k_start.setEnabled(False)
        self.k_zeichnung.setEnabled(False)
        self.k_abbruch.setEnabled(True)
        hintergrund.starten(self, beschreibung, "werkzeuge.standort.kern", funktion, args, kwargs, fertig)

    def _lauf_ende(self):
        self.k_start.setEnabled(True)
        self.k_zeichnung.setEnabled(self._methode() == "zeichnen" and self._zeichenlayer() is not None)
        self.k_abbruch.setEnabled(False)

    def _ergebnis_uebernehmen(self, r):
        dateiwahl.merken("nvt_standorte", r["gpkg"])
        self.ergebnis = r
        self.gpkg = r["gpkg"]
        self._layer_laden(r["gpkg"])
        self._tabelle_fuellen()
        for b in (self.k_plaene, self.k_excel, self.k_blatt, self.k_shape):
            b.setEnabled(True)

    def _punkte_uebernehmen(self, punkte, herkunft):
        """Gemeinsamer Abschluss fuer Zeichnen und Uebernahme: Standortdatei im Hintergrund schreiben, dann Layer laden, Uebersicht fuellen."""
        quelle, out_dir, regeln, typ = self._lauf_vorbereiten()

        def fertig(r, fehler, rv):
            self._lauf_ende()
            if fehler is not None:
                return self._lauf_fehler("Standorte uebernehmen - Fehler", fehler, rv)
            self._ergebnis_uebernehmen(r)
            QMessageBox.information(self, "Standorte uebernommen", "{} Standorte ({}) in die Standortdatei geschrieben.\nLage: {}\n\n"
                                    "Layer sind geladen. Weiter wie gewohnt: Standort in der Uebersicht waehlen, Checkliste fuehren, Excel, "
                                    "StoSi-Shape.".format(r["n"], herkunft, ", ".join("{} {}".format(v, k) for k, v in r["lagen"].items())))
        self._lauf_starten("Standorte uebernehmen", "uebernehmen", [quelle, punkte],
                           {"out_dir": out_dir, "regeln": regeln, "gehaeusetyp": typ, "herkunft": herkunft, "lage_pruefen": self.cb_lage.isChecked()}, fertig)

    def _vorschlagen(self):
        quelle, out_dir, regeln, typ = self._lauf_vorbereiten()
        if not quelle:
            self._log("NVT-Datei nicht gefunden - erst Werkzeug 3 laufen lassen oder Datei waehlen.")
            self.k_log.setChecked(True)
            return

        def fertig(r, fehler, rv):
            self._lauf_ende()
            if fehler is not None:
                return self._lauf_fehler("Standorte - Fehler", fehler, rv)
            self._ergebnis_uebernehmen(r)
            QMessageBox.information(self, "Standorte vorgeschlagen", "{} von {} NVT haben einen zulaessigen Standort im Umkreis ({}).\n\n"
                                    "Layer sind geladen: Standort (Vorschlag), Korridor, Sitz vorher, Bestand-NVT.\nExcel: {}\n\n"
                                    "Naechster Schritt: Standort in der Uebersicht waehlen, Punkt bei Bedarf im Layer verschieben, Checkliste fuehren."
                                    .format(r["zulaessig"], r["n"], ", ".join("{} {}".format(v, k) for k, v in r["lagen"].items()),
                                            os.path.basename(r["excel"] or "-")))
        self._lauf_starten("Standorte vorschlagen", "pruefen", [quelle], {"out_dir": out_dir, "regeln": regeln, "gehaeusetyp": typ}, fertig)

    def _shape_export(self):
        """StoSi-Shape wie Plan[Goo] (Markus 12.10.2026)."""
        from . import kern
        if not self.gpkg:
            return
        try:
            self._layer_sichern()
            out_dir = dateiwahl.ausgabeordner(self.out.text()) if self.out.text().strip() else os.path.dirname(os.path.abspath(self.gpkg))
            p = kern.stosi_shape(self.gpkg, out_dir=out_dir, log=self._log)
            QMessageBox.information(self, "StoSi-Shape exportieren", "Geschrieben:\n{}\n\nInhalt: ESRI-Shape (UTF-8, EPSG:25832) im Plan[Goo]-Punktschema "
                                    "(TYPE nvt, NAME, PLZ, ORT, STRASSE, HS_NR, MAIN_MATERIAL = Gehaeusetyp, MAIN_PROJECT = NVT) - wie 'Export StoSi-Shape fuer GDI'."
                                    .format(p))
        except Exception as e:
            self.k_log.setChecked(True)
            self._log("StoSi-Shape: {!r}".format(e))
            QMessageBox.critical(self, "StoSi-Shape exportieren", "{!r}".format(e)[:500])

    def _datei_fallen_gelassen(self, p):
        if not p.lower().endswith((".gpkg", ".shp")):
            return False
        if "nvt_standorte" in os.path.basename(p).lower():
            self._ergebnis_laden(p)
        else:
            self.f_nvt.setText(p)
        return True

    # --- Aktionen ----------------------------------------------------------------------------------------------------------------------
    def _start(self):
        m = self._methode()
        if m == "zeichnen":
            return self._zeichnen_starten()
        if m == "uebernahme":
            return self._aus_layer()
        return self._vorschlagen()

    def _ergebnis_laden(self, pfad):
        """Fruehere Standortdatei laden: Layer in den Baum, Uebersicht fuellen, Knoepfe frei."""
        from . import kern
        if not pfad or not os.path.exists(pfad):
            return
        try:
            g = kern.standorte_lesen(pfad)
            land = "NW"
            try:
                from ..adressen import alkis as a_alkis
                k = a_alkis.laender_fuer_bbox(*g.total_bounds)
                land = k[0] if k else "NW"
            except Exception:
                pass
            out_dir = os.path.dirname(os.path.abspath(pfad))
            stamm = kern.stamm_von(pfad)
            excel = os.path.join(out_dir, "Netzverteiler-Standorte [{}].xlsx".format(stamm))
            blatt = os.path.join(out_dir, "nvt_standorte_{}_pruefblatt.md".format(stamm))
            self.ergebnis = {"gpkg": pfad, "out_dir": out_dir, "stamm": stamm, "land": land, "excel": excel if os.path.exists(excel) else None,
                             "bericht": blatt if os.path.exists(blatt) else None}
            self.gpkg = pfad
            dateiwahl.merken("nvt_standorte", pfad)
            self._layer_laden(pfad)
            self._tabelle_fuellen()
            for b in (self.k_plaene, self.k_excel, self.k_blatt, self.k_shape):
                b.setEnabled(True)
            self.k_blatt.setEnabled(bool(self.ergebnis["bericht"]))
            self._log("Standortdatei geladen: {} ({} Standorte)".format(pfad, len(g)))
        except Exception as e:
            self.k_log.setChecked(True)
            self._log("Standortdatei nicht geladen: {!r}".format(e))

    def _excel(self):
        from . import kern
        if not self.gpkg:
            return
        try:
            self._layer_sichern()
            p = kern.excel_aus_gpkg(self.gpkg, log=self._log)
            if p:
                self.ergebnis["excel"] = p
                self._oeffnen(p)
        except Exception as e:
            self.k_log.setChecked(True)
            self._log("Excel: {!r}".format(e))

    # --- Standortsicherung --------------------------------------------------------------------------------------------------------------
    def _tabelle_fuellen(self):
        from . import kern
        self.tab.setRowCount(0)
        self._zeilen = []
        for b in (self.k_zoom, self.k_check, self.k_alt):
            b.setEnabled(False)
        if not self.gpkg or not os.path.exists(self.gpkg):
            self.l_zahl.setText("")
            return
        try:
            g = kern.standorte_lesen(self.gpkg)
        except Exception as e:
            self._log("Uebersicht: {!r}".format(e))
            return
        zaehl = g["gesamt"].map(lambda v: _s(v) or "Offen").value_counts().to_dict()
        self.l_zahl.setText("  ".join("{} {}".format(zaehl.get(k, 0), k) for k in ("Offen", "Abgelehnt", "Gesichert")) +
                            "   ({} Standorte, {} NVT)".format(len(g), g["name"].nunique()))
        wahl = self.filter.currentText()
        g = g.sort_values(["name", "variante"])
        for _, z in g.iterrows():
            gesamt = _s(z.get("gesamt")) or "Offen"
            if wahl != "alle" and gesamt != wahl:
                continue
            r = self.tab.rowCount()
            self.tab.insertRow(r)
            werte = [_s(z["name"]), _s(z.get("variante")) or "Haupt", _s(z.get("lage")),
                     "ja" if str(z.get("zulaessig")).lower() in ("1", "true", "ja") else "nein",
                     gesamt.upper() if gesamt != "Gesichert" else gesamt, _s(z.get("offene_punkte"))]
            for c, w in enumerate(werte):
                it = QTableWidgetItem(w)
                if c == 4:
                    it.setForeground(QColor(FARBE_STATUS.get(gesamt, ci.GRAU)))
                    fnt = it.font()
                    fnt.setBold(gesamt != "Gesichert")
                    it.setFont(fnt)
                if c == 5:
                    it.setToolTip(w)
                self.tab.setItem(r, c, it)
            self._zeilen.append({"name": _s(z["name"]), "variante": _s(z.get("variante")) or "Haupt", "daten": z.to_dict()})
            g = z.geometry if z.geometry is not None and not isinstance(z.geometry, float) else None
            self.tab.karte_setzen(r, xy=(g.x, g.y) if g is not None else None,
                                  bezug=("standorte", {"name": _s(z["name"]), "variante": _s(z.get("variante")) or "Haupt"}))
        self.tab.fertig()

    def _gewaehlt(self):
        zeilen = self.tab.auswahl_indizes()
        if not zeilen or zeilen[0] >= len(self._zeilen):
            return None
        return self._zeilen[zeilen[0]]

    def _layer(self):
        return layerbaum.layer_aus_gpkg(self.gpkg, "nvt_standorte")

    def _layer_sichern(self):
        """Verschobene Punkte des Planers erst in die Datei schreiben, bevor der Kern sie liest."""
        lyr = self._layer()
        if lyr is not None and lyr.isEditable():
            if lyr.isModified():
                lyr.commitChanges()
                self._log("Layer Standort (Vorschlag): Aenderungen gespeichert")
            else:
                lyr.rollBack()
        return lyr

    def _layer_neu(self):
        lyr = self._layer()
        if lyr is not None:
            try:
                lyr.dataProvider().reloadData()
                lyr.updateExtents()
                lyr.triggerRepaint()
            except Exception:
                pass

    def _zeigen(self, zoom=False):
        z = self._gewaehlt()
        for b in (self.k_zoom, self.k_check, self.k_alt):
            b.setEnabled(z is not None)
        if z is None:
            return
        self.k_alt.setEnabled(z["variante"] == "Haupt")
        lyr = self._layer()
        if lyr is None:
            return
        try:
            lyr.selectByExpression("\"name\" = '{}' AND coalesce(\"variante\", 'Haupt') = '{}'".format(
                z["name"].replace("'", "''"), z["variante"].replace("'", "''")))
            canvas = self.iface.mapCanvas()
            geome = [f.geometry() for f in lyr.selectedFeatures()]
            if zoom and geome:
                canvas.zoomToSelected(lyr)
                if canvas.scale() < 500:
                    canvas.zoomScale(500)
            if geome:
                canvas.flashGeometries(geome, lyr.crs(), QColor("#C62828"), QColor(198, 40, 40, 0), 3, 600)
        except Exception as e:
            self._log("Standort zeigen: {!r}".format(e))

    def _checkliste(self):
        from . import kern
        z = self._gewaehlt()
        if z is None or not self.gpkg:
            return
        dlg = StosiDialog(z["daten"], self)
        if dlg.exec_() != QDialog.Accepted:
            return
        try:
            self._layer_sichern()
            gesamt, offen = kern.standort_speichern(self.gpkg, z["name"], z["variante"], dlg.werte(), log=self._log)
            self._layer_neu()
            merk = (z["name"], z["variante"])
            self._tabelle_fuellen()
            for i, zz in enumerate(self._zeilen):
                if (zz["name"], zz["variante"]) == merk:
                    self.tab.selectRow(i)
                    break
        except Exception as e:
            self.k_log.setChecked(True)
            self._log("Checkliste speichern: {!r}".format(e))
            self._log(traceback.format_exc()[-1200:])
            QMessageBox.critical(self, "Checkliste", "{!r}\n\nEinzelheiten im Protokoll.".format(e)[:600])

    def _alternative(self):
        from . import kern
        z = self._gewaehlt()
        if z is None or not self.gpkg:
            return
        if QMessageBox.question(self, "Alternativstandort", "Fuer {} einen Alternativstandort anlegen?\n\nEr wird als Kopie 3 m oestlich des "
                                "Hauptstandorts angelegt (Checkliste leer). Danach den Punkt im Layer 'Standort (Vorschlag)' an die richtige "
                                "Stelle schieben und die Checkliste fuehren.".format(z["name"]),
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes) != QMessageBox.Yes:
            return
        try:
            self._layer_sichern()
            if kern.alternative_anlegen(self.gpkg, z["name"], log=self._log):
                self._layer_neu()
                self._tabelle_fuellen()
                for i, zz in enumerate(self._zeilen):
                    if zz["name"] == z["name"] and zz["variante"] == "Alternativ":
                        self.tab.selectRow(i)
                        break
        except Exception as e:
            self.k_log.setChecked(True)
            self._log("Alternativstandort: {!r}".format(e))

    # --- Lageplaene --------------------------------------------------------------------------------------------------------------------
    def _lageplaene(self, massstab=1000, breite=1200, hoehe=800):
        """Je Standort ein PNG 1:1000 mit ALKIS-Hintergrund (NRW-WMS), Flurstuecken, Korridor und Standort - fuer das Stosi-Formular."""
        if not self.ergebnis:
            return
        self.k_plaene.setEnabled(False)
        try:
            self._layer_sichern()
            gpkg = self.ergebnis["gpkg"]
            ordner = os.path.join(self.ergebnis["out_dir"], "Standortsicherungen {}".format(self.ergebnis["stamm"]))
            os.makedirs(ordner, exist_ok=True)
            lyr_st = QgsVectorLayer("{}|layername=nvt_standorte".format(gpkg), "Standort", "ogr")
            lyr_ko = QgsVectorLayer("{}|layername=korridore".format(gpkg), "Korridor", "ogr")
            lyr_fl = QgsVectorLayer("{}|layername=flurstuecke".format(gpkg), "Flurstuecke", "ogr")
            for lyr in (lyr_st, lyr_ko, lyr_fl):
                lyr.setCrs(QgsCoordinateReferenceSystem("EPSG:25832"))
            self._stil_standort(lyr_st, gross=True)
            lyr_ko.renderer().setSymbol(QgsFillSymbol.createSimple({"color": "46,139,87,51", "outline_color": "#2E8B57", "outline_width": "0.5"}))
            lyr_fl.renderer().setSymbol(QgsFillSymbol.createSimple({"color": "255,255,255,0", "outline_color": "#555555", "outline_width": "0.3"}))
            self._label(lyr_fl, "flstnrzae", 8, False)
            wms = QgsRasterLayer(WMS_NW, "ALKIS NRW", "wms") if self.ergebnis.get("land") == "NW" else None
            layers = [lyr_st, lyr_ko, lyr_fl] + ([wms] if wms is not None and wms.isValid() else [])
            n = lyr_st.featureCount()
            for i, f in enumerate(lyr_st.getFeatures()):
                self._fortschritt(100.0 * i / max(n, 1), "Lageplan {}/{}".format(i + 1, n))
                p = f.geometry().asPoint()
                # 1:1000 bei 96 dpi: 1 px = 0,2646 mm -> Karteneinheit je px = massstab * 0.0002646 m
                m_px = massstab * 0.0002646
                rect = QgsRectangle(p.x() - breite / 2 * m_px, p.y() - hoehe / 2 * m_px, p.x() + breite / 2 * m_px, p.y() + hoehe / 2 * m_px)
                var = _s(f["variante"]) if "variante" in [fl.name() for fl in lyr_st.fields()] else ""
                lyr_st.setSubsetString("\"name\" = '{}'{}".format(str(f["name"]).replace("'", "''"),
                                                                  " AND \"variante\" = '{}'".format(var) if var else ""))
                ms = QgsMapSettings()
                ms.setLayers(layers)
                ms.setDestinationCrs(QgsCoordinateReferenceSystem("EPSG:25832"))
                ms.setBackgroundColor(QColor("#FFFFFF"))
                ms.setExtent(rect)
                ms.setOutputSize(QSize(breite, hoehe))
                ms.setOutputDpi(96)
                img = QImage(breite, hoehe, QImage.Format_ARGB32_Premultiplied)
                img.fill(QColor("#FFFFFF"))
                painter = QPainter(img)
                job = QgsMapRendererCustomPainterJob(ms, painter)
                job.start()
                job.waitForFinished()
                painter.end()
                name = str(f["name"]).replace("/", "_") + ("_Alternativ" if var == "Alternativ" else "")
                img.save(os.path.join(ordner, "Lageplan_{}.png".format(name)))
            lyr_st.setSubsetString("")
            self._fortschritt(100, "Fertig")
            self._log("Lageplaene: {} PNG in {}".format(n, ordner))
            QMessageBox.information(self, "Lageplaene fertig", "{} Lageplaene 1:{} gespeichert:\n{}\n\nZusammen mit der Excel-Liste die Grundlage "
                                    "fuer das Formular 'Standortsicherung fuer Schaltgehaeuse' (Zustimmung nach § 127 TKG). Fotos vor Ort ergaenzen."
                                    .format(n, massstab, ordner))
        except Exception as e:
            self._log("Fehler bei den Lageplaenen: {!r}".format(e))
            self._log(traceback.format_exc()[-1200:])
        finally:
            self.k_plaene.setEnabled(True)

    # --- Layer -------------------------------------------------------------------------------------------------------------------------
    def _layer_laden(self, gpkg):
        gruppe = layerbaum.gruppe("standort", "NVT-Standorte {}".format(os.path.basename(gpkg).replace("nvt_standorte_", "").replace(".gpkg", "")))
        for lname, titel in (("nvt_standorte", "Standort (Vorschlag)"), ("bestand_nvt", "Bestand-NVT (OSM, Plan[Goo])"), ("sitz_vorher", "Sitz vorher"),
                             ("korridore", "Korridor (zulaessig)"), ("verkehrsflaechen", "ALKIS Verkehrsflaechen"), ("flurstuecke", "ALKIS Flurstuecke")):
            lyr = QgsVectorLayer("{}|layername={}".format(gpkg, lname), titel, "ogr")
            if not lyr.isValid():
                continue
            lyr.setCrs(QgsCoordinateReferenceSystem("EPSG:25832"))
            if lname == "nvt_standorte":
                self._stil_standort(lyr)
            elif lname == "bestand_nvt":
                lyr.renderer().setSymbol(ci.nvt_symbol("#1A1A1A", 4.0))
                self._label(lyr, "name", 7, False)
            elif lname == "sitz_vorher":
                lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({"name": "cross2", "color": "#9E9E9E", "outline_color": "#9E9E9E", "size": "3"}))
            elif lname == "korridore":
                lyr.renderer().setSymbol(QgsFillSymbol.createSimple({"color": "46,139,87,68", "outline_color": "#2E8B57", "outline_width": "0.4"}))
            elif lname == "verkehrsflaechen":
                if lyr.fields().indexOf("einstufung") >= 0:
                    # Einstufung sichtbar machen: Fahrbahn grau, Gehweg gruen, Weg braun (Kern: Kontext.teile)
                    kats = []
                    for klasse, farbe, rand in (("Fahrbahn", "176,190,197,70", "#78909C"), ("Gehweg", "165,214,167,110", "#388E3C"),
                                                ("Weg", "215,204,200,90", "#8D6E63")):
                        kats.append(QgsRendererCategory(klasse, QgsFillSymbol.createSimple({"color": farbe, "outline_color": rand, "outline_width": "0.2"}),
                                                        {"Fahrbahn": "Fahrbahn (Strassenraum, befahrbarer Weg)", "Gehweg": "Gehweg / Begleitflaeche",
                                                         "Weg": "Weg ohne Strassenanschluss"}[klasse]))
                    lyr.setRenderer(QgsCategorizedSymbolRenderer("einstufung", kats))
                else:
                    lyr.renderer().setSymbol(QgsFillSymbol.createSimple({"color": "176,190,197,51", "outline_color": "#78909C", "outline_width": "0.2"}))
            elif lname == "flurstuecke":
                lyr.renderer().setSymbol(QgsFillSymbol.createSimple({"color": "255,255,255,0", "outline_color": "#8D6E63", "outline_width": "0.25"}))
                self._label(lyr, "flstnrzae", 7, False)
            layerbaum.einhaengen(gruppe, lyr, "standort", sichtbar=lname not in ("verkehrsflaechen", "flurstuecke"))
        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass

    def _stil_standort(self, lyr, gross=False):
        # NVT-Symbol wie in Plan[Goo]; Farbe = Gesamtstatus der Standortsicherung: Orange OFFEN, Rot Abgelehnt, Gruen Gesichert.
        # Alternativstandorte kleiner. (Plan[Goo]: Rot = NVt Planung, Schwarz = Bestand - deshalb Bestand-NVT hier schwarz.)
        gr = 6.0 if gross else 5.0
        kats = []
        for status, farbe in FARBE_STATUS.items():
            kats.append(QgsRendererCategory(status, ci.nvt_symbol(farbe, gr), status))
            kats.append(QgsRendererCategory(status + " (Alt.)", ci.nvt_symbol(farbe, gr * 0.7), status + " (Alternativstandort)"))
        kats.append(QgsRendererCategory("", ci.nvt_symbol(ci.ORANGE, gr), "Offen"))
        lyr.setRenderer(QgsCategorizedSymbolRenderer(STATUS_AUSDRUCK, kats))
        self._label(lyr, "concat(\"name\", if(\"variante\" = 'Alternativ', ' (Alt.)', ''), ' ', "
                         "if(coalesce(\"gesamt\", 'Offen') = 'Gesichert', 'gesichert', upper(coalesce(\"gesamt\", 'Offen'))), '\\n', "
                         "coalesce(\"lage\", ''), if(\"zulaessig\" = 0, ' - kein zulaessiger Platz', ''), '\\n', \"strasse\", ' ', \"hausnummer\", "
                         "'\\n', 'Flst. ', \"flurstueck\", if(\"flurstueck_nenner\" <> '', '/' || \"flurstueck_nenner\", ''), ' Flur ', \"flur\")",
                    8 if not gross else 10, True, True)

class StosiDialog(QDialog):
    """Checkliste eines Standorts: 8 Pruefpunkte mit Status OK / Nicht OK / Nicht relevant und Bemerkung, Rechtliche Sicherung
    (oeffentlich: Zustimmung § 127 TKG; privat: Gestattungsvertrag, Eigentuemer), Kommentar. Gesamtstatus wird live abgeleitet."""

    def __init__(self, daten, parent=None):
        from . import kern
        super().__init__(parent)
        self.kern = kern
        self.d = dict(daten)
        name, var = _s(self.d.get("name")), _s(self.d.get("variante")) or "Haupt"
        self.setWindowTitle("Standort {} ({}) - Checkliste".format(name, var))
        self.setMinimumWidth(820)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 12, 18, 10)
        lay.setSpacing(8)
        titel = QLabel("{}  <span style='color:{}; font-size:12px;'>{}standort</span>".format(name, ci.GRAU, var))
        titel.setStyleSheet("font-size:16px; font-weight:700;")
        lay.addWidget(titel)
        info = []
        for k, txt in (("lage", "Lage {}"), ("fahrbahn_m", "Fahrbahnkante {} m"), ("achse_m", "Achse {} m"), ("restgehweg_m", "Gehwegrest {} m"),
                       ("rand_m", "Grenze {} m"), ("gebaeude_m", "Gebaeude {} m"), ("kreuzung_m", "Kreuzung {} m"), ("bestand_m", "Bestand-NVT {} m")):
            v = _s(self.d.get(k))
            if v and v != "99" and v != "99.0":
                info.append(txt.format(v))
        adresse = " ".join(x for x in (_s(self.d.get("strasse")), _s(self.d.get("hausnummer"))) if x)
        flst = _s(self.d.get("flurstueck")) + ("/" + _s(self.d.get("flurstueck_nenner")) if _s(self.d.get("flurstueck_nenner")) else "")
        zeile2 = ", ".join(x for x in (adresse, "Flst. {} Flur {}".format(flst, _s(self.d.get("flur"))) if flst else "", _s(self.d.get("gemarkung"))) if x)
        l_info = QLabel("<br>".join(x for x in (" | ".join(info), zeile2, _s(self.d.get("hinweis")), _s(self.d.get("gruende"))) if x))
        l_info.setWordWrap(True)
        l_info.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        lay.addWidget(l_info)

        lay.addWidget(self._ueberschrift("Pruef-Checkliste"))
        g = QGridLayout()
        g.setHorizontalSpacing(8)
        g.setVerticalSpacing(4)
        self.status, self.bem = {}, {}
        for i, (k, text) in enumerate(kern.CHECKLISTE):
            lab = QLabel("{}  {}".format(k.upper(), text))
            lab.setToolTip(kern.CHECKLISTE_LANG.get(k, text))
            g.addWidget(lab, i, 0)
            cb = QComboBox()
            cb.addItems(list(kern.PRUEF_STATUS))
            cb.setItemText(0, "- offen -")
            cb.setCurrentIndex(max(0, cb.findText(_s(self.d.get(k + "_status")))) if _s(self.d.get(k + "_status")) else 0)
            cb.setFixedWidth(120)
            cb.currentIndexChanged.connect(lambda *_: self._gesamt())
            g.addWidget(cb, i, 1)
            le = QLineEdit(_s(self.d.get(k + "_bem")))
            le.setPlaceholderText("Bemerkung")
            g.addWidget(le, i, 2)
            self.status[k], self.bem[k] = cb, le
        g.setColumnStretch(0, 3)
        g.setColumnStretch(2, 2)
        lay.addLayout(g)

        lay.addWidget(self._ueberschrift("Rechtliche Sicherung"))
        r = QGridLayout()
        r.setHorizontalSpacing(8)
        r.setVerticalSpacing(4)
        r.addWidget(QLabel("Grund:"), 0, 0)
        self.grund = QComboBox()
        self.grund.addItems(["- offen -", "oeffentlich", "privat"])
        self.grund.setToolTip("Oeffentlicher Grund: Zustimmung des Wegebaulasttraegers nach § 127 TKG. Privatgrund: Gestattungsvertrag mit dem Eigentuemer.")
        self.grund.setCurrentIndex(max(0, self.grund.findText(_s(self.d.get("grund")))))
        self.grund.currentIndexChanged.connect(lambda *_: self._grund_umschalten())
        r.addWidget(self.grund, 0, 1)
        r.addWidget(QLabel("Zustimmung § 127 TKG:"), 0, 2)
        self.zustimmung = QComboBox()
        self.zustimmung.addItems(["- offen -", "beantragt", "erteilt", "abgelehnt"])
        self.zustimmung.setCurrentIndex(max(0, self.zustimmung.findText(_s(self.d.get("zustimmung")))))
        self.zustimmung.currentIndexChanged.connect(lambda *_: self._gesamt())
        r.addWidget(self.zustimmung, 0, 3)
        r.addWidget(QLabel("Gestattungsvertrag:"), 1, 0)
        self.gestattung = QComboBox()
        self.gestattung.addItems(["- offen -", "in Verhandlung", "unterschrieben", "abgelehnt"])
        self.gestattung.setCurrentIndex(max(0, self.gestattung.findText(_s(self.d.get("gestattung")))))
        self.gestattung.currentIndexChanged.connect(lambda *_: self._gesamt())
        r.addWidget(self.gestattung, 1, 1)
        r.addWidget(QLabel("Eigentuemer-Kontakt:"), 1, 2)
        self.eigentuemer = QLineEdit(_s(self.d.get("eigentuemer")))
        self.eigentuemer.setPlaceholderText("Name, Telefon, E-Mail")
        r.addWidget(self.eigentuemer, 1, 3)
        r.addWidget(QLabel("Kommentar:"), 2, 0)
        self.kommentar = QLineEdit(_s(self.d.get("kommentar")))
        r.addWidget(self.kommentar, 2, 1, 1, 3)
        r.setColumnStretch(1, 1)
        r.setColumnStretch(3, 1)
        lay.addLayout(r)

        self.l_gesamt = QLabel("")
        self.l_gesamt.setWordWrap(True)
        self.l_gesamt.setStyleSheet("font-size:12px; padding:6px; border:1px solid {}; border-radius:4px;".format(ci.GRAU_HELL))
        lay.addWidget(self.l_gesamt)

        k = QHBoxLayout()
        k.addStretch(1)
        ok = QPushButton("Speichern")
        ok.setStyleSheet(ci.STIL_KNOPF)
        ok.clicked.connect(self.accept)
        k.addWidget(ok)
        ab = QPushButton("Abbrechen")
        ab.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        ab.clicked.connect(self.reject)
        k.addWidget(ab)
        lay.addLayout(k)
        self._grund_umschalten()

    def _ueberschrift(self, t):
        lab = QLabel(t.upper())
        lab.setStyleSheet("font-size:11px; font-weight:700; letter-spacing:1px; color:{}; margin-top:4px;".format(ci.ORANGE_DUNKEL))
        return lab

    def _grund_umschalten(self):
        g = self.grund.currentText()
        self.zustimmung.setEnabled(g == "oeffentlich")
        self.gestattung.setEnabled(g == "privat")
        self.eigentuemer.setEnabled(g == "privat")
        self._gesamt()

    def werte(self):
        w = {}
        for k in self.status:
            st = self.status[k].currentText()
            w[k + "_status"] = "" if st.startswith("-") else st
            w[k + "_bem"] = self.bem[k].text().strip()
        for feld, box in (("grund", self.grund), ("zustimmung", self.zustimmung), ("gestattung", self.gestattung)):
            t = box.currentText()
            w[feld] = "" if t.startswith("-") else t
        w["eigentuemer"] = self.eigentuemer.text().strip()
        w["kommentar"] = self.kommentar.text().strip()
        return w

    def _gesamt(self):
        gesamt, offen = self.kern.gesamtstatus(self.werte())
        farbe = FARBE_STATUS.get(gesamt, ci.GRAU)
        text = "<b style='color:{}'>{}</b>".format(farbe, gesamt.upper() if gesamt != "Gesichert" else "Gesichert")
        if offen:
            text += "<span style='color:{}'>  -  {}</span>".format(ci.GRAU, "; ".join(offen))
        self.l_gesamt.setText(text)
