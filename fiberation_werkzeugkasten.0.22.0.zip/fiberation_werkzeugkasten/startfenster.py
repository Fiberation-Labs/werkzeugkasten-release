# -*- coding: utf-8 -*-
"""Hauptfenster des Werkzeugkastens: EIN Fenster mit Seiten (Markus 18.09.2026: "die einzelnen Kacheln oeffnen, ohne dass sich immer
ein neues Fenster oeffnet, und mich dann hin und her bewegen").

Seite 0 ist die Uebersicht: der Planungsablauf als Liste von Schritten (Nummer, Titel, Kurztext, Stand mit Datum, Knopf; Abschnitte
und Texte aus ablauf.py). Jeder gebaute Schritt oeffnet als weitere Seite IM SELBEN Fenster - der Werkzeugdialog wird per
fenster.einbetten zur Seite, sein eigener Kopf und sein Schliessen-Knopf verschwinden, der Fensterkopf zeigt seinen Titel.
Auf den Werkzeugseiten steht eine Navigationszeile: zurueck zur Uebersicht, die Schrittnummern zum Springen, vor/zurueck im Ablauf.
Seiten bleiben geoeffnet (Eingaben, Ergebnis, Protokoll), bis das Fenster geschlossen wird; Escape auf einer Seite fuehrt zur Uebersicht.

Andocken (Markus 18.09.2026, "direkt ans QGIS-Fenster andocken, wenn man das moechte"): der Knopf in der Fusszeile haengt das Fenster
als Panel (QgsDockWidget) rechts an das QGIS-Hauptfenster - dort laesst es sich wie das Layer-Panel verschieben, loesen und mit anderen
Panels stapeln; "Als Fenster loesen" macht wieder ein eigenes Fenster daraus. Die Wahl wird gemerkt (QSettings) und beim naechsten Oeffnen
wiederhergestellt. Angedockt schliesst das X nur das Panel, die Seiten bleiben; der Knopf in der Werkzeugleiste holt es zurueck.
"""
import os
from datetime import datetime

from qgis.PyQt.QtCore import QSettings, Qt, QTimer
from qgis.PyQt.QtWidgets import (QAbstractScrollArea, QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea,
                                 QSizePolicy, QStackedWidget, QVBoxLayout, QWidget)

from . import ablauf, ci, dateiwahl
from .plugin import NAME, version

UNTER_START = "Planungsablauf Schritt fuer Schritt. Ergebnisse als Layer, die Entscheidung bleibt beim Planer."

STIL_ZEILE = ("QFrame#zeile {{ border:1px solid {g}; border-radius:8px; background:palette(base); }}"
              "QFrame#zeile:hover {{ border-color:{o}; }}").format(g=ci.GRAU_HELL, o=ci.ORANGE)
STIL_ZEILE_AUS = "QFrame#zeile {{ border:1px dashed {g}; border-radius:8px; background:transparent; }}".format(g=ci.GRAU_HELL)
STIL_NUMMER = ("QLabel {{ background:{o}; color:{s}; border-radius:14px; font-weight:700; font-size:13px; min-width:28px; max-width:28px; "
               "min-height:28px; max-height:28px; }}").format(o=ci.ORANGE, s=ci.SCHWARZ)
STIL_NUMMER_AUS = ("QLabel {{ background:{g}; color:{gr}; border-radius:14px; font-weight:700; font-size:13px; min-width:28px; max-width:28px; "
                   "min-height:28px; max-height:28px; }}").format(g=ci.GRAU_HELL, gr=ci.GRAU)
STIL_FRAGE = ("QPushButton {{ background:transparent; color:{gr}; border:1px solid {g}; border-radius:11px; min-width:22px; max-width:22px; "
              "min-height:22px; max-height:22px; padding:0; font-weight:700; }} QPushButton:hover {{ border-color:{o}; color:{o}; }}"
              ).format(gr=ci.GRAU, g=ci.GRAU_HELL, o=ci.ORANGE)
# Schrittnummern in der Navigationszeile: aktiv (orange), waehlbar (Rand), noch nicht gebaut (gestrichelt, aus)
_CHIP = ("min-width:26px; max-width:26px; min-height:26px; max-height:26px; border-radius:13px; padding:0; font-weight:700; font-size:12px;")
STIL_CHIP_AKTIV = "QPushButton {{ {c} background:{o}; color:{s}; border:1px solid {o}; }}".format(c=_CHIP, o=ci.ORANGE, s=ci.SCHWARZ)
STIL_CHIP = ("QPushButton {{ {c} background:transparent; color:palette(text); border:1px solid {g}; }}"
             "QPushButton:hover {{ border-color:{o}; color:{o}; }}").format(c=_CHIP, g=ci.GRAU, o=ci.ORANGE)
STIL_CHIP_AUS = "QPushButton {{ {c} background:transparent; color:{gr}; border:1px dashed {gr}; }}".format(c=_CHIP, gr=ci.GRAU)
STIL_NAV = "QFrame#nav {{ border:none; border-bottom:1px solid {g}; background:transparent; }}".format(g=ci.GRAU_HELL)

UEBERSICHT = "uebersicht"
ANLEITUNG = "anleitung"
UNTER_ANLEITUNG = "Kurzanleitung zu allen Schritten. Die Knoepfe unten springen zum Kapitel; Uebersicht oder Escape fuehren zurueck."
EINSTELLUNG_ANGEDOCKT = "fiberation_werkzeugkasten/angedockt"
DOCK_BREITE = 640


class _Zeile(QFrame):
    """Eine Ablaufzeile; Klick auf die Zeile oeffnet den Schritt wie der Knopf."""

    def __init__(self, oeffnen=None, parent=None):
        super().__init__(parent)
        self._oeffnen = oeffnen
        self.setObjectName("zeile")
        if oeffnen:
            self.setCursor(Qt.PointingHandCursor)

    def mousePressEvent(self, ev):
        if self._oeffnen and ev.button() == Qt.LeftButton:
            self._oeffnen()
        super().mousePressEvent(ev)


class Werkzeugfenster(QDialog):
    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.seiten = {}            # schluessel -> eingebetteter Werkzeugdialog
        self.anleitung = None       # Seite Anleitung (hilfe.AnleitungWidget), entsteht beim ersten Aufruf
        self.aktuell = UEBERSICHT
        self._stand_labels = {}
        self._chips = {}
        self.setWindowTitle(NAME)
        root = QVBoxLayout(self)
        root.setContentsMargins(22, 14, 22, 10)
        root.setSpacing(6)

        self.kopf = ci.kopf_widget("Werkzeugkasten", UNTER_START, logo_hoehe=40, titel_px=20)
        root.addWidget(self.kopf)

        self.nav = self._navigation()
        root.addWidget(self.nav)

        self.stapel = QStackedWidget()
        self.stapel.setFrameShape(QFrame.NoFrame)
        self.uebersicht = self._uebersicht_bauen()
        self.stapel.addWidget(self.uebersicht)
        root.addWidget(self.stapel, 1)

        fusszeile = QHBoxLayout()
        fusszeile.setSpacing(8)
        self.k_dock = QPushButton("Andocken")
        self.k_dock.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_dock.setCursor(Qt.PointingHandCursor)
        self.k_dock.clicked.connect(self._dock_wechseln)
        fusszeile.addWidget(self.k_dock)
        fusszeile.addStretch(1)
        fuss = QLabel(ci.fuss_text(version()))
        fuss.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        fusszeile.addWidget(fuss)
        root.addLayout(fusszeile)
        self.dock = None

        from . import fenster
        fenster.einrichten(self, "haupt", None, scrollen=False)
        self.setMinimumWidth(fenster.MIN_BREITE_DIALOG)
        self.setMinimumHeight(fenster.MIN_HOEHE_DIALOG)
        self._nav_aktualisieren()
        self._dock_knopf()

    # --- Andocken an QGIS -------------------------------------------------------------------------------------------------------------
    @staticmethod
    def angedockt_gewuenscht():
        return QSettings().value(EINSTELLUNG_ANGEDOCKT, False, type=bool)

    def ist_angedockt(self):
        return self.dock is not None

    def _dock_knopf(self):
        if self.ist_angedockt():
            self.k_dock.setText("Als Fenster loesen")
            self.k_dock.setToolTip("Aus dem QGIS-Fenster loesen und wieder als eigenes Fenster zeigen.")
        else:
            self.k_dock.setText("An QGIS andocken")
            self.k_dock.setToolTip("Als Panel rechts an das QGIS-Fenster haengen - wie das Layer-Panel verschiebbar, stapelbar, "
                                   "per Doppelklick auf die Titelleiste schwebend. Die Wahl wird gemerkt.")

    def _dock_wechseln(self):
        if self.ist_angedockt():
            self.loesen()
        else:
            self.andocken()

    def _qgis_hauptfenster(self):
        try:
            mw = self.plugin.iface.mainWindow()
            if mw is not None:
                return mw
        except Exception:
            pass
        from . import fenster
        return fenster.qgis_fenster()

    def andocken(self, bereich=Qt.RightDockWidgetArea):
        """Als Panel an das QGIS-Hauptfenster haengen. Das Fenster wird Inhalt eines QgsDockWidget (Fallback QDockWidget)."""
        if self.ist_angedockt():
            return self.dock
        mw = self._qgis_hauptfenster()
        if mw is None or not hasattr(mw, "addDockWidget"):
            return None
        from . import fenster
        try:
            from qgis.gui import QgsDockWidget as _Dock
        except Exception:
            from qgis.PyQt.QtWidgets import QDockWidget as _Dock
        w = getattr(self, "_fwk_waechter", None)
        if w is not None:
            w._merken()
            self.removeEventFilter(w)
            self._fwk_waechter = None
        war_sichtbar = self.isVisible()
        self.hide()
        dock = _Dock(NAME, mw)
        dock.setObjectName("FiberationWerkzeugkasten")
        dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.setWindowFlags(Qt.Widget)
        self.setSizeGripEnabled(False)
        self.layout().setContentsMargins(10, 8, 10, 6)
        self.setMinimumWidth(0)
        self.setMinimumHeight(0)
        self.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)   # das Panel bestimmt die Groesse, der Inhalt rollt
        dock.setWidget(self)
        dock.setWindowTitle(self.windowTitle())
        self.windowTitleChanged.connect(dock.setWindowTitle)
        mw.addDockWidget(bereich, dock)
        try:
            mw.resizeDocks([dock], [DOCK_BREITE], Qt.Horizontal)
        except Exception:
            pass
        self.dock = dock
        self.show()
        dock.show()
        dock.raise_()
        QSettings().setValue(EINSTELLUNG_ANGEDOCKT, True)
        self._dock_knopf()
        return dock

    def loesen(self):
        """Aus dem QGIS-Fenster loesen: wieder eigenes Fenster mit Groesse/Lage vom letzten Mal."""
        if not self.ist_angedockt():
            return
        from . import fenster
        dock = self.dock
        self.dock = None
        try:
            self.windowTitleChanged.disconnect(dock.setWindowTitle)
        except Exception:
            pass
        mw = self._qgis_hauptfenster()
        dock.setWidget(None)
        self.setParent(None)
        if mw is not None and hasattr(mw, "removeDockWidget"):
            mw.removeDockWidget(dock)
        dock.deleteLater()
        self.setWindowFlags(fenster.FLAGS)
        self.setSizeGripEnabled(True)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        self.layout().setContentsMargins(22, 14, 22, 10)
        self.setMinimumWidth(fenster.MIN_BREITE_DIALOG)
        self.setMinimumHeight(fenster.MIN_HOEHE_DIALOG)
        self._fwk_waechter = fenster._Waechter(self, "haupt")
        self.installEventFilter(self._fwk_waechter)
        QSettings().setValue(EINSTELLUNG_ANGEDOCKT, False)
        self._dock_knopf()
        fenster.hervorholen(self)

    def hervorholen(self):
        """Fenster oder Panel zeigen und nach vorn holen (Knopf in der Werkzeugleiste, Menue)."""
        if self.ist_angedockt():
            self.show()
            try:
                self.dock.setUserVisible(True)      # QgsDockWidget: auch aus einem Panel-Stapel nach vorn
            except Exception:
                self.dock.show()
                self.dock.raise_()
            return
        from . import fenster
        fenster.hervorholen(self)

    def reject(self):
        """Escape auf der Uebersicht bzw. Schliessen: angedockt nur das Panel ausblenden (Seiten bleiben), sonst wie ein Fenster."""
        if self.ist_angedockt():
            self.dock.hide()
            return
        super().reject()

    def aufraeumen(self):
        """Beim Entladen des Plugins: Seiten schliessen, Panel entfernen."""
        self._seiten_schliessen()
        if self.ist_angedockt():
            dock = self.dock
            self.dock = None
            mw = self._qgis_hauptfenster()
            try:
                dock.setWidget(None)
                if mw is not None and hasattr(mw, "removeDockWidget"):
                    mw.removeDockWidget(dock)
                dock.deleteLater()
            except Exception:
                pass
            self.setParent(None)
        self.close()

    # --- Navigationszeile ------------------------------------------------------------------------------------------------------------
    def _navigation(self):
        f = QFrame()
        f.setObjectName("nav")
        f.setStyleSheet(STIL_NAV)
        lay = QHBoxLayout(f)
        lay.setContentsMargins(0, 2, 0, 6)
        lay.setSpacing(6)
        self.k_uebersicht = QPushButton("←  Uebersicht")
        self.k_uebersicht.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_uebersicht.setCursor(Qt.PointingHandCursor)
        self.k_uebersicht.setToolTip("Zurueck zur Liste aller Schritte. Die Seite bleibt geoeffnet, Eingaben und Ergebnis bleiben erhalten.")
        self.k_uebersicht.clicked.connect(lambda *_: self.zeige(UEBERSICHT))
        lay.addWidget(self.k_uebersicht)
        lay.addSpacing(10)
        for nr, titel_, kurz, lang, schluessel, art, anker in ablauf.SCHRITTE:
            if nr in ablauf.ABSCHNITTE and nr != "0":
                trenner = QLabel("·")
                trenner.setStyleSheet("color:{}; font-weight:700;".format(ci.GRAU))
                lay.addWidget(trenner)
            b = QPushButton(nr)
            b.setToolTip("{}  {}\n{}".format(nr, titel_, kurz))
            if schluessel:
                b.setCursor(Qt.PointingHandCursor)
                b.clicked.connect(lambda *_, s=schluessel: self.zeige(s))
            else:
                b.setEnabled(False)
            self._chips[schluessel or "folgt_" + nr] = b
            lay.addWidget(b)
        lay.addStretch(1)
        self.k_anleitung = QPushButton("Anleitung")
        self.k_anleitung.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_anleitung.setCursor(Qt.PointingHandCursor)
        self.k_anleitung.clicked.connect(lambda *_: self.zeige(ANLEITUNG, anker=self._anker_aktuell()))
        lay.addWidget(self.k_anleitung)
        lay.addSpacing(10)
        self.k_zurueck = QPushButton("←")
        self.k_zurueck.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
        self.k_zurueck.setCursor(Qt.PointingHandCursor)
        self.k_zurueck.clicked.connect(lambda *_: self._springen(-1))
        lay.addWidget(self.k_zurueck)
        self.k_weiter = QPushButton("→")
        self.k_weiter.setStyleSheet(ci.STIL_KNOPF)
        self.k_weiter.setCursor(Qt.PointingHandCursor)
        self.k_weiter.clicked.connect(lambda *_: self._springen(+1))
        lay.addWidget(self.k_weiter)
        return f

    def _anker_aktuell(self):
        """Kapitel der Anleitung zum aktuellen Schritt (None auf der Uebersicht)."""
        s = ablauf.schritt(self.aktuell)
        return s[6] if s else None

    def _nachbar(self, richtung):
        """Schluessel des vorigen/naechsten gebauten Schritts oder None."""
        reihe = ablauf.gebaut()
        if self.aktuell not in reihe:
            return None
        i = reihe.index(self.aktuell) + richtung
        return reihe[i] if 0 <= i < len(reihe) else None

    def _springen(self, richtung):
        ziel = self._nachbar(richtung)
        if ziel:
            self.zeige(ziel)

    def _nav_aktualisieren(self):
        auf_seite = self.aktuell != UEBERSICHT
        self.nav.setVisible(auf_seite)
        self.k_anleitung.setEnabled(self.aktuell != ANLEITUNG)
        s = ablauf.schritt(self.aktuell)
        self.k_anleitung.setToolTip("Anleitung, Kapitel zu Schritt {}".format(s[0]) if s else "Anleitung")
        for schluessel, b in self._chips.items():
            if not b.isEnabled():
                b.setStyleSheet(STIL_CHIP_AUS)
            elif schluessel == self.aktuell:
                b.setStyleSheet(STIL_CHIP_AKTIV)
            else:
                b.setStyleSheet(STIL_CHIP)
        for knopf, richtung, muster in ((self.k_zurueck, -1, "←  {}"), (self.k_weiter, +1, "{}  →")):
            ziel = self._nachbar(richtung)
            knopf.setEnabled(ziel is not None)
            if ziel:
                s = ablauf.schritt(ziel)
                knopf.setText(muster.format("Schritt " + s[0]))
                knopf.setToolTip("{}  {}\n{}".format(s[0], s[1], s[2]))
            else:
                knopf.setText(muster.format("Schritt"))
                knopf.setToolTip("Kein weiterer Schritt gebaut" if richtung > 0 else "Erster Schritt")

    # --- Seiten ---------------------------------------------------------------------------------------------------------------------
    def zeige(self, schluessel=UEBERSICHT, anker=None):
        """Seite anzeigen: 'uebersicht', 'anleitung' (anker = Kapitel) oder der Schluessel eines gebauten Schritts (umfeld, adressen,
        cluster, standort, trassen, wesi, uebergabe). Der Werkzeugdialog entsteht beim ersten Aufruf und bleibt danach als Seite
        erhalten. Gibt die Seite zurueck."""
        if schluessel == ANLEITUNG:
            return self._anleitung_zeigen(anker)
        if not schluessel or schluessel == UEBERSICHT or ablauf.schritt(schluessel) is None:
            self.aktuell = UEBERSICHT
            self.stapel.setCurrentWidget(self.uebersicht)
            self.kopf.titel.setText("Werkzeugkasten")
            self.kopf.unter.setText(UNTER_START)
            self.setWindowTitle(NAME)
            self._nav_aktualisieren()
            self._stand_aktualisieren()
            return None
        d = self.seiten.get(schluessel)
        if d is None:
            d = self._seite_bauen(schluessel)
            if d is None:
                return None
        self.aktuell = schluessel
        d.show()                                   # nach Escape/Schliessen ist die Seite versteckt
        self.stapel.setCurrentWidget(d)
        d.setGeometry(self.stapel.contentsRect())  # QDialog.showEvent darf die Seite nicht verschieben
        s = ablauf.schritt(schluessel)
        self.kopf.titel.setText(ablauf.titel(schluessel))
        kopf = getattr(d, "kopf", None)
        self.kopf.unter.setText(getattr(kopf, "unter_text", None) or s[2])
        self.setWindowTitle("{} - {}".format(NAME, ablauf.titel(schluessel).replace("  ", " ", 1)))
        self._nav_aktualisieren()
        return d

    def _anleitung_zeigen(self, anker=None):
        if self.anleitung is None:
            from .hilfe import AnleitungWidget
            self.anleitung = AnleitungWidget()
            self.anleitung.zurueck.connect(lambda: self.zeige(UEBERSICHT))
            self.stapel.addWidget(self.anleitung)
        self.aktuell = ANLEITUNG
        self.stapel.setCurrentWidget(self.anleitung)
        self.anleitung.springe(anker)
        self.kopf.titel.setText("Anleitung")
        self.kopf.unter.setText(UNTER_ANLEITUNG)
        self.setWindowTitle("{} - Anleitung".format(NAME))
        self._nav_aktualisieren()
        self.anleitung.tb.setFocus()
        return self.anleitung

    def _seite_bauen(self, schluessel):
        from . import fenster
        try:
            d = self.plugin.dialog_bauen(schluessel)
        except Exception as e:
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.critical(self, NAME, "Schritt konnte nicht geoeffnet werden:\n{!r}".format(e)[:700])
            return None
        if d is None:
            return None
        fenster.einbetten(d)
        inhalt = getattr(d, "_fwk_inhalt", None)
        if inhalt is not None and inhalt.layout() is not None:
            inhalt.layout().setContentsMargins(0, 6, 6, 0)   # Rand kommt vom Hauptfenster; rechts Platz fuer den Rollbalken
        d.finished.connect(lambda *_, s=schluessel: self._seite_geschlossen(s))
        self.stapel.addWidget(d)
        self.seiten[schluessel] = d
        self._breite_anpassen(d)
        return d

    def _seite_geschlossen(self, schluessel):
        """Escape oder ein Schliessen im Werkzeug: die Seite bleibt erhalten, das Fenster zeigt die Uebersicht."""
        if self.aktuell == schluessel and self.isVisible():
            self.zeige(UEBERSICHT)

    def _breite_anpassen(self, d):
        """Fenster so breit machen, dass die Seite ohne waagerechten Rollbalken passt (soweit der Bildschirm es zulaesst)."""
        from . import fenster
        inhalt = getattr(d, "_fwk_inhalt", None)
        breite = (inhalt.minimumWidth() if inhalt is not None else d.minimumSizeHint().width()) + 24 + 44
        if self.ist_angedockt() or breite <= self.width() or self.isMaximized():
            return
        r = self.geometry()
        r.setWidth(breite)
        r = fenster.sichtbar_machen(r, fenster.qgis_fenster())
        self.setGeometry(r)

    def seite(self, schluessel):
        """Vorhandene Seite (Dialog) oder None - ohne sie anzuzeigen."""
        return self.seiten.get(schluessel)

    def closeEvent(self, ev):
        """Fenster schliessen = alle Seiten schliessen (Werkzeuge raeumen auf, z. B. Fang in Schritt 4) und verwerfen.
        Angedockt kommt kein closeEvent (das X des Panels blendet nur aus) - dann bleiben die Seiten erhalten."""
        self._seiten_schliessen()
        super().closeEvent(ev)

    def _seiten_schliessen(self):
        for schluessel, d in list(self.seiten.items()):
            try:
                d.blockSignals(True)
                d.close()
                self.stapel.removeWidget(d)
                d.setParent(None)
                d.deleteLater()
            except Exception:
                pass
        self.seiten = {}
        if self.aktuell != UEBERSICHT:
            self.zeige(UEBERSICHT)

    # --- Uebersicht -------------------------------------------------------------------------------------------------------------------
    def _uebersicht_bauen(self):
        inhalt = QWidget()
        inhalt.setMinimumWidth(560)
        lay = QVBoxLayout(inhalt)
        lay.setContentsMargins(0, 0, 6, 0)
        lay.setSpacing(6)
        for nr, titel_, kurz, lang, schluessel, art, anker in ablauf.SCHRITTE:
            if nr in ablauf.ABSCHNITTE:
                lay.addWidget(self._abschnitt(ablauf.ABSCHNITTE[nr]))
            lay.addWidget(self._zeile(nr, titel_, kurz, lang, schluessel, art, anker))
        lay.addWidget(self._abschnitt(ablauf.HELFER_TITEL))
        helfer = QHBoxLayout()
        helfer.setSpacing(8)
        for text, tipp, slot in ablauf.HELFER:
            b = QPushButton(text)
            b.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
            b.setToolTip(tipp)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda *_, s=slot: getattr(self.plugin, s)())
            helfer.addWidget(b)
        helfer.addStretch(1)
        lay.addLayout(helfer)
        lay.addStretch(1)
        scroll = QScrollArea()
        scroll.setObjectName("fwk_uebersicht")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setSizeAdjustPolicy(QAbstractScrollArea.AdjustToContents)
        scroll.setWidget(inhalt)
        return scroll

    def _abschnitt(self, text):
        lab = QLabel(text.upper())
        lab.setStyleSheet("font-size:10px; font-weight:700; letter-spacing:1px; color:{}; margin-top:6px;".format(ci.ORANGE_DUNKEL))
        return lab

    def _zeile(self, nr, titel, kurz, lang, schluessel, art, anker):
        aktiv = schluessel is not None
        oeffnen = (lambda s=schluessel: self.zeige(s)) if aktiv else None
        f = _Zeile(oeffnen)
        f.setStyleSheet(STIL_ZEILE if aktiv else STIL_ZEILE_AUS)
        f.setToolTip(lang)
        g = QGridLayout(f)
        g.setContentsMargins(10, 5, 10, 5)
        g.setHorizontalSpacing(12)
        g.setVerticalSpacing(0)
        num = QLabel(nr)
        num.setAlignment(Qt.AlignCenter)
        num.setStyleSheet(STIL_NUMMER if aktiv else STIL_NUMMER_AUS)
        g.addWidget(num, 0, 0, 2, 1, Qt.AlignVCenter)
        t = QLabel(titel)
        t.setStyleSheet("font-size:13px; font-weight:600; border:none; background:transparent; color:{};".format("palette(text)" if aktiv else ci.GRAU))
        g.addWidget(t, 0, 1)
        # Stand rechts in der Titelzeile, der Kurztext darunter ueber die volle Breite - so stossen sie nicht zusammen
        stand = QLabel("")
        stand.setStyleSheet("color:{}; font-size:11px; border:none; background:transparent;".format(ci.GRAU))
        stand.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        g.addWidget(stand, 0, 2)
        k = QLabel(kurz)
        k.setWordWrap(True)
        k.setStyleSheet("color:{}; font-size:11px; border:none; background:transparent;".format(ci.GRAU))
        g.addWidget(k, 1, 1, 1, 2)
        g.setColumnStretch(1, 1)
        g.setColumnStretch(2, 1)
        if art:
            self._stand_labels[art] = stand
        if aktiv:
            b = QPushButton("Oeffnen")
            b.setStyleSheet(ci.STIL_KNOPF)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda *_: oeffnen())
        else:
            b = QPushButton("Folgt")
            b.setStyleSheet(ci.STIL_KNOPF_ZWEIT)
            b.setEnabled(False)
        b.setFixedWidth(104)
        g.addWidget(b, 0, 3, 2, 1, Qt.AlignVCenter)
        frage = QPushButton("?")
        frage.setStyleSheet(STIL_FRAGE)
        frage.setToolTip("Anleitung zu diesem Schritt")
        frage.setCursor(Qt.PointingHandCursor)
        if anker:
            frage.clicked.connect(lambda *_, a=anker: self._anleitung(a))
        else:
            frage.setEnabled(False)
        g.addWidget(frage, 0, 4, 2, 1, Qt.AlignVCenter)
        return f

    def _anleitung(self, anker):
        self.zeige(ANLEITUNG, anker=anker)

    # --- Stand je Schritt ------------------------------------------------------------------------------------------------------------
    def showEvent(self, ev):
        super().showEvent(ev)
        if self.aktuell == UEBERSICHT:
            self._stand_aktualisieren()

    def _stand_aktualisieren(self):
        """Juengstes Ergebnis je Schritt (aus den gemerkten Pfaden) mit Datum - der Planer sieht, wo er steht."""
        for art, lab in self._stand_labels.items():
            try:
                pfade = dateiwahl.zuletzt(art)
            except Exception:
                pfade = []
            if not pfade:
                lab.setText("noch kein Ergebnis")
                lab.setStyleSheet("color:{}; font-size:11px; border:none; background:transparent;".format(ci.GRAU))
                lab.setToolTip("")
                continue
            p = pfade[0]
            try:
                wann = datetime.fromtimestamp(os.path.getmtime(p)).strftime("%d.%m. %H:%M")
            except Exception:
                wann = ""
            name = os.path.basename(p)
            if len(name) > 30:
                name = name[:14] + "..." + name[-13:]
            lab.setText("{}  {}".format(wann, name).strip())
            lab.setStyleSheet("color:#2E8B57; font-size:11px; border:none; background:transparent;")
            lab.setToolTip(p)


Startfenster = Werkzeugfenster   # alter Name
