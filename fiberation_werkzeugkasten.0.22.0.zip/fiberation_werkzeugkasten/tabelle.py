# -*- coding: utf-8 -*-
"""Gemeinsame Tabelle fuer alle Schritte (Markus 12.10.2026: "dieselben Funktionen wie die QGIS-Attributtabelle, ueberall gleich").

Tabelle(schluessel, spalten, iface) ist ein QWidget: oben eine Leiste (Suche, Nur Auswahl, Spalten, Hinzoomen, Blinken, Kopieren, Zaehler),
darunter die Tabelle. Sie kann:
  * sortieren per Klick auf den Spaltenkopf (Zahlen als Zahlen, Texte natuerlich: 1V2 vor 1V10), auf- und absteigend
  * Spaltenbreite ziehen, Doppelklick auf den Spaltenrand passt an den Inhalt an; Spalten per Drag and Drop umsortieren,
    ein- und ausblenden (Knopf "Spalten" oder Rechtsklick auf den Kopf)
  * Tooltip je Zelle mit dem vollen Inhalt, je Kopf mit dem vollen Spaltennamen
  * filtern ueber das Suchfeld (alle sichtbaren Spalten, Gross/Klein egal); "Nur Auswahl" zeigt nur markierte Zeilen
  * Mehrfachauswahl (Strg/Umschalt), synchron mit der Kartenauswahl in beide Richtungen (Kartenbezug je Zeile)
  * Hinzoomen und Blinken fuer die markierten Zeilen (Kartenbezug oder Koordinaten)
  * markierte Zeilen (sonst alle sichtbaren) als Tabulator-Text in die Zwischenablage (Strg+C), Excel nimmt das direkt
  * Zaehler "12 von 340 ausgewaehlt", mit Filterstand
  * Spaltenbreiten, Reihenfolge, ausgeblendete Spalten und Sortierung werden je Tabelle gemerkt (QSettings, Schluessel)

Fuellen wie bei QTableWidget: setRowCount(0) (oder leeren()), insertRow/setItem (Datenindex = Zeile beim Fuellen), danach fertig().
Wird fertig() vergessen, holt die Tabelle es im naechsten Ereignisdurchlauf selbst nach. Waehrend des Fuellens ist die Sortierung aus,
damit die Zeilen nicht unter den Haenden wegsortiert werden.

Kartenbezug je Zeile (Datenindex): karte_setzen(idx, xy=[(x, y), ...] in EPSG:25832, bezug=(layerschluessel, {feld: wert | [werte]}),
geometrien=[QgsGeometry in EPSG:25832]). layer_finder(schluessel) -> Layer liefert den aktuellen Layer (die Schritte legen ihre Layer
neu an, deshalb kein fester Layer). Zeilenauswahl -> selectByExpression im Layer; Layerauswahl -> Zeilen markieren.

Datenindex statt Zeile: wegen der Sortierung ist die sichtbare Zeile nicht der Index in der Datenliste des Dialogs. auswahl_indizes()
liefert Datenindizes, selectRow(idx) und zelle(idx, spalte) nehmen Datenindizes. item(zeile, spalte) bleibt zeilenbezogen."""
import re

from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry, QgsPointXY, QgsProject, QgsRectangle
from qgis.PyQt.QtCore import QSettings, Qt, QTimer, pyqtSignal
from qgis.PyQt.QtGui import QColor, QKeySequence
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMenu, QShortcut, QTableWidget,
                                 QTableWidgetItem, QToolButton, QVBoxLayout, QWidget)

from . import ci, gemeinsam

ROLLE_INDEX = Qt.UserRole + 7          # Datenindex an jeder Zelle
EINSTELLUNGEN = "fiberation_werkzeugkasten/tabellen/"
CRS_DATEN = "EPSG:25832"
_ZAHL = re.compile(r"^\s*[-+]?\d{1,3}(?:[.\d]{3})*(?:,\d+)?\s*$|^\s*[-+]?\d+(?:[.,]\d+)?\s*$")
_TEILE = re.compile(r"(\d+)")


def _zahl(text):
    t = text.strip()
    if not t or not _ZAHL.match(t):
        return None
    try:
        if "," in t and "." in t:
            t = t.replace(".", "").replace(",", ".")
        elif "," in t:
            t = t.replace(",", ".")
        return float(t)
    except ValueError:
        return None


natuerlich = gemeinsam.natsort


class Zelle(QTableWidgetItem):
    """QTableWidgetItem, das Zahlen als Zahlen sortiert und Texte natuerlich."""

    def __lt__(self, other):
        a, b = self.text(), other.text()
        za, zb = _zahl(a), _zahl(b)
        if za is not None and zb is not None:
            return za < zb
        if (za is None) != (zb is None):          # Zahlen vor Texten, leere Zellen ans Ende
            if not a.strip():
                return False
            if not b.strip():
                return True
            return za is not None
        return natuerlich(a) < natuerlich(b)

    @classmethod
    def aus(cls, item):
        if isinstance(item, cls):
            return item
        z = cls(item.text())
        z.setForeground(item.foreground())
        z.setBackground(item.background())
        z.setFont(item.font())
        z.setTextAlignment(item.textAlignment())
        if item.toolTip():
            z.setToolTip(item.toolTip())
        for rolle in (Qt.UserRole, Qt.UserRole + 1, Qt.UserRole + 2, ROLLE_INDEX):
            v = item.data(rolle)
            if v is not None:
                z.setData(rolle, v)
        z.setFlags(item.flags())
        return z


class _LayerSlot(object):
    """Verbindung Layerauswahl -> Tabelle; haelt Layer und Schluessel, ueberlebt den Layer nicht."""

    def __init__(self, tab, lyr, schl, lid):
        self.tab, self.lyr, self.schl, self.lid = tab, lyr, schl, lid

    def auswahl(self, *_):
        try:
            self.tab._von_karte(self.lyr, self.schl)
        except RuntimeError:
            self.weg()

    def weg(self, *_):
        try:
            self.tab._verbunden.pop(self.lid, None)
        except Exception:
            pass


class Tabelle(QWidget):
    itemSelectionChanged = pyqtSignal()
    itemDoubleClicked = pyqtSignal(object)
    auswahlGeaendert = itemSelectionChanged

    def __init__(self, schluessel, spalten, iface=None, mehrfach=True, parent=None, karte=True):
        super().__init__(parent)
        self.schluessel = schluessel
        self.iface = iface
        self._spalten = list(spalten)
        self._karte = {}             # Datenindex -> dict(xy, bezug, geometrien)
        self._finder = None
        self._verbunden = {}         # Layer-Id -> Layer (Karte -> Tabelle verbunden)
        self._sperre = 0
        self._fuellt = False
        self._fertig_offen = False
        self._gesamt = 0
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(3)
        # --- Leiste --------------------------------------------------------------------------------------------------------------------
        leiste = QHBoxLayout()
        leiste.setSpacing(6)
        self.suche = QLineEdit()
        self.suche.setPlaceholderText("Filtern ...")
        self.suche.setClearButtonEnabled(True)
        self.suche.setMaximumWidth(220)
        self.suche.setToolTip("Zeilen filtern: Text in irgendeiner sichtbaren Spalte (Gross/Klein egal). Leeren zeigt wieder alle.")
        self.suche.textChanged.connect(self._filter_geaendert)
        leiste.addWidget(self.suche)
        self.k_nur = self._knopf("Nur Auswahl", "Nur die markierten Zeilen zeigen (wie in der QGIS-Attributtabelle)", checkable=True)
        self.k_nur.toggled.connect(self._filter_geaendert)
        leiste.addWidget(self.k_nur)
        self.k_spalten = self._knopf("Spalten", "Spalten ein- und ausblenden; Reihenfolge per Ziehen am Spaltenkopf, Breite am Rand ziehen "
                                                "(Doppelklick auf den Rand = an Inhalt anpassen)")
        self.k_spalten.setPopupMode(QToolButton.InstantPopup)
        self.menue_spalten = QMenu(self)
        self.menue_spalten.aboutToShow.connect(self._spaltenmenue_fuellen)
        self.k_spalten.setMenu(self.menue_spalten)
        leiste.addWidget(self.k_spalten)
        self.k_zoom = self._knopf("Hinzoomen", "Karte auf die markierten Zeilen zoomen und sie aufblinken lassen")
        self.k_zoom.clicked.connect(self.zoom)
        self.k_blink = self._knopf("Blinken", "Markierte Zeilen in der Karte dreimal rot aufblinken lassen, Ausschnitt bleibt")
        self.k_blink.clicked.connect(self.blinken)
        self.k_kopie = self._knopf("Kopieren", "Markierte Zeilen (sonst alle sichtbaren) mit Kopfzeile in die Zwischenablage - fuer Excel (Strg+C)")
        self.k_kopie.clicked.connect(self.kopieren)
        for k in (self.k_zoom, self.k_blink):
            k.setVisible(bool(karte))
        leiste.addWidget(self.k_zoom)
        leiste.addWidget(self.k_blink)
        leiste.addWidget(self.k_kopie)
        self.zaehler = QLabel("")
        self.zaehler.setStyleSheet("color:{}; font-size:11px;".format(ci.GRAU))
        leiste.addWidget(self.zaehler, 1)
        lay.addLayout(leiste)
        # --- Tabelle -------------------------------------------------------------------------------------------------------------------
        self.view = QTableWidget(0, len(self._spalten))
        self.view.setHorizontalHeaderLabels(self._spalten)
        for i, s in enumerate(self._spalten):
            h = self.view.horizontalHeaderItem(i)
            if h is not None:
                h.setToolTip(s)
        self.view.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.view.setSelectionMode(QAbstractItemView.ExtendedSelection if mehrfach else QAbstractItemView.SingleSelection)
        self.view.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.view.verticalHeader().setVisible(False)
        self.view.setAlternatingRowColors(True)
        self.view.setSortingEnabled(True)
        self.view.setWordWrap(False)
        self.view.setStyleSheet("font-size:11px;")
        kopf = self.view.horizontalHeader()
        kopf.setSectionResizeMode(QHeaderView.Interactive)
        kopf.setStretchLastSection(False)
        kopf.setSectionsMovable(True)
        kopf.setSectionsClickable(True)
        kopf.setSortIndicatorShown(True)
        kopf.setMinimumSectionSize(28)
        kopf.setDefaultSectionSize(110)
        kopf.setContextMenuPolicy(Qt.CustomContextMenu)
        kopf.customContextMenuRequested.connect(self._kopf_menue)
        self.view.sortByColumn(-1, Qt.AscendingOrder)
        self.view.itemSelectionChanged.connect(self._auswahl_geaendert)
        self.view.itemDoubleClicked.connect(self.itemDoubleClicked.emit)
        lay.addWidget(self.view, 1)
        QShortcut(QKeySequence.Copy, self.view, activated=self.kopieren, context=Qt.WidgetShortcut)
        self._laden()
        # Merken erst im naechsten Ereignisdurchlauf: saveState() mitten im Sortier-/Resize-Signal stuerzt QGIS ab (Zugriffsverletzung, 12.10.)
        self._merk_timer = QTimer(self)
        self._merk_timer.setSingleShot(True)
        self._merk_timer.setInterval(300)
        self._merk_timer.timeout.connect(self._merken)
        self._auswahl_timer = QTimer(self)
        self._auswahl_timer.setSingleShot(True)
        self._auswahl_timer.setInterval(0)
        self._auswahl_timer.timeout.connect(self._auswahl_verarbeiten)
        # keine Lambdas an Qt-Signalen in dieser Klasse: beim Sortieren stuerzte QGIS mit "line ??? in <lambda>" ab (12.10.2026)
        kopf.sectionResized.connect(self._kopf_geaendert)
        kopf.sectionMoved.connect(self._kopf_geaendert)
        kopf.sortIndicatorChanged.connect(self._kopf_geaendert)
        self._zaehlen()

    def _kopf_geaendert(self, *_):
        self._merk_timer.start()

    def _kopf_menue(self, pos):
        self._spaltenmenue_fuellen()
        self.menue_spalten.exec_(self.view.horizontalHeader().mapToGlobal(pos))

    def _knopf(self, text, tipp, checkable=False):
        k = QToolButton()
        k.setText(text)
        k.setToolTip(tipp)
        k.setCheckable(checkable)
        k.setAutoRaise(True)
        k.setStyleSheet("QToolButton {{ font-size:11px; padding:2px 6px; border:1px solid {g}; border-radius:3px; }} "
                        "QToolButton:checked {{ background:{o}; color:white; }}".format(g=ci.GRAU_HELL, o=ci.ORANGE))
        return k

    # --- Einstellungen merken ----------------------------------------------------------------------------------------------------------
    def _laden(self):
        """Gemerkten Kopf (Breiten, Reihenfolge, ausgeblendete Spalten, Sortierung) zurueckholen. Danach passen die Dialoge die Breiten
        nicht mehr automatisch an den Inhalt an (sonst waeren die gezogenen Breiten bei jedem Fuellen weg)."""
        self._gemerkt = False
        try:
            roh = QSettings().value(EINSTELLUNGEN + self.schluessel + "/kopf")
            if roh is not None and len(roh) and self.view.horizontalHeader().restoreState(roh):
                self._gemerkt = True
        except Exception:
            self._gemerkt = False
        # Sortierung wird erst beim ersten fertig() angewandt (restoreState setzt den Indikator)

    def _abschliessen(self):
        if self._fuellt:
            self.fertig()

    def _merken(self):
        if self._fuellt:
            return
        try:
            QSettings().setValue(EINSTELLUNGEN + self.schluessel + "/kopf", self.view.horizontalHeader().saveState())
            self._gemerkt = True
        except Exception:
            pass

    # --- Fuellen (QTableWidget-Schnittstelle) -------------------------------------------------------------------------------------------
    def beginnen(self):
        if not self._fuellt:
            self._fuellt = True
            self._sperre += 1
            self.view.setSortingEnabled(False)
            self.view.blockSignals(True)
        self._karte = {}
        self.view.setRowCount(0)
        if not self._fertig_offen:
            self._fertig_offen = True
            QTimer.singleShot(0, self._auto_fertig)

    def leeren(self):
        self.beginnen()
        self.fertig()

    def _auto_fertig(self):
        if self._fuellt:
            self.fertig()

    def fertig(self):
        """Fuellen abschliessen: Sortierung an, Tooltips, Filter, Zaehler, Kartenlayer verbinden."""
        self._fertig_offen = False
        if not self._fuellt:
            return
        self._fuellt = False
        for z in range(self.view.rowCount()):
            for s in range(self.view.columnCount()):
                it = self.view.item(z, s)
                if it is None:
                    it = Zelle("")
                    it.setData(ROLLE_INDEX, z)
                    self.view.setItem(z, s, it)
                elif it.data(ROLLE_INDEX) is None:
                    it.setData(ROLLE_INDEX, z)
                if not it.toolTip() and it.text():
                    it.setToolTip(it.text())
        self._gesamt = self.view.rowCount()
        kopf = self.view.horizontalHeader()
        sp, ordnung = kopf.sortIndicatorSection(), kopf.sortIndicatorOrder()
        self.view.setSortingEnabled(True)
        if 0 <= sp < self.view.columnCount():
            self.view.sortItems(sp, ordnung)
        self.view.blockSignals(False)
        self._sperre -= 1
        self._filtern()
        self._layer_verbinden()
        self._zaehlen()

    def setRowCount(self, n):
        if n == 0 or not self._fuellt:
            self.beginnen()
        if n:
            self.view.setRowCount(n)

    def rowCount(self):
        return self.view.rowCount()

    def columnCount(self):
        return self.view.columnCount()

    def insertRow(self, zeile):
        if not self._fuellt:
            self.beginnen()
        self.view.insertRow(zeile)

    def setItem(self, zeile, spalte, item):
        if not self._fuellt:
            self.beginnen()
        z = Zelle.aus(item)
        if z.data(ROLLE_INDEX) is None:
            z.setData(ROLLE_INDEX, zeile)
        self.view.setItem(zeile, spalte, z)

    def item(self, zeile, spalte):
        return self.view.item(zeile, spalte)

    def setHorizontalHeaderLabels(self, namen):
        self._spalten = list(namen)
        self.view.setColumnCount(len(self._spalten))
        self.view.setHorizontalHeaderLabels(self._spalten)
        for i, s in enumerate(self._spalten):
            h = self.view.horizontalHeaderItem(i)
            if h is not None:
                h.setToolTip(s)

    def horizontalHeader(self):
        return self.view.horizontalHeader()

    def selectionModel(self):
        return self.view.selectionModel()

    def resizeColumnToContents(self, s, erzwingen=False):
        """Breite an den Inhalt (hoechstens 420 px) - nur, solange der Planer noch keine eigenen Breiten gezogen hat (sonst blieben sie nie)."""
        if self._gemerkt and not erzwingen:
            return
        self.view.resizeColumnToContents(s)
        if self.view.columnWidth(s) > 420:
            self.view.setColumnWidth(s, 420)

    def resizeColumnsToContents(self, erzwingen=False):
        for s in range(self.view.columnCount()):
            self.resizeColumnToContents(s, erzwingen)

    def breiten_anpassen(self):
        self.resizeColumnsToContents(True)
        self._merken()

    def resizeRowsToContents(self):
        self.view.resizeRowsToContents()

    def columnWidth(self, s):
        return self.view.columnWidth(s)

    def setColumnWidth(self, s, b):
        self.view.setColumnWidth(s, b)

    def setSelectionMode(self, m):
        self.view.setSelectionMode(m)

    def setSelectionBehavior(self, b):
        self.view.setSelectionBehavior(b)

    def setEditTriggers(self, t):
        self.view.setEditTriggers(t)

    def setAlternatingRowColors(self, an):
        self.view.setAlternatingRowColors(an)

    def verticalHeader(self):
        return self.view.verticalHeader()

    def setMinimumHeight(self, h):
        self.view.setMinimumHeight(max(60, h - 30))

    def setMaximumHeight(self, h):
        self.view.setMaximumHeight(max(60, h - 30))

    def setStyleSheet(self, s):
        self.view.setStyleSheet(s)

    def setToolTip(self, t):
        self.view.setToolTip(t)

    def blockSignals(self, an):
        if an:
            self._sperre += 1
        else:
            self._sperre = max(0, self._sperre - 1)
        return super().blockSignals(an)

    def selectedIndexes(self):
        return self.view.selectedIndexes()

    def clearSelection(self):
        self.view.clearSelection()

    def selectRow(self, idx):
        """Zeile mit diesem DATENINDEX markieren (nicht die sichtbare Zeile)."""
        self._abschliessen()
        z = self.zeile_von(idx)
        if z is not None:
            self.view.selectRow(z)
            self.view.scrollToItem(self.view.item(z, 0) or self.view.item(z, self._erste_spalte()))

    # --- Datenindex <-> Zeile -------------------------------------------------------------------------------------------------------------
    def _erste_spalte(self):
        for s in range(self.view.columnCount()):
            if self.view.item(0, s) is not None:
                return s
        return 0

    def index_von_zeile(self, zeile):
        for s in range(self.view.columnCount()):
            it = self.view.item(zeile, s)
            if it is not None:
                v = it.data(ROLLE_INDEX)
                return int(v) if v is not None else zeile
        return zeile

    def zeile_von(self, idx):
        for z in range(self.view.rowCount()):
            if self.index_von_zeile(z) == idx:
                return z
        return None

    def zelle(self, idx, spalte):
        self._abschliessen()
        z = self.zeile_von(idx)
        return None if z is None else self.view.item(z, spalte)

    def auswahl_indizes(self):
        """Datenindizes der markierten Zeilen, in der sichtbaren Reihenfolge."""
        self._abschliessen()
        zeilen = sorted({i.row() for i in self.view.selectedIndexes()})
        return [self.index_von_zeile(z) for z in zeilen]

    def auswahl_zeilen(self):
        return sorted({i.row() for i in self.view.selectedIndexes()})

    def zeilen_waehlen(self, indizes, nur=True):
        self._abschliessen()
        gesucht = set(indizes)
        self._sperre += 1
        try:
            if nur:
                self.view.clearSelection()
            sm = self.view.selectionModel()
            erste = None
            for z in range(self.view.rowCount()):
                if self.index_von_zeile(z) in gesucht:
                    sm.select(self.view.model().index(z, 0), sm.Select | sm.Rows)
                    if erste is None:
                        erste = z
            if erste is not None:
                self.view.scrollToItem(self.view.item(erste, self._erste_spalte()))
        finally:
            self._sperre -= 1
        self._filtern()
        self._zaehlen()
        self.itemSelectionChanged.emit()

    # --- Filter, Spalten, Zaehler ------------------------------------------------------------------------------------------------------
    def _filter_geaendert(self, *_):
        self._filtern()

    def _filtern(self):
        if self._fuellt:
            return
        text = self.suche.text().strip().lower()
        nur = self.k_nur.isChecked()
        gewaehlt = {i.row() for i in self.view.selectedIndexes()} if nur else None
        sichtbar = 0
        for z in range(self.view.rowCount()):
            weg = False
            if nur and z not in gewaehlt:
                weg = True
            elif text:
                treffer = False
                for s in range(self.view.columnCount()):
                    if self.view.isColumnHidden(s):
                        continue
                    it = self.view.item(z, s)
                    if it is not None and text in it.text().lower():
                        treffer = True
                        break
                weg = not treffer
            self.view.setRowHidden(z, weg)
            if not weg:
                sichtbar += 1
        self._sichtbar = sichtbar
        self._zaehlen()

    def _spaltenmenue_fuellen(self):
        m = self.menue_spalten
        m.clear()
        kopf = self.view.horizontalHeader()
        for pos in range(self.view.columnCount()):
            s = kopf.logicalIndex(pos)
            a = m.addAction(self._spalten[s] if s < len(self._spalten) else str(s))
            a.setCheckable(True)
            a.setChecked(not self.view.isColumnHidden(s))
            a.setData(s)
            a.toggled.connect(self._spaltenaktion)
        m.addSeparator()
        m.addAction("Alle Spalten zeigen", self._alle_spalten)
        m.addAction("Breiten an Inhalt anpassen", self.breiten_anpassen)
        m.addAction("Reihenfolge und Sortierung zuruecksetzen", self._zuruecksetzen)

    def _spaltenaktion(self, an):
        a = self.sender()
        if a is not None and a.data() is not None:
            self._spalte_zeigen(int(a.data()), an)

    def _alle_spalten(self):
        for s in range(self.view.columnCount()):
            self._spalte_zeigen(s, True)

    def _spalte_zeigen(self, s, an):
        if not an and sum(1 for i in range(self.view.columnCount()) if not self.view.isColumnHidden(i)) <= 1:
            return      # die letzte Spalte bleibt
        self.view.setColumnHidden(s, not an)
        self._merken()
        self._filtern()

    def _zuruecksetzen(self):
        kopf = self.view.horizontalHeader()
        for pos in range(self.view.columnCount()):
            vis = kopf.visualIndex(pos)
            if vis != pos:
                kopf.moveSection(vis, pos)
        for s in range(self.view.columnCount()):
            self.view.setColumnHidden(s, False)
        self.view.sortByColumn(-1, Qt.AscendingOrder)
        self._gemerkt = False
        self.resizeColumnsToContents()
        self._merken()

    def _zaehlen(self):
        n = self.view.rowCount()
        aus = len({i.row() for i in self.view.selectedIndexes()})
        sichtbar = getattr(self, "_sichtbar", n)
        text = "{} von {} ausgewaehlt".format(aus, n) if n else "keine Zeilen"
        if n and sichtbar != n:
            text += " | Filter: {} sichtbar".format(sichtbar)
        self.zaehler.setText(text)
        for k in (self.k_zoom, self.k_blink):
            k.setEnabled(aus > 0 and bool(self._karte))
        self.k_kopie.setEnabled(n > 0)

    # --- Auswahl und Karte ---------------------------------------------------------------------------------------------------------------
    def _auswahl_geaendert(self):
        # Erst im naechsten Ereignisdurchlauf verarbeiten: waehrend Qt sortiert, aendert sich die Auswahl mehrfach, und selectedIndexes()
        # mitten im Umbau des Modells stuerzt ab (Zugriffsverletzung, 12.10.2026). Mehrere Aenderungen fallen zu einer zusammen.
        if self._fuellt:
            return
        if not self._auswahl_timer.isActive():
            self._auswahl_timer.start()

    def _auswahl_verarbeiten(self):
        if self._fuellt:
            return
        self._zaehlen()
        if self._sperre == 0:
            self._nach_karte()
            self.itemSelectionChanged.emit()

    def karte_setzen(self, idx, xy=None, bezug=None, geometrien=None):
        """Kartenbezug einer Zeile (Datenindex). xy: (x, y) oder Liste davon in EPSG:25832. bezug: (layerschluessel, {feld: wert|[werte]})."""
        if xy is not None and xy and not isinstance(xy[0], (list, tuple)):
            xy = [xy]
        self._karte[idx] = {"xy": [p for p in (xy or []) if p is not None], "bezug": bezug, "geometrien": list(geometrien or [])}

    def layer_finder(self, fn):
        """fn(layerschluessel) -> QgsVectorLayer oder None; wird bei jedem Zugriff gerufen (Layer werden neu angelegt)."""
        self._finder = fn

    def _layer(self, schl):
        if self._finder is None:
            return None
        try:
            return self._finder(schl)
        except Exception:
            return None

    def _bezuege(self, indizes=None):
        """-> {layerschluessel: [(idx, {feld: werte})]}"""
        out = {}
        for idx, k in self._karte.items():
            if indizes is not None and idx not in indizes:
                continue
            b = k.get("bezug")
            if not b:
                continue
            out.setdefault(b[0], []).append((idx, b[1]))
        return out

    @staticmethod
    def _ausdruck(felder_liste):
        """Liste von {feld: wert|[werte]} -> QGIS-Ausdruck (ODER-verknuepft)."""
        teile = []
        for felder in felder_liste:
            und = []
            for feld, wert in felder.items():
                werte = wert if isinstance(wert, (list, tuple, set)) else [wert]
                werte = [str(w).replace("'", "''") for w in werte if w is not None and str(w) != ""]
                if not werte:
                    continue
                und.append("\"{}\" IN ({})".format(feld, ", ".join("'{}'".format(w) for w in werte)))
            if und:
                teile.append("(" + " AND ".join(und) + ")")
        return " OR ".join(teile)

    def _nach_karte(self):
        """Zeilenauswahl -> Layerauswahl (nur Layer, die Zeilen dieser Tabelle kennen)."""
        if not self._karte:
            return
        aus = set(self.auswahl_indizes())
        alle = self._bezuege()
        for schl, zeilen in alle.items():
            lyr = self._layer(schl)
            if lyr is None:
                continue
            ausdruck = self._ausdruck([f for idx, f in zeilen if idx in aus])
            self._sperre += 1
            try:
                if ausdruck:
                    lyr.selectByExpression(ausdruck)
                else:
                    lyr.removeSelection()
            except Exception:
                pass
            finally:
                self._sperre -= 1

    def _layer_verbinden(self):
        for schl in self._bezuege():
            lyr = self._layer(schl)
            if lyr is None:
                continue
            try:
                lid = lyr.id()
            except Exception:
                continue
            if lid in self._verbunden:
                continue
            slot = _LayerSlot(self, lyr, schl, lid)
            self._verbunden[lid] = slot        # Referenz halten, sonst wird der Slot eingesammelt
            try:
                lyr.selectionChanged.connect(slot.auswahl)
                lyr.willBeDeleted.connect(slot.weg)
            except Exception:
                pass

    def _von_karte(self, lyr, schl):
        """Layerauswahl -> Zeilen markieren (nur, wenn sich dadurch etwas aendert; sonst Schleife mit den Dialog-Handlern)."""
        if self._sperre or self._fuellt:
            return
        try:
            feats = lyr.selectedFeatures()
        except Exception:
            return
        zeilen = self._bezuege().get(schl, [])
        if not zeilen:
            return
        felder = sorted({f for _, d in zeilen for f in d.keys()})
        werte = set()
        for f in feats:
            try:
                werte.add(tuple(str(f[k]) if f[k] is not None else "" for k in felder))
            except Exception:
                continue
        treffer = set()
        for idx, d in zeilen:
            kombis = [()]
            for k in felder:
                w = d.get(k)
                ws = [str(x) for x in (w if isinstance(w, (list, tuple, set)) else [w]) if x is not None]
                kombis = [kb + (x,) for kb in kombis for x in (ws or [""])]
            if any(kb in werte for kb in kombis):
                treffer.add(idx)
        if treffer == set(self.auswahl_indizes()) & {idx for idx, _ in zeilen}:
            return
        # Zeilen anderer Layer bleiben, wie sie sind
        andere = {i for i in self.auswahl_indizes() if i not in {idx for idx, _ in zeilen}}
        self.zeilen_waehlen(treffer | andere, nur=True)

    def _geometrien(self, indizes):
        """Geometrien (EPSG:25832) der Zeilen: Kartenbezug aus den Layern, sonst Koordinaten."""
        geome = []
        gedeckt = set()          # Zeilen, deren Kartenbezug Geometrien geliefert hat - deren Koordinaten nicht noch einmal
        crs = QgsCoordinateReferenceSystem(CRS_DATEN)
        for schl, zeilen in self._bezuege(set(indizes)).items():
            lyr = self._layer(schl)
            if lyr is None:
                continue
            ausdruck = self._ausdruck([f for _, f in zeilen])
            if not ausdruck:
                continue
            try:
                from qgis.core import QgsFeatureRequest
                ct = QgsCoordinateTransform(lyr.crs(), crs, QgsProject.instance())
                n0 = len(geome)
                for f in lyr.getFeatures(QgsFeatureRequest().setFilterExpression(ausdruck)):
                    g = f.geometry()
                    if g is not None and not g.isEmpty():
                        g = QgsGeometry(g)
                        g.transform(ct)
                        geome.append(g)
                if len(geome) > n0:
                    gedeckt.update(idx for idx, _ in zeilen)
            except Exception:
                pass
        for idx in indizes:
            k = self._karte.get(idx)
            if not k or idx in gedeckt:
                continue
            for x, y in k["xy"]:
                geome.append(QgsGeometry.fromPointXY(QgsPointXY(float(x), float(y))))
            geome.extend(QgsGeometry(g) for g in k["geometrien"])
        return geome

    def zoom(self):
        if self.iface is None:
            return
        geome = self._geometrien(self.auswahl_indizes())
        if not geome:
            return
        try:
            canvas = self.iface.mapCanvas()
            kasten = QgsRectangle()
            for g in geome:
                kasten.combineExtentWith(g.boundingBox())
            rand = max(25.0, 0.15 * max(kasten.width(), kasten.height()))
            kasten.grow(rand)
            ct = QgsCoordinateTransform(QgsCoordinateReferenceSystem(CRS_DATEN), canvas.mapSettings().destinationCrs(), QgsProject.instance())
            canvas.setExtent(ct.transformBoundingBox(kasten))
            canvas.refresh()
            canvas.flashGeometries(geome, QgsCoordinateReferenceSystem(CRS_DATEN), QColor("#C62828"), QColor(198, 40, 40, 0), 3, 600)
        except Exception:
            pass

    def blinken(self):
        if self.iface is None:
            return
        geome = self._geometrien(self.auswahl_indizes())
        if not geome:
            return
        try:
            self.iface.mapCanvas().flashGeometries(geome, QgsCoordinateReferenceSystem(CRS_DATEN), QColor("#C62828"), QColor(198, 40, 40, 0), 3, 600)
        except Exception:
            pass

    # --- Zwischenablage ---------------------------------------------------------------------------------------------------------------------
    def text_tabelle(self, nur_auswahl=True):
        kopf = self.view.horizontalHeader()
        spalten = [kopf.logicalIndex(p) for p in range(self.view.columnCount())]
        spalten = [s for s in spalten if not self.view.isColumnHidden(s)]
        zeilen = self.auswahl_zeilen() if nur_auswahl else []
        if not zeilen:
            zeilen = [z for z in range(self.view.rowCount()) if not self.view.isRowHidden(z)]
        out = ["\t".join(self._spalten[s] if s < len(self._spalten) else "" for s in spalten)]
        for z in zeilen:
            out.append("\t".join((self.view.item(z, s).text() if self.view.item(z, s) is not None else "").replace("\t", " ").replace("\n", " ")
                                 for s in spalten))
        return "\n".join(out)

    def kopieren(self):
        try:
            QApplication.clipboard().setText(self.text_tabelle(True))
        except Exception:
            pass
