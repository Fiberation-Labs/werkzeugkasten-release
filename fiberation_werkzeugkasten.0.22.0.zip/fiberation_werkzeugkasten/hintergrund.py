# -*- coding: utf-8 -*-
"""Lange Kernlaeufe (ALKIS-WFS, Overpass, Rechnen) in einem eigenen Prozess, damit QGIS bedienbar bleibt und Abbrechen greift
(Markus 12.10.2026, Punkt 5: Netzabrufe aus dem Hauptfenster).

Warum ein Prozess und kein Thread: pyproj/GeoPandas im QgsTask-Thread stuerzen ab, sobald QGIS im Hauptthread gleichzeitig PROJ nutzt
(Zugriffsverletzung in pyproj CRS.__init__, 12.10.2026 im Test reproduziert). Ein Kindprozess mit demselben QGIS-Python ist davon frei,
isoliert Abstuerze und laesst sich hart abbrechen.

starten(dialog, beschreibung, modul, funktion, args, kwargs, fertig):
  ruft im Kindprozess fiberation_werkzeugkasten.<modul>.<funktion>(*args, log=..., fortschritt=..., **kwargs). Argumente muessen JSON-faehig
  sein (Pfade, Zahlen, Listen, dicts). Das Ergebnis geht durch <funktion>_zusammenfassung(r) (oder lauf_zusammenfassung) des Moduls - ein
  JSON-faehiges dict mit dem, was der Dialog braucht (Pfade, Zahlen). log/fortschritt kommen zeilenweise zurueck und landen in
  dialog._log / dialog._fortschritt. fertig(ergebnis, fehler, rueckverfolgung) laeuft im Hauptthread.
abbrechen(dialog) beendet den Kindprozess. laeuft(dialog) / warten(dialog) fuer Tests."""
import json
import os
import sys
import tempfile

from qgis.core import QgsApplication
from qgis.PyQt.QtCore import QProcess, QProcessEnvironment

PAKET = os.path.dirname(os.path.abspath(__file__))


class Abgebrochen(Exception):
    pass


def python():
    """Das QGIS-Python fuer den Kindprozess: python-qgis(-ltr).bat neben QGIS, sonst sys.executable (Tests laufen schon darunter)."""
    if os.path.basename(sys.executable).lower().startswith("python"):
        return [sys.executable]
    try:
        prefix = QgsApplication.prefixPath()                     # .../apps/qgis-ltr
        bin_ = os.path.normpath(os.path.join(prefix, "..", "..", "bin"))
        for name in ("python-qgis-ltr.bat", "python-qgis.bat"):
            p = os.path.join(bin_, name)
            if os.path.exists(p):
                return ["cmd", "/c", p]
    except Exception:
        pass
    return [sys.executable]


def starten(dialog, beschreibung, modul, funktion, args, kwargs, fertig):
    ordner = tempfile.mkdtemp(prefix="werkzeugkasten_")
    spec = {"pfad": os.path.dirname(PAKET), "modul": "fiberation_werkzeugkasten." + modul, "funktion": funktion, "args": list(args or []),
            "kwargs": dict(kwargs or {}), "ergebnis": os.path.join(ordner, "ergebnis.json")}
    spec_pfad = os.path.join(ordner, "auftrag.json")
    with open(spec_pfad, "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, default=str)
    proz = QProcess(dialog)
    env = QProcessEnvironment.systemEnvironment()
    env.insert("PYTHONIOENCODING", "utf-8")
    env.insert("PYTHONUNBUFFERED", "1")
    env.insert("QT_QPA_PLATFORM", "offscreen")
    proz.setProcessEnvironment(env)
    proz.setProcessChannelMode(QProcess.MergedChannels)
    rest = {"puffer": b"", "abgebrochen": False}

    def lesen():
        rest["puffer"] += bytes(proz.readAllStandardOutput())
        while b"\n" in rest["puffer"]:
            zeile, rest["puffer"] = rest["puffer"].split(b"\n", 1)
            z = zeile.decode("utf-8", "replace").rstrip("\r")
            if z.startswith("LOG "):
                dialog._log(z[4:])
            elif z.startswith("FORTSCHRITT "):
                p, _, t = z[12:].partition("|")
                try:
                    dialog._fortschritt(float(p), t)
                except Exception:
                    pass
            elif z.startswith(("FERTIG", "FEHLER")):
                pass
            elif z.strip():
                dialog._log("  " + z)

    def ende(code, status):
        lesen()
        dialog._prozess = None
        erg = None
        try:
            with open(spec["ergebnis"], encoding="utf-8") as f:
                erg = json.load(f)
        except Exception:
            erg = None
        try:
            import shutil
            shutil.rmtree(ordner, ignore_errors=True)
        except Exception:
            pass
        if rest["abgebrochen"]:
            fertig(None, Abgebrochen("abgebrochen"), "")
        elif erg is None:
            fertig(None, RuntimeError("Hintergrundlauf ohne Ergebnis (Exit {}) - Einzelheiten im Protokoll".format(code)), "")
        elif "fehler" in erg:
            fertig(None, RuntimeError(erg["fehler"]), erg.get("rueckverfolgung", ""))
        else:
            fertig(erg, None, "")

    proz.readyReadStandardOutput.connect(lesen)
    proz.finished.connect(ende)
    dialog._prozess = proz
    dialog._prozess_abbruch = rest
    befehl = python()
    proz.start(befehl[0], befehl[1:] + [os.path.join(PAKET, "hintergrund_lauf.py"), spec_pfad])
    dialog._log("{} - laeuft im Hintergrund, QGIS bleibt bedienbar.".format(beschreibung))
    return proz


def abbrechen(dialog):
    """Laufenden Kindprozess beenden; der OSM-Abruf im eigenen Prozess bekommt sein Abbruchsignal."""
    try:
        from .werkzeuge.cluster import osm
        osm.abbrechen()
    except Exception:
        pass
    p = getattr(dialog, "_prozess", None)
    if p is not None:
        try:
            getattr(dialog, "_prozess_abbruch", {})["abgebrochen"] = True
            p.kill()
        except Exception:
            pass


def laeuft(dialog):
    p = getattr(dialog, "_prozess", None)
    try:
        return p is not None and p.state() != QProcess.NotRunning
    except Exception:
        return False


def warten(dialog, sekunden=600):
    """Nur fuer Tests: Ereignisschleife treiben, bis der Kindprozess fertig ist."""
    import time
    from qgis.PyQt.QtWidgets import QApplication
    t0 = time.time()
    while laeuft(dialog) and time.time() - t0 < sekunden:
        QApplication.processEvents()
        time.sleep(0.02)
    for _ in range(5):
        QApplication.processEvents()
